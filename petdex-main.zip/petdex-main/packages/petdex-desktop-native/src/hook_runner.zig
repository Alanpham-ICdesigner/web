//! petdex-hook: the bubble runner living INSIDE the app binary.
//!
//! Agent hooks invoke `petdex-hook bubble <phase> <agent>` (a stable
//! symlink to this binary) with the hook payload on stdin. This is the
//! hot path — it runs 20-50 times per active session — so it must cost
//! native-binary startup, not a node cold start, and it must never
//! stain the agent: every failure exits 0 silently.
//!
//! A line-for-line port of the CLI's bubble-runner.ts + templates
//! (kept in parity by the tests at the bottom, which mirror the TS
//! suite's expectations). Extraction uses the hook server's flat JSON scan:
//! hook payloads never repeat our keys across nesting levels.

const std = @import("std");
const hook_server = @import("hook_server.zig");
const plat = @import("plat.zig");

const jsonString = hook_server.jsonStringPub;

const stdin_cap = 64 * 1024;
const title_max = 60;
const preview_max = 110;
const transcript_tail_cap = 64 * 1024;
const session_ttl_secs: i64 = 24 * 60 * 60;
const post_timeout_ms: u64 = 300;
const post_poll_ms: u64 = 5;

// ------------------------------------------------------------- entry

/// argv tail after "bubble": [phase, agent?]. Reads stdin, formats,
/// POSTs bubble + state to the in-process hook server. Never fails outward.
pub fn run(phase: []const u8, arg_agent: ?[]const u8, origin_app: plat.OriginApplication, source_cwd_raw: ?[]const u8, herdr_pane_raw: ?[]const u8, home: []const u8) void {
    // Always finish consuming the host's payload before any early return.
    // The host may still be writing after the useful 64 KiB prefix, and
    // closing the read end early propagates EPIPE/Broken pipe to the agent.
    var stdin_buf: [stdin_cap]u8 = undefined;
    const payload = readStdin(&stdin_buf);

    var path_buf: [512]u8 = undefined;
    var probe: [1]u8 = undefined;

    // Killswitch remains a cheap no-op after the mandatory stdin drain.
    if (std.fmt.bufPrint(&path_buf, "{s}/.petdex/runtime/hooks-disabled", .{home})) |ks| {
        if (cReadFile(ks, &probe) != null) return;
    } else |_| {}

    var token_buf: [128]u8 = undefined;
    const token_raw = blk: {
        const tp = std.fmt.bufPrint(&path_buf, "{s}/.petdex/runtime/update-token", .{home}) catch break :blk null;
        break :blk cReadFile(tp, &token_buf);
    } orelse return;
    const token = std.mem.trim(u8, token_raw, " \t\r\n");
    if (token.len == 0) return;

    const agent = resolveAgent(payload, arg_agent);

    // A Hermes background-review fork is internal machinery, not a session:
    // drop it before it can seed a title, move the pet, or open a card. The
    // stdin drain above is already complete, so returning here is safe.
    if (std.mem.eql(u8, agent, "hermes") and isBackgroundReview(payload)) return;

    const source_app = origin_app.wireName();
    var tty_buf: [64]u8 = undefined;
    const source_tty = if (origin_app == .terminal) (plat.controllingTty(&tty_buf) orelse "") else "";
    const source_cwd = plat.safeSourceCwd(source_cwd_raw) orelse "";
    const herdr_pane = plat.safeHerdrPaneId(herdr_pane_raw) orelse "";
    var session_hash_buf: [64]u8 = undefined;
    const session_id = payloadSessionId(payload, &session_hash_buf);

    // Session title: user-prompt seeds it, every event attaches it.
    var sessions_buf: [512]u8 = undefined;
    const sessions_dir = std.fmt.bufPrint(&sessions_buf, "{s}/.petdex/runtime/sessions", .{home}) catch return;
    if (session_id) |sid| {
        if (isPromptPhase(phase)) {
            if (jsonString(payload, "prompt") orelse jsonString(payload, "user_message")) |prompt| rememberTitle(sessions_dir, sid, prompt);
        }
    }
    var title_buf: [256]u8 = undefined;
    const title: []const u8 = jsonString(payload, "petdex_session_title") orelse if (session_id) |sid| (readTitle(sessions_dir, sid, &title_buf) orelse "") else "";

    var text_buf: [256]u8 = undefined;
    var text = formatBubble(phase, payload, &text_buf) orelse "";

    var preview_buf: [512]u8 = undefined;
    var tail_buf: [transcript_tail_cap]u8 = undefined;
    if (isStopPhase(phase) or isAssistantPhase(phase) or isSubagentStopPhase(phase)) {
        // Close-of-turn preview: Codex ships last_assistant_message in
        // the payload; Claude Code needs the bounded transcript tail.
        const written: ?[]const u8 = if (isAssistantPhase(phase))
            jsonString(payload, "assistant_response")
        else if (isSubagentStopPhase(phase))
            jsonString(payload, "child_summary")
        else
            jsonString(payload, "last_assistant_message") orelse blk: {
                const tp = jsonString(payload, "transcript_path") orelse break :blk null;
                const tail = cReadTail(tp, &tail_buf) orelse break :blk null;
                break :blk lastAssistantFromTail(tail);
            };
        if (written) |w| {
            if (clipEscaped(w, preview_max, &preview_buf)) |p| {
                if (p.len > 0) text = p;
            }
        }
        if (!isSubagentStopPhase(phase)) pruneSessions(sessions_dir);
    }

    // A failed tool does not end the turn — the agent reacts to the error and
    // keeps working — so the bubble keeps its spinner, same as `post`.
    const busy = isPromptPhase(phase) or std.mem.eql(u8, phase, "pre") or
        std.mem.eql(u8, phase, "post") or isToolFailurePhase(phase) or
        std.mem.eql(u8, phase, "approval-response") or std.mem.eql(u8, phase, "subagent-start");
    const state = stateForEvent(phase, jsonString(payload, "tool_name"));

    var posts: [2]PostJob = undefined;
    var post_count: usize = 0;
    var body_buf: [1536]u8 = undefined;
    if (text.len > 0) {
        const body = bubbleBodyWithMetadata(&body_buf, text, title, busy, agent, session_id, source_app, source_tty, source_cwd, herdr_pane, state);
        if (body) |b| {
            if (startPost("/bubble", b, token)) |post| {
                posts[post_count] = post;
                post_count += 1;
            }
        }
    }
    if (state) |s| {
        const duration_ms: u32 = if (isToolFailurePhase(phase)) failed_duration_ms else 0;
        const body = stateBody(&body_buf, s, duration_ms, agent);
        if (body) |b| {
            if (startPost("/state", b, token)) |post| {
                posts[post_count] = post;
                post_count += 1;
            }
        }
    }
    waitForPosts(posts[0..post_count]);
}

/// The hook command identifies the agent that actually invoked this runner.
/// Prefer that explicit argument over payload metadata, which may be nested,
/// copied from another integration, or supplied by an agent subprocess.
fn resolveAgent(payload: []const u8, arg_agent: ?[]const u8) []const u8 {
    if (arg_agent) |agent| {
        if (agent.len > 0) return agent;
    }
    return jsonString(payload, "agent_source") orelse "";
}

/// Review prompts Hermes' `agent/background_review.py` feeds its post-turn
/// fork, verbatim (the module's `_MEMORY_REVIEW_PROMPT` / `_SKILL_REVIEW_PROMPT`
/// / `_COMBINED_REVIEW_PROMPT`). The fork runs its prompt through the ordinary
/// `pre_llm_call` path, so the prompt arrives as this runner's `user_message`.
const background_review_prompts = [_][]const u8{
    "Review the conversation above and update the skill library",
    "Review the conversation above and consider saving to memory",
    "Review the conversation above and update two things",
};

/// True when a Hermes payload comes from a background-review fork rather than a
/// user turn. The fork is internal machinery: it shares the parent's session id
/// and fires the same lifecycle hooks as a real turn, so without this filter its
/// own review prompt becomes a session title (and the fork's events keep the
/// parent card busy long after the user's turn ended).
///
/// Two independent marks, either one decisive:
///   * the payload carries one of the fork's review prompts; or
///   * it names itself as its own parent — how a fork that reuses the parent
///     session id appears (`build_cache_parity_fork` sets `session_id` and
///     `_parent_session_id` to the same value, which no real session does).
/// The second mark also covers the fork's later hooks (post_llm_call,
/// approvals) that carry no prompt at all, and the first still catches a fork
/// that Hermes someday gives a session id of its own.
pub fn isBackgroundReview(payload: []const u8) bool {
    if (jsonString(payload, "user_message") orelse jsonString(payload, "prompt")) |message| {
        const trimmed = std.mem.trimStart(u8, message, " \t\r\n");
        for (background_review_prompts) |prompt| {
            if (std.mem.startsWith(u8, trimmed, prompt)) return true;
        }
    }
    const session = jsonString(payload, "session_id") orelse return false;
    if (session.len == 0) return false;
    const parent = jsonString(payload, "parent_session_id") orelse return false;
    return std.mem.eql(u8, session, parent);
}

fn isPromptPhase(phase: []const u8) bool {
    return std.mem.eql(u8, phase, "user-prompt") or std.mem.eql(u8, phase, "session-start");
}

fn isStopPhase(phase: []const u8) bool {
    return std.mem.eql(u8, phase, "stop") or std.mem.eql(u8, phase, "session-end");
}

fn isAssistantPhase(phase: []const u8) bool {
    return std.mem.eql(u8, phase, "assistant");
}

fn isSubagentStopPhase(phase: []const u8) bool {
    return std.mem.eql(u8, phase, "subagent-stop");
}

fn isToolFailurePhase(phase: []const u8) bool {
    return std.mem.eql(u8, phase, "tool-failure");
}

/// The /bubble request body, extracted and pure for the same reason stateBody
/// is: `run()` reaches stdin, the token file and a socket, so a body built
/// inline there cannot be reached from `zig test`.
///
/// `session_id` is what lets the desktop hold one bubble per conversation
/// instead of one globally. Omitted rather than sent empty when absent, so a
/// payload without a session keeps landing on the server's single-bubble key
/// and renders exactly what shipped before per-conversation bubbles.
///
/// Title and session are optional fragments in ONE format string rather than a
/// separate string per combination: the two divergent bodies this replaces are
/// precisely how session_id got parsed, used for titles, and then left out of
/// the POST that needed it.
pub fn bubbleBody(out: []u8, text: []const u8, title: []const u8, busy: bool, agent: []const u8, session_id: ?[]const u8) ?[]const u8 {
    return bubbleBodyWithMetadata(out, text, title, busy, agent, session_id, "", "", "", "", null);
}

/// `agent_state` carries what this one session is doing to the bubble the
/// desktop keys by session. The same value already goes to /state, but
/// that endpoint aggregates: with several agents live it can only show
/// one. The flock renders a body per session, so the rich states the
/// hooks already compute (failed, review, waiting) have to travel here to
/// survive. Senders that pass null keep the previous body byte for byte.
pub fn bubbleBodyWithMetadata(out: []u8, text: []const u8, title: []const u8, busy: bool, agent: []const u8, session_id: ?[]const u8, source_app: []const u8, source_tty: []const u8, source_cwd: []const u8, herdr_pane: []const u8, agent_state: ?[]const u8) ?[]const u8 {
    var title_buf: [256]u8 = undefined;
    const title_part: []const u8 = if (title.len > 0)
        (std.fmt.bufPrint(&title_buf, ",\"title\":\"{s}\"", .{title}) catch return null)
    else
        "";
    var session_buf: [96]u8 = undefined;
    const session_part: []const u8 = if (session_id) |sid|
        (std.fmt.bufPrint(&session_buf, ",\"session_id\":\"{s}\"", .{sid}) catch return null)
    else
        "";
    var metadata_buf: [800]u8 = undefined;
    const metadata = if (source_app.len > 0 or source_tty.len > 0 or source_cwd.len > 0 or herdr_pane.len > 0)
        (std.fmt.bufPrint(&metadata_buf, ",\"source_app\":\"{s}\",\"source_tty\":\"{s}\",\"source_cwd\":\"{s}\",\"herdr_pane_id\":\"{s}\"", .{ source_app, source_tty, source_cwd, herdr_pane }) catch return null)
    else
        "";
    var state_buf: [48]u8 = undefined;
    const state_part: []const u8 = if (agent_state) |st|
        (std.fmt.bufPrint(&state_buf, ",\"agent_state\":\"{s}\"", .{st}) catch return null)
    else
        "";
    return std.fmt.bufPrint(out, "{{\"text\":\"{s}\"{s},\"busy\":{},\"agent_source\":\"{s}\"{s}{s}{s}}}", .{ text, title_part, busy, agent, session_part, metadata, state_part }) catch null;
}

/// The /state request body. Extracted and pure for one reason: `run()` reaches
/// stdin, the token file and a socket, so a body built inline there is
/// unreachable from `zig test`. One format string with an optional fragment
/// means duration_ms == 0 provably renders exactly what shipped before this
/// phase existed — byte-identity for every other agent is structural, not a
/// promise someone has to keep across future edits.
pub fn stateBody(out: []u8, state: []const u8, duration_ms: u32, agent: []const u8) ?[]const u8 {
    var dur_buf: [24]u8 = undefined;
    const dur: []const u8 = if (duration_ms > 0)
        (std.fmt.bufPrint(&dur_buf, ",\"duration\":{d}", .{duration_ms}) catch return null)
    else
        "";
    return std.fmt.bufPrint(out, "{{\"state\":\"{s}\"{s},\"agent_source\":\"{s}\"}}", .{ state, dur, agent }) catch null;
}

// ------------------------------------------------------- state mapping

/// `failed` is a duration state (main.zig isDurationState), so it reverts to
/// idle once its dwell expires — and dwellFor(.failed, 0) yields only the 250ms
/// floor against a 1220ms animation, about two of eight frames. The tool-failure
/// POST therefore carries an explicit duration. 1220 is `failed`'s durationMs in
/// src/lib/pet-states.ts, not a magic number.
pub const failed_duration_ms: u32 = 1220;

/// Port of stateForEvent: phase + tool → sprite state.
pub fn stateForEvent(phase: []const u8, tool_name: ?[]const u8) ?[]const u8 {
    if (std.mem.eql(u8, phase, "pre")) {
        if (tool_name) |name| {
            if (asciiEqlLower(name, "read") or asciiEqlLower(name, "grep") or asciiEqlLower(name, "glob")) return "review";
        }
        return "running";
    }
    if (std.mem.eql(u8, phase, "post")) return "idle";
    if (isToolFailurePhase(phase)) return "failed";
    if (isStopPhase(phase)) return "waving";
    if (isAssistantPhase(phase)) return "waving";
    if (isPromptPhase(phase)) return "jumping";
    if (std.mem.eql(u8, phase, "waiting") or std.mem.eql(u8, phase, "notification") or std.mem.eql(u8, phase, "approval-request")) return "waiting";
    if (std.mem.eql(u8, phase, "approval-response") or std.mem.eql(u8, phase, "subagent-start")) return "running";
    if (isSubagentStopPhase(phase)) return "idle";
    return null;
}

// ---------------------------------------------------------- templates

/// Port of formatBubble. Writes into `out`, returns the rendered text
/// (raw JSON-escaped content passes through untouched so it can be
/// re-embedded into the POST body).
pub fn formatBubble(phase: []const u8, payload: []const u8, out: []u8) ?[]const u8 {
    if (isPromptPhase(phase)) return "Thinking…";
    if (isStopPhase(phase)) return "Done.";
    if (isAssistantPhase(phase)) return "Done.";
    if (std.mem.eql(u8, phase, "waiting") or std.mem.eql(u8, phase, "notification")) return "Waiting for you…";
    if (std.mem.eql(u8, phase, "approval-request")) return "Waiting for approval…";
    if (std.mem.eql(u8, phase, "approval-response")) return "Approval received";
    if (std.mem.eql(u8, phase, "subagent-start")) return "Subagent working…";
    if (isSubagentStopPhase(phase)) return "Subagent done";
    // Tool name only, never the payload's `error` string. jsonString stops at
    // the first `"` or `\` and decodes neither, and error text routinely carries
    // both; tool_name is a controlled identifier from the agent's own registry.
    if (isToolFailurePhase(phase)) {
        const failed_tool = jsonString(payload, "tool_name") orelse return "Tool failed";
        return fmt2(out, clipRaw(failed_tool, 28), " failed");
    }

    const running = std.mem.eql(u8, phase, "pre");
    const done = std.mem.eql(u8, phase, "post");
    if (!running and !done) return null;

    const tool = jsonString(payload, "tool_name") orelse "tool";

    if (asciiEqlLower(tool, "read")) {
        if (pathField(payload)) |p| return fmt2(out, if (done) "Read " else "Reading ", clipBase(p, 40));
        return if (done) "Read file" else "Reading file";
    }
    if (asciiEqlLower(tool, "edit") or asciiEqlLower(tool, "multiedit") or asciiEqlLower(tool, "write")) {
        if (pathField(payload)) |p| return fmt2(out, if (done) "Edited " else "Editing ", clipBase(p, 40));
        return if (done) "Edited file" else "Editing file";
    }
    if (asciiEqlLower(tool, "bash") or asciiEqlLower(tool, "shell")) {
        if (jsonString(payload, "description")) |d| {
            var clip_buf: [200]u8 = undefined;
            if (clipEscaped(d, 40, &clip_buf)) |c| {
                if (c.len > 0) return fmt2(out, "", c);
            }
        }
        if (jsonString(payload, "command")) |cmd| {
            const head = firstWord(cmd, 24);
            if (head.len > 0) return fmt2(out, if (done) "Ran " else "Running ", head);
        }
        return if (done) "Ran command" else "Running command";
    }
    if (asciiEqlLower(tool, "grep")) {
        // Curly quotes, not ASCII ones: the bubble text is embedded raw
        // into the POST body and read back out by hook_server's scanner,
        // and neither step decodes escapes. A bare `"` closed the JSON
        // string early and the pattern never reached the bubble; an
        // escaped `\"` fares no better, since the reader stops at the
        // backslash too.
        if (jsonString(payload, "pattern")) |p| return fmt3(out, if (done) "Searched “" else "Searching “", clipRaw(p, 28), "”");
        return if (done) "Searched files" else "Searching files";
    }
    if (asciiEqlLower(tool, "glob")) {
        if (jsonString(payload, "pattern")) |p| return fmt2(out, if (done) "Listed " else "Listing ", clipRaw(p, 28));
        return if (done) "Listed files" else "Listing files";
    }
    if (asciiEqlLower(tool, "webfetch") or asciiEqlLower(tool, "websearch")) {
        if (jsonString(payload, "url")) |u| {
            if (hostOf(u)) |h| return fmt2(out, if (done) "Fetched " else "Fetching ", clipRaw(h, 28));
        }
        return if (done) "Fetched web" else "Searching web";
    }
    if (asciiEqlLower(tool, "task") or asciiEqlLower(tool, "agent")) {
        if (done) return "Subagent done";
        if (jsonString(payload, "description") orelse jsonString(payload, "subject")) |d| return fmt2(out, "Spawning ", clipRaw(d, 28));
        return "Spawning subagent";
    }
    return fmt2(out, if (done) "Called " else "Calling ", clipRaw(tool, 28));
}

fn pathField(payload: []const u8) ?[]const u8 {
    return jsonString(payload, "file_path") orelse jsonString(payload, "path");
}

fn fmt2(out: []u8, prefix: []const u8, rest: []const u8) ?[]const u8 {
    return std.fmt.bufPrint(out, "{s}{s}", .{ prefix, rest }) catch null;
}

fn fmt3(out: []u8, prefix: []const u8, mid: []const u8, suffix: []const u8) ?[]const u8 {
    return std.fmt.bufPrint(out, "{s}{s}{s}", .{ prefix, mid, suffix }) catch null;
}

/// basename + clip to `max` (raw clip; paths have no JSON escapes
/// worth preserving beyond the boundary rule handled by clipRaw).
fn clipBase(path: []const u8, max: usize) []const u8 {
    var base = path;
    if (std.mem.lastIndexOfAny(u8, path, "/\\")) |i| base = path[i + 1 ..];
    return clipRaw(base, max);
}

/// Clip WITHOUT an ellipsis marker, on a safe boundary: never mid
/// UTF-8 sequence, never splitting a JSON escape.
fn clipRaw(text: []const u8, max: usize) []const u8 {
    if (text.len <= max) return text;
    return text[0..safeBoundary(text, max)];
}

/// Escaped-content-aware flatten+clip into `buf`: JSON escape
/// sequences for whitespace (\n, \t, \r) become spaces, runs of
/// spaces collapse, and the cut lands on a safe boundary.
pub fn clipEscaped(text: []const u8, max: usize, buf: []u8) ?[]const u8 {
    var w: usize = 0;
    var i: usize = 0;
    var last_space = true;
    while (i < text.len and w < buf.len) {
        var ch = text[i];
        var advance: usize = 1;
        if (ch == '\\' and i + 1 < text.len) {
            const esc = text[i + 1];
            if (esc == 'n' or esc == 't' or esc == 'r') {
                ch = ' ';
                advance = 2;
            } else {
                // Any other escape passes through whole.
                if (w + 2 > buf.len) break;
                buf[w] = '\\';
                buf[w + 1] = esc;
                w += 2;
                i += 2;
                last_space = false;
                continue;
            }
        }
        if (ch == ' ' or ch == '\t') {
            if (!last_space) {
                buf[w] = ' ';
                w += 1;
            }
            last_space = true;
        } else {
            buf[w] = ch;
            w += 1;
            last_space = false;
        }
        i += advance;
    }
    var result = std.mem.trim(u8, buf[0..w], " ");
    if (result.len > max) result = result[0..safeBoundary(result, max)];
    return result;
}

/// Largest cut <= max that neither splits a UTF-8 sequence nor a JSON
/// escape (an odd run of trailing backslashes).
fn safeBoundary(text: []const u8, max: usize) usize {
    var cut = @min(max, text.len);
    while (cut > 0 and (text[cut] & 0xC0) == 0x80) cut -= 1;
    var backslashes: usize = 0;
    while (cut > backslashes and text[cut - 1 - backslashes] == '\\') backslashes += 1;
    if (backslashes % 2 == 1) cut -= 1;
    return cut;
}

fn firstWord(text: []const u8, max: usize) []const u8 {
    var end: usize = 0;
    while (end < text.len and text[end] != ' ' and text[end] != '\t' and !(text[end] == '\\' and end + 1 < text.len and (text[end + 1] == 'n' or text[end + 1] == 't'))) end += 1;
    return clipRaw(text[0..end], max);
}

fn hostOf(url: []const u8) ?[]const u8 {
    const scheme = std.mem.indexOf(u8, url, "://") orelse return null;
    const rest = url[scheme + 3 ..];
    var end: usize = 0;
    while (end < rest.len and rest[end] != '/' and rest[end] != ':' and rest[end] != '?') end += 1;
    if (end == 0) return null;
    return rest[0..end];
}

fn asciiEqlLower(text: []const u8, lower: []const u8) bool {
    if (text.len != lower.len) return false;
    for (text, lower) |a, b| {
        if (std.ascii.toLower(a) != b) return false;
    }
    return true;
}

// ------------------------------------------------------ session titles

fn safeSessionId(raw: ?[]const u8) ?[]const u8 {
    const sid = raw orelse return null;
    if (sid.len == 0 or sid.len > 64) return null;
    for (sid) |c| {
        if (!(std.ascii.isAlphanumeric(c) or c == '-' or c == '_')) return null;
    }
    return sid;
}

fn normalizedConversationKey(raw: ?[]const u8, hash_buf: *[64]u8) ?[]const u8 {
    const value = raw orelse return null;
    if (safeSessionId(value)) |safe| return safe;
    if (value.len == 0) return null;
    var digest: [std.crypto.hash.sha2.Sha256.digest_length]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(value, &digest, .{});
    hash_buf.* = std.fmt.bytesToHex(digest, .lower);
    return hash_buf;
}

fn payloadSessionId(payload: []const u8, hash_buf: *[64]u8) ?[]const u8 {
    if (jsonString(payload, "petdex_conversation_key")) |key| return normalizedConversationKey(key, hash_buf);
    if (safeSessionId(jsonString(payload, "session_id"))) |session| return session;
    if (jsonString(payload, "session_key")) |key| return normalizedConversationKey(key, hash_buf);
    return safeSessionId(jsonString(payload, "parent_session_id"));
}

fn rememberTitle(dir: []const u8, session_id: []const u8, prompt: []const u8) void {
    plat.makeDir(dir);
    var title_buf: [256]u8 = undefined;
    const title = clipEscaped(prompt, title_max, &title_buf) orelse return;
    if (title.len == 0) return;
    var path_buf: [512]u8 = undefined;
    const path = std.fmt.bufPrint(&path_buf, "{s}/{s}.json", .{ dir, session_id }) catch return;
    var json_buf: [512]u8 = undefined;
    const json = std.fmt.bufPrint(&json_buf, "{{\"title\":\"{s}\",\"at\":{d}}}", .{ title, plat.nowSeconds() }) catch return;
    cWriteFile(path, json);
}

fn readTitle(dir: []const u8, session_id: []const u8, buf: *[256]u8) ?[]const u8 {
    var path_buf: [512]u8 = undefined;
    const path = std.fmt.bufPrint(&path_buf, "{s}/{s}.json", .{ dir, session_id }) catch return null;
    var file_buf: [512]u8 = undefined;
    const json = cReadFile(path, &file_buf) orelse return null;
    const title = jsonString(json, "title") orelse return null;
    if (title.len == 0 or title.len > buf.len) return null;
    @memcpy(buf[0..title.len], title);
    return buf[0..title.len];
}

const PruneCtx = struct {
    dir: []const u8,
    now: i64,
    // Deleting through the handle being iterated is not portable, so
    // expired names are staged here and unlinked after the walk. A
    // session dir past this many files just prunes on the next run.
    stale: [64][std.Io.Dir.max_name_bytes]u8 = undefined,
    stale_len: [64]usize = @splat(0),
    count: usize = 0,
};

fn pruneVisit(ctx: *PruneCtx, name: []const u8) void {
    if (ctx.count == ctx.stale.len) return;
    if (!std.mem.endsWith(u8, name, ".json")) return;
    if (name.len > std.Io.Dir.max_name_bytes) return;
    var path_buf: [512]u8 = undefined;
    const path = std.fmt.bufPrint(&path_buf, "{s}/{s}", .{ ctx.dir, name }) catch return;
    var file_buf: [512]u8 = undefined;
    const json = cReadFile(path, &file_buf) orelse return;
    // The write stamp lives inside the file ("at": epoch seconds),
    // so GC never needs a stat struct.
    const at = hook_server.jsonNumberPub(json, "at") orelse return;
    if (@as(f64, @floatFromInt(ctx.now)) - at <= @as(f64, @floatFromInt(session_ttl_secs))) return;
    @memcpy(ctx.stale[ctx.count][0..name.len], name);
    ctx.stale_len[ctx.count] = name.len;
    ctx.count += 1;
}

fn pruneSessions(dir: []const u8) void {
    var ctx: PruneCtx = .{ .dir = dir, .now = plat.nowSeconds() };
    plat.forEachEntry(dir, &ctx, pruneVisit);
    for (0..ctx.count) |i| {
        var path_buf: [512]u8 = undefined;
        const path = std.fmt.bufPrint(&path_buf, "{s}/{s}", .{ dir, ctx.stale[i][0..ctx.stale_len[i]] }) catch continue;
        plat.deleteFile(path);
    }
}

// --------------------------------------------------- transcript preview

/// Newest assistant text in a transcript tail: walk JSONL lines from
/// the end, take the first "type":"assistant" line that carries a
/// non-empty {"type":"text","text":...} part. Pure over bytes so the
/// parity tests need no filesystem.
pub fn lastAssistantFromTail(tail: []const u8) ?[]const u8 {
    var end = tail.len;
    while (end > 0) {
        const start = if (std.mem.lastIndexOfScalar(u8, tail[0..end], '\n')) |i| i + 1 else 0;
        const line = std.mem.trim(u8, tail[start..end], " \r");
        end = if (start == 0) 0 else start - 1;
        if (line.len == 0) continue;
        if (std.mem.indexOf(u8, line, "\"type\":\"assistant\"") == null) continue;
        if (firstTextPart(line)) |text| return text;
    }
    return null;
}

/// First {"type":"text","text":"..."} value in the line (raw escaped
/// bytes; the caller re-embeds or flattens them).
fn firstTextPart(line: []const u8) ?[]const u8 {
    const marker = "{\"type\":\"text\",\"text\":\"";
    var search: usize = 0;
    while (std.mem.indexOfPos(u8, line, search, marker)) |at| {
        const value_start = at + marker.len;
        var i = value_start;
        while (i < line.len) {
            if (line[i] == '\\') {
                i += 2;
                continue;
            }
            if (line[i] == '"') break;
            i += 1;
        }
        if (i > value_start and i <= line.len) {
            const value = line[value_start..@min(i, line.len)];
            if (std.mem.trim(u8, value, " ").len > 0) return value;
        }
        search = at + marker.len;
    }
    return null;
}

// ------------------------------------------------------------- plumbing

const readStdin = plat.readStdin;
const cReadFile = plat.readFile;
const cReadTail = plat.readFileTail;

fn cWriteFile(path: []const u8, bytes: []const u8) void {
    _ = plat.writeFile(path, bytes);
}

const PostTask = struct {
    done: std.atomic.Value(bool) = .init(false),
    path: [16]u8 = undefined,
    path_len: usize = 0,
    body: [1024]u8 = undefined,
    body_len: usize = 0,
    token: [128]u8 = undefined,
    token_len: usize = 0,

    fn run(self: *PostTask) void {
        postLocalhostBlocking(
            self.path[0..self.path_len],
            self.body[0..self.body_len],
            self.token[0..self.token_len],
        );
        self.done.store(true, .release);
    }
};

const PostJob = struct {
    task: *PostTask,
    thread: std.Thread,
};

/// Start a localhost POST on a private worker. Every byte is copied into the
/// task so the worker remains valid even when the hook's stack frame returns.
fn startPost(path: []const u8, body: []const u8, token: []const u8) ?PostJob {
    if (path.len > 16 or body.len > 1024 or token.len > 128) return null;
    const task = std.heap.page_allocator.create(PostTask) catch return null;
    task.* = .{};
    @memcpy(task.path[0..path.len], path);
    task.path_len = path.len;
    @memcpy(task.body[0..body.len], body);
    task.body_len = body.len;
    @memcpy(task.token[0..token.len], token);
    task.token_len = token.len;
    const thread = std.Thread.spawn(.{}, PostTask.run, .{task}) catch {
        std.heap.page_allocator.destroy(task);
        return null;
    };
    return .{ .task = task, .thread = thread };
}

/// The hook waits for both localhost requests together, never for more than
/// 300ms. A stalled loopback socket cannot hold an agent session hostage.
/// Timed-out jobs intentionally retain their small task allocation until the
/// short-lived runner process exits; freeing it here would race the worker.
fn waitForPosts(posts: []PostJob) void {
    if (posts.len == 0) return;
    const polls = post_timeout_ms / post_poll_ms;
    var scope = plat.Scope.init();
    defer scope.deinit();
    for (0..polls) |_| {
        var all_done = true;
        for (posts) |post| {
            if (!post.task.done.load(.acquire)) {
                all_done = false;
                break;
            }
        }
        if (all_done) break;
        std.Io.sleep(scope.io(), std.Io.Duration.fromMilliseconds(post_poll_ms), .awake) catch {};
    }
    for (posts) |*post| {
        if (post.task.done.load(.acquire)) {
            post.thread.join();
            std.heap.page_allocator.destroy(post.task);
        } else {
            post.thread.detach();
        }
    }
}

/// Minimal HTTP POST to the in-process hook server. The caller owns the deadline; this
/// worker only flushes a small request and never waits for a response.
fn postLocalhostBlocking(path: []const u8, body: []const u8, token: []const u8) void {
    var scope = plat.Scope.init();
    defer scope.deinit();
    const io = scope.io();
    const addr: std.Io.net.IpAddress = .{ .ip4 = .loopback(7777) };
    // No .timeout here: Zig 0.16 panics on it (netConnectIpPosix and
    // netConnectIpWindows are both "TODO implement ... with timeout"),
    // and a panic in the runner is the one thing this binary must never
    // do to an agent. The caller's worker deadline is the timeout boundary;
    // the target is loopback, so connect either wins immediately or fails
    // with connection refused when no app listens.
    var stream = addr.connect(io, .{ .mode = .stream, .protocol = .tcp }) catch return;
    defer stream.close(io);
    var req_buf: [1600]u8 = undefined;
    const req = std.fmt.bufPrint(&req_buf, "POST {s} HTTP/1.1\r\nhost: 127.0.0.1\r\nx-petdex-update-token: {s}\r\ncontent-type: application/json\r\ncontent-length: {d}\r\nconnection: close\r\n\r\n{s}", .{ path, token, body.len, body }) catch return;
    var write_buf: [64]u8 = undefined;
    var writer = stream.writer(io, &write_buf);
    writer.interface.writeAll(req) catch return;
    writer.interface.flush() catch return;
}

// ------------------------------------------------------------ parity

// Mirrors of bubble-templates.test.ts / bubble-runner.test.ts cases.
const t = std.testing;

test "read template uses basename" {
    var out: [256]u8 = undefined;
    const payload = "{\"tool_name\":\"Read\",\"tool_input\":{\"file_path\":\"/a/b/server.ts\"}}";
    try t.expectEqualStrings("Reading server.ts", formatBubble("pre", payload, &out).?);
    try t.expectEqualStrings("Read server.ts", formatBubble("post", payload, &out).?);
}

test "bash description beats the command heuristic" {
    var out: [256]u8 = undefined;
    const payload = "{\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"for f in *.svg; do magick $f; done\",\"description\":\"Rasterize agent SVGs\"}}";
    try t.expectEqualStrings("Rasterize agent SVGs", formatBubble("pre", payload, &out).?);
}

test "bash falls back to first word" {
    var out: [256]u8 = undefined;
    const payload = "{\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"git status\"}}";
    try t.expectEqualStrings("Running git", formatBubble("pre", payload, &out).?);
    try t.expectEqualStrings("Ran git", formatBubble("post", payload, &out).?);
}

test "unknown tool falls through to generic" {
    var out: [256]u8 = undefined;
    const payload = "{\"tool_name\":\"mcp__custom__thing\"}";
    try t.expectEqualStrings("Calling mcp__custom__thing", formatBubble("pre", payload, &out).?);
}

test "grep quotes the pattern without ASCII quotes" {
    var out: [256]u8 = undefined;
    const payload = "{\"tool_name\":\"Grep\",\"tool_input\":{\"pattern\":\"TODO\"}}";
    try t.expectEqualStrings("Searching “TODO”", formatBubble("pre", payload, &out).?);
    try t.expectEqualStrings("Searched “TODO”", formatBubble("post", payload, &out).?);
}

test "every template survives the body round trip" {
    // The bug this pins: a bubble goes out as raw bytes interpolated into
    // the POST body and comes back through hook_server's scanner, which
    // stops at the first `"` OR `\` and decodes neither. A template that
    // renders either one loses everything after it, silently — the ASCII
    // quotes Grep used to wrap its pattern in dropped the pattern.
    const payloads = [_][]const u8{
        "{\"tool_name\":\"Grep\",\"tool_input\":{\"pattern\":\"TODO\"}}",
        "{\"tool_name\":\"Glob\",\"tool_input\":{\"pattern\":\"*.zig\"}}",
        "{\"tool_name\":\"Read\",\"tool_input\":{\"file_path\":\"/a/b/server.ts\"}}",
        "{\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"git status\"}}",
        "{\"tool_name\":\"WebFetch\",\"tool_input\":{\"url\":\"https://petdex.dev/x\"}}",
        "{\"tool_name\":\"Agent\",\"tool_input\":{\"description\":\"review hooks\"}}",
    };
    for (payloads) |payload| {
        for ([_][]const u8{ "pre", "post" }) |phase| {
            var out: [256]u8 = undefined;
            const text = formatBubble(phase, payload, &out) orelse continue;
            var body_buf: [1024]u8 = undefined;
            const body = try std.fmt.bufPrint(
                &body_buf,
                "{{\"text\":\"{s}\",\"busy\":true,\"agent_source\":\"claude-code\"}}",
                .{text},
            );
            try t.expectEqualStrings(text, jsonString(body, "text").?);
        }
    }
}

test "session phases render fixed strings" {
    var out: [256]u8 = undefined;
    try t.expectEqualStrings("Thinking…", formatBubble("user-prompt", "", &out).?);
    try t.expectEqualStrings("Done.", formatBubble("stop", "", &out).?);
    try t.expectEqualStrings("Waiting for you…", formatBubble("notification", "", &out).?);
}

test "Hermes lifecycle phases render bubbles and states" {
    var out: [256]u8 = undefined;
    try t.expectEqualStrings("Done.", formatBubble("assistant", "{}", &out).?);
    try t.expectEqualStrings("Waiting for approval…", formatBubble("approval-request", "{}", &out).?);
    try t.expectEqualStrings("Approval received", formatBubble("approval-response", "{}", &out).?);
    try t.expectEqualStrings("Subagent working…", formatBubble("subagent-start", "{}", &out).?);
    try t.expectEqualStrings("Subagent done", formatBubble("subagent-stop", "{}", &out).?);
    try t.expectEqualStrings("waving", stateForEvent("assistant", null).?);
    try t.expectEqualStrings("waiting", stateForEvent("approval-request", null).?);
    try t.expectEqualStrings("running", stateForEvent("approval-response", null).?);
    try t.expectEqualStrings("running", stateForEvent("subagent-start", null).?);
    try t.expectEqualStrings("idle", stateForEvent("subagent-stop", null).?);
}

test "Hermes metadata chooses canonical conversation identity" {
    var hash_buf: [64]u8 = undefined;
    try t.expectEqualStrings(
        "stable-session",
        payloadSessionId("{\"session_id\":\"raw-session\",\"petdex_conversation_key\":\"stable-session\"}", &hash_buf).?,
    );
    try t.expectEqualStrings("approval-session", payloadSessionId("{\"session_key\":\"approval-session\"}", &hash_buf).?);
    const gateway = payloadSessionId("{\"session_key\":\"agent:main:telegram:dm:123\"}", &hash_buf).?;
    try t.expectEqual(@as(usize, 64), gateway.len);
    try t.expect(std.mem.indexOfScalar(u8, gateway, ':') == null);
}

test "state mapping mirrors the TS runner" {
    try t.expectEqualStrings("review", stateForEvent("pre", "Read").?);
    try t.expectEqualStrings("running", stateForEvent("pre", "Bash").?);
    try t.expectEqualStrings("idle", stateForEvent("post", null).?);
    try t.expectEqualStrings("waving", stateForEvent("stop", null).?);
    try t.expectEqualStrings("jumping", stateForEvent("user-prompt", null).?);
    try t.expectEqualStrings("waiting", stateForEvent("notification", null).?);
    try t.expectEqualStrings("failed", stateForEvent("tool-failure", "Bash").?);
}

test "tool-failure bubble names the tool and never the error text" {
    var out: [256]u8 = undefined;
    const payload =
        "{\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"npm test\"}," ++
        "\"error\":\"Command failed: \\\"npm test\\\" exited 1\",\"error_type\":\"execution_failed\"}";
    const rendered = formatBubble("tool-failure", payload, &out).?;
    try t.expectEqualStrings("Bash failed", rendered);
    // AC9: the payload carries both an ASCII quote and a backslash, and neither
    // reaches the bubble. jsonString would truncate the body at the first one.
    try t.expect(std.mem.indexOfScalar(u8, rendered, '"') == null);
    try t.expect(std.mem.indexOfScalar(u8, rendered, '\\') == null);
    // Missing tool_name falls back capitalised, matching the TS runner.
    try t.expectEqualStrings("Tool failed", formatBubble("tool-failure", "{}", &out).?);
}

test "stateBody adds duration only for the failure phase" {
    var buf: [256]u8 = undefined;
    try t.expectEqualStrings(
        "{\"state\":\"failed\",\"duration\":1220,\"agent_source\":\"qoder\"}",
        stateBody(&buf, "failed", failed_duration_ms, "qoder").?,
    );
    // AC12 regression guard: every pre-existing phase must render exactly what
    // shipped before this change. This fails the moment anyone reintroduces a
    // second format string or reorders the keys.
    try t.expectEqualStrings(
        "{\"state\":\"idle\",\"agent_source\":\"claude-code\"}",
        stateBody(&buf, "idle", 0, "claude-code").?,
    );
    try t.expectEqualStrings(
        "{\"state\":\"waving\",\"agent_source\":\"codex\"}",
        stateBody(&buf, "waving", 0, "codex").?,
    );
}

test "explicit hook agent wins over payload metadata" {
    try t.expectEqualStrings(
        "codex",
        resolveAgent("{\"agent_source\":\"claude-code\"}", "codex"),
    );
    try t.expectEqualStrings(
        "claude-code",
        resolveAgent("{\"agent_source\":\"claude-code\"}", null),
    );
    try t.expectEqualStrings("", resolveAgent("{}", null));
    try t.expectEqualStrings("codex", resolveAgent("{}", "codex"));
}

test "bubbleBody carries session_id, and omits it when there is none" {
    var buf: [512]u8 = undefined;
    // The bug this pins: session_id was parsed and used for titles, but
    // neither body format string emitted it, so every Claude Code session
    // installed through the Zig runner collapsed onto one bubble slot.
    try t.expectEqualStrings(
        "{\"text\":\"Reading main.zig\",\"title\":\"Fix the tail\",\"busy\":true,\"agent_source\":\"claude-code\",\"session_id\":\"abc123\"}",
        bubbleBody(&buf, "Reading main.zig", "Fix the tail", true, "claude-code", "abc123").?,
    );
    // Regression guard: no session means byte-identity with what shipped
    // before per-conversation bubbles, title present or not.
    try t.expectEqualStrings(
        "{\"text\":\"Done.\",\"busy\":false,\"agent_source\":\"codex\"}",
        bubbleBody(&buf, "Done.", "", false, "codex", null).?,
    );
    try t.expectEqualStrings(
        "{\"text\":\"Done.\",\"title\":\"Ship it\",\"busy\":false,\"agent_source\":\"codex\"}",
        bubbleBody(&buf, "Done.", "Ship it", false, "codex", null).?,
    );
    try t.expectEqualStrings(
        "{\"text\":\"Working\",\"busy\":true,\"agent_source\":\"codex\",\"session_id\":\"s-1\"}",
        bubbleBody(&buf, "Working", "", true, "codex", "s-1").?,
    );
}

test "bubble metadata carries the exact Herdr pane id" {
    var buf: [1024]u8 = undefined;
    const body = bubbleBodyWithMetadata(&buf, "Needs approval", "Fix auth", false, "cursor", "session-1", "ghostty", "", "/repo", "w1:p5", null).?;
    try t.expectEqualStrings("w1:p5", hook_server.jsonStringPub(body, "herdr_pane_id").?);
}

test "two runner sessions reach the mailbox as two bubbles" {
    // End to end over the real parser and the real mailbox: this is the
    // acceptance criterion of #657 on the path the default install uses,
    // which the TS CLI fix alone never covered.
    hook_server.mailbox.clearBubbles();

    var buf_a: [512]u8 = undefined;
    var buf_b: [512]u8 = undefined;
    const body_a = bubbleBody(&buf_a, "Reading main.zig", "Fix the tail", true, "claude-code", "sess-a").?;
    const body_b = bubbleBody(&buf_b, "Running tests", "Ship it", true, "claude-code", "sess-b").?;

    for ([_][]const u8{ body_a, body_b }) |body| {
        const text = hook_server.jsonStringPub(body, "text").?;
        const agent = hook_server.jsonStringPub(body, "agent_source").?;
        const title = hook_server.jsonStringPub(body, "title") orelse "";
        const session = hook_server.jsonStringPub(body, "session_id") orelse "";
        const busy = std.mem.indexOf(u8, body, "\"busy\":true") != null;
        _ = hook_server.mailbox.setBubble(session, text, agent, title, busy);
    }

    var out: [hook_server.max_bubbles]hook_server.Bubble = @splat(.{});
    try t.expectEqual(@as(?usize, 2), hook_server.mailbox.takeBubbles(&out));
    try t.expectEqualStrings("sess-a", out[0].sessionSlice());
    try t.expectEqualStrings("sess-b", out[1].sessionSlice());

    // A payload with no session still shares the single legacy slot.
    hook_server.mailbox.clearBubbles();
    var buf_c: [512]u8 = undefined;
    const legacy = bubbleBody(&buf_c, "Done.", "", false, "codex", null).?;
    const legacy_session = hook_server.jsonStringPub(legacy, "session_id") orelse "";
    try t.expectEqualStrings("", legacy_session);
    _ = hook_server.mailbox.setBubble(legacy_session, "Done.", "codex", "", false);
    _ = hook_server.mailbox.setBubble(legacy_session, "Again.", "codex", "", false);
    try t.expectEqual(@as(?usize, 1), hook_server.mailbox.takeBubbles(&out));
    hook_server.mailbox.clearBubbles();
}

test "tool-failure bubble survives the hook server reader round trip" {
    // The whole class #628 exposed: formatBubble output is embedded raw into the
    // POST body, then read back by a scanner that stops at `"` and `\`. Push the
    // new template through both halves and assert nothing is lost.
    var out: [256]u8 = undefined;
    const rendered = formatBubble("tool-failure", "{\"tool_name\":\"Bash\"}", &out).?;
    var body_buf: [512]u8 = undefined;
    const body = std.fmt.bufPrint(
        &body_buf,
        "{{\"text\":\"{s}\",\"busy\":true,\"agent_source\":\"qoder\"}}",
        .{rendered},
    ) catch unreachable;
    try t.expectEqualStrings("Bash failed", jsonString(body, "text").?);
    try t.expectEqualStrings("qoder", jsonString(body, "agent_source").?);
}

test "transcript tail takes the newest assistant text" {
    const tail =
        "{\"type\":\"user\",\"message\":{\"content\":\"hola\"}}\n" ++
        "{\"type\":\"assistant\",\"message\":{\"content\":[{\"type\":\"text\",\"text\":\"older answer\"}]}}\n" ++
        "{\"type\":\"assistant\",\"message\":{\"content\":[{\"type\":\"tool_use\",\"name\":\"Bash\"},{\"type\":\"text\",\"text\":\"Listo, el fix quedo\\npusheado.\"}]}}\n" ++
        "{\"type\":\"system\",\"subtype\":\"hook\"}\n";
    try t.expectEqualStrings("Listo, el fix quedo\\npusheado.", lastAssistantFromTail(tail).?);
}

test "clipEscaped flattens escapes and collapses spaces" {
    var buf: [512]u8 = undefined;
    try t.expectEqualStrings("hola mundo", clipEscaped("hola\\n  mundo", 110, &buf).?);
}

test "clipEscaped cuts on a safe boundary" {
    var buf: [512]u8 = undefined;
    var long: [200]u8 = @splat('x');
    long[109] = '\\';
    const clipped = clipEscaped(&long, 110, &buf).?;
    try t.expect(clipped.len <= 110);
    try t.expect(clipped[clipped.len - 1] != '\\');
}

test "a bubble without a reported state is byte-identical to before" {
    // The flock reads agent_state, but every sender that does not know one
    // must keep producing exactly the body that shipped before the field
    // existed: this is the compatibility promise, not a preference.
    var with: [1536]u8 = undefined;
    var without: [1536]u8 = undefined;
    const a = bubbleBodyWithMetadata(&with, "text", "title", true, "claude", "s1", "", "", "", "", null).?;
    const b = bubbleBody(&without, "text", "title", true, "claude", "s1").?;
    try std.testing.expectEqualStrings(b, a);
    try std.testing.expect(std.mem.indexOf(u8, a, "agent_state") == null);
}

test "a reported state rides the bubble that carries the session" {
    var buf: [1536]u8 = undefined;
    const body = bubbleBodyWithMetadata(&buf, "text", "title", true, "claude", "s1", "", "", "", "", "failed").?;
    try std.testing.expect(std.mem.indexOf(u8, body, "\"agent_state\":\"failed\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, body, "\"session_id\":\"s1\"") != null);
}

test "the states only direct hooks can see reach the bubble" {
    // stateForEvent already computes these; before this they only went to
    // /state, which aggregates and cannot show two agents at once.
    try std.testing.expectEqualStrings("failed", stateForEvent("tool-failure", "Bash").?);
    try std.testing.expectEqualStrings("review", stateForEvent("pre", "Read").?);
    try std.testing.expectEqualStrings("waiting", stateForEvent("approval-request", null).?);
}

test "Hermes background review forks are recognised" {
    // The fork's own prompt is its `user_message` on the ordinary
    // pre_llm_call path; unfiltered it becomes the session title.
    try t.expect(isBackgroundReview(
        "{\"session_id\":\"s1\",\"user_message\":\"Review the conversation above and update the skill library. Be ACTIVE — most sessions produce at least one skill update, even if small.\"}",
    ));
    try t.expect(isBackgroundReview(
        "{\"session_id\":\"s1\",\"user_message\":\"Review the conversation above and consider saving to memory if appropriate.\\n\\nFocus on:\"}",
    ));
    // Carried under `prompt` rather than `user_message`, as the /refine scope does.
    try t.expect(isBackgroundReview(
        "{\"session_id\":\"s1\",\"prompt\":\"Review the conversation above and update two things:\\n\\n**Memory**\"}",
    ));
    // Later fork hooks carry no prompt: the fork is its own parent, which no
    // genuine session or delegated worker ever is.
    try t.expect(isBackgroundReview(
        "{\"session_id\":\"s1\",\"parent_session_id\":\"s1\",\"assistant_response\":\"Nothing to save.\"}",
    ));
}

test "real sessions and subagents are not taken for a background review" {
    // A user turn that merely opens with the phrase must stay visible.
    try t.expect(!isBackgroundReview(
        "{\"session_id\":\"s1\",\"user_message\":\"Review the conversation above and tell me which decisions we settled on.\"}",
    ));
    // A delegated worker points at a DIFFERENT session as its parent.
    try t.expect(!isBackgroundReview("{\"session_id\":\"child-1\",\"parent_session_id\":\"parent-1\"}"));
    // An ordinary top-level turn, and an empty payload.
    try t.expect(!isBackgroundReview("{\"session_id\":\"s1\",\"user_message\":\"ship the fix\"}"));
    try t.expect(!isBackgroundReview("{\"parent_session_id\":\"parent-1\"}"));
    try t.expect(!isBackgroundReview("{}"));
}
