"use client";

import { useEffect, useRef, useState } from "react";

import { useUser } from "@clerk/nextjs";
import JSZip from "jszip";
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Copy,
  FileArchive,
  Loader2,
  Send,
  Upload,
} from "lucide-react";
import { useTranslations } from "next-intl";

import { petStates } from "@/lib/pet-states";
import { deriveSlug } from "@/lib/slug";
import {
  canonicalSpriteDimensions,
  detectSpriteAtlas,
} from "@/lib/sprite-atlas";
import { parseSpriteVersionNumber } from "@/lib/sprite-version";
import {
  PET_LICENSE_CHOICES,
  type PetLicenseChoice,
} from "@/lib/submissions-validation";
import { PET_ASSET_MAX_BYTES } from "@/lib/upload-limits";

import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

type ParsedPet = {
  petId: string;
  displayName: string;
  description: string;
  petJson: Record<string, unknown>;
  zipBlob: Blob;
  zipFileName: string;
  spritesheetBlob: Blob;
  spritesheetExt: "webp" | "png";
  petJsonString: string;
  spritesheetUrl: string;
  spritesheetWidth: number;
  spritesheetHeight: number;
  spriteVersionNumber: 1 | 2;
  issues: string[];
  source: "folder" | "zip" | "spritesheet";
};

// Mirrors MAX_BYTES in /api/r2/presign. Checked here too so an oversized
// pet is caught before the upload starts rather than after the round
// trip, and so the message can name the file (#594 reported only the
// bare error code with no way to tell which of the three was over).
const MAX_UPLOAD_BYTES = PET_ASSET_MAX_BYTES;

const MAX_DISPLAY_NAME_LENGTH = 60;
const MAX_DESCRIPTION_LENGTH = 500;

type SubmissionReviewOutcome = {
  decision: "approved" | "rejected" | "hold";
  applied: boolean;
  reasonCode: string | null;
  summary: string | null;
};

type SubmissionResult =
  | { kind: "idle" }
  | { kind: "uploading"; step: "validating" | "uploading" | "registering" }
  | { kind: "error"; message: string }
  | {
      kind: "success";
      slug: string;
      displayName: string;
      status: "pending" | "approved" | "rejected";
      review: SubmissionReviewOutcome;
    };

type SubmitResponse = {
  slug: string;
  status: "pending" | "approved" | "rejected";
  review: SubmissionReviewOutcome;
};

const CLASSIC_ATLAS = canonicalSpriteDimensions(1);
const V2_ATLAS = canonicalSpriteDimensions(2);
const PETS_DIR = "~/.codex/pets";

export function PetSubmitForm() {
  const t = useTranslations("submit.form");
  const { isSignedIn, isLoaded, user } = useUser();
  const [parsed, setParsed] = useState<ParsedPet | null>(null);
  const [isReading, setIsReading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [submission, setSubmission] = useState<SubmissionResult>({
    kind: "idle",
  });

  // Editable copies of displayName/description. handleFiles() re-seeds these
  // from the parsed (or placeholder-generated) pet.json every time a new
  // package is read; the user can then override them before submit.
  const [editedDisplayName, setEditedDisplayName] = useState("");
  const [editedDescription, setEditedDescription] = useState("");
  // No preselected value: the creator has to pick, so the grant is an
  // actual choice and not something we inferred from their silence.
  const [license, setLicense] = useState<PetLicenseChoice | "">("");

  const uploadErrorRef = useRef<string | null>(null);
  const [, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      if (parsed?.spritesheetUrl) URL.revokeObjectURL(parsed.spritesheetUrl);
    };
  }, [parsed?.spritesheetUrl]);

  async function handleFiles(files: FileList | null) {
    if (!files?.length) return;
    setIsReading(true);
    setSubmission({ kind: "idle" });
    setParsed(null);

    try {
      const items = [...files];
      // True folder upload has a "/" inside webkitRelativePath
      // (e.g. "boba/pet.json"). A single dropped file via webkitGetAsEntry
      // gets stamped with just its filename, so we treat that as zip mode
      // unless it's a bare spritesheet image (ChatGPT/Codex Desktop pet
      // sharing exports a single PNG/WebP with no pet.json alongside it).
      const fromFolder = items.some((f) => f.webkitRelativePath?.includes("/"));
      const bareSpritesheetFile =
        !fromFolder && items.length === 1 && isSpritesheetImage(items[0])
          ? items[0]
          : null;
      const source: "folder" | "zip" | "spritesheet" = fromFolder
        ? "folder"
        : bareSpritesheetFile
          ? "spritesheet"
          : "zip";

      let petJsonString = "";
      let spritesheetBlob: Blob = new Blob();
      let spritesheetExt: "webp" | "png" = "webp";
      let zipBlob: Blob = new Blob();
      let zipFileName = "";
      let petIdFromName = "untitled";
      const issues: string[] = [];

      if (fromFolder) {
        // ── Folder upload path ──────────────────────────────────────────
        const findByBase = (...names: string[]) => {
          for (const name of names) {
            const hit = items.find(
              (f) =>
                f.name === name ||
                f.webkitRelativePath?.endsWith(`/${name}`) ||
                f.webkitRelativePath === name,
            );
            if (hit) return hit;
          }
          return undefined;
        };

        const petFile = findByBase("pet.json");
        const spriteWebp = findByBase("spritesheet.webp");
        const spritePng = findByBase("spritesheet.png");
        const spriteFile = spriteWebp ?? spritePng;
        spritesheetExt = spriteWebp ? "webp" : "png";

        if (!petFile) issues.push(t("issues.folderMissingPetJson"));
        if (!spriteFile) {
          const present = items
            .slice(0, 6)
            .map((f) => f.webkitRelativePath || f.name)
            .join(", ");
          issues.push(t("issues.folderMissingSpritesheet", { present }));
        }

        if (petFile) {
          petJsonString = await petFile.text();
        }
        if (spriteFile) {
          spritesheetBlob = spriteFile;
        }

        // Derive pet id from top-level folder name (boba/pet.json → "boba")
        const firstPath =
          petFile?.webkitRelativePath || spriteFile?.webkitRelativePath || "";
        const folderName = firstPath.split("/")[0] || "untitled";
        petIdFromName = folderName;

        // Build a fresh zip in memory so server flow stays unchanged.
        if (petFile && spriteFile) {
          const zip = new JSZip();
          zip.file("pet.json", petJsonString);
          zip.file(`spritesheet.${spritesheetExt}`, spritesheetBlob);
          zipBlob = await zip.generateAsync({
            type: "blob",
            compression: "DEFLATE",
          });
          zipFileName = `${folderName}.zip`;
        }
      } else if (bareSpritesheetFile) {
        // ── Bare spritesheet path (ChatGPT/Codex Desktop pet export) ─────
        spritesheetBlob = bareSpritesheetFile;
        spritesheetExt = bareSpritesheetFile.name
          .toLowerCase()
          .endsWith(".webp")
          ? "webp"
          : "png";
        petIdFromName = deriveIdFromSpritesheetName(bareSpritesheetFile.name);
        // The spritesheetMissingPetInfo issue is derived at render time from
        // the editable displayName field (see effectiveIssues below), not
        // pushed here — the placeholder name is only a problem until the
        // user edits it, and there's now a field to do that in.

        // pet.json isn't generated here — width/height aren't known until
        // the shared measurement step below runs, and the server only
        // needs the JSON string, not the exact validated dimensions.
        const generatedPetJson = {
          id: petIdFromName,
          displayName: t("defaults.untitledPet"),
          description: t("defaults.description"),
          spritesheetPath: `spritesheet.${spritesheetExt}`,
        };
        petJsonString = JSON.stringify(generatedPetJson, null, 2);

        const zip = new JSZip();
        zip.file("pet.json", petJsonString);
        zip.file(`spritesheet.${spritesheetExt}`, spritesheetBlob);
        zipBlob = await zip.generateAsync({
          type: "blob",
          compression: "DEFLATE",
        });
        zipFileName = `${petIdFromName}.zip`;
      } else {
        // ── ZIP upload path (legacy) ────────────────────────────────────
        const zipFile = items.find((f) => f.name.endsWith(".zip"));
        if (!zipFile) {
          setParsed({
            petId: "missing",
            displayName: t("defaults.missingFiles"),
            description: t("drop.short"),
            petJson: {},
            zipBlob: new Blob(),
            zipFileName: "",
            spritesheetBlob: new Blob(),
            spritesheetExt: "webp",
            petJsonString: "",
            spritesheetUrl: "",
            spritesheetWidth: 0,
            spritesheetHeight: 0,
            spriteVersionNumber: 1,
            issues: [t("issues.dropPetFolderOrZip")],
            source: "zip",
          });
          setEditedDisplayName(t("defaults.missingFiles"));
          setEditedDescription(t("drop.short"));
          return;
        }

        const buf = await zipFile.arrayBuffer();
        const zip = await JSZip.loadAsync(buf);
        const petJsonEntry = zip.file("pet.json");
        const webpEntry = zip.file("spritesheet.webp");
        const pngEntry = zip.file("spritesheet.png");
        const spriteEntry = webpEntry ?? pngEntry;
        spritesheetExt = webpEntry ? "webp" : "png";

        // Detect "petdex-approved.zip" — the all-pets bundle, not a single pet.
        const allFiles = Object.keys(zip.files);
        const looksLikeBundle =
          !petJsonEntry &&
          allFiles.some((p) => p.includes("/pet.json")) &&
          allFiles.length > 4;

        if (looksLikeBundle) {
          issues.push(t("issues.allPetsBundle"));
        } else {
          if (!petJsonEntry) issues.push(t("issues.zipMissingPetJson"));
          if (!spriteEntry) {
            issues.push(
              t("issues.zipMissingSpritesheet", {
                present: allFiles.slice(0, 5).join(", "),
              }),
            );
          }
        }

        petJsonString = petJsonEntry ? await petJsonEntry.async("string") : "";
        spritesheetBlob = spriteEntry
          ? await spriteEntry.async("blob")
          : new Blob();
        zipBlob = new Blob([buf], { type: "application/zip" });
        zipFileName = zipFile.name;
        petIdFromName = zipFile.name.replace(/\.zip$/i, "");
      }

      // ── Common: parse pet.json, validate sprite dims ──────────────────
      let petJson: Record<string, unknown> = {};
      if (petJsonString) {
        try {
          petJson = JSON.parse(petJsonString);
        } catch {
          issues.push(t("issues.invalidJson"));
        }
      }
      const spriteVersion = parseSpriteVersionNumber(petJson);
      if (!spriteVersion.ok) {
        issues.push(
          t("issues.invalidSpriteVersion", {
            value: String(spriteVersion.value),
          }),
        );
      }

      const spritesheetUrl = spritesheetBlob.size
        ? URL.createObjectURL(spritesheetBlob)
        : "";

      let width = 0;
      let height = 0;
      if (spritesheetUrl) {
        ({ width, height } = await measureImage(spritesheetUrl));
        const atlas = detectSpriteAtlas(width, height);
        if (width === 0 || height === 0) {
          issues.push(t("issues.unreadableSpritesheet"));
        } else if (width < 256 || height < 256) {
          issues.push(
            t("issues.tooSmall", {
              width,
              height,
              classicWidth: CLASSIC_ATLAS.width,
              classicHeight: CLASSIC_ATLAS.height,
              v2Width: V2_ATLAS.width,
              v2Height: V2_ATLAS.height,
            }),
          );
        } else if (!atlas) {
          // Mirror the server-side grid check so the preview never says
          // "ready" for a sheet /api/submit will reject.
          issues.push(t("issues.badGrid", { width, height }));
        } else if (
          spriteVersion.ok &&
          atlas.version !== spriteVersion.version
        ) {
          issues.push(
            t("issues.spriteVersionMismatch", {
              detected: atlas.version,
              declared: spriteVersion.version,
            }),
          );
        }
      }

      const displayName =
        typeof petJson.displayName === "string" && petJson.displayName.trim()
          ? petJson.displayName.trim()
          : t("defaults.untitledPet");
      const description =
        typeof petJson.description === "string" && petJson.description.trim()
          ? petJson.description.trim()
          : t("defaults.description");
      const petId =
        typeof petJson.id === "string" && petJson.id.trim()
          ? petJson.id.trim()
          : petIdFromName;

      setParsed({
        petId,
        displayName,
        description,
        petJson,
        zipBlob,
        zipFileName,
        spritesheetBlob,
        spritesheetExt,
        petJsonString,
        spritesheetUrl,
        spritesheetWidth: width,
        spritesheetHeight: height,
        spriteVersionNumber: spriteVersion.ok ? spriteVersion.version : 1,
        issues,
        source,
      });
      setEditedDisplayName(displayName);
      setEditedDescription(description);
    } finally {
      setIsReading(false);
    }
  }

  async function handleSubmit() {
    const effectiveIssues = getEffectiveIssues(
      parsed,
      t("issues.spritesheetMissingPetInfo"),
      editedDisplayName,
      t("defaults.untitledPet"),
    );
    if (!parsed || effectiveIssues.length > 0) return;
    if (!isSignedIn) return;

    const displayName = editedDisplayName.trim();
    const description = editedDescription.trim();

    setSubmission({ kind: "uploading", step: "validating" });

    // Rebuild pet.json with the edited displayName/description so the zip's
    // manifest matches the submitted fields. The server compares them
    // (scanPetManifestsSecurity's pet_json_manifest_mismatch check) and
    // holds the submission if they drift apart.
    const updatedPetJson = {
      ...parsed.petJson,
      id: parsed.petId,
      displayName,
      description,
    };
    const petJsonString = JSON.stringify(updatedPetJson, null, 2);
    const zip = new JSZip();
    zip.file("pet.json", petJsonString);
    zip.file(`spritesheet.${parsed.spritesheetExt}`, parsed.spritesheetBlob);
    const zipBlob = await zip.generateAsync({
      type: "blob",
      compression: "DEFLATE",
    });

    const zipFile = new File([zipBlob], parsed.zipFileName, {
      type: "application/zip",
    });
    const spriteMime =
      parsed.spritesheetExt === "png" ? "image/png" : "image/webp";
    const spriteFile = new File(
      [parsed.spritesheetBlob],
      `${deriveSlug(parsed.petId, displayName)}-spritesheet.${parsed.spritesheetExt}`,
      { type: spriteMime },
    );
    const petJsonFile = new File(
      [petJsonString],
      `${deriveSlug(parsed.petId, displayName)}-pet.json`,
      { type: "application/json" },
    );

    const oversized = (
      [
        ["zip", zipFile.size],
        ["sprite", spriteFile.size],
      ] as const
    ).find(([, size]) => size > MAX_UPLOAD_BYTES);
    if (oversized) {
      const [role, size] = oversized;
      const mb = (n: number) => `${(n / (1024 * 1024)).toFixed(1)} MB`;
      const message = `Your ${role} is ${mb(size)}, over the ${mb(MAX_UPLOAD_BYTES)} limit.`;
      uploadErrorRef.current = message;
      setUploadError(message);
      setSubmission({ kind: "error", message });
      return;
    }

    setSubmission({ kind: "uploading", step: "uploading" });
    setUploadError(null);
    uploadErrorRef.current = null;

    // ── R2 presigned PUT flow ─────────────────────────────────────────────
    let zipUrl: string;
    let spritesheetUrl: string;
    let petJsonUrl: string;

    try {
      const presignRes = await fetch("/api/r2/presign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slugHint: deriveSlug(parsed.petId, displayName),
          files: [
            {
              role: "zip",
              contentType: "application/zip",
              size: zipFile.size,
            },
            {
              role: "sprite",
              contentType: spriteMime,
              size: spriteFile.size,
            },
            {
              role: "petjson",
              contentType: "application/json",
              size: petJsonFile.size,
            },
          ],
        }),
      });

      if (!presignRes.ok) {
        const data = (await presignRes.json().catch(() => ({}))) as {
          error?: string;
          message?: string;
        };
        throw new Error(
          data.message ?? data.error ?? `presign ${presignRes.status}`,
        );
      }

      const presignData = (await presignRes.json()) as {
        files: Array<{
          role: "zip" | "sprite" | "petjson";
          uploadUrl: string;
          publicUrl: string;
        }>;
      };

      const byRole = new Map(presignData.files.map((f) => [f.role, f]));
      const zipSlot = byRole.get("zip");
      const spriteSlot = byRole.get("sprite");
      const petJsonSlot = byRole.get("petjson");
      if (!zipSlot || !spriteSlot || !petJsonSlot) {
        throw new Error("presign response missing slots");
      }

      // Serialize the three R2 PUTs instead of Promise.all-ing them.
      // Three concurrent uploads of 2-3MB sprites saturate flaky / mobile
      // links and one of them aborts mid-flight. The reports in
      // crafter-station/petdex#22-#51 all hit "Failed to fetch" on the
      // parallel upload path. Sequential is slower but completes.
      const slots: Array<{
        role: "petjson" | "sprite" | "zip";
        slot: { uploadUrl: string; publicUrl: string };
        body: Blob;
        ct: string;
      }> = [
        // petjson first — smallest, validates auth/CORS/presign quickly.
        {
          role: "petjson",
          slot: petJsonSlot,
          body: petJsonFile,
          ct: "application/json",
        },
        { role: "sprite", slot: spriteSlot, body: spriteFile, ct: spriteMime },
        { role: "zip", slot: zipSlot, body: zipFile, ct: "application/zip" },
      ];

      for (const { role, slot, body, ct } of slots) {
        const res = await putToR2(slot.uploadUrl, body, ct);
        if (!res.ok) {
          throw new Error(
            `R2 PUT ${role} ${res.status} ${res.statusText} (${body.size} bytes)`,
          );
        }
      }

      zipUrl = zipSlot.publicUrl;
      spritesheetUrl = spriteSlot.publicUrl;
      petJsonUrl = petJsonSlot.publicUrl;
    } catch (err) {
      const reason = (err as Error).message ?? "unknown";
      setSubmission({
        kind: "error",
        message: t("errors.uploadFailed", { reason }),
      });
      return;
    }

    setSubmission({ kind: "uploading", step: "registering" });

    const res = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        zipUrl,
        spritesheetUrl,
        petJsonUrl,
        displayName,
        description,
        petId: parsed.petId,
        spritesheetWidth: parsed.spritesheetWidth,
        spritesheetHeight: parsed.spritesheetHeight,
        spriteVersionNumber: parsed.spriteVersionNumber,
        license,
      }),
    });

    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as {
        message?: string;
        error?: string;
      };
      const errorCode = data.error ?? "unknown";
      setSubmission({
        kind: "error",
        message: submissionErrorMessage(errorCode, t),
      });
      return;
    }

    const data = (await res.json()) as SubmitResponse;
    setSubmission({
      kind: "success",
      slug: data.slug,
      displayName,
      status: data.status,
      review: data.review,
    });
  }

  const effectiveIssues = getEffectiveIssues(
    parsed,
    t("issues.spritesheetMissingPetInfo"),
    editedDisplayName,
    t("defaults.untitledPet"),
  );

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
      <fieldset
        className={`glass-panel flex min-h-80 flex-col items-center justify-center rounded-3xl p-8 text-center transition ${
          isDragging ? "bg-white/95 ring-2 ring-black/40 ring-offset-2" : ""
        }`}
        onDragOver={(event) => {
          event.preventDefault();
          event.dataTransfer.dropEffect = "copy";
          if (!isDragging) setIsDragging(true);
        }}
        onDragLeave={(event) => {
          if (event.currentTarget.contains(event.relatedTarget as Node | null))
            return;
          setIsDragging(false);
        }}
        onDrop={(event) => {
          event.preventDefault();
          setIsDragging(false);
          void readDataTransfer(event.dataTransfer).then((files) => {
            if (files.length > 0) void handleFiles(files);
          });
        }}
      >
        <legend className="sr-only">{t("drop.ariaLabel")}</legend>
        <span className="grid size-16 place-items-center rounded-2xl bg-inverse text-on-inverse">
          <Upload className="size-7" />
        </span>
        <span className="mt-6 text-2xl font-medium text-foreground">
          {t("drop.title")}
        </span>
        <span className="mt-3 max-w-md text-sm leading-6 text-muted-2">
          {t.rich("drop.instructions", {
            petJson: (chunks) => (
              <code className="rounded bg-surface-muted px-1 py-0.5">
                {chunks}
              </code>
            ),
            spritesheet: (chunks) => (
              <code className="rounded bg-surface-muted px-1 py-0.5">
                {chunks}
              </code>
            ),
            classicWidth: CLASSIC_ATLAS.width,
            classicHeight: CLASSIC_ATLAS.height,
            v2Width: V2_ATLAS.width,
            v2Height: V2_ATLAS.height,
          })}
        </span>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          <label className="inline-flex h-9 cursor-pointer items-center justify-center gap-1.5 rounded-full bg-inverse px-4 text-xs font-medium text-on-inverse transition hover:bg-inverse-hover">
            <Upload className="size-3.5" />
            {t("drop.pickFolder")}
            <input
              type="file"
              {...({ webkitdirectory: "" } as Record<string, string>)}
              {...({ directory: "" } as Record<string, string>)}
              multiple
              className="sr-only"
              onChange={(event) =>
                void handleFiles(event.target.files).then(() => {
                  // Allow re-picking the same folder
                  event.target.value = "";
                })
              }
            />
          </label>
          <label className="inline-flex h-9 cursor-pointer items-center justify-center gap-1.5 rounded-full border border-border-base bg-surface/70 px-4 text-xs font-medium text-foreground transition hover:bg-surface">
            <FileArchive className="size-3.5" />
            {t("drop.pickZip")}
            <input
              type="file"
              accept=".zip"
              className="sr-only"
              onChange={(event) =>
                void handleFiles(event.target.files).then(() => {
                  event.target.value = "";
                })
              }
            />
          </label>
          <label className="inline-flex h-9 cursor-pointer items-center justify-center gap-1.5 rounded-full border border-border-base bg-surface/70 px-4 text-xs font-medium text-foreground transition hover:bg-surface">
            <Upload className="size-3.5" />
            {t("drop.pickSpritesheet")}
            <input
              type="file"
              accept=".png,.webp"
              className="sr-only"
              onChange={(event) =>
                void handleFiles(event.target.files).then(() => {
                  event.target.value = "";
                })
              }
            />
          </label>
        </div>

        {!isLoaded ? null : !isSignedIn ? (
          <span className="mt-5 inline-flex items-center gap-2 rounded-full bg-chip-warning-bg px-3 py-1 font-mono text-[10px] tracking-[0.18em] text-chip-warning-fg uppercase">
            {t("auth.signIn")}
          </span>
        ) : null}
      </fieldset>

      <aside className="rounded-3xl border border-border-base bg-surface/80 p-5 shadow-sm shadow-blue-950/5 backdrop-blur">
        <div className="flex items-center gap-2 text-sm font-medium text-foreground">
          <FileArchive className="size-4" />
          {t("check.title")}
        </div>

        {isReading ? (
          <p className="mt-6 inline-flex items-center gap-2 text-sm text-muted-2">
            <Loader2 className="size-3.5 animate-spin" />
            {t("check.reading")}
          </p>
        ) : parsed ? (
          <div className="mt-6 space-y-5">
            {parsed.spritesheetUrl ? (
              <SpritePreview src={parsed.spritesheetUrl} />
            ) : null}
            <div className="space-y-3">
              <div>
                <label
                  htmlFor="pet-display-name"
                  className="font-mono text-[10px] tracking-[0.18em] text-muted-4 uppercase"
                >
                  {t("edit.displayNameLabel")}
                </label>
                <Input
                  id="pet-display-name"
                  className="mt-1 h-9 rounded-xl px-3 text-sm"
                  value={editedDisplayName}
                  maxLength={MAX_DISPLAY_NAME_LENGTH}
                  placeholder={t("edit.displayNamePlaceholder")}
                  onChange={(event) => setEditedDisplayName(event.target.value)}
                  disabled={submission.kind === "uploading"}
                />
              </div>
              <div>
                <label
                  htmlFor="pet-description"
                  className="font-mono text-[10px] tracking-[0.18em] text-muted-4 uppercase"
                >
                  {t("edit.descriptionLabel")}
                </label>
                <Textarea
                  id="pet-description"
                  className="mt-1 rounded-xl px-3 py-2 text-sm"
                  value={editedDescription}
                  maxLength={MAX_DESCRIPTION_LENGTH}
                  placeholder={t("edit.descriptionPlaceholder")}
                  onChange={(event) => setEditedDescription(event.target.value)}
                  disabled={submission.kind === "uploading"}
                />
              </div>
              <div>
                <label
                  htmlFor="pet-license"
                  className="font-mono text-[10px] tracking-[0.18em] text-muted-4 uppercase"
                >
                  {t("edit.licenseLabel")}
                </label>
                <select
                  id="pet-license"
                  className="mt-1 h-9 w-full rounded-xl border border-border-base bg-surface px-3 text-sm"
                  value={license}
                  onChange={(event) =>
                    setLicense(event.target.value as PetLicenseChoice | "")
                  }
                  disabled={submission.kind === "uploading"}
                >
                  <option value="">{t("edit.licensePlaceholder")}</option>
                  {PET_LICENSE_CHOICES.map((choice) => (
                    <option key={choice} value={choice}>
                      {t(`edit.licenseOption.${choice}`)}
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-[11px] leading-4 text-muted-4">
                  {t("edit.licenseHint")}
                </p>
              </div>
              {parsed.spritesheetWidth ? (
                <p className="font-mono text-[10px] tracking-[0.18em] text-muted-4 uppercase">
                  {parsed.spritesheetWidth}×{parsed.spritesheetHeight}
                </p>
              ) : null}
            </div>
            {effectiveIssues.length > 0 ? (
              <div className="flex items-start gap-2 rounded-2xl bg-chip-warning-bg p-4 text-sm leading-6 text-chip-warning-fg">
                <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                <ul className="space-y-1">
                  {effectiveIssues.map((issue) => (
                    <li key={issue}>{issue}</li>
                  ))}
                </ul>
              </div>
            ) : (
              <div className="flex items-center gap-2 rounded-2xl bg-chip-success-bg p-4 text-sm text-chip-success-fg">
                <CheckCircle2 className="size-4" />
                {t("check.ready")}
              </div>
            )}

            <SubmitButton
              disabled={
                effectiveIssues.length > 0 ||
                !license ||
                !isSignedIn ||
                submission.kind === "uploading" ||
                submission.kind === "success"
              }
              submission={submission}
              onSubmit={() => void handleSubmit()}
            />

            {submission.kind === "error" ? (
              <div className="space-y-2 rounded-2xl bg-chip-danger-bg p-3 text-sm text-chip-danger-fg">
                <p>{submission.message}</p>
                <p className="text-xs leading-5 text-rose-800/80">
                  {t("fallback.beforeLink")}{" "}
                  <a
                    href={buildIssueUrl(
                      parsed,
                      submission.message,
                      user?.id ?? null,
                      editedDisplayName,
                      editedDescription,
                    )}
                    target="_blank"
                    rel="noreferrer"
                    className="font-medium underline underline-offset-4 hover:text-rose-950"
                  >
                    {t("fallback.link")}
                  </a>{" "}
                  {t("fallback.afterLink")}
                </p>
              </div>
            ) : null}

            {submission.kind === "success" ? (
              <SubmissionSuccessMessage submission={submission} />
            ) : null}
          </div>
        ) : (
          <p className="mt-6 text-sm leading-6 text-muted-2">
            {t("check.empty")}
          </p>
        )}
      </aside>

      <p className="col-span-full inline-flex flex-wrap items-center gap-2 text-xs text-muted-2">
        {t("path.prefix")}
        <code className="rounded bg-surface/70 px-1.5 py-0.5 font-mono">
          {PETS_DIR}
        </code>
        <CopyPathButton path={PETS_DIR} />
        <span className="text-[#9a9aa1]">{t("path.platforms")}</span>
      </p>
    </div>
  );
}

function SubmissionSuccessMessage({
  submission,
}: {
  submission: Extract<SubmissionResult, { kind: "success" }>;
}) {
  const t = useTranslations("submit.form.success");
  const explanation = reviewExplanation(submission.review, t);
  const tone =
    submission.review.decision === "approved"
      ? "bg-chip-success-bg text-chip-success-fg"
      : submission.review.decision === "rejected"
        ? "bg-chip-danger-bg text-chip-danger-fg"
        : "bg-chip-warning-bg text-chip-warning-fg";

  return (
    <div className={`rounded-2xl p-3 text-sm ${tone}`}>
      <p>{t(submission.review.decision, { name: submission.displayName })}</p>
      {explanation ? (
        <p className="mt-2 text-xs leading-5">{explanation}</p>
      ) : null}
      {submission.review.decision === "approved" ? (
        <a
          href={`/pets/${submission.slug}`}
          className="mt-2 inline-flex font-medium underline underline-offset-4"
        >
          {t("viewPet")}
        </a>
      ) : null}
    </div>
  );
}

function reviewExplanation(
  review: SubmissionReviewOutcome,
  t: ReturnType<typeof useTranslations>,
): string | null {
  const reasonCode = review.reasonCode ?? "";
  if (reasonCode.startsWith("duplicate_")) {
    return t("details.duplicate", {
      summary: review.summary ?? t("details.duplicateFallback"),
    });
  }
  if (reasonCode.startsWith("policy_")) return t("details.policy");
  if (reasonCode.startsWith("asset_")) return t("details.assets");
  if (reasonCode === "review_timeout") return t("details.timeout");
  if (reasonCode === "review_error" || reasonCode === "review_failed") {
    return t("details.reviewFailed");
  }
  if (review.decision === "rejected") return t("details.rejectedGeneric");
  if (review.decision === "hold") return t("details.holdGeneric");
  return null;
}

function submissionErrorMessage(
  code: string,
  t: ReturnType<typeof useTranslations>,
): string {
  switch (code) {
    case "rate_limited":
      return t("errors.rateLimited");
    case "missing_field":
      return t("errors.missingField");
    case "invalid_spritesheet":
      return t("errors.invalidSpritesheet");
    case "invalid_asset_url":
      return t("errors.invalidAssetUrl");
    case "invalid_slug":
      return t("errors.invalidSlug");
    case "unauthorized":
      return t("errors.unauthorized");
    case "invalid_json":
      return t("errors.invalidJson");
    case "invalid_sprite_version":
      return t("errors.invalidSpriteVersion");
    case "unknown":
      return t("errors.submissionFailed");
    default:
      return t("errors.submissionFailedWithCode", { code });
  }
}

function CopyPathButton({ path }: { path: string }) {
  const t = useTranslations("submit.form.copy");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const t = window.setTimeout(() => setCopied(false), 1500);
    return () => window.clearTimeout(t);
  }, [copied]);

  async function handleClick(event: React.MouseEvent<HTMLButtonElement>) {
    event.preventDefault();
    event.stopPropagation();
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(path);
      } else {
        // Fallback for non-secure contexts / older Safari
        const textarea = document.createElement("textarea");
        textarea.value = path;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopied(true);
    } catch {
      /* swallow */
    }
  }

  return (
    <button
      type="button"
      aria-label={copied ? t("ariaCopied") : t("ariaCopy")}
      onClick={(e) => void handleClick(e)}
      className="inline-flex items-center gap-1 rounded-full border border-border-base bg-surface/70 px-2 py-0.5 text-[11px] font-medium text-[#3a3a44] transition hover:bg-white dark:hover:bg-stone-800"
    >
      {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
      {copied ? t("copied") : t("copy")}
    </button>
  );
}

function SubmitButton({
  disabled,
  submission,
  onSubmit,
}: {
  disabled: boolean;
  submission: SubmissionResult;
  onSubmit: () => void;
}) {
  const t = useTranslations("submit.form.submitButton");
  const label =
    submission.kind === "uploading"
      ? submission.step === "validating"
        ? t("validating")
        : submission.step === "uploading"
          ? t("uploading")
          : t("finalizing")
      : submission.kind === "success"
        ? t("submitted")
        : t("idle");

  return (
    <button
      type="button"
      onClick={onSubmit}
      disabled={disabled}
      className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-inverse px-5 text-sm font-medium text-on-inverse transition hover:bg-inverse-hover disabled:cursor-not-allowed disabled:opacity-60"
    >
      {submission.kind === "uploading" ? (
        <Loader2 className="size-4 animate-spin" />
      ) : submission.kind === "success" ? (
        <CheckCircle2 className="size-4" />
      ) : (
        <Send className="size-4" />
      )}
      {label}
    </button>
  );
}

function SpritePreview({ src }: { src: string }) {
  const t = useTranslations("submit.form.preview");
  const [index, setIndex] = useState(0);
  const animation = petStates[index];

  useEffect(() => {
    const interval = window.setInterval(() => {
      setIndex((current) => (current + 1) % petStates.length);
    }, 1500);
    return () => window.clearInterval(interval);
  }, []);

  return (
    <div className="w-fit rounded-2xl border border-border-base bg-background p-3">
      <div
        className="pet-sprite-frame"
        role="img"
        aria-label={t("ariaLabel")}
        style={{ "--pet-scale": 0.5 } as React.CSSProperties}
      >
        <div
          className="pet-sprite"
          style={
            {
              "--sprite-url": `url(${src})`,
              "--sprite-row": animation.row,
              "--sprite-frames": animation.frames,
              "--sprite-duration": `${animation.durationMs}ms`,
            } as React.CSSProperties
          }
        />
      </div>
    </div>
  );
}

// The spritesheetMissingPetInfo issue is pushed once at parse time (see
// handleFiles, bare-spritesheet path) using the pre-edit placeholder name.
// Whether it still applies depends on the *current* value of the editable
// displayName field, not on where the file came from — so it's cleared here
// once the user has typed a real name, instead of being baked into
// parsed.issues permanently.
function getEffectiveIssues(
  parsed: ParsedPet | null,
  placeholderIssueText: string,
  currentDisplayName: string,
  untitledPlaceholder: string,
): string[] {
  if (!parsed) return [];
  const hasRealName =
    currentDisplayName.trim().length > 0 &&
    currentDisplayName.trim() !== untitledPlaceholder;
  return parsed.issues.filter(
    (issue) => hasRealName || issue !== placeholderIssueText,
  );
}

function isSpritesheetImage(file: File): boolean {
  const name = file.name.toLowerCase();
  return (
    !name.endsWith(".zip") && (name.endsWith(".png") || name.endsWith(".webp"))
  );
}

// ChatGPT/Codex Desktop pet sharing exports files named
// "pet_<hash>-spritesheet.png". Stripping that pattern leaves nothing
// usable, so the caller falls back to "untitled" and the fallback GitHub
// issue flow lets the user supply a real name/description.
function deriveIdFromSpritesheetName(fileName: string): string {
  const base = fileName.replace(/\.(png|webp)$/i, "");
  const stripped = base
    .replace(/^pet_[a-f0-9]+-spritesheet$/i, "")
    .replace(/-spritesheet$/i, "")
    .trim();
  return stripped || "untitled";
}

function measureImage(url: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () =>
      resolve({ width: img.naturalWidth, height: img.naturalHeight });
    img.onerror = () => resolve({ width: 0, height: 0 });
    img.src = url;
  });
}

async function putToR2(
  url: string,
  body: Blob,
  contentType: string,
): Promise<Response> {
  // Three retries with exponential backoff. fetch() throws a generic
  // "Failed to fetch" with no diagnostic on network drop, so we wrap it
  // in XMLHttpRequest which gives us status / abort detection.
  const delays = [0, 800, 2000];
  let lastErr: Error | null = null;
  for (const delay of delays) {
    if (delay > 0) await new Promise((r) => setTimeout(r, delay));
    try {
      return await xhrPut(url, body, contentType);
    } catch (err) {
      lastErr = err as Error;
    }
  }
  throw new Error(
    `R2 PUT network error: ${lastErr?.message ?? "unknown"} (size=${body.size}, type=${contentType})`,
  );
}

function xhrPut(
  url: string,
  body: Blob,
  contentType: string,
): Promise<Response> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", url, true);
    xhr.setRequestHeader("Content-Type", contentType);
    xhr.timeout = 60_000; // 60s for a 3MB sprite is generous.
    xhr.onload = () => {
      // Construct a Response-like object the caller already expects.
      resolve(
        new Response(xhr.responseText, {
          status: xhr.status,
          statusText: xhr.statusText,
        }),
      );
    };
    xhr.onerror = () => reject(new Error("xhr network error"));
    xhr.ontimeout = () => reject(new Error("xhr timeout"));
    xhr.onabort = () => reject(new Error("xhr aborted"));
    xhr.send(body);
  });
}

function buildIssueUrl(
  parsed: ParsedPet | null,
  message: string | undefined,
  userId: string | null,
  editedDisplayName?: string,
  editedDescription?: string,
): string {
  // Prefer the edited fields the user actually submitted over the original
  // parsed snapshot, since this fallback link only renders after a failed
  // submit attempt (i.e. after the user has had a chance to edit).
  const displayName = editedDisplayName?.trim() || parsed?.displayName;
  const description = (editedDescription ?? parsed?.description)?.trim();
  const title = displayName
    ? `[Submit fail] ${displayName}`
    : "[Submit fail] Petdex upload";
  const sizeText = parsed?.spritesheetWidth
    ? `${parsed.spritesheetWidth}×${parsed.spritesheetHeight}`
    : "n/a";
  const body = [
    "## ⚠️ BEFORE YOU SUBMIT THIS ISSUE",
    "",
    "Without your pet files I cannot recover the upload. Please:",
    "",
    "- [ ] **Attach your zipped pet folder below** (drag-and-drop the .zip into the comment box). It must contain `pet.json` + `spritesheet.webp` (or `.png`).",
    "- [ ] If the pet has a backstory or tags I should add, paste them in a comment.",
    "",
    "Issues without a zip get closed after 48h because there is nothing for me to import.",
    "",
    "---",
    "",
    "## What the form captured",
    "",
    `- **Pet name:** ${displayName ?? "n/a"}`,
    `- **Pet id:** ${parsed?.petId ?? "n/a"}`,
    `- **Sprite size:** ${sizeText}`,
    `- **Source:** ${parsed?.source ?? "n/a"}`,
    `- **Error:** ${message ?? "Unknown"}`,
    userId ? `- **User id:** \`${userId}\`` : "- **User id:** (not signed in)",
    description
      ? `- **Description:**\n  > ${description.replace(/\n/g, "\n  > ")}`
      : "- **Description:** (none captured)",
    "",
    "<!-- ⬇️ Drag-and-drop your pet folder zipped here ⬇️ -->",
  ].join("\n");

  const params = new URLSearchParams({
    title,
    body,
    labels: "submit-fallback",
  });
  return `https://github.com/crafter-station/petdex/issues/new?${params.toString()}`;
}

// Resolve a DataTransfer to a flat FileList-like array. If the user dropped a
// folder, recursively walks it via webkitGetAsEntry and stamps each File with
// `webkitRelativePath` so handleFiles() can detect folder mode and find files
// by their basename.
async function readDataTransfer(dt: DataTransfer): Promise<FileList> {
  const items = Array.from(dt.items);
  const hasEntry = items.some((it) => "webkitGetAsEntry" in it);

  if (!hasEntry) {
    return dt.files;
  }

  const collected: File[] = [];
  await Promise.all(
    items.map(async (item) => {
      const entry = (
        item as DataTransferItem & {
          webkitGetAsEntry?: () => FileSystemEntry | null;
        }
      ).webkitGetAsEntry?.();
      if (!entry) {
        const f = item.getAsFile?.();
        if (f) collected.push(f);
        return;
      }
      await walkEntry(entry, "", collected);
    }),
  );

  // Build a synthetic FileList from the collected array
  const dt2 = new DataTransfer();
  for (const f of collected) dt2.items.add(f);
  return dt2.files;
}

async function walkEntry(
  entry: FileSystemEntry,
  prefix: string,
  out: File[],
): Promise<void> {
  if (entry.isFile) {
    const fileEntry = entry as FileSystemFileEntry;
    const file = await new Promise<File>((resolve, reject) =>
      fileEntry.file(resolve, reject),
    );
    // Patch webkitRelativePath so the handler treats this as folder-mode
    const path = `${prefix}${entry.name}`;
    Object.defineProperty(file, "webkitRelativePath", {
      value: path,
      writable: false,
      configurable: true,
    });
    out.push(file);
    return;
  }
  if (entry.isDirectory) {
    const dirEntry = entry as FileSystemDirectoryEntry;
    const reader = dirEntry.createReader();
    const entries = await new Promise<FileSystemEntry[]>((resolve, reject) =>
      reader.readEntries(resolve, reject),
    );
    await Promise.all(
      entries.map((child) => walkEntry(child, `${prefix}${entry.name}/`, out)),
    );
  }
}
