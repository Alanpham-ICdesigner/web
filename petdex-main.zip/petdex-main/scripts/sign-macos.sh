#!/usr/bin/env bash
# Build, sign, notarize and staple the macOS desktop app, then stage the
# release zips beside it.
#
# This runs from a workstation, not CI: the Developer ID lives in a local
# keychain. Skipping it produces an adhoc bundle that Gatekeeper rejects
# everywhere except the machine that built it, which is exactly how
# v0.3.0 first shipped.
#
# Needs ~/.config/petdex-apple/env with:
#   APPLE_API_KEY, APPLE_API_KEY_ID, APPLE_API_ISSUER, SIGN_IDENTITY
# And the caller must export NATIVE_CLI and NATIVE_SDK_PATH for the pinned
# Native SDK used by the matching CI build.
#
# Usage:
#   scripts/sign-macos.sh [output-dir] [arm64|x64]
#   gh release upload desktop-vX.Y.Z <output-dir>/*.zip --clobber
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$REPO_ROOT/dist/macos}"
if [[ "$OUT" != /* ]]; then
  OUT="$REPO_ROOT/$OUT"
fi
if [[ -n "${NATIVE_CLI:-}" && "$NATIVE_CLI" != /* ]]; then
  NATIVE_CLI="$REPO_ROOT/$NATIVE_CLI"
  export NATIVE_CLI
fi
if [[ -n "${NATIVE_SDK_PATH:-}" && "$NATIVE_SDK_PATH" != /* ]]; then
  NATIVE_SDK_PATH="$REPO_ROOT/$NATIVE_SDK_PATH"
  export NATIVE_SDK_PATH
fi
if [[ -n "${NATIVE_PACKAGER_CLI:-}" && "$NATIVE_PACKAGER_CLI" != /* ]]; then
  NATIVE_PACKAGER_CLI="$REPO_ROOT/$NATIVE_PACKAGER_CLI"
  export NATIVE_PACKAGER_CLI
fi
# Which Mac this build runs on. arm64 by default so the common case is
# unchanged; pass x64 for the Intel build (#609). Cross-compiled from
# either host: Zig does not need an Intel machine, but the signature and
# notarization still come from this keychain, so both architectures ship
# from the same workstation run.
ARCH="${2:-arm64}"
case "$ARCH" in
  arm64) ZIG_TARGET="aarch64-macos" ;;
  x64)   ZIG_TARGET="x86_64-macos" ;;
  *) echo "unknown arch: $ARCH (expected arm64 or x64)" >&2; exit 1 ;;
esac
PKG="$REPO_ROOT/packages/petdex-desktop-native"
CREDS="$HOME/.config/petdex-apple/env"

[ -f "$CREDS" ] || { echo "missing $CREDS" >&2; exit 1; }
# shellcheck disable=SC1090
set -a && . "$CREDS" && set +a

# The key path in env may be a bare filename; resolve it next to the env.
KEY="$APPLE_API_KEY"
[ -f "$KEY" ] || KEY="$(dirname "$CREDS")/$(basename "$APPLE_API_KEY")"
[ -f "$KEY" ] || { echo "missing notarization key: $APPLE_API_KEY" >&2; exit 1; }

: "${NATIVE_CLI:?set NATIVE_CLI to the native CLI built from the pinned SDK}"
: "${NATIVE_SDK_PATH:?set NATIVE_SDK_PATH to the pinned SDK checkout}"
: "${NATIVE_PACKAGER_CLI:?set NATIVE_PACKAGER_CLI to the patched Native SDK 0.10.1 CLI}"

"$(dirname "${BASH_SOURCE[0]}")/patch-native-sdk.sh"

mkdir -p "$OUT"
# Only this arch's outputs: a second run for the other arch must not
# delete what the first one produced.
rm -rf "$OUT/Petdex.app" "$OUT/petdex-desktop-darwin-$ARCH.zip" \
  "$OUT/petdex-desktop-native-darwin-$ARCH.zip" "$OUT/Petdex-$ARCH.dmg"

echo "==> build ($ARCH)"
# -Dcpu=baseline for the same reason the release workflow uses it: Zig
# targets the host CPU otherwise, and a Mac newer than the user's would
# emit instructions their machine cannot decode (#604 was exactly this
# on Windows).
(cd "$PKG" && "$NATIVE_CLI" build -Dtarget="$ZIG_TARGET" -Dcpu=baseline -Dtrace=off)

echo "==> package + sign"
# The bundle must be named Petdex.app: the name is baked into the
# signature, so renaming it afterwards breaks the seal.
ALIAS_PATH="$PKG/packaging/dmg/Applications"
rm -f "$ALIAS_PATH"
osascript - "$PKG/packaging/dmg" <<'APPLESCRIPT'
on run argv
  set outputFolder to POSIX file (item 1 of argv) as alias
  tell application "Finder"
    set createdAlias to make new alias file at outputFolder to folder "Applications" of startup disk
    set name of createdAlias to "Applications"
  end tell
end run
APPLESCRIPT
swift - "$ALIAS_PATH" <<'SWIFT'
import AppKit
import Foundation

let path = CommandLine.arguments[1]
let workspace = NSWorkspace.shared
let icon = workspace.icon(forFile: "/Applications")
icon.size = NSSize(width: 512, height: 512)
if !workspace.setIcon(icon, forFile: path, options: []) {
  exit(1)
}
SWIFT

(cd "$PKG" && "$NATIVE_PACKAGER_CLI" package \
  --target macos \
  --manifest app.package.json \
  --binary zig-out/bin/petdex-desktop-native \
  --output "$OUT/Petdex.app" \
  --signing identity \
  --identity "$SIGN_IDENTITY" \
  --archive)

PACKAGE_VERSION="$(bun -e 'const value = await Bun.file(process.argv[1]).json(); console.log(value.version)' "$PKG/app.package.json")"
PACKAGED_DMG="$OUT/petdex-desktop-native-$PACKAGE_VERSION-macos-ReleaseFast.dmg"
DMG="$OUT/Petdex-$ARCH.dmg"
mv "$PACKAGED_DMG" "$DMG"

# Agent logos are compiled into the binary, so only the app icon still
# has to survive packaging.
test -f "$OUT/Petdex.app/Contents/Resources/assets/icon.png"

echo "==> notarize"
ditto -c -k --keepParent "$OUT/Petdex.app" "$OUT/notarize.zip"
xcrun notarytool submit "$OUT/notarize.zip" \
  --key "$KEY" --key-id "$APPLE_API_KEY_ID" --issuer "$APPLE_API_ISSUER" --wait
rm -f "$OUT/notarize.zip"

echo "==> staple"
# Stapling embeds the ticket so the app opens without a network round
# trip on first launch.
xcrun stapler staple "$OUT/Petdex.app"

echo "==> verify"
spctl -a -vvv "$OUT/Petdex.app"

echo "==> dmg"
# The DMG exists to make people drag the app to Applications before
# opening it. Launching a .app straight out of Downloads triggers
# macOS App Translocation: the app runs from a random read-only path
# under /var/folders, so anything it writes that points at its own
# binary (the agent hook symlink, for one) breaks on the next boot.
# The DMG is signed and notarized in its own right: Gatekeeper checks
# the container the user actually double-clicks, not just what is
# inside it.
codesign --force --sign "$SIGN_IDENTITY" "$DMG"
xcrun notarytool submit "$DMG" \
  --key "$KEY" --key-id "$APPLE_API_KEY_ID" --issuer "$APPLE_API_ISSUER" --wait
xcrun stapler staple "$DMG"
spctl -a -vvv -t open --context context:primary-signature "$DMG"

echo "==> stage release assets"
# Both zip names carry the same notarized bundle. petdex-desktop-<target>
# is the name existing installs update through; shipping a bare
# executable under it does not work, since a lone Mach-O outside its
# bundle fails Gatekeeper the same way an unsigned app does.
ditto -c -k --keepParent "$OUT/Petdex.app" "$OUT/petdex-desktop-native-darwin-$ARCH.zip"
cp "$OUT/petdex-desktop-native-darwin-$ARCH.zip" "$OUT/petdex-desktop-darwin-$ARCH.zip"

ls -lh "$OUT"/*.zip "$DMG"
echo
echo "Upload with:"
echo "  gh release upload desktop-vX.Y.Z $OUT/*.zip $DMG --clobber"
