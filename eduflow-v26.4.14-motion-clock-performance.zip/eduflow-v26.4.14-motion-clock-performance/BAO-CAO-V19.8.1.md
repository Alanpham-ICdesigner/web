# PHMT MATH v19.8.1

## Phạm vi hoàn thành

- Nâng cấp riêng tab **Lớp học** thành trung tâm quản lý lớp và hồ sơ học sinh.
- Thêm **Nhãn lớp** tùy chọn, tối đa 10 ký tự, có bộ đếm và fallback cho lớp cũ.
- Thêm trang chi tiết lớp, bảng học sinh và các liên kết mở đúng tab hồ sơ.
- Thêm hồ sơ học sinh gồm Tổng quan, Điểm học tập, Điểm danh, Cộng/trừ điểm, Nhận xét và Hoạt động.
- Thêm lịch điểm danh tháng với trạng thái có mặt, đi trễ, có phép, không phép, không có lịch và chưa điểm danh.
- Thêm nhận xét giáo viên có preset, nội dung tự do, ngày, loại, sửa và xóa.
- Thêm báo cáo cá nhân A4; điểm danh trong báo cáo được tách thành lịch riêng từng tháng, có màu và ký hiệu.
- Tự động hiển thị thư mục tài liệu theo lớp; khi xóa thư mục, tệp được chuyển an toàn sang **Tài liệu lưu trữ** chỉ giáo viên thấy.
- Giới hạn tài liệu học sinh ở tầng API: chỉ **Tài liệu chung** và đúng thư mục lớp của học sinh mới được liệt kê/tải xuống.
- Giữ ba nút thao tác Sổ điểm trên cùng một hàng ở desktop; mobile vẫn xếp dọc.
- Loại bỏ các nút quảng bá AI còn sót ở thao tác nhanh và cuối sidebar; không thêm AI/chatbot/API AI.

## Dữ liệu và migration

Không có migration mới. `class label`, nhận xét và trạng thái thư mục lớp tận dụng `admin_items` hiện có. Không đổi schema, D1/R2 binding, Worker entry, route đăng nhập hoặc logic cộng/trừ điểm.

## File nguồn chính đã thay đổi

- `app/class-hub.tsx`
- `app/page.tsx`
- `app/globals.css`
- `app/api/admin/items/route.ts`
- `app/api/class-dashboard/route.ts`
- `app/api/student-records/[id]/route.ts`
- `app/api/documents/route.ts`
- `app/api/documents/[id]/route.ts`
- `app/api/documents/complete/route.ts`
- `app/api/student/portal/route.ts`
- `tests/class-hub.test.mjs`
- `package.json`, `package-lock.json`
- `HUONG-DAN-CAP-NHAT.txt`, `cap-nhat-cloudflare.ps1`

## Kiểm tra

Chạy `npm run lint`, `npm run build`, `npm test` và `npm run validate:artifact`. Không tự deploy production.
