# BÁO CÁO REDESIGN EDUFLOW / PHMT MATH

## Phạm vi

Bản này redesign presentation layer trên chính source V20 đã cung cấp. Hướng thiết kế được chọn là dashboard EdTech dùng hằng ngày, sạch, chuyên nghiệp, dễ quét dữ liệu và ưu tiên tốc độ thao tác.

- Design variance: 4/10.
- Motion intensity: 3/10.
- Visual density: 7/10.
- Giữ nguyên Be Vietnam Pro, logo, màu nhận diện chính và cấu trúc điều hướng.

## Redesigned

- Khung ứng dụng giáo viên: sidebar, trạng thái active, header, tìm kiếm, hồ sơ và điều hướng mobile.
- Dashboard: gom các chỉ số vào bề mặt dữ liệu thống nhất, giảm card rời, giảm shadow và gradient trang trí.
- Page header, action group, button, icon button, form, input, select, badge, card và empty state.
- Bảng học sinh, sổ điểm, lịch sử, quy tắc điểm, điểm danh, bài tập, tài liệu, thông báo, đổi quà và báo cáo.
- Trang lớp và hồ sơ chi tiết học sinh.
- Modal, popup, dropdown, toast, loading và vùng cuộn dữ liệu dài.
- Trang đăng nhập với bố cục gọn, bỏ glow và gradient thừa.
- Toàn bộ portal học sinh, gồm tổng quan, lịch và bài tập, tài liệu, kết quả, điểm danh và kho quà.

## Shared design system

File `app/redesign.css` là lớp presentation cuối cùng, sử dụng chung semantic token cho giáo viên và học sinh:

- background, surface, surface-muted;
- text, text-secondary;
- border và border-strong;
- primary, success, warning, danger, info;
- control radius, card radius, modal radius;
- focus ring, shadow và kích thước shell.

Light Mode và Dark Mode chỉ đổi token, không tạo hai hệ giao diện riêng.

## Responsive

- Có quy tắc riêng cho các nhóm màn hình 1180px, 1000px, 850px, 700px, 560px và 430px.
- CSS nền vẫn hỗ trợ toàn bộ dải 360px, 375px, 390px, 430px, 768px, 1024px, 1280px và 1440px.
- Sidebar giáo viên chuyển thành drawer dưới 850px.
- Portal học sinh chuyển sang bottom navigation dưới 700px.
- Action trên desktop nằm ngang; trên mobile tự chia hai cột hoặc xếp một cột theo chiều rộng.
- Bảng rộng giữ nguyên dữ liệu và cuộn ngang trong đúng vùng chứa.
- Danh sách học sinh của lớp chuyển thành compact card trên mobile.
- Modal dùng `100dvh`, chừa safe area và có vùng nội dung cuộn độc lập.
- Tên, mô tả, tài liệu và thông báo dài được truncate hoặc line clamp, phần chi tiết vẫn hiển thị đầy đủ.

## Dark Mode và accessibility

- Đồng bộ background, surface, border, form, table, modal, notification, badge, empty state và scrollbar.
- Contrast đã kiểm tra:
  - Light body: 15.39:1.
  - Light secondary: 5.50:1.
  - Primary button: 5.25:1.
  - Dark body: 14.75:1.
  - Dark secondary: 8.77:1.
  - Dark primary: 7.19:1.
- Focus visible áp dụng cho button, link, input, select, textarea và phần tử có `tabindex`.
- Touch target quan trọng có chiều cao khoảng 38-44px.
- `prefers-reduced-motion` tắt animation và transition không cần thiết.

## Functional regression

Kết quả `npm test`:

- 35 test passed.
- 0 failed.
- Bao phủ đăng nhập, bảo mật login, tìm kiếm, điều hướng đến học sinh, lớp, điểm danh, quy tắc điểm, bài tập, sổ điểm, tài liệu, thông báo, popup, báo cáo, responsive guardrail và deploy script.

## Backend safety

Đã so sánh với ZIP V20 gốc. Không thay đổi:

- toàn bộ `app/api`;
- D1 schema và thư mục `drizzle`;
- R2 và `r2-cors.json`;
- Worker;
- API endpoint, request payload và response payload;
- authentication, session, cookie và permission;
- `wrangler.jsonc`;
- `vite.config.ts`, `next.config.ts`, `package.json`, `package-lock.json`;
- migration;
- route;
- `cap-nhat-cloudflare.ps1`.

## Build

- `npm run build`: thành công.
- `npm test`: 35/35 passed.
- `npm run validate:artifact`: thành công.
- `npm run lint`: 0 error, còn 4 warning có sẵn từ source V20 về một component chưa dùng và dependency của React hook. Không thay đổi các hook này để tránh tác động logic đang hoạt động.

Build vẫn có warning sẵn về client chunk lớn hơn 500 kB và hai tùy chọn Wrangler không áp dụng trong Vite. Đây không phải lỗi build và không phát sinh từ lớp CSS redesign.

## Deploy

Workflow deploy một lệnh được giữ nguyên:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Script vẫn thực hiện cài dependency, build, kiểm tra artifact và deploy theo cấu hình Cloudflare hiện tại.
