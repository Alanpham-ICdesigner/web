import { index, integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const appState = sqliteTable("app_state", {
  key: text("key").primaryKey(),
  value: text("value").notNull()
});

export const adminItems = sqliteTable("admin_items", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  kind: text("kind").notNull(),
  itemKey: text("item_key").notNull(),
  title: text("title").notNull(),
  data: text("data").notNull().default("{}"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
}, function(table) {
  return [uniqueIndex("admin_items_kind_key_unique").on(table.kind, table.itemKey)];
});

export const students = sqliteTable("students", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  className: text("class_name").notNull(),
  averageScore: real("average_score").notNull().default(0),
  attendanceRate: integer("attendance_rate").notNull().default(100),
  status: text("status").notNull().default("Đang học"),
  phone: text("phone").notNull().default(""),
  email: text("email").notNull().default(""),
  createdAt: text("created_at").notNull()
});

// `students.class_name` is intentionally retained as the legacy/primary class
// snapshot. New course membership is authoritative in this join table so one
// account can safely participate in many classes without duplicating students.
export const studentEnrollments = sqliteTable("student_enrollments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  classKey: text("class_key").notNull(),
  className: text("class_name").notNull(),
  status: text("status").notNull().default("active"),
  enrolledAt: text("enrolled_at").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
}, function(table) {
  return [
    uniqueIndex("student_enrollments_student_class_unique").on(table.studentId, table.classKey),
    index("student_enrollments_student_idx").on(table.studentId),
    index("student_enrollments_class_idx").on(table.classKey)
  ];
});

export const courseSchedules = sqliteTable("course_schedules", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  classKey: text("class_key").notNull(),
  weekday: integer("weekday").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  room: text("room").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
}, function(table) {
  return [
    uniqueIndex("course_schedules_slot_unique").on(table.classKey, table.weekday, table.startTime, table.endTime),
    index("course_schedules_class_idx").on(table.classKey)
  ];
});

export const courseSessions = sqliteTable("course_sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  classKey: text("class_key").notNull(),
  className: text("class_name").notNull(),
  sessionType: text("session_type").notNull().default("makeup"),
  sessionDate: text("session_date").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  note: text("note").notNull().default(""),
  status: text("status").notNull().default("scheduled"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
}, function(table) {
  return [
    index("course_sessions_class_idx").on(table.classKey),
    index("course_sessions_date_idx").on(table.sessionDate)
  ];
});

export const assignments = sqliteTable("assignments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  className: text("class_name").notNull(),
  classKey: text("class_key").notNull().default(""),
  description: text("description").notNull().default(""),
  dueDate: text("due_date").notNull(),
  maxScore: real("max_score").notNull().default(10),
  status: text("status").notNull().default("Đang mở"),
  submittedCount: integer("submitted_count").notNull().default(0),
  totalStudents: integer("total_students").notNull().default(0),
  attachmentObjectKey: text("attachment_object_key").notNull().default(""),
  attachmentName: text("attachment_name").notNull().default(""),
  attachmentType: text("attachment_type").notNull().default(""),
  attachmentSize: integer("attachment_size").notNull().default(0),
  createdAt: text("created_at").notNull()
});

export const studentAccounts = sqliteTable("student_accounts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  pinHash: text("pin_hash").notNull(),
  pinSalt: text("pin_salt").notNull(),
  updatedAt: text("updated_at").notNull()
}, function(table) {
  return [uniqueIndex("student_accounts_student_unique").on(table.studentId)];
});

export const loginAttempts = sqliteTable("login_attempts", {
  accountKey: text("account_key").primaryKey(),
  failedAttempts: integer("failed_attempts").notNull().default(0),
  lockedUntil: integer("locked_until").notNull().default(0),
  updatedAt: text("updated_at").notNull()
});

export const pointTransactions = sqliteTable("point_transactions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  delta: integer("delta").notNull(),
  reason: text("reason").notNull(),
  source: text("source").notNull().default("admin"),
  eventKey: text("event_key"),
  createdAt: text("created_at").notNull()
}, function(table) {
  return [index("point_transactions_student_idx").on(table.studentId), uniqueIndex("point_transactions_event_unique").on(table.studentId, table.eventKey)];
});

export const pointRules = sqliteTable("point_rules", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  trigger: text("trigger").notNull(),
  points: integer("points").notNull(),
  threshold: integer("threshold").notNull().default(1),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
});

export const rewardItems = sqliteTable("reward_items", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  cost: integer("cost").notNull(),
  stock: integer("stock").notNull().default(0),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
});

export const rewardRedemptions = sqliteTable("reward_redemptions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  rewardId: integer("reward_id").notNull().references(function() { return rewardItems.id; }),
  cost: integer("cost").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: text("created_at").notNull(),
  reviewedAt: text("reviewed_at")
}, function(table) {
  return [index("reward_redemptions_student_idx").on(table.studentId), index("reward_redemptions_status_idx").on(table.status)];
});

export const assignmentSubmissions = sqliteTable("assignment_submissions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  assignmentId: integer("assignment_id").notNull().references(function() { return assignments.id; }, { onDelete: "cascade" }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  submittedAt: text("submitted_at").notNull(),
  responseText: text("response_text").notNull().default(""),
  objectKey: text("object_key").notNull().default(""),
  fileName: text("file_name").notNull().default(""),
  fileSize: integer("file_size").notNull().default(0),
  contentType: text("content_type").notNull().default(""),
  status: text("status").notNull().default("submitted"),
  score: real("score"),
  feedback: text("feedback").notNull().default(""),
  gradedAt: text("graded_at"),
  updatedAt: text("updated_at").notNull().default("")
}, function(table) {
  return [uniqueIndex("assignment_submissions_unique").on(table.assignmentId, table.studentId), index("assignment_submissions_student_idx").on(table.studentId)];
});

export const assignmentSubmissionFiles = sqliteTable("assignment_submission_files", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  submissionId: integer("submission_id").notNull().references(function() { return assignmentSubmissions.id; }, { onDelete: "cascade" }),
  objectKey: text("object_key").notNull(),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size").notNull().default(0),
  contentType: text("content_type").notNull().default(""),
  createdAt: text("created_at").notNull(),
}, function(table) {
  return [
    index("assignment_submission_files_submission_idx").on(table.submissionId),
    uniqueIndex("assignment_submission_files_object_unique").on(table.submissionId, table.objectKey),
  ];
});

// A teacher completion is an academic status, not a student submission. Keeping
// it in a separate table prevents placeholder rows from being mistaken for
// uploaded work while preserving the legacy submission table unchanged.
export const assignmentTeacherCompletions = sqliteTable("assignment_teacher_completions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  assignmentId: integer("assignment_id").notNull().references(function() { return assignments.id; }, { onDelete: "cascade" }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  completedAt: text("completed_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [
    uniqueIndex("assignment_teacher_completions_unique").on(table.assignmentId, table.studentId),
    index("assignment_teacher_completions_assignment_idx").on(table.assignmentId),
    index("assignment_teacher_completions_student_idx").on(table.studentId),
  ];
});

// V8.2 student companion: daily check-in streaks and completed focus sessions
// are isolated from academic points/attendance so gamification cannot mutate
// existing learning records or reward balances.
export const studentPetProfiles = sqliteTable("student_pet_profiles", {
  studentId: integer("student_id").primaryKey().references(function() { return students.id; }, { onDelete: "cascade" }),
  petSlug: text("pet_slug").notNull().default("punch"),
  petName: text("pet_name").notNull().default("Punch"),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  totalCheckins: integer("total_checkins").notNull().default(0),
  lastCheckinDate: text("last_checkin_date").notNull().default(""),
  freezeUsedMonth: text("freeze_used_month").notNull().default(""), // legacy V8.2 field kept for backward compatibility
  freezeLastUsedDate: text("freeze_last_used_date").notNull().default(""),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const studentDailyCheckins = sqliteTable("student_daily_checkins", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  checkinDate: text("checkin_date").notNull(),
  checkedAt: text("checked_at").notNull(),
  usedFreeze: integer("used_freeze", { mode: "boolean" }).notNull().default(false),
}, function(table) {
  return [
    uniqueIndex("student_daily_checkins_student_date_unique").on(table.studentId, table.checkinDate),
    index("student_daily_checkins_student_idx").on(table.studentId),
    index("student_daily_checkins_date_student_idx").on(table.checkinDate, table.studentId),
  ];
});



// V23 cross-device Pomodoro: one authoritative timer row per student account.
// The timer state is separate from completed focus sessions so opening another
// device can resume the same countdown without duplicating history.
export const studentFocusTimerState = sqliteTable("student_focus_timer_state", {
  studentId: integer("student_id").primaryKey().references(function() { return students.id; }, { onDelete: "cascade" }),
  mode: text("mode").notNull().default("focus"),
  status: text("status").notNull().default("idle"),
  focusMinutes: integer("focus_minutes").notNull().default(25),
  breakMinutes: integer("break_minutes").notNull().default(5),
  remainingMs: integer("remaining_ms").notNull().default(1_500_000),
  durationMs: integer("duration_ms").notNull().default(1_500_000),
  endsAt: text("ends_at").notNull().default(""),
  sessionKey: text("session_key").notNull().default(""),
  sessionId: text("session_id").notNull().default(""),
  startedAt: text("started_at").notNull().default(""),
  revision: integer("revision").notNull().default(0),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [index("student_focus_timer_running_end_idx").on(table.status, table.endsAt)];
});
// Focus Workspace: personal student tasks are intentionally separate from teacher
// assignments. Pomodoro links only count completed focus sessions and never alter LMS data.
export const studentFocusTasks = sqliteTable("student_focus_tasks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  title: text("title").notNull(),
  isDone: integer("is_done", { mode: "boolean" }).notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  targetPomodoros: integer("target_pomodoros").notNull().default(1),
  completedPomodoros: integer("completed_pomodoros").notNull().default(0),
  completedAt: text("completed_at").notNull().default(""),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [index("student_focus_tasks_student_done_sort_idx").on(table.studentId, table.isDone, table.sortOrder, table.id)];
});

export const studentFocusTaskSessions = sqliteTable("student_focus_task_sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  taskId: integer("task_id").notNull().references(function() { return studentFocusTasks.id; }, { onDelete: "cascade" }),
  sessionKey: text("session_key").notNull(),
  completedAt: text("completed_at").notNull().default(""),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [
    uniqueIndex("student_focus_task_sessions_student_session_unique").on(table.studentId, table.sessionKey),
    index("student_focus_task_sessions_task_idx").on(table.taskId, table.completedAt),
  ];
});

export const studentFocusSessions = sqliteTable("student_focus_sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  sessionKey: text("session_key").notNull(),
  focusMinutes: integer("focus_minutes").notNull(),
  startedAt: text("started_at").notNull(),
  completedAt: text("completed_at").notNull(),
  dateKey: text("date_key").notNull(),
}, function(table) {
  return [
    uniqueIndex("student_focus_sessions_student_key_unique").on(table.studentId, table.sessionKey),
    index("student_focus_sessions_student_date_idx").on(table.studentId, table.dateKey),
    index("student_focus_sessions_date_student_idx").on(table.dateKey, table.studentId),
  ];
});



// V26.3 quiet-focus push queue. Non-Pomodoro Web Push is deferred while a
// student has an active Focus countdown, then flushed by the minute cron.
export const deferredPushNotifications = sqliteTable("deferred_push_notifications", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  eventKey: text("event_key").notNull(),
  payload: text("payload").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [
    uniqueIndex("deferred_push_notifications_student_event_unique").on(table.studentId, table.eventKey),
    index("deferred_push_notifications_student_idx").on(table.studentId, table.id),
  ];
});

// V26.2.2 teacher-confirmed focus time completed outside EDUFLOW.
// This table stores only the manual daily supplement; it never fabricates or
// rewrites rows in student_focus_sessions, so completed timer history remains intact.
export const studentFocusAdjustments = sqliteTable("student_focus_adjustments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  dateKey: text("date_key").notNull(),
  manualMinutes: integer("manual_minutes").notNull().default(0),
  note: text("note").notNull().default(""),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [
    uniqueIndex("student_focus_adjustments_student_date_unique").on(table.studentId, table.dateKey),
    index("student_focus_adjustments_date_student_idx").on(table.dateKey, table.studentId),
  ];
});

// V26.2.5 immutable audit trail for each teacher change to manual focus time.
// Totals still come from student_focus_adjustments; this table exists only for
// traceability and never participates in Pomodoro session counts.
export const studentFocusAdjustmentHistory = sqliteTable("student_focus_adjustment_history", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  dateKey: text("date_key").notNull(),
  previousManualMinutes: integer("previous_manual_minutes").notNull().default(0),
  manualMinutes: integer("manual_minutes").notNull().default(0),
  deltaMinutes: integer("delta_minutes").notNull().default(0),
  trackedFocusMinutesSnapshot: integer("tracked_focus_minutes_snapshot").notNull().default(0),
  focusMinutesAfter: integer("focus_minutes_after").notNull().default(0),
  note: text("note").notNull().default(""),
  createdAt: text("created_at").notNull(),
}, function(table) {
  return [
    index("student_focus_adjustment_history_created_idx").on(table.createdAt, table.id),
    index("student_focus_adjustment_history_student_date_idx").on(table.studentId, table.dateKey, table.id),
  ];
});


// V26 Web Push subscriptions are additive and isolated from academic data.
// One browser/device endpoint can belong to one current student account.
export const pushSubscriptions = sqliteTable("push_subscriptions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  userAgent: text("user_agent").notNull().default(""),
  platform: text("platform").notNull().default(""),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
  lastSuccessAt: text("last_success_at").notNull().default(""),
  failureCount: integer("failure_count").notNull().default(0),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [
    uniqueIndex("push_subscriptions_endpoint_unique").on(table.endpoint),
    index("push_subscriptions_student_enabled_idx").on(table.studentId, table.enabled),
  ];
});

export const pushDeliveries = sqliteTable("push_deliveries", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  subscriptionId: integer("subscription_id").notNull().references(function() { return pushSubscriptions.id; }, { onDelete: "cascade" }),
  studentId: integer("student_id").notNull().references(function() { return students.id; }, { onDelete: "cascade" }),
  eventKey: text("event_key").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, function(table) {
  return [
    uniqueIndex("push_deliveries_subscription_event_unique").on(table.subscriptionId, table.eventKey),
    index("push_deliveries_student_idx").on(table.studentId, table.createdAt),
  ];
});
