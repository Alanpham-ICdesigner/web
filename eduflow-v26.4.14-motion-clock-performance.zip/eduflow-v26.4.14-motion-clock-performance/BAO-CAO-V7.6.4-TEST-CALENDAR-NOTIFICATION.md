# EDUFLOW V7.6.4 — Test Calendar Notification

- Nền: V7.6.3.
- Khi Admin tạo lịch kiểm tra theo lớp, API tạo đồng thời một notification `audience=all_students` có `classKey/className` tương ứng.
- Notification mở thẳng tab `Lịch kiểm tra` của đúng môn (`actionView=schedule`).
- Học sinh không thuộc lớp không nhìn thấy notification vì portal lọc theo enrollment.
- Khi xóa lịch kiểm tra, notification tự động liên quan cũng bị xóa để tránh thông báo cũ.
- Không thêm migration D1.
