import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const ROOT = new URL("../", import.meta.url);
const read = (path) => fs.readFileSync(new URL(path, ROOT), "utf8");

test("teacher engagement supports day week and month without duplicate date label", () => {
  const component = read("app/admin/student-engagement-stats.tsx");
  assert.match(component, /type PeriodMode = "day" \| "week" \| "month"/);
  assert.match(component, /setPeriod\("month"\)/);
  assert.match(component, /type=\{period === "month" \? "month" : "date"\}/);
  assert.doesNotMatch(component, /<strong>\{periodLabel\}<\/strong>/);
  assert.match(component, /engagement-period-meta-count-only/);
});

test("native date picker is not preceded by a duplicate custom calendar icon", () => {
  const component = read("app/admin/student-engagement-stats.tsx");
  const picker = component.match(/<label className="engagement-date-picker">[\s\S]*?<\/label>/)?.[0] || "";
  assert.match(picker, /<input/);
  assert.doesNotMatch(picker, /<CalendarDays/);
});

test("day summary uses earliest check-in while week/month show named streak leader and named focus leader", () => {
  const component = read("app/admin/student-engagement-stats.tsx");
  const route = read("app/api/admin/student-engagement/route.ts");
  assert.match(component, /Check-in sớm nhất/);
  assert.match(component, /summary\.earliestCheckin\.name/);
  assert.match(component, /summary\.topStreak\.name/);
  assert.match(component, /summary\.topFocus\.name/);
  assert.match(component, /Pomodoro nhiều nhất/);
  assert.match(route, /MIN\(checked_at\) AS earliest_period_checkin_at/);
});

test("month range is calendar-accurate and capped at today", () => {
  const route = read("app/api/admin/student-engagement/route.ts");
  assert.match(route, /monthStartDateKey/);
  assert.match(route, /monthEndDateKey/);
  assert.match(route, /mode === "month" \? monthStartDateKey/);
  assert.match(route, /naturalPeriodEnd > today \? today : naturalPeriodEnd/);
});

test("stats toolbar is collision-proof and TasteSkill motion uses transform with reduced-motion fallback", () => {
  const css = read("app/astryx-taste-deep.css");
  assert.match(css, /\.engagement-toolbar[\s\S]*grid-template-columns: max-content minmax\(0, 1fr\)/);
  assert.match(css, /\.engagement-toolbar-actions[\s\S]*grid-template-columns: minmax\(220px, 1fr\) minmax\(150px, 210px\) 38px/);
  assert.match(css, /\.engagement-date-nav[\s\S]*grid-template-columns: 36px 170px 36px max-content/);
  assert.match(css, /\.engagement-today[\s\S]*appearance: none[\s\S]*width: auto/);
  assert.match(css, /transform: translateY\(-1px\)/);
  assert.match(css, /transform: scale\(\.98\)/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
});
