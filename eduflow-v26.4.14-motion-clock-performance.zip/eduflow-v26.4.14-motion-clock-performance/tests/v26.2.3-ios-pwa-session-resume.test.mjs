import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const auth = fs.readFileSync('lib/student-auth.ts', 'utf8');
const gateway = fs.readFileSync('app/page.tsx', 'utf8');
const student = fs.readFileSync('app/student/page.tsx', 'utf8');

test('student session cookie is explicitly persistent and iOS-friendly', () => {
  assert.match(auth, /30 \* 24 \* 60 \* 60/);
  assert.match(auth, /Max-Age=/);
  assert.match(auth, /Expires=/);
  assert.match(auth, /HttpOnly/);
  assert.match(auth, /Secure/);
  assert.match(auth, /SameSite=Lax/);
});

test('standalone home-screen launch resumes an existing student session before showing login', () => {
  assert.match(gateway, /display-mode: standalone/);
  assert.match(gateway, /standalone\?: boolean/);
  assert.match(gateway, /fetch\("\/api\/student\/session", \{ cache: "no-store", credentials: "include" \}\)/);
  assert.match(gateway, /window\.location\.replace\("\/student\?source=pwa"\)/);
  assert.match(gateway, /!brandReady \|\| !standaloneSessionChecked/);
});

test('login and student bootstrap explicitly include same-origin credentials', () => {
  assert.match(gateway, /method: "POST"[\s\S]*credentials: "include"/);
  assert.match(student, /fetch\("\/api\/student\/session", \{ cache: "no-store", credentials: "include" \}\)/);
});
