import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const studio = fs.readFileSync(new URL("../app/student/focus-studio.tsx", import.meta.url), "utf8");
const css = fs.readFileSync(new URL("../app/astryx-taste-deep.css", import.meta.url), "utf8");

test("Spotify embed keeps Spotify official encrypted-media permissions", () => {
  assert.match(studio, /allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"/);
  assert.match(studio, /frameBorder="0"/);
  assert.match(studio, /loading="eager"/);
});

test("Spotify mobile recovery can hand off to Spotify and remount the embed", () => {
  assert.match(studio, /function spotifyContentUrl/);
  assert.match(studio, />Mở Spotify<\/a>/);
  assert.match(studio, />Tải lại player<\/button>/);
  assert.match(studio, /spotifyFrameRevision/);
  assert.match(studio, /key=\{mediaEmbed\.url \+ ":" \+ spotifyFrameRevision\}/);
});

test("Spotify recovery actions are compact and responsive", () => {
  assert.match(css, /focus-spotify-mobile-actions/);
  assert.match(css, /grid-template-columns: minmax\(0, 1fr\) minmax\(0, 1fr\)/);
  assert.match(css, /@media \(max-width: 420px\)/);
});
