import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const viewer = await readFile(new URL("../app/file-viewer-modal.tsx", import.meta.url), "utf8");
const css = await readFile(new URL("../app/astryx-taste-deep.css", import.meta.url), "utf8");

test("PDF viewer is portaled to document.body so fixed overlay is not trapped by animated page ancestors", () => {
  assert.match(viewer, /import \{ createPortal \} from "react-dom";/);
  assert.match(viewer, /setPortalHost\(document\.body\)/);
  assert.match(viewer, /return createPortal\(/);
  assert.match(viewer, /portalHost,/);
});

test("PDF viewer geometry is constrained to the real dynamic viewport", () => {
  assert.match(css, /\.file-viewer-overlay \{[\s\S]*width: 100dvw;[\s\S]*height: 100dvh;/);
  assert.match(css, /\.file-viewer-modal \{[\s\S]*max-width: calc\(100dvw - 20px\);[\s\S]*max-height: calc\(100dvh - 20px\);/);
});

test("PDF viewer keeps restrained motion and reduced-motion support", () => {
  assert.match(css, /@media \(prefers-reduced-motion: no-preference\)/);
  assert.match(css, /eduflow-viewer-modal-in/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
});

test("background page scrolling is restored when viewer closes", () => {
  assert.match(viewer, /previousOverflow = root\.style\.overflow/);
  assert.match(viewer, /root\.style\.overflow = "hidden"/);
  assert.match(viewer, /root\.style\.overflow = previousOverflow/);
});
