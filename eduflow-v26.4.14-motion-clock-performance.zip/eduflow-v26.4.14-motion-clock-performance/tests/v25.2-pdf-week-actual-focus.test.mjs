import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const ROOT = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, ROOT), "utf8");

test("shared teacher and student PDF viewer follows a Drive-style responsive layout", async () => {
  const [viewer, admin, student, css] = await Promise.all([
    read("app/file-viewer-modal.tsx"),
    read("app/page.tsx"),
    read("app/student/page.tsx"),
    read("app/astryx-taste-deep.css"),
  ]);
  assert.match(admin, /FileViewerModal/);
  assert.match(student, /FileViewerModal/);
  assert.match(viewer, /PdfThumbnail/);
  assert.match(viewer, /file-viewer-thumbnails/);
  assert.match(viewer, /aria-label="Số trang"/);
  assert.match(viewer, /renderedScaleRef/);
  assert.match(css, /background: #202124/);
  assert.match(css, /\.file-viewer-shell\.thumbnails-closed/);
  assert.match(css, /@media \(max-width: 760px\)[\s\S]*\.file-viewer-thumbnails/);
});

test("document tab uses continuous vertical PDF scrolling while assignment previews stay paged", async () => {
  const [viewer, admin, student, css] = await Promise.all([
    read("app/file-viewer-modal.tsx"),
    read("app/page.tsx"),
    read("app/student/page.tsx"),
    read("app/astryx-taste-deep.css"),
  ]);
  assert.match(viewer, /viewMode\?: "paged" \| "continuous"/);
  assert.match(viewer, /function PdfContinuousPage/);
  assert.match(viewer, /rootMargin: "900px 0px"/);
  assert.match(viewer, /className="file-viewer-continuous-pages"/);
  assert.match(viewer, /onScroll=\{trackContinuousPage\}/);
  assert.match(admin, /name: file\.name, url, contentType: file\.contentType, viewMode: "continuous"/);
  assert.match(student, /name: item\.name, url, contentType: item\.contentType, viewMode: "continuous"/);
  assert.match(student, /name: props\.assignment\.attachmentName, url: "\/api\/assignments\/" \+ props\.assignment\.id \+ "\/attachment", contentType: props\.assignment\.attachmentType \}/);
  assert.match(css, /\.file-viewer-canvas-wrap\.continuous/);
  assert.match(css, /\.file-viewer-continuous-page/);
});

test("teacher week statistics visibly state the returned start and end dates", async () => {
  const component = await read("app/admin/student-engagement-stats.tsx");
  assert.match(component, /Tuần từ/);
  assert.match(component, /payload\.periodStart/);
  assert.match(component, /payload\.periodEnd/);
  assert.match(component, /engagement-period-range/);
});

test("day view shows each student's current Pomodoro countdown without changing completed history", async () => {
  const [route, component, timer] = await Promise.all([
    read("app/api/admin/student-engagement/route.ts"),
    read("app/admin/student-engagement-stats.tsx"),
    read("lib/focus-timer.ts"),
  ]);
  assert.match(route, /LEFT JOIN student_focus_timer_state/);
  assert.match(route, /focus_timer_remaining_ms/);
  assert.match(route, /focusTimerStatus/);
  assert.match(route, /mode === "day" && anchorDate === today/);
  assert.match(component, /period === "day" \? <th>Pomodoro hiện tại<\/th>/);
  assert.match(component, /setInterval[\s\S]*1000/);
  assert.match(component, /setInterval[\s\S]*10_000/);
  assert.match(component, /Đang tập trung/);
  assert.match(component, /Đang tạm dừng/);
  assert.doesNotMatch(timer, /actual_focus_seconds|is_completed/);
});
