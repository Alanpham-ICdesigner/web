import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const scriptUrl = new URL("../cap-nhat-cloudflare.ps1", import.meta.url);

test("the one-command updater installs, builds, verifies, then deploys", async () => {
  const source = await readFile(scriptUrl, "utf8");

  assert.match(source, /npm\.cmd ci --include=optional --no-audit --no-fund/);
  assert.match(source, /@cloudflare\/workerd-windows-64/);
  assert.doesNotMatch(source, /Read-Host "Nhan Y de cap nhat Worker edumath"/);
  assert.match(source, /node_modules\\\.bin\\vinext\.cmd" build/);
  assert.match(source, /dist\\server\\index\.js/);
  assert.match(source, /node --test \$testFiles\.FullName/);
  assert.match(source, /node_modules\\\.bin\\wrangler\.cmd/);

  const buildIndex = source.indexOf("vinext.cmd\" build");
  const dryRunIndex = source.indexOf("deploy --config wrangler.jsonc --dry-run");
  const deployIndex = source.lastIndexOf("deploy");

  assert.ok(buildIndex >= 0 && buildIndex < dryRunIndex);
  assert.ok(dryRunIndex < deployIndex);
});
