import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("01 student UI accepts multiple supported files", () => {
  const source = read("app/student/page.tsx");
  assert.match(source, /type="file" multiple/);
  assert.match(source, /accept="image\/jpeg,image\/png,image\/webp,application\/pdf"/);
});

test("02 aggregate size is capped at 10 MB in UI and API", () => {
  assert.match(read("app/student/page.tsx"), /maxTotalSize = 10 \* 1024 \* 1024/);
  assert.match(read("app/api/student/submissions/route.ts"), /MAX_SUBMISSION_TOTAL_SIZE = 10 \* 1024 \* 1024/);
});

test("03 existing files can be viewed, downloaded, and removed", () => {
  const source = read("app/student/page.tsx");
  assert.match(source, /removeExistingFile/);
  assert.match(source, /setViewerTarget\(\{ name: file\.fileName/);
  assert.match(source, /url \+ "\?download=1"/);
});

test("04 direct resubmission does not require withdrawal", () => {
  const source = read("app/student/page.tsx");
  assert.match(source, /submission \? "Nộp lại" : "Nộp bài"/);
  assert.doesNotMatch(source, /Thu hồi bài nộp/);
});

test("05 overdue submissions are read only", () => {
  const source = read("app/student/page.tsx");
  assert.match(source, /const editable = !overdue/);
  assert.match(source, /disabled=\{!editable\}/);
  assert.match(source, /Đã hết hạn nộp bài/);
});

test("06 student save carries an optimistic revision", () => {
  assert.match(read("app/student/page.tsx"), /form\.set\("expectedUpdatedAt", submission\.updatedAt/);
  assert.match(read("app/api/student/submissions/route.ts"), /expectedUpdatedAt !== existing\.updatedAt/);
});

test("07 R2 uploads are parallel and partial failures are cleaned", () => {
  const source = read("app/api/student/submissions/route.ts");
  assert.match(source, /Promise\.allSettled\(pendingUploads\.map/);
  assert.match(source, /result\.status === "fulfilled"/);
  assert.match(source, /storageBucket\?\.delete\(file\.objectKey\)/);
});

test("08 D1 metadata replacement is an atomic guarded batch", () => {
  const source = read("app/api/student/submissions/route.ts");
  assert.match(source, /raw\.batch\(statements\)/);
  assert.match(source, /WHERE id = \? AND assignment_id = \? AND student_id = \? AND updated_at = \?/);
});

test("09 obsolete R2 objects are removed only when unreferenced", () => {
  const source = read("app/api/student/submissions/route.ts");
  assert.match(source, /SELECT 1 FROM assignment_submission_files WHERE object_key = \? LIMIT 1/);
  assert.match(source, /SELECT 1 FROM assignment_submissions WHERE object_key = \? LIMIT 1/);
  assert.match(source, /if \(!referenced\) await bucket\.delete\(key\)/);
});

test("10 teacher completion has a separate table and unique key", () => {
  const schema = read("db/schema.ts");
  assert.match(schema, /assignmentTeacherCompletions = sqliteTable\("assignment_teacher_completions"/);
  assert.match(schema, /uniqueIndex\("assignment_teacher_completions_unique"\)/);
});

test("11 teacher completion cannot replace real submitted work", () => {
  const source = read("app/api/assignments/[id]/submissions/route.ts");
  assert.match(source, /existing && isStudentSubmittedStatus\(existing\.status\)/);
  assert.match(source, /không thể thay bằng trạng thái giáo viên đánh dấu/);
});

test("12 teacher roster is canonical, searchable, filterable, and sortable", () => {
  const source = read("app/page.tsx");
  assert.match(source, /canonicalRecords = Array\.from\(new Map/);
  assert.match(source, /setSearchQuery/);
  assert.match(source, /setStatusFilter/);
  assert.match(source, /setSortBy/);
});

test("13 teacher grading opens a per-student dialog", () => {
  const source = read("app/page.tsx");
  assert.match(source, /className="submission-grader-modal"/);
  assert.match(source, /aria-label=\{"Chấm bài " \+ selectedStudent\.name\}/);
  assert.match(source, /setSelectedStudentId\(student\.id\)/);
});

test("14 graded work is read only until explicit edit", () => {
  const source = read("app/page.tsx");
  assert.match(source, /isFullyGradedSubmission\(selectedStudent\) && !editingGrade/);
  assert.match(source, />Chỉnh sửa<\/button>/);
  assert.match(source, /cancelGradeEdit\(selectedStudent\)/);
});

test("15 teacher grading carries and validates a revision", () => {
  assert.match(read("app/page.tsx"), /expectedUpdatedAt: student\.updatedAt/);
  assert.match(read("app/api/assignments/[id]/submissions/route.ts"), /eq\(assignmentSubmissions\.updatedAt, existing\.updatedAt\)/);
});

test("16 PDF viewer has navigation, zoom, fit, fullscreen, and download", () => {
  const source = read("app/file-viewer-modal.tsx");
  for (const pattern of [/Trang trước/, /Trang sau/, /ZoomIn/, /requestFullscreen/, /download=1/]) assert.match(source, pattern);
  assert.doesNotMatch(source, /Vừa chiều rộng|Vừa trang/);
});

test("17 viewer supports authenticated PDF and image preview", () => {
  const source = read("app/file-viewer-modal.tsx");
  assert.match(source, /pdfjs-dist\/build\/pdf\.mjs/);
  assert.match(source, /withCredentials: true/);
  assert.match(source, /kind === "image"/);
});

test("18 file routes default to inline and download is explicit", () => {
  const helper = read("lib/secure-file-response.ts");
  assert.match(helper, /download \? "attachment" : "inline"/);
  assert.match(helper, /private, no-store/);
  assert.match(helper, /X-Content-Type-Options/);
});

test("19 document authorization gives admin precedence", () => {
  const source = read("app/api/documents/[id]/route.ts");
  assert.match(source, /const admin = await isAdmin\(request\)/);
  assert.match(source, /const studentId = admin \? null : await getStudentSessionId\(request\)/);
  assert.match(source, /if \(studentId\)/);
});

test("20 responsive viewer and roster retain mobile controls and reduced motion", () => {
  const css = read("app/astryx-taste-deep.css");
  assert.match(css, /@media \(max-width: 760px\)/);
  assert.match(css, /@media \(max-width: 430px\)/);
  assert.match(css, /min-height: 44px/);
  assert.match(css, /prefers-reduced-motion: reduce/);
});

test("21 migration and deploy stay additive and verify before deploy", () => {
  const migration = read("drizzle/0012_assignment_lms_viewer_integrity.sql");
  const deploy = read("cap-nhat-cloudflare.ps1");
  assert.match(migration, /Đã hoàn thành theo dữ liệu cũ/);
  assert.doesNotMatch(migration, /DROP TABLE|TRUNCATE|DELETE FROM/i);
  assert.match(deploy, /assignment_teacher_completions_unique/);
  assert.doesNotMatch(deploy, /DELETE FROM login_attempts/);
  assert.ok(deploy.indexOf("d1 migrations apply") < deploy.lastIndexOf("deploy --config wrangler.jsonc --keep-vars"));
});
