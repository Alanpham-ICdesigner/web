import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const classHub = await readFile(new URL("../app/class-hub.tsx", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
const schema = await readFile(new URL("../db/schema.ts", import.meta.url), "utf8");
const security = await readFile(new URL("../lib/login-security.ts", import.meta.url), "utf8");
const adminSession = await readFile(new URL("../app/api/admin/session/route.ts", import.meta.url), "utf8");
const studentSession = await readFile(new URL("../app/api/student/session/route.ts", import.meta.url), "utf8");

test("report modal is portaled to the viewport with independent scrolling", () => {
  assert.match(classHub, /createPortal\s*\(/);
  assert.match(classHub, /document\.body/);
  assert.match(classHub, /document\.body\.style\.overflow = "hidden"/);
  assert.match(styles, /\.student-report-modal[^}]*max-height:\s*calc\(100dvh - 32px\)/s);
  assert.match(styles, /\.report-modal-body[^}]*overflow-y:\s*auto/s);
});

test("attendance calendar marks today and resolves future scheduled days", () => {
  assert.match(classHub, /APP_TIME_ZONE = "Asia\/Ho_Chi_Minh"/);
  assert.match(classHub, /days\.has\(parseDate\(date\)\.getDay\(\)\) \? "unmarked" : "none"/);
  assert.doesNotMatch(classHub, /date <= localDate\(\) \? "unmarked"/);
  assert.match(classHub, /aria-current=\{isToday \? "date" : undefined\}/);
  assert.match(styles, /\.attendance-day-date\.today/);
});

test("login throttling is persistent, server-side, and shared by both login APIs", () => {
  assert.match(schema, /sqliteTable\("login_attempts"/);
  assert.match(security, /MAX_FAILED_ATTEMPTS = 5/);
  assert.match(security, /LOGIN_LOCK_MINUTES = 15/);
  assert.match(security, /rate-limit storage failure must never block a valid login/);
  for (const route of [adminSession, studentSession]) {
    assert.match(route, /checkLoginAllowed/);
    assert.match(route, /recordFailedLogin/);
    assert.match(route, /resetFailedLogins/);
    assert.match(route, /TEMPORARILY_LOCKED/);
    assert.match(route, /remainingAttempts/);
  }
});
