import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";

function read(path) { return readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("V26 package and PWA manifest expose standalone student app", () => {
  const pkg = JSON.parse(read("package.json"));
  const manifest = JSON.parse(read("public/manifest.webmanifest"));
  assert.match(pkg.version, /^26\./);
  assert.equal(manifest.id, "/student");
  assert.match(manifest.start_url, /^\/student/);
  assert.equal(manifest.display, "standalone");
  assert.equal(manifest.scope, "/");
  assert.ok(manifest.icons.some((icon) => icon.sizes === "192x192"));
  assert.ok(manifest.icons.some((icon) => icon.sizes === "512x512"));
  assert.ok(existsSync(new URL("../public/icons/apple-touch-icon.png", import.meta.url)));
});

test("layout declares manifest and iOS Home Screen metadata", () => {
  const source = read("app/layout.tsx");
  assert.match(source, /manifest:\s*["']\/manifest\.webmanifest["']/);
  assert.match(source, /appleWebApp/);
  assert.match(source, /mobile-web-app-capable/);
  assert.match(source, /viewportFit:\s*["']cover["']/);
  assert.match(source, /apple-touch-icon\.png/);
});

test("service worker handles push, notification deep links and background badge without caching academic data", () => {
  const sw = read("public/sw.js");
  assert.match(sw, /addEventListener\(["']push["']/);
  assert.match(sw, /showNotification/);
  assert.match(sw, /addEventListener\(["']notificationclick["']/);
  assert.match(sw, /client\.navigate\(target\.href\)/);
  assert.match(sw, /clients\.openWindow\(target\.href\)/);
  assert.match(sw, /setAppBadge/);
  assert.match(sw, /clearAppBadge/);
  assert.doesNotMatch(sw, /caches\.open|cache\.put|respondWith/);
});

test("student Push settings expose required Vietnamese states and iOS A2HS gate", () => {
  const source = read("app/student/push-notification-settings.tsx");
  assert.match(source, /"Đã bật"/);
  assert.match(source, /"Chưa bật"/);
  assert.match(source, /"Bị trình duyệt chặn"/);
  assert.match(source, /display-mode:\s*standalone/);
  assert.match(source, /Notification\.requestPermission\(\)/);
  assert.match(source, /pushManager\.subscribe/);
  assert.match(source, /applicationServerKey/);
  assert.match(source, /Add to Home Screen|Thêm vào Màn hình chính/);
  assert.match(source, /\/api\/student\/push/);
});

test("student portal registers service worker, syncs unread badge and applies push deep links", () => {
  const source = read("app/student/page.tsx");
  assert.match(source, /serviceWorker\.register\(["']\/sw\.js["']/);
  assert.match(source, /setAppBadge/);
  assert.match(source, /SET_BADGE/);
  assert.match(source, /view === "messages"/);
  assert.match(source, /view === "notifications"/);
  assert.match(source, /view === "pomodoro"/);
  assert.match(source, /assignmentId/);
  assert.match(source, /PushNotificationSettings/);
});

test("push subscription API is student-authenticated and persists endpoint keys without touching academic schema", () => {
  const source = read("app/api/student/push/route.ts");
  assert.match(source, /getStudentSessionId/);
  assert.match(source, /push_subscriptions/);
  assert.match(source, /ON CONFLICT\(endpoint\) DO UPDATE/);
  assert.match(source, /enabled = 0/);
  assert.match(source, /https:/);
  assert.doesNotMatch(source, /DELETE FROM students|UPDATE assignments|UPDATE admin_items/);
});

test("additive V26 migration stores subscriptions, delivery dedupe and server Pomodoro identifiers", () => {
  const migration = read("drizzle/0013_web_push_pwa_v26.sql");
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `push_subscriptions`/);
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `push_deliveries`/);
  assert.match(migration, /push_deliveries_subscription_event_unique/);
  assert.match(migration, /ADD COLUMN `duration_ms`/);
  assert.match(migration, /ADD COLUMN `session_id`/);
  assert.doesNotMatch(migration, /DROP TABLE|DELETE FROM/);
});

test("Pomodoro remains server authoritative with one row per student and explicit V26 fields", () => {
  const schema = read("db/schema.ts");
  const timer = read("lib/focus-timer.ts");
  assert.match(schema, /studentFocusTimerState = sqliteTable\("student_focus_timer_state"/);
  assert.match(schema, /studentId: integer\("student_id"\)\.primaryKey\(\)/);
  assert.match(schema, /durationMs: integer\("duration_ms"\)/);
  assert.match(schema, /sessionId: text\("session_id"\)/);
  assert.match(timer, /startedAt:/);
  assert.match(timer, /endsAt:/);
  assert.match(timer, /status:/);
  assert.match(timer, /duration:/);
  assert.match(timer, /sessionId:/);
  assert.match(timer, /userId:/);
  assert.match(timer, /FocusTimerConflictError/);
  assert.match(timer, /WHERE student_id = \? AND revision = \?/);
});

test("Web Push sender uses VAPID, payload encryption, badge count and per-event delivery dedupe", () => {
  const source = read("lib/web-push.ts");
  assert.match(source, /aes128gcm/);
  assert.match(source, /ECDH/);
  assert.match(source, /AES-GCM/);
  assert.match(source, /VAPID_PUBLIC_KEY/);
  assert.match(source, /VAPID_PRIVATE_JWK/);
  assert.match(source, /push_deliveries/);
  assert.match(source, /subscription_id = \? AND event_key = \?/);
  assert.match(source, /badgeCount/);
  assert.match(source, /sendDuePomodoroPushes/);
  assert.match(source, /15 \* 60 \* 1000/);
  assert.match(source, /"pomodoro:" \+ String\(session\.session_key\)/);
});

test("all requested academic events trigger student Web Push with deep links", () => {
  const assignment = read("app/api/assignments/route.ts");
  const adminItems = read("app/api/admin/items/route.ts");
  const messages = read("app/api/admin/messages/route.ts");
  const grading = read("app/api/assignments/[id]/submissions/route.ts");
  assert.match(assignment, /sendPushToCourse/);
  assert.match(assignment, /tab=assignments&assignmentId=/);
  assert.match(adminItems, /kind === "calendar"/);
  assert.match(adminItems, /test-calendar:/);
  assert.match(adminItems, /kind === "notifications"/);
  assert.match(adminItems, /pushAnnouncement/);
  assert.match(adminItems, /kind === "grades"/);
  assert.match(messages, /sendPushToStudent/);
  assert.match(messages, /view=messages/);
  assert.match(grading, /Có điểm\/nhận xét mới/);
  assert.match(grading, /gradingChanged/);
  assert.match(grading, /unchanged: true/);
  assert.match(grading, /tab=assignments&assignmentId=/);
});

test("teacher notification popover can create targeted announcements without a redesign", () => {
  const source = read("app/page.tsx");
  assert.match(source, /openContentModal\("notifications"\)/);
  assert.match(source, /Gửi thông báo/);
  assert.match(source, /value=\{"class:" \+ key\}/);
  assert.match(source, /value=\{"student:" \+ item\.id\}/);
  assert.match(source, /data\.audience = "all_students"/);
  assert.match(source, /data\.audience = "student"/);
});


test("shared-device logout detaches the current student while granted subscriptions re-bind on next login", () => {
  const source = read("app/student/page.tsx");
  assert.match(source, /method: "DELETE"[\s\S]*endpoint: subscription\.endpoint/);
  assert.match(source, /Notification\.permission === "granted"/);
  assert.match(source, /method: "POST"[\s\S]*value\.endpoint \|\| subscription\.endpoint/);
  assert.match(source, /clearAppBadge/);
});

test("Cloudflare worker schedules completion reconciliation but delivery logic prevents per-minute notification spam", () => {
  const wrangler = read("wrangler.jsonc");
  const worker = read("worker/index.ts");
  const push = read("lib/web-push.ts");
  assert.match(wrangler, /"\* \* \* \* \*"/);
  assert.match(worker, /scheduled\(/);
  assert.match(worker, /sendDuePomodoroPushes/);
  assert.match(push, /INSERT OR IGNORE INTO push_deliveries/);
  assert.match(push, /if \(!await reserveDelivery/);
  assert.doesNotMatch(worker, /showNotification|sendPushToStudent/);
});

test("Cloudflare deployment workflow provisions stable VAPID secrets and verifies V26 migration", () => {
  const script = read("cap-nhat-cloudflare.ps1");
  assert.match(script, /Ensure-WebPushSecrets/);
  assert.match(script, /secret put VAPID_PUBLIC_KEY/);
  assert.match(script, /secret put VAPID_PRIVATE_JWK/);
  assert.match(script, /push_subscriptions/);
  assert.match(script, /push_deliveries/);
  assert.match(script, /duration_ms/);
  assert.match(script, /session_id/);
  assert.match(script, /vinext\.cmd" build/);
  assert.match(script, /node --test/);
});

test("V26 UI changes remain scoped and responsive with TasteSkill-style reduced-motion handling", () => {
  const css = read("app/astryx-taste-deep.css");
  assert.match(css, /student-settings-popover/);
  assert.match(css, /student-push-settings/);
  assert.match(css, /@media \(max-width: 760px\)/);
  assert.match(css, /@media \(max-width: 430px\)/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(css, /transform/);
});

test("V26 stays Web Push/PWA only and does not introduce native iOS frameworks", () => {
  const files = [
    read("package.json"),
    read("worker/index.ts"),
    read("app/student/push-notification-settings.tsx"),
    read("public/sw.js"),
  ].join("\n");
  assert.doesNotMatch(files, /@capacitor|CapacitorConfig|ActivityKit|DynamicIsland|WidgetKit/);
});
