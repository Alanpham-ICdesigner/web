import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("V26.2.5 creates an immutable audit table without changing daily summary semantics", async () => {
  const migration = await read("drizzle/0015_focus_adjustment_history.sql");
  const schema = await read("db/schema.ts");
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `student_focus_adjustment_history`/);
  assert.match(migration, /`delta_minutes` integer/);
  assert.match(migration, /`tracked_focus_minutes_snapshot` integer/);
  assert.match(migration, /INSERT INTO `student_focus_adjustment_history`[\s\S]*FROM `student_focus_adjustments` a/);
  assert.match(schema, /studentFocusAdjustmentHistory/);
  assert.match(schema, /student_focus_adjustments_student_date_unique/);
});

test("each real teacher change is written to history atomically with the daily adjustment", async () => {
  const route = await read("app/api/admin/student-engagement/route.ts");
  assert.match(route, /searchParams\.get\("view"\) === "adjustment-history"/);
  assert.match(route, /INSERT INTO student_focus_adjustment_history/);
  assert.match(route, /manualMinutes - previousManualMinutes/);
  assert.match(route, /db\.batch\(\[adjustmentStatement, historyStatement, notificationStatement\]\)/);
  assert.match(route, /db\.batch\(\[adjustmentStatement, historyStatement\]\)/);
  assert.match(route, /const noteSuffix = note \? " Ghi chú: " \+ note \+ "\." : ""/);
});

test("teacher UI shows the adjustment audit history below the manual focus form", async () => {
  const component = await read("app/admin/student-engagement-stats.tsx");
  const css = await read("app/astryx-taste-deep.css");
  assert.match(component, /Lịch sử bổ sung thời gian/);
  assert.match(component, /Ngày học/);
  assert.match(component, /Ngoài web sau lưu/);
  assert.match(component, /Cập nhật lúc/);
  assert.match(component, /formatSignedFocusDuration/);
  assert.match(css, /\.engagement-adjustment-history/);
  assert.match(css, /\.engagement-history-table/);
  assert.match(css, /@media \(max-width: 720px\)/);
});

test("smart alerts appear before streak and Pomodoro statistics", async () => {
  const page = await read("app/page.tsx");
  const alertIndex = page.indexOf("<h2>Cảnh báo thông minh</h2>");
  const engagementIndex = page.indexOf("<StudentEngagementStats");
  assert.ok(alertIndex >= 0, "smart alert card must exist");
  assert.ok(engagementIndex >= 0, "engagement stats must exist");
  assert.ok(alertIndex < engagementIndex, "smart alerts must render before engagement statistics");
});
