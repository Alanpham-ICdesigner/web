import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

function read(path) { return fs.readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("student notifications open a full detail modal and push carries notification id", () => {
  const student = read("app/student/page.tsx");
  const api = read("app/api/admin/items/route.ts");
  assert.match(student, /selectedNotification/);
  assert.match(student, /notification-detail-body/);
  assert.match(student, /setSelectedNotification\(item\)/);
  assert.match(student, /params\.get\("notificationId"\)/);
  assert.match(api, /view=notifications&notificationId=/);
});

test("message and announcement composers expose emoji picker without a new dependency", () => {
  const student = read("app/student/page.tsx");
  const admin = read("app/page.tsx");
  const picker = read("app/emoji-picker.tsx");
  assert.match(student, /EmojiPicker/);
  assert.match(admin, /Thêm emoji vào thông báo/);
  assert.match(admin, /Thêm emoji vào tin nhắn/);
  assert.match(picker, /const EMOJIS/);
});

test("student progress cards stay compact and expose detail dialogs", () => {
  const student = read("app/student/page.tsx");
  assert.match(student, /const gradePreview = grades\.slice\(0, 4\)/);
  assert.match(student, /const attendancePreview = data\.attendance\.slice\(0, 4\)/);
  assert.match(student, /const commentPreview = data\.comments\.slice\(0, 4\)/);
  assert.match(student, /setProgressDetail\("grades"\)/);
  assert.match(student, /setProgressDetail\("attendance"\)/);
  assert.match(student, /setProgressDetail\("comments"\)/);
  assert.match(student, /student-progress-detail-list scroll-region/);
});

test("deleting a class removes its attendance records instead of archiving them", () => {
  const api = read("app/api/admin/items/route.ts");
  const admin = read("app/page.tsx");
  assert.match(api, /existing\[0\]\?\.kind === "classes"/);
  assert.match(api, /eq\(adminItems\.kind, "attendance"\)/);
  assert.match(api, /belongsToDeletedClass/);
  assert.match(api, /attendanceDeleted \+= 1/);
  assert.match(admin, /relatedAttendanceItems/);
  assert.match(admin, /relatedAttendanceItems\.map[\s\S]*method: "DELETE"/);
});
