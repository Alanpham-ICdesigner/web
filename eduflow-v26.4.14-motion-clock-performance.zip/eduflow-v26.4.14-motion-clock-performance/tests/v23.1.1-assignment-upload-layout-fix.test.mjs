import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const css = fs.readFileSync(new URL("../app/astryx-taste-deep.css", import.meta.url), "utf8");

test("submission multi-file picker overrides the legacy two-column field grid", () => {
  assert.match(css, /\.lms-submission-modal \.lms-file-field\s*\{[\s\S]*?grid-template-columns:\s*minmax\(0, 1fr\)/);
  assert.match(css, /\.lms-submission-modal \.lms-file-field > \*\s*\{[\s\S]*?grid-column:\s*1 \/ -1/);
});

test("desktop picker keeps a flexible copy lane and compact file action", () => {
  assert.match(css, /\.lms-submission-modal \.lms-file-field-head\s*\{[\s\S]*?grid-template-columns:\s*38px minmax\(220px, 1fr\) auto/);
  assert.match(css, /\.lms-submission-modal \.lms-file-picker\s*\{[\s\S]*?justify-self:\s*end[\s\S]*?width:\s*auto !important/);
});

test("mobile picker has an explicit non-overlapping collapse", () => {
  assert.match(css, /@media \(max-width: 640px\)[\s\S]*?\.lms-submission-modal \.lms-file-field-head[\s\S]*?grid-template-columns:\s*36px minmax\(0, 1fr\)/);
  assert.match(css, /@media \(max-width: 640px\)[\s\S]*?\.lms-submission-modal \.lms-file-picker[\s\S]*?grid-column:\s*1 \/ -1[\s\S]*?width:\s*100% !important/);
});
