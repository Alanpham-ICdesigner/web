import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

test("class hub keeps the required student profile and attendance states", async () => {
  const source = await readFile(new URL("app/class-hub.tsx", root), "utf8");
  for (const label of ["Tổng quan", "Điểm học tập", "Điểm danh", "Cộng / trừ điểm", "Nhận xét", "Hoạt động"]) {
    assert.ok(source.includes(label));
  }
  for (const state of ["Có mặt đúng giờ", "Đi trễ", "Vắng có phép", "Vắng không phép", "Không có lịch học", "Chưa điểm danh"]) {
    assert.ok(source.includes(state));
  }
  assert.ok(source.includes("Tạo bản PDF"));
});

test("class label is limited and saved separately from class name", async () => {
  const source = await readFile(new URL("app/page.tsx", root), "utf8");
  assert.ok(source.includes('name="label"'));
  assert.ok(source.includes("maxLength={10}"));
  assert.ok(source.includes("label: String(item.label"));
});

test("student document access is restricted to common and own class folders", async () => {
  const portal = await readFile(new URL("app/api/student/portal/route.ts", root), "utf8");
  const download = await readFile(new URL("app/api/documents/[id]/route.ts", root), "utf8");
  assert.ok(portal.includes('folder === "Tài liệu chung" || folder === student.className'));
  assert.ok(download.includes('folder !== "Tài liệu chung" && folder !== studentRows[0].className'));
});

test("desktop page actions neutralize the full-width soft button rule", async () => {
  const css = await readFile(new URL("app/globals.css", root), "utf8");
  assert.ok(css.includes(".page-actions .button.soft { width: auto; margin-top: 0; }"));
});

test("global search opens the selected student inside the matching class", async () => {
  const page = await readFile(new URL("app/page.tsx", root), "utf8");
  const hub = await readFile(new URL("app/class-hub.tsx", root), "utf8");
  assert.ok(page.includes("resolveStudentNavigationTarget(student, liveClassRecords)"));
  assert.ok(page.includes('setView("classes")'));
  assert.ok(page.includes("navigationTarget={classNavigationTarget}"));
  assert.ok(hub.includes("props.navigationTarget?.studentId"));
  assert.ok(hub.includes("props.navigationTarget?.classId"));
  assert.ok(hub.includes('useState<DetailTab>("overview")'));
});

test("new gradebook resets book-specific state and table keeps scoped horizontal scrolling", async () => {
  const page = await readFile(new URL("app/page.tsx", root), "utf8");
  const css = await readFile(new URL("app/globals.css", root), "utf8");
  assert.ok(page.includes("function startNewBook()"));
  assert.ok(page.includes("setSelectedGradebookId(null)"));
  assert.ok(page.includes("setAssessments([])"));
  assert.ok(page.includes("setScores({})"));
  assert.ok(page.includes("Tạo sổ mới (chưa lưu)"));
  assert.ok(css.includes(".grade-wrap {"));
  assert.ok(css.includes("overflow: auto"));
  assert.ok(css.includes(".dynamic-grade-table .grade-assessment"));
  assert.ok(css.includes("background: var(--surface)"));
});

test("assignment detail modal uses the wider viewport-safe layout", async () => {
  const css = await readFile(new URL("app/globals.css", root), "utf8");
  assert.ok(css.includes("width:min(1080px,calc(100vw - 48px))"));
  assert.ok(css.includes("max-height:calc(100dvh - 40px)"));
  assert.ok(css.includes("overflow-wrap:anywhere"));
  assert.ok(css.includes("body:has(.modal) { overflow: hidden; }"));
  assert.match(css, /\.assignment-detail-modal\s*>\s*\.assignment-submission-list\s*\{/);
  assert.ok(css.includes("max-height: min(430px, 48dvh)"));
  assert.match(css, /\.assignment-detail-modal\s+\.assignment-submission-head\s*\{/);
});

test("all teacher and student popups are anchored to the full viewport", async () => {
  const css = await readFile(new URL("app/globals.css", root), "utf8");
  assert.match(css, /\.view-transition:has\(\.modal\)/);
  assert.match(css, /\.student-tab-transition:has\(\.student-detail-overlay\)/);
  assert.match(css, /transform:\s*none\s*!important/);
  assert.match(css, /body:has\(\.modal, \.student-detail-overlay, \.report-modal-overlay\)/);
  assert.match(css, /\.modal,[\s\S]*?\.student-detail-overlay,[\s\S]*?\.report-modal-overlay\s*\{[\s\S]*?width:\s*100vw/);
});
