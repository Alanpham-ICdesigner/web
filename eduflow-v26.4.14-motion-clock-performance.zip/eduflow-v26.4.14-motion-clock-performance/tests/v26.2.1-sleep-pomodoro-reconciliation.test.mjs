import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("Focus continues by server wall clock when every browser is hidden or laptop sleeps", async () => {
  const timerLib = await read("lib/focus-timer.ts");
  const worker = await read("worker/index.ts");
  const wrangler = await read("wrangler.jsonc");

  assert.match(timerLib, /ends_at/);
  assert.match(timerLib, /Date\.parse\(row\.ends_at\)/);
  assert.match(timerLib, /reconcileAllExpiredFocusTimers/);
  assert.match(worker, /scheduled\(/);
  assert.match(worker, /sendDuePomodoroPushes/);
  assert.match(wrangler, /"crons"\s*:\s*\[\s*"\* \* \* \* \*"/s);
});

test("reconciled Focus is backdated to the Vietnam day on which the student started it", async () => {
  const timerLib = await read("lib/focus-timer.ts");
  const route = await read("app/api/student/focus/route.ts");

  assert.match(timerLib, /function focusSessionDateKey\(startedAt: string, completedAt: Date\)/);
  assert.match(timerLib, /focusSessionDateKey\(row\.started_at, completedAt\)/);
  assert.match(route, /function focusSessionDateKey\(startedAt: Date, completedAt: Date\)/);
  assert.match(route, /focusSessionDateKey\(startedAtDate, completedAt\)/);
});

test("manual pause remains paused; sleep/background is not treated as a pause", async () => {
  const timerLib = await read("lib/focus-timer.ts");
  const component = await read("app/student/pet-focus-companion.tsx");

  assert.match(timerLib, /if \(mutation\.action === "pause"\)/);
  assert.match(timerLib, /SET status = 'paused'/);
  assert.doesNotMatch(component, /visibilityState[^\n]{0,120}sendTimerAction\("pause"\)/);
  assert.match(component, /visibilitychange/);
  assert.match(component, /syncFocusState/);
});
