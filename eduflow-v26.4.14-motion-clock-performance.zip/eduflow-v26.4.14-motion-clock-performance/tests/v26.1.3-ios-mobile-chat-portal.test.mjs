import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const page = fs.readFileSync("app/student/page.tsx", "utf8");
const css = fs.readFileSync("app/astryx-taste-deep.css", "utf8");

test("student chat is portaled outside the sticky/backdrop-filter topbar", () => {
  assert.match(page, /import \{ createPortal \} from "react-dom";/);
  assert.match(page, /messagesOpen && typeof document !== "undefined" \? createPortal\([\s\S]*messenger-student-chat[\s\S]*document\.body[\s\S]*\) : null/);
  assert.match(page, /role="dialog" aria-modal="true" aria-label="Nhắn tin với giáo viên"/);
  assert.match(page, /if \(!messagesOpen\) return;[\s\S]*document\.body\.style\.overflow = "hidden"/);
});

test("portaled chat is viewport-fixed on desktop and iOS-sized on mobile", () => {
  assert.match(css, /EDUFLOW V26\.1\.3[\s\S]*\.student-message-popover\.messenger-student-chat \{[\s\S]*position:\s*fixed;[\s\S]*top:\s*84px;[\s\S]*z-index:\s*calc\(var\(--layer-modal\) \+ 20\)/);
  assert.match(css, /@media \(max-width: 700px\) \{[\s\S]*\.student-message-popover\.messenger-student-chat \{[\s\S]*env\(safe-area-inset-top[\s\S]*bottom:\s*max\(8px, env\(safe-area-inset-bottom/);
});
