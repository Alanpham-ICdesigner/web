import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

function read(path) { return fs.readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("Pomodoro card keeps only Focus Space entry and removes the extra FOCUS badge", () => {
  const companion = read("app/student/pet-focus-companion.tsx");
  assert.doesNotMatch(companion, /focus-mode-badge/);
  assert.match(companion, />Focus Space<\/span>/);
});

test("Focus Space has local dark mode and remembers it per student", () => {
  const studio = read("app/student/focus-studio.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(studio, /eduflow-focus-theme/);
  assert.match(studio, /data-focus-theme=\{focusTheme\}/);
  assert.match(studio, /<Moon \/>/);
  assert.match(studio, /<Sun \/>/);
  assert.match(css, /focus-space-v2\[data-focus-theme="dark"\]/);
  assert.match(css, /focus-space-v2\[data-focus-theme="light"\]/);
});

test("Focus Space exposes Focus and Break modes and server supports direct break", () => {
  const studio = read("app/student/focus-studio.tsx");
  const timer = read("lib/focus-timer.ts");
  const api = read("app/api/student/focus/route.ts");
  assert.match(studio, /focus-mode-switch/);
  assert.match(studio, />Focus<\/button>/);
  assert.match(studio, />Break<\/button>/);
  assert.match(timer, /mutation\.action === "start-break"/);
  assert.match(api, /"start-break"/);
});

test("Focus Space can edit Focus and Break duration without leaving fullscreen", () => {
  const studio = read("app/student/focus-studio.tsx");
  const companion = read("app/student/pet-focus-companion.tsx");
  assert.match(studio, /focus-timer-settings/);
  assert.match(studio, /focusMinutesDraft/);
  assert.match(studio, /breakMinutesDraft/);
  assert.match(studio, /props\.onConfigure\(focus, rest\)/);
  assert.match(companion, /onConfigure=\{configureFocusSpaceDurations\}/);
});

test("clock size is capped for desktop and phone", () => {
  const css = read("app/astryx-taste-deep.css");
  assert.match(css, /font-size:\s*clamp\(86px,\s*11\.5vw,\s*166px\)/);
  assert.match(css, /font-size:\s*clamp\(68px,\s*22vw,\s*104px\)/);
});
