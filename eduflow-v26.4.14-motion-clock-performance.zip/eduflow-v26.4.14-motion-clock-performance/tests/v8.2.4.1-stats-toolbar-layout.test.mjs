import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const css = fs.readFileSync(new URL("../app/astryx-taste-deep.css", import.meta.url), "utf8");
const component = fs.readFileSync(new URL("../app/admin/student-engagement-stats.tsx", import.meta.url), "utf8");

test("engagement Today control is isolated from global full-width soft-button layout", () => {
  assert.match(component, /className="engagement-today"/);
  assert.doesNotMatch(component, /className="button soft engagement-today"/);
  const block = css.match(/\.engagement-today\s*\{[\s\S]*?\}/)?.[0] || "";
  assert.match(block, /appearance:\s*none/);
  assert.match(block, /width:\s*auto/);
  assert.match(block, /margin:\s*0/);
});

test("desktop engagement date picker uses a fixed grid lane and native picker affordance", () => {
  const nav = css.match(/\.engagement-date-nav\s*\{[\s\S]*?\}/)?.[0] || "";
  assert.match(nav, /grid-template-columns:\s*36px 170px 36px max-content/);
  const picker = css.match(/\.engagement-date-picker\s*\{[\s\S]*?\}/)?.[0] || "";
  assert.match(picker, /width:\s*170px/);
});
