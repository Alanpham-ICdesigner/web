import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const page = fs.readFileSync(new URL("../app/page.tsx", import.meta.url), "utf8");
const studentsApi = fs.readFileSync(new URL("../app/api/students/route.ts", import.meta.url), "utf8");
const assignmentsApi = fs.readFileSync(new URL("../app/api/assignments/route.ts", import.meta.url), "utf8");
const auth = fs.readFileSync(new URL("../lib/student-auth.ts", import.meta.url), "utf8");
const session = fs.readFileSync(new URL("../app/api/student/session/route.ts", import.meta.url), "utf8");
const css = fs.readFileSync(new URL("../app/astryx-taste-deep.css", import.meta.url), "utf8");

test("student editor saves a diffable multi-course selection instead of one class", () => {
  assert.match(page, /selectedClassKeys/);
  assert.match(page, /classEnrollments:/);
  assert.match(studentsApi, /desiredByKey/);
  assert.match(studentsApi, /currentActiveByKey/);
  assert.match(studentsApi, /db\.delete\(studentEnrollments\)/);
  assert.match(studentsApi, /onConflictDoUpdate/);
});

test("student PIN reset uses an app modal and never tries to reveal a one-way hash", () => {
  assert.match(page, /function StudentPinModal/);
  assert.match(page, /PIN hiện tại được mã hóa một chiều/);
  assert.doesNotMatch(page, /window\.prompt\([\s\S]*PIN 6 số cho/);
});

test("assignment queue exposes class filtering, active sidebar badge and pending grading counts", () => {
  assert.match(page, /assignment-class-filter/);
  assert.match(page, /pendingGradingCount/);
  assert.match(page, /item\.id === "assignments"[\s\S]*assignment\.status !== "Đã kết thúc"/);
  assert.match(assignmentsApi, /submission\.score === null/);
  assert.match(assignmentsApi, /!String\(submission\.feedback \|\| ""\)\.trim\(\)/);
  assert.match(css, /\.assignment-card,\s*\n\.assignment-card:nth-child\(n\)[\s\S]*grid-column:\s*auto/);
});

test("teacher mobile sidebar has an explicit logout action", () => {
  assert.match(page, /className="mobile-teacher-logout"/);
  assert.match(page, />Đăng xuất<\/span>/);
  assert.match(css, /@media \(max-width: 850px\)[\s\S]*\.mobile-teacher-logout[\s\S]*display:\s*flex/);
});

test("student login persists for 30 days and refreshes on the existing session bootstrap", () => {
  assert.match(auth, /STUDENT_SESSION_MAX_AGE_SECONDS = 30 \* 24 \* 60 \* 60/);
  assert.match(auth, /Max-Age=" \+ STUDENT_SESSION_MAX_AGE_SECONDS/);
  assert.match(auth, /HttpOnly; Secure; SameSite=Lax/);
  assert.match(auth, /Expires=/);
  assert.match(session, /"Set-Cookie": await studentSessionCookie\(studentId\)/);
});
