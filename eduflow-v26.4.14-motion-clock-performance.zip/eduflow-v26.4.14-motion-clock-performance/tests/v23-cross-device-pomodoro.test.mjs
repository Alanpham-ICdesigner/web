import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("V23 migration adds one authoritative timer row per student without destructive SQL", async () => {
  const sql = await read("drizzle/0009_cross_device_focus_timer.sql");
  assert.match(sql, /CREATE TABLE IF NOT EXISTS `student_focus_timer_state`/i);
  assert.match(sql, /`student_id` integer PRIMARY KEY NOT NULL/i);
  assert.match(sql, /`status` text DEFAULT 'idle' NOT NULL/i);
  assert.match(sql, /`revision` integer DEFAULT 0 NOT NULL/i);
  assert.match(sql, /student_focus_timer_running_end_idx/i);
  assert.doesNotMatch(sql, /\bDROP\b|\bTRUNCATE\b|\bDELETE\s+FROM\b|\bALTER\s+TABLE\b/i);
  assert.doesNotMatch(sql, /point_transactions|attendance_records|assignments/i);
});

test("server is authoritative for timer lifecycle and uses revision compare-and-swap", async () => {
  const timerLib = await read("lib/focus-timer.ts");
  const route = await read("app/api/student/focus/route.ts");
  assert.match(timerLib, /student_focus_timer_state/);
  assert.match(timerLib, /expectedRevision !== current\.revision/);
  assert.match(timerLib, /WHERE student_id = \? AND revision = \?/);
  assert.match(timerLib, /FocusTimerConflictError/);
  assert.match(timerLib, /crypto\.randomUUID\(\)/);
  assert.match(route, /action:\s*action|action,/);
  assert.match(route, /revision,/);
  assert.match(route, /status:\s*409/);
});

test("expired Focus is recorded once and the next phase waits instead of being consumed in the background", async () => {
  const timerLib = await read("lib/focus-timer.ts");
  assert.match(timerLib, /INSERT OR IGNORE INTO student_focus_sessions/);
  assert.match(timerLib, /mode = 'break', status = 'paused'/);
  assert.match(timerLib, /remaining_ms = break_minutes \* 60000/);
  assert.match(timerLib, /ends_at = '', session_key = '', started_at = ''/);
  assert.match(timerLib, /student_focus_sessions_student_key_unique|session_key/);
  assert.match(timerLib, /mode = 'focus', status = 'idle'/);
});

test("student client hydrates server time, polls lightly, and resyncs immediately on app return", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  assert.match(component, /serverNow/);
  assert.match(component, /clockOffsetRef/);
  assert.match(component, /\?timerOnly=1/);
  assert.match(component, /10_000/);
  assert.match(component, /visibilitychange/);
  assert.match(component, /window\.addEventListener\("focus"/);
  assert.match(component, /window\.addEventListener\("online"/);
  assert.match(component, /body:\s*JSON\.stringify\(\{ action, revision: timerRef\.current\.revision/);
  assert.match(component, /normalized\.timer\.revision < previous\.revision/);
  assert.doesNotMatch(component, /TIMER_STORAGE_KEY|safeStoredTimer|backgroundedAt/);
});

test("teacher engagement stats reconcile expired background Focus sessions before aggregating", async () => {
  const adminRoute = await read("app/api/admin/student-engagement/route.ts");
  const timerLib = await read("lib/focus-timer.ts");
  assert.match(adminRoute, /reconcileAllExpiredFocusTimers/);
  assert.match(adminRoute, /await reconcileAllExpiredFocusTimers\(db, new Date\(\)\)/);
  assert.match(timerLib, /WHERE status = 'running' AND ends_at <> '' AND ends_at <= \?/);
});

test("deploy workflow verifies the V23 timer table and expiry index before replacing the Worker", async () => {
  const deploy = await read("cap-nhat-cloudflare.ps1");
  assert.match(deploy, /student_focus_timer_state/);
  assert.match(deploy, /student_focus_timer_running_end_idx/);
  assert.match(deploy, /Migration V23/);
  const migrationPos = deploy.indexOf("d1 migrations apply");
  const deployPos = deploy.lastIndexOf("wrangler.cmd\" deploy");
  assert.ok(migrationPos >= 0 && deployPos > migrationPos);
});
