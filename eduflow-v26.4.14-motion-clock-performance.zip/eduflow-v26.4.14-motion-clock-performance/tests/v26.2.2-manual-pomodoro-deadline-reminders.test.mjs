import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const root = path.resolve(import.meta.dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("V26.2.2 stores manual Pomodoro supplements separately from completed timer sessions", () => {
  const migration = read("drizzle/0014_manual_focus_adjustments.sql");
  const schema = read("db/schema.ts");
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `student_focus_adjustments`/);
  assert.match(migration, /UNIQUE INDEX IF NOT EXISTS `student_focus_adjustments_student_date_unique`/);
  assert.match(schema, /export const studentFocusAdjustments = sqliteTable\("student_focus_adjustments"/);
  assert.doesNotMatch(migration, /UPDATE\s+`?student_focus_sessions`?/i);
  assert.doesNotMatch(migration, /DELETE\s+FROM\s+`?student_focus_sessions`?/i);
});

test("teacher day stats sum tracked + manual minutes and expose a day adjustment editor", () => {
  const route = read("app/api/admin/student-engagement/route.ts");
  const component = read("app/admin/student-engagement-stats.tsx");
  assert.match(route, /period_manual AS/);
  assert.match(route, /trackedFocusMinutes \+ manualFocusMinutes/);
  assert.match(route, /export async function PATCH\(request: Request\)/);
  assert.match(route, /manualMinutes > 1440/);
  assert.match(route, /trackedFocusMinutes \+ manualMinutes > 1440/);
  assert.match(component, /Bổ sung Pomodoro theo ngày/);
  assert.match(component, /Web ghi nhận/);
  assert.match(component, /Thời gian bổ sung ngoài web/);
  assert.match(component, /Tổng sau điều chỉnh/);
  assert.match(component, /setPayload\(next\)/);
  assert.match(component, /Cập nhật ngay ở Ngày \/ Tuần \/ Tháng/);
});

test("manual minute changes notify only the targeted student and trigger Web Push", () => {
  const route = read("app/api/admin/student-engagement/route.ts");
  assert.match(route, /INSERT INTO admin_items/);
  assert.match(route, /await db\.batch\(\[adjustmentStatement, historyStatement, notificationStatement\]\)/);
  assert.match(route, /INSERT INTO student_focus_adjustment_history/);
  assert.match(route, /audience: "student"/);
  assert.match(route, /studentId,/);
  assert.match(route, /category: "pomodoro_adjustment"/);
  assert.match(route, /sendPushToStudent\(studentId/);
  assert.match(route, /if \(minutesChanged\)/);
  assert.match(route, /học ngoài EDUFLOW/);
});

test("upcoming assignment reminders reuse the exact six-hour status and skip completed students", () => {
  const status = read("lib/assignment-status.ts");
  const push = read("lib/web-push.ts");
  const assignmentsRoute = read("app/api/assignments/route.ts");
  assert.match(status, /deadline - now <= 6 \* 60 \* 60 \* 1000/);
  assert.match(push, /getAssignmentStatus\(String\(assignment\.due_date \|\| ""\), now\.getTime\(\)\) === "Sắp hết hạn"/);
  assert.match(push, /status === "submitted" \|\| status === "graded" \|\| status === "teacher_completed"/);
  assert.match(push, /assignment_teacher_completions/);
  assert.match(push, /INSERT OR IGNORE INTO admin_items/);
  assert.match(push, /assignment-due:/);
  assert.match(assignmentsRoute, /sendUpcomingAssignmentReminders\(new Date\(\)\)/);
  assert.match(assignmentsRoute, /getAssignmentStatus\(assignment\.dueDate\) === "Sắp hết hạn"/);
  assert.match(push, /audience: "student"/);
  assert.match(push, /actionView: "assignments"/);
});

test("deadline scan runs hourly without changing the existing once-per-minute Pomodoro cron", () => {
  const worker = read("worker/index.ts");
  const wrangler = read("wrangler.jsonc");
  assert.match(wrangler, /"\* \* \* \* \*"/);
  assert.match(worker, /sendDuePomodoroPushes/);
  assert.match(worker, /scheduledNow\.getUTCMinutes\(\) === 0/);
  assert.match(worker, /sendUpcomingAssignmentReminders/);
});
