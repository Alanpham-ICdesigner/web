import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("Petdex picker is portaled outside transformed LMS surfaces and traps focus", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  assert.match(component, /import \{ createPortal \} from "react-dom"/);
  assert.match(component, /createPortal\([\s\S]*document\.body/);
  assert.match(component, /body\.style\.position = "fixed"/);
  assert.match(component, /document\.addEventListener\("keydown", handleKeyDown\)/);
  assert.match(component, /event\.key === "Escape"/);
  assert.match(component, /event\.key !== "Tab"/);
  assert.match(component, /previouslyFocused\?\.focus\(\)/);
});

test("Pet choice is previewed locally and persisted only by the confirmation action", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  const route = await read("app/api/student/pet/route.ts");
  assert.match(component, /const \[petDraft, setPetDraft\]/);
  assert.match(component, /onClick=\{function\(\) \{ setPetDraft\(choice\); \}\}/);
  assert.match(component, /Sử dụng Pet này/);
  assert.match(component, /async function choosePet\(\)/);
  assert.match(component, /body: JSON\.stringify\(\{ petSlug: choice\.slug \}\)/);
  assert.match(route, /UPDATE student_pet_profiles SET pet_slug = \?, updated_at = \?/);
  assert.doesNotMatch(component, /Chỉ tải pet bạn đang xem\/chọn|Action vẫn dùng chung với Punch|Không nhúng cả thư viện/);
});

test("Petdex catalog paginates and filters only real manifest metadata", async () => {
  const catalog = await read("lib/petdex-catalog.ts");
  const route = await read("app/api/student/pets/route.ts");
  // V26.4.3 follows Petdex manifest/v2 exactly: kind is field #2 and
  // version comes from spriteVersionNumber (#7). Legacy object manifests are
  // still supported as a fallback.
  assert.match(catalog, /const kind = asString\(item\[2\]\)\.toLowerCase\(\)/);
  assert.match(catalog, /const spriteVersionNumber = item\[7\] === 2 \? 2 : 1/);
  assert.match(catalog, /kind: asString\(item\.kind\)\.toLowerCase\(\)/);
  assert.match(catalog, /version: spriteVersionNumber === 2 \? "v2" : "v1"/);
  assert.match(route, /searchParams\.get\("offset"\)/);
  assert.match(route, /searchParams\.get\("kind"\)/);
  assert.match(route, /searchParams\.get\("tag"\)/);
  assert.match(route, /searchParams\.get\("version"\)/);
  assert.match(route, /nextOffset/);
  assert.match(route, /facets: \{ kinds, tags, versions \}/);
});

test("Pet sprites load lazily through the same-origin EDUFLOW proxy and retry automatically", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  const catalog = await read("lib/petdex-catalog.ts");
  const assetRoute = await read("app/api/student/pets/asset/route.ts");
  assert.match(component, /new IntersectionObserver/);
  assert.match(component, /rootMargin: "240px 0px"/);
  assert.match(component, /automaticRetry/);
  assert.match(component, /eduflow_retry=/);
  assert.doesNotMatch(component, />Thử tải lại<\/button>/);
  assert.match(catalog, /assets\.petdex\.dev/);
  assert.match(catalog, /const assetBase = trustedAssetUrl\(root\.assetBase\)/);
  assert.match(catalog, /new URL\(text, base\)/);
  assert.match(catalog, /proxiedPetdexAsset/);
  assert.match(catalog, /\/api\/student\/pets\/asset\?/);
  assert.match(assetRoute, /isAllowedPetdexAsset\(source\)/);
  assert.match(assetRoute, /const upstream = await fetch\(source/);
  assert.match(assetRoute, /return new Response\(upstream\.body/);
  assert.doesNotMatch(assetRoute, /Response\.redirect/);
  // Picker renders a cropped first sprite frame instead of relying on a
  // separate thumb.webp that may not exist for every community asset key.
  assert.match(component, /pet-choice-preview"><PetSprite state="idle"/);
  assert.match(component, /pet-picker-current-preview"><PetSprite state="idle"/);
});

test("Petdex modal uses dynamic viewport, safe areas, internal scroll and fixed footer", async () => {
  const css = await read("app/astryx-taste-deep.css");
  assert.match(css, /\.pet-picker-backdrop[\s\S]*width: 100dvw;[\s\S]*height: 100dvh;/);
  assert.match(css, /\.pet-picker-dialog[\s\S]*height: min\(90dvh, 820px\)/);
  assert.match(css, /env\(safe-area-inset-top/);
  assert.match(css, /env\(safe-area-inset-bottom/);
  assert.match(css, /\.pet-picker-scroll[\s\S]*overflow-y: auto/);
  assert.match(css, /\.pet-picker-footer[\s\S]*calc\(12px \+ env\(safe-area-inset-bottom/);
  assert.match(css, /@media \(max-height: 620px\) and \(pointer: coarse\)/);
});

test("service worker does not precache or intercept Petdex assets", async () => {
  const serviceWorker = await read("public/sw.js");
  assert.doesNotMatch(serviceWorker, /addEventListener\("fetch"/);
  assert.doesNotMatch(serviceWorker, /petdex|spritesheet/i);
});
