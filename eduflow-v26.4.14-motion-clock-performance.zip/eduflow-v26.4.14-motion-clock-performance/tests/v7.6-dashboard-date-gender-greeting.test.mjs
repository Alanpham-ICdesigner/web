import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const page = await readFile(new URL("app/page.tsx", root), "utf8");

test("dashboard attendance is scoped to current Vietnam date instead of newest saved record", () => {
  assert.match(page, /const dashboardAttendanceDate = localDateInTimeZone\(\)/);
  assert.match(page, /String\(item\.data\.date \|\| ""\) === dashboardAttendanceDate/);
  assert.match(page, /markedAttendance \? attendance \+ "%" : "—"/);
  assert.match(page, /markedAttendance \? "Chuyên cần" : "Chưa điểm danh"/);
});

test("dashboard greeting follows Vietnam time and configured teacher gender", () => {
  assert.match(page, /gender: "male" \| "female"/);
  assert.match(page, /function greetingForTime/);
  assert.match(page, /hour >= 5 && hour < 12/);
  assert.match(page, /hour >= 12 && hour < 18/);
  assert.match(page, /gender === "female" \? "Cô" : "Thầy"/);
  assert.match(page, /name="gender"/);
  assert.match(page, /Nam \(xưng hô Thầy\)/);
  assert.match(page, /Nữ \(xưng hô Cô\)/);
});

test("today teaching dashboard no longer uses hard-coded date and filters current weekday", () => {
  assert.match(page, /const todayLabel = new Intl\.DateTimeFormat\("vi-VN"/);
  assert.match(page, /schedule\.weekday === todayWeekday/);
  assert.match(page, /<p>\{todayLabel\}<\/p>/);
  assert.doesNotMatch(page, /Thứ Ba, 11 tháng 8/);
});
