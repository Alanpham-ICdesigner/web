import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const root = process.cwd();
const read = (...parts) => fs.readFileSync(path.join(root, ...parts), "utf8");

test("V26.4.14 stays based on V26.4.13 and loads the performance layer last", () => {
  const pkg = JSON.parse(read("package.json"));
  const layout = read("app", "layout.tsx");
  assert.equal(pkg.version, "26.4.14");
  assert.equal(fs.existsSync(path.join(root, "VERSION-V26.4.13-SPOTIFY-MOBILE-PLAYBACK-FIX.txt")), true);
  assert.match(layout, /import "\.\/astryx-taste-deep\.css";\s*import "\.\/motion-performance\.css";/);
  assert.equal(fs.existsSync(path.join(root, "build", "sites-vite-plugin.ts")), true);
});

test("digital and flip clocks keep stable geometry and only animate changing half leaves", () => {
  const studio = read("app", "student", "focus-studio.tsx");
  const css = read("app", "motion-performance.css");
  assert.match(studio, /const DigitalClock = memo/);
  assert.match(studio, /focus-digital-slot/);
  assert.match(studio, /key=\{"m-" \+ index\}/);
  assert.doesNotMatch(studio, /key=\{index \+ "-" \+ digit\}/);
  assert.match(studio, /focus-flip-leaf-top/);
  assert.match(studio, /focus-flip-leaf-bottom/);
  assert.match(css, /\.focus-digital-slot[\s\S]*width: \.68em/);
  assert.match(css, /@keyframes eduflow-flap-top/);
  assert.match(css, /@keyframes eduflow-flap-bottom/);
  assert.match(css, /animation: none !important;[\s\S]*perspective: 780px/);
});

test("Pomodoro and pet motion avoid high-frequency React rerenders", () => {
  const companion = read("app", "student", "pet-focus-companion.tsx");
  const css = read("app", "motion-performance.css");
  assert.doesNotMatch(companion, /setInterval\(tick, 500\)/);
  assert.match(companion, /Math\.ceil\(current\.remainingMs \/ 1000\) === nextSecond/);
  assert.match(companion, /boundary \+ 18/);
  assert.doesNotMatch(companion, /setInterval\(function\(\) \{ setFrame/);
  assert.match(companion, /className="petdex-sprite-track"/);
  assert.match(css, /animation: eduflow-pet-sprite/);
  assert.match(css, /steps\(var\(--pet-frame-steps\), end\)/);
});

test("Focus Space removes paint-heavy continuous blur and motion", () => {
  const css = read("app", "motion-performance.css");
  assert.match(css, /\.focus-space-v2 \.focus-timer-aura[\s\S]*animation: none !important/);
  assert.match(css, /\.focus-space-v2 \.focus-studio-topbar,[\s\S]*backdrop-filter: none !important/);
  assert.match(css, /@keyframes eduflow-window-enter/);
  assert.match(css, /animation: eduflow-window-enter 150ms/);
});
