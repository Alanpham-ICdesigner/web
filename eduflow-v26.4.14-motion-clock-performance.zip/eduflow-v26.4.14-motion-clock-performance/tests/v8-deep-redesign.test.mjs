import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const layout = fs.readFileSync(new URL("../app/layout.tsx", import.meta.url), "utf8");
const css = fs.readFileSync(new URL("../app/astryx-taste-deep.css", import.meta.url), "utf8");
const adminPage = fs.readFileSync(new URL("../app/page.tsx", import.meta.url), "utf8");
const studentPage = fs.readFileSync(new URL("../app/student/page.tsx", import.meta.url), "utf8");

test("deep redesign layer loads last and keeps one semantic token system", function () {
  assert.match(layout, /redesign\.css[\s\S]*astryx-taste\.css[\s\S]*astryx-taste-deep\.css/);
  assert.match(css, /--radius-control:\s*12px/);
  assert.match(css, /--radius-card:\s*18px/);
  assert.match(css, /--radius-modal:\s*22px/);
  assert.match(css, /:root\[data-theme="dark"\]/);
});

test("teacher and student shells use asymmetric grids with explicit mobile collapse", function () {
  assert.match(css, /\.kpi-grid\s*\{[\s\S]*repeat\(6/);
  assert.match(css, /\.lms-course-grid\s*\{[\s\S]*repeat\(12/);
  assert.match(css, /\.class-hub-grid,[\s\S]*repeat\(12/);
  assert.match(css, /@media \(max-width: 820px\)/);
  assert.match(css, /@media \(max-width: 560px\)/);
});

test("accessibility fallbacks cover navigation, motion and transparency", function () {
  assert.match(adminPage, /className="skip-link" href="#teacher-main-content"/);
  assert.match(studentPage, /className="skip-link" href="#student-main-content"/);
  assert.match(css, /prefers-reduced-motion: reduce/);
  assert.match(css, /prefers-reduced-transparency: reduce/);
});
