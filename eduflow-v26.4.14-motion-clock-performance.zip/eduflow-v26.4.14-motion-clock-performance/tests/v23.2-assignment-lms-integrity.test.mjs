import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("student submission states remain compatible while teacher completion is separate", () => {
  const helper = read("lib/assignment-submission.ts");
  const schema = read("db/schema.ts");
  assert.match(helper, /COMPLETED_SUBMISSION_STATUSES = \["submitted", "graded"\]/);
  assert.match(helper, /status === "teacher_completed"/);
  assert.match(schema, /assignmentTeacherCompletions/);
});

test("student can directly add, remove, and resubmit files before the deadline", () => {
  const api = read("app/api/student/submissions/route.ts");
  const ui = read("app/student/page.tsx");
  assert.match(api, /removeFileIds/);
  assert.match(api, /expectedUpdatedAt/);
  assert.doesNotMatch(api, /Vui lòng thu hồi bài nộp trước khi chỉnh sửa hoặc nộp lại/);
  assert.doesNotMatch(ui, />Thu hồi bài nộp</);
  assert.match(ui, /submission \? "Nộp lại" : "Nộp bài"/);
});

test("multi-file upload uses parallel R2 work and one guarded D1 batch", () => {
  const api = read("app/api/student/submissions/route.ts");
  assert.match(api, /Promise\.allSettled\(pendingUploads\.map/);
  assert.match(api, /raw\.batch\(statements\)/);
  assert.match(api, /updated_at = \?/);
  assert.match(api, /deleteUnreferencedObjects/);
});

test("teacher drafts and canonical roster rows are isolated by student id", () => {
  const ui = read("app/page.tsx");
  assert.match(ui, /useState<Record<number, \{ score: string; feedback: string \}>>/);
  assert.match(ui, /new Map\(records\.map\(function\(student\)/);
  assert.match(ui, /updateStudentDraft\(selectedStudent\.id/);
  assert.match(ui, /key=\{props\.assignment\.id \+ "-" \+ student\.id\}/);
});

test("legacy completion migration is additive and leaves real work untouched", () => {
  const migration = read("drizzle/0012_assignment_lms_viewer_integrity.sql");
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `assignment_teacher_completions`/);
  assert.match(migration, /NOT EXISTS[\s\S]*assignment_submission_files/);
  assert.doesNotMatch(migration, /DROP TABLE|TRUNCATE|DELETE FROM/i);
});

test("assignment modal refreshes on visibility without a heavy modal polling loop", () => {
  const teacher = read("app/page.tsx");
  assert.match(teacher, /document\.addEventListener\("visibilitychange", onVisibility\)/);
  const modal = teacher.slice(teacher.indexOf("function AssignmentDetailModal"), teacher.indexOf("function AssignmentsView"));
  assert.doesNotMatch(modal, /setInterval/);
});

test("submission mutations reject stale student and teacher revisions", () => {
  const studentApi = read("app/api/student/submissions/route.ts");
  const teacherApi = read("app/api/assignments/[id]/submissions/route.ts");
  assert.match(studentApi, /expectedUpdatedAt !== existing\.updatedAt/);
  assert.match(studentApi, /SubmissionConflictError/);
  assert.match(teacherApi, /String\(payload\.expectedUpdatedAt \|\| ""\) !== existing\.updatedAt/);
  assert.match(teacherApi, /status: 409/);
});
