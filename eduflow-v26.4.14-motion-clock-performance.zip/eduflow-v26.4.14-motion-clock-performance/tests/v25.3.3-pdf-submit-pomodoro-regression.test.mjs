import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const ROOT = new URL("../", import.meta.url);
const read = (path) => fs.readFileSync(new URL(path, ROOT), "utf8");

test("current Pomodoro header matches the compact typography of neighboring sortable columns", () => {
  const stats = read("app/admin/student-engagement-stats.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(stats, /period === "day" \? <th>Pomodoro hiện tại<\/th>/);
  assert.match(css, /\.engagement-table\.has-live-focus th:nth-child\(8\) \{[^}]*font-size: 10px;[^}]*font-weight: 800;/);
});

test("PDF toolbar keeps the V26.1 manual-zoom layout without legacy fit controls", () => {
  const source = read("app/file-viewer-modal.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.doesNotMatch(source, /Vừa chiều rộng|Vừa trang|file-viewer-fit-controls/);
  assert.doesNotMatch(css, /\.file-viewer-fit-controls/);
  assert.match(css, /@media \(max-width: 1440px\) \{[\s\S]*\.file-viewer-toolbar \{[\s\S]*grid-template-rows: auto;/);
});

test("student submission files use a raw streaming R2 upload before the JSON commit", () => {
  const student = read("app/student/page.tsx");
  const upload = read("app/api/student/submissions/upload/route.ts");
  const commit = read("app/api/student/submissions/route.ts");
  const nextConfig = read("next.config.ts");
  assert.match(student, /fetch\("\/api\/student\/submissions\/upload\?" \+ query\.toString\(\), \{[\s\S]*method: "PUT"[\s\S]*body: file/);
  assert.match(student, /headers: \{ "Content-Type": "application\/json" \}[\s\S]*uploadedFiles/);
  assert.match(upload, /await bucket\.put\(objectKey, request\.body,/);
  assert.match(upload, /await bucket\.head\(objectKey\)/);
  assert.match(commit, /uploadedFiles\?: Array/);
  assert.match(commit, /await storageBucket\.head\(file\.objectKey\)/);
  assert.match(nextConfig, /bodySizeLimit: "12mb"/);
});

test("failed direct uploads can be cleaned without deleting already referenced submission objects", () => {
  const upload = read("app/api/student/submissions/upload/route.ts");
  const student = read("app/student/page.tsx");
  assert.match(upload, /SELECT 1 FROM assignment_submission_files WHERE object_key = \? LIMIT 1/);
  assert.match(upload, /SELECT 1 FROM assignment_submissions WHERE object_key = \? LIMIT 1/);
  assert.match(student, /method: "DELETE"[\s\S]*objectKeys: uploadedFiles\.map/);
});
