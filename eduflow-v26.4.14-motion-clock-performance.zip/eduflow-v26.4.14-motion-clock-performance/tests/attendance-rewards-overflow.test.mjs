import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

function section(source, start, end) {
  return source.slice(source.indexOf(start), source.indexOf(end));
}

test("all four attendance states and all-present save only attendance data", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const saveFlow = section(page, "async function saveAttendance", "async function saveGrades");
  const allPresentFlow = section(page, "function allPresent", "function setStatus");

  assert.match(saveFlow, /putAdminItem\(\s*"attendance"/);
  assert.match(saveFlow, /session\.storageKey/);
  assert.doesNotMatch(saveFlow, /rewards|points?|transaction|applyRule/i);
  assert.doesNotMatch(allPresentFlow, /fetch\(|rewards|points?|transaction|applyRule/i);
  for (const status of ["present", "late", "allowed", "absent"])
    assert.ok(page.includes('["' + status + '"'));
});

test("editing or deleting attendance never reconciles point transactions", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const deleteFlow = section(page, "async function deleteAttendance", "async function createFolder");
  assert.match(deleteFlow, /api\/admin\/items/);
  assert.doesNotMatch(deleteFlow, /rewards|points?|transaction|hoàn tác/i);

  await assert.rejects(
    readFile(new URL("../app/api/rewards/events/route.ts", import.meta.url), "utf8"),
    function (error) { return error && error.code === "ENOENT"; },
  );
  await assert.rejects(
    readFile(new URL("../lib/attendance-rewards.mjs", import.meta.url), "utf8"),
    function (error) { return error && error.code === "ENOENT"; },
  );
});

test("every active point rule remains available for manual application", async () => {
  const [page, rewardsRoute] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/api/rewards/admin/route.ts", import.meta.url), "utf8"),
  ]);
  assert.ok(page.includes("return rule.active;"));
  assert.ok(!page.includes('rule.active && rule.trigger !== "assignment_streak"'));
  assert.ok(page.includes("Hiển thị đủ"));
  assert.ok(page.includes("pointRuleTriggerLabels[rule.trigger]"));
  assert.ok(rewardsRoute.includes('requestedTrigger === "assignment_streak" ? "assignment_streak" : "manual"'));
  const manualFlow = section(rewardsRoute, 'if (action === "apply_rules")', 'if (action === "save_rule")');
  assert.match(manualFlow, /pointTransactions/);
  assert.match(manualFlow, /source: "selected_rule"/);
});

test("the rule editor no longer asks teachers to choose an application method", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const editor = section(page, "{ruleForm ? (", "{rewardForm ? (");

  assert.ok(!editor.includes("Cách áp dụng"));
  assert.ok(!editor.includes('name="trigger"'));
  assert.ok(page.includes('trigger: ruleForm?.trigger || "manual"'));
});

test("growing histories retain all data inside bounded scroll regions", async () => {
  const [adminPage, studentPage, styles, portal] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/student/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
    readFile(new URL("../app/api/student/portal/route.ts", import.meta.url), "utf8"),
  ]);
  for (const className of [
    "attendance-roster-scroll",
    "attendance-history-scroll",
    "student-table-scroll",
  ]) assert.ok(adminPage.includes(className));
  for (const className of [
    "student-document-list",
    "student-attendance-scroll",
    "student-grade-scroll",
    "reward-history-scroll",
  ]) assert.ok(studentPage.includes(className));
  assert.ok(!studentPage.includes("data.attendance.slice(0, 12)"));
  assert.ok(studentPage.includes("item.createdAt"));
  assert.ok(portal.includes("createdAt: item.createdAt"));
  assert.ok(portal.includes("String(b.createdAt).localeCompare(String(a.createdAt))"));
  assert.match(styles, /\.scroll-region\s*\{/);
  assert.match(styles, /\.student-document-list\s*\{/);
  assert.match(styles, /max-height:/);
  assert.match(styles, /overflow-y:\s*auto/);
}
);

test("teacher documents keep the original row layout and canonical filename", async () => {
  const [adminPage, documentRoute, completeRoute] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/api/documents/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/api/documents/complete/route.ts", import.meta.url), "utf8"),
  ]);
  assert.ok(adminPage.includes('className="card files"'));
  assert.ok(!adminPage.includes("teacher-document-scroll"));
  assert.ok(adminPage.includes("<strong title={file.name}>{file.name}</strong>"));
  assert.match(documentRoute, /\.\.\.data, name: row\.title/);
  assert.match(completeRoute, /\.\.\.data, name: row\.title/);
});

test("empty states, attendance history, folder delete and student notice actions stay aligned", async () => {
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.match(styles, /\.attendance-history\s*>\s*div\.attendance-history-scroll:not\(\.card-head\)\s*\{/);
  assert.match(styles, /\.empty-row,[\s\S]*?flex-direction:\s*row\s*!important/);
  assert.match(styles, /\.folder-grid\s+\.folder\s*\{[\s\S]*?grid-template-columns:\s*36px minmax\(0, 1fr\) 36px/);
  assert.match(styles, /\.folder-grid\s+\.folder\s+\.folder-delete\s*\{[\s\S]*?width:\s*32px/);
  assert.match(styles, /\.student-shell\s*>\s*header\s+\.student-notice-popover footer button\s*\{[\s\S]*?justify-content:\s*center/);
});
