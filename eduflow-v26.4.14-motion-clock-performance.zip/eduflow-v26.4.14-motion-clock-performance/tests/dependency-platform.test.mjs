import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const readJson = async (path) => JSON.parse(await readFile(new URL("../" + path, import.meta.url), "utf8"));

test("Windows workerd binary is pinned as an optional platform dependency", async () => {
  const [pkg, lock] = await Promise.all([readJson("package.json"), readJson("package-lock.json")]);
  assert.equal(pkg.optionalDependencies?.["@cloudflare/workerd-windows-64"], "1.20260515.1");
  assert.equal(lock.packages?.[""]?.optionalDependencies?.["@cloudflare/workerd-windows-64"], "1.20260515.1");
  assert.equal(lock.packages?.["node_modules/@cloudflare/workerd-windows-64"]?.os?.[0], "win32");
  assert.equal(lock.packages?.["node_modules/@cloudflare/workerd-windows-64"]?.cpu?.[0], "x64");
});
