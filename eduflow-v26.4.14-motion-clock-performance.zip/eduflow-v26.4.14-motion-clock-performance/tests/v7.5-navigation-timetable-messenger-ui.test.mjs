import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("teacher sidebar can be reordered by drag and persists locally", async () => {
  const [page, css] = await Promise.all([read("app/page.tsx"), read("app/redesign.css")]);
  assert.match(page, /eduflow-admin-nav-order-v1/);
  assert.match(page, /draggable=\{!collapsed\}/);
  assert.match(page, /onDragStart/);
  assert.match(page, /moveNavItem/);
  assert.match(page, /sidebar-drag-handle/);
  assert.match(css, /\.sidebar nav button\[draggable="true"\]/);
  assert.match(css, /cursor: grab/);
});

test("student and teacher timetables scroll vertically from a safe early range and cycle overlap cards", async () => {
  const [admin, student, css] = await Promise.all([read("app/page.tsx"), read("app/student/page.tsx"), read("app/redesign.css")]);
  assert.match(admin, /timetableScrollRef/);
  assert.match(admin, /cycleScheduleFocus/);
  assert.match(admin, /7 \* 60 - rangeStart/);
  assert.match(student, /timetableScrollRef/);
  assert.match(student, /cycleEvent/);
  assert.match(student, /7 \* 60 - rangeStart/);
  assert.match(css, /\.weekly-timetable-scroll[\s\S]*?overflow: auto !important/);
  assert.match(css, /\.weekly-timetable-day-head[\s\S]*?position: sticky/);
});

test("long histories are bounded with automatic scroll regions", async () => {
  const css = await read("app/redesign.css");
  assert.match(css, /\.attendance-history-scroll,[\s\S]*?\.reward-history-scroll,[\s\S]*?\.comment-history,[\s\S]*?max-height:/);
  assert.match(css, /overscroll-behavior: contain/);
  assert.match(css, /scrollbar-gutter: stable/);
});

test("messaging is messenger-like and direct rather than course-scoped", async () => {
  const [admin, student, adminApi, studentApi, css] = await Promise.all([
    read("app/page.tsx"), read("app/student/page.tsx"), read("app/api/admin/messages/route.ts"), read("app/api/student/messages/route.ts"), read("app/redesign.css"),
  ]);
  assert.match(admin, /messenger-teacher-chat/);
  assert.match(admin, /teacher-message-search/);
  assert.match(admin, /teacher-message-conversation-list/);
  assert.doesNotMatch(admin, /teacherMessageCourseKey/);
  assert.match(student, /messenger-student-chat/);
  assert.doesNotMatch(student, /messageCourseKey/);
  assert.doesNotMatch(adminApi, /classKey\?: string; body\?: string/);
  assert.doesNotMatch(studentApi, /classKey\?: string; body\?: string/);
  assert.match(css, /\.teacher-message-messenger/);
});
