import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { formatDateKey, mondayDateKey, shiftDateKey } from "../lib/admin-ui-utils.mjs";

const ROOT = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, ROOT), "utf8");

test("date-key week math is timezone-neutral for the current Vietnam week", () => {
  assert.equal(mondayDateKey("2026-09-06"), "2026-08-31");
  assert.equal(shiftDateKey("2026-08-31", 6), "2026-09-06");
  assert.equal(shiftDateKey("2026-09-06", 1), "2026-09-07");
  assert.equal(formatDateKey("2026-09-06", "vi-VN", { day: "2-digit", month: "2-digit" }).replace(/\D/g, ""), "0609");
});

test("teacher Today button no longer converts local midnight through UTC ISO", async () => {
  const page = await read("app/page.tsx");
  assert.match(page, /useState\(function\(\) \{ return mondayDateKey\(localDateInTimeZone\(\)\); \}\)/);
  assert.match(page, /setWeekStart\(mondayDateKey\(localDateInTimeZone\(\)\)\)/);
  assert.match(page, /shiftDateKey\(current, delta \* 7\)/);
  assert.match(page, /function dateAt\(offset: number\) \{ return shiftDateKey\(weekStart, offset\); \}/);
  assert.doesNotMatch(page, /new Date\(localDateInTimeZone\(\) \+ "T00:00:00"\)/);
});

test("legacy test-calendar dates are derived from their stored timestamp instead of August 2026", async () => {
  const page = await read("app/page.tsx");
  assert.doesNotMatch(page, /month === "2026-08"/);
  assert.match(page, /localDateInTimeZone\(timestampDate\)\.slice\(0, 7\)/);
});

test("server-side fallback date uses Vietnam date rather than UTC date", async () => {
  const route = await read("app/api/student-records/[id]/route.ts");
  assert.match(route, /vietnamDateKey\(\)/);
  assert.doesNotMatch(route, /new Date\(\)\.toISOString\(\)\.slice\(0, 10\)/);
});

test("class reports and comment defaults use the Vietnam calendar date", async () => {
  const hub = await read("app/class-hub.tsx");
  assert.match(hub, /const to = appToday\(\);/);
  assert.match(hub, /shiftAppDateKey\(to, -days\)/);
  assert.match(hub, /useState\(appToday\(\)\)/);
  assert.doesNotMatch(hub, /const today = new Date\(\);[\s\S]{0,300}today\.getFullYear\(\)/);
});
