import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("Lich hoc admin becomes a class-specific test calendar and student course tab shows only test calendar", async () => {
  const [admin, student, portal] = await Promise.all([
    read("app/page.tsx"),
    read("app/student/page.tsx"),
    read("app/api/student/portal/route.ts"),
  ]);
  assert.match(admin, /id: "calendar", label: "Lịch kiểm tra"/);
  assert.match(admin, /title="Lịch kiểm tra"/);
  assert.match(admin, /data\.classKey = selectedClassKey/);
  assert.match(admin, /data\.type = "Kiểm tra"/);
  assert.match(admin, /classes=\{liveClassRecords\}/);
  assert.match(student, /\["schedule", "Lịch kiểm tra", CalendarDays\]/);
  assert.match(student, /function CourseTestCalendar/);
  assert.match(student, /<CourseTestCalendar items=\{data\.calendar\}/);
  assert.match(student, /<StudentWeeklyTimetable courses=\{homeData\.courses\} sessions=\{homeData\.sessions\} aggregate/);
  assert.match(portal, /String\(data\.classKey \|\| ""\) === requestedCourseKey/);
});

test("Thi dua page places student points before rules and gift inventory", async () => {
  const admin = await read("app/page.tsx");
  const points = admin.indexOf("<h2>Điểm học sinh</h2>");
  const rules = admin.indexOf("<h2>Quy tắc cộng / trừ điểm</h2>");
  const gifts = admin.indexOf("<h2>Kho quà</h2>");
  assert.ok(points > 0 && rules > 0 && gifts > 0);
  assert.ok(points < rules);
  assert.ok(points < gifts);
});

test("teacher schedule keeps class, time, room visible and raises the selected overlapping class", async () => {
  const [admin, css] = await Promise.all([read("app/page.tsx"), read("app/redesign.css")]);
  assert.match(admin, /teacher-event-class/);
  assert.match(admin, /teacher-event-time/);
  assert.match(admin, /teacher-event-room/);
  assert.match(admin, /zIndex: isFocused \? 40/);
  assert.match(admin, /eventHeight = isFocused \? Math\.max\(124, naturalHeight\)/);
  assert.match(css, /\.teacher-event\.active/);
  assert.match(css, /\.teacher-event\.overlap:not\(\.active\)/);
});

test("TasteSkill interaction audit gives pointer cursors to clickable controls", async () => {
  const css = await read("app/redesign.css");
  assert.match(css, /button:not\(:disabled\)[\s\S]*?\[role="button"\][\s\S]*?cursor: pointer;/);
  assert.match(css, /button:disabled[\s\S]*?cursor: not-allowed;/);
});
