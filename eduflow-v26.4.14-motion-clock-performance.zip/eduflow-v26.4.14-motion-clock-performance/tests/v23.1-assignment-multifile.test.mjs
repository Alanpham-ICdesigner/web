import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const read = (p) => fs.readFileSync(path.join(root,p),'utf8');

test('student assignment links are rendered as explicit open-link actions', () => {
  const source = read('app/student/page.tsx');
  assert.match(source, /function RichAssignmentDescription/);
  assert.match(source, />Mở liên kết<\/a>/);
  assert.match(source, /target="_blank"/);
});

test('student can select multiple submission files with a 10 MB aggregate limit', () => {
  const ui = read('app/student/page.tsx');
  const api = read('app/api/student/submissions/route.ts');
  assert.match(ui, /type="file" multiple/);
  assert.match(ui, /Tổng dung lượng tất cả tệp tối đa 10 MB/);
  assert.match(api, /MAX_SUBMISSION_TOTAL_SIZE = 10 \* 1024 \* 1024/);
  assert.match(api, /form\.getAll\("files"\)/);
});

test('multi-file submission storage is additive and teacher can open every file', () => {
  const migration = read('drizzle/0010_assignment_submission_multifile.sql');
  const teacher = read('app/page.tsx');
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `assignment_submission_files`/);
  assert.doesNotMatch(migration, /DROP TABLE|TRUNCATE/i);
  assert.match(teacher, /submission-review-files/);
  assert.match(teacher, /\/api\/submission-files\//);
});

test('TasteSkill upload surface hides native file chrome and preserves reduced motion', () => {
  const css = read('app/redesign.css');
  assert.match(css, /\.lms-file-input \{ position: absolute !important/);
  assert.match(css, /\.lms-file-field-head/);
  assert.match(css, /prefers-reduced-motion: reduce/);
});
