import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const pageSource = await readFile(
  new URL("../app/page.tsx", import.meta.url),
  "utf8",
);

test("login quote is editable in teacher settings and rendered on login", () => {
  assert.match(pageSource, /name="loginQuote"/);
  assert.match(pageSource, /maxLength=\{180\}/);
  assert.match(pageSource, /profile\?\.data\.loginQuote/);
  assert.match(pageSource, /“\{loginQuote\}”/);
});
