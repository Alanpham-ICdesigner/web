import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../app/student/page.tsx', import.meta.url), 'utf8');

test('student header helper captions requested for removal are absent', () => {
  const removed = [
    'Chọn một môn để xem tài liệu, bài tập và kết quả riêng của môn đó.',
    'Xem toàn bộ lịch của các môn đang học trong cùng một thời khóa biểu tuần.',
    'Chọn một món quà, sau đó xác nhận đổi bằng điểm thi đua chung.',
    'Cập nhật theo xử lý của giáo viên.',
    'Những nội dung cần chú ý gần nhất.',
    'Lịch kiểm tra riêng của môn',
    'Tài liệu chung và tài liệu riêng của',
    'Nộp ảnh hoặc PDF, sau đó xem điểm và nhận xét của giáo viên.',
    'Dữ liệu được tách riêng theo môn',
    'Theo từng mốc học tập.'
  ];
  for (const text of removed) assert.equal(source.includes(text), false, text);
});

test('functional student content remains', () => {
  for (const text of ['Các môn học của tôi', 'Lịch học tổng hợp', 'Quà có thể đổi', 'Lịch sử đổi quà', 'Lịch kiểm tra', 'Tài liệu', 'Bài tập', 'Điểm / Quá trình học', 'Nhận xét giáo viên']) {
    assert.equal(source.includes(text), true, text);
  }
});
