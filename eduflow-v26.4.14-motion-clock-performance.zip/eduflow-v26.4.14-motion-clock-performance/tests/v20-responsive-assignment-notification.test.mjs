import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

test("assignment totals count distinct students and distinct assignments", async () => {
  const [assignmentRoute, submissionRoute, studentSubmissionRoute, portalRoute, studentPage] = await Promise.all([
    readFile(new URL("app/api/assignments/route.ts", root), "utf8"),
    readFile(new URL("app/api/assignments/[id]/submissions/route.ts", root), "utf8"),
    readFile(new URL("app/api/student/submissions/route.ts", root), "utf8"),
    readFile(new URL("app/api/student/portal/route.ts", root), "utf8"),
    readFile(new URL("app/student/page.tsx", root), "utf8"),
  ]);

  assert.match(assignmentRoute, /activeStudentsByClass/);
  assert.match(assignmentRoute, /submittedStudentIds\.size/);
  assert.match(assignmentRoute, /pendingGradingCount/);
  assert.match(submissionRoute, /new Set\(submissionRows\.concat\(completionRows\)/);
  assert.match(submissionRoute, /submittedStudentIds/);
  assert.match(studentSubmissionRoute, /const completedCount = new Set\(completedSubmissionRows\.concat\(completedTeacherRows\)/);
  assert.match(portalRoute, /submissions: Array\.from\(new Set\(/);
  assert.ok(studentPage.includes("{completed.size}/{data.assignments.length} bài đã làm"));
  assert.ok(!studentPage.includes("{data.submissions.length}/{data.assignments.length} bài đã làm"));
});

test("ten assignments with one completed assignment still report completed as one", () => {
  const assignments = Array.from({ length: 10 }, function (_, index) { return { id: index + 1 }; });
  const legacyRows = [
    { assignmentId: 1, studentId: 7 },
    { assignmentId: 1, studentId: 7 },
  ];
  const completedAssignmentIds = new Set(legacyRows.map(function (row) { return row.assignmentId; }));
  const submittedStudentIds = new Set(legacyRows.map(function (row) { return row.studentId; }));

  assert.equal(assignments.length, 10);
  assert.equal(completedAssignmentIds.size, 1);
  assert.equal(submittedStudentIds.size, 1);
});

test("notification action stays above a separately scrollable list", async () => {
  const [adminPage, studentPage, styles] = await Promise.all([
    readFile(new URL("app/page.tsx", root), "utf8"),
    readFile(new URL("app/student/page.tsx", root), "utf8"),
    readFile(new URL("app/globals.css", root), "utf8"),
  ]);

  for (const source of [adminPage, studentPage]) {
    const actionIndex = source.indexOf('className="notice-action"');
    const listIndex = source.indexOf('className="notification-list"', actionIndex);
    assert.ok(actionIndex >= 0 && listIndex > actionIndex);
    assert.match(source, /if \(markingAllNotifications\) return/);
  }
  assert.match(styles, /\.notification-list\s*\{[\s\S]*?overflow-y:\s*auto/);
  assert.match(styles, /\.notice-popover,[\s\S]*?\.student-notice-popover\s*\{[\s\S]*?overflow:\s*hidden/);
});

test("long content is clamped and mobile tables scroll inside their wrappers", async () => {
  const styles = await readFile(new URL("app/globals.css", root), "utf8");
  assert.match(styles, /\.assignment-card h2,[\s\S]*?-webkit-line-clamp:\s*2/);
  assert.match(styles, /overflow-wrap:\s*anywhere/);
  assert.match(styles, /\.student-table-scroll\.scroll-region,[\s\S]*?overflow-x:\s*auto/);
  assert.match(styles, /-webkit-overflow-scrolling:\s*touch/);
  assert.doesNotMatch(styles, /(?:html|body)\s*,?\s*(?:html|body)?\s*\{[^}]*overflow-x:\s*hidden/);
});
