import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("V23 supersedes local V8.2.5 background state with an account-synced wall-clock timer", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  const route = await read("app/api/student/focus/route.ts");
  const timerLib = await read("lib/focus-timer.ts");

  assert.match(component, /normalizeServerTimer/);
  assert.match(component, /serverNow/);
  assert.match(component, /clockOffsetRef\.current/);
  assert.match(component, /timer\.endAt - serverNowEstimate/);
  assert.match(component, /syncFocusState\(false, true\)/);
  assert.doesNotMatch(component, /previousMode[\s\S]*sendTimerAction\("resume-break"\)/);
  assert.match(route, /timerOnly/);
  assert.match(timerLib, /ends_at/);
  assert.match(timerLib, /Date\.parse\(row\.ends_at\)/);
  assert.match(timerLib, /mode = 'break', status = 'paused'/);
  assert.match(timerLib, /mode = 'focus', status = 'idle'/);
  assert.doesNotMatch(component, /eduflow-focus-timer-v1|backgroundedAt|safeStoredTimer/);
});
