import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

function read(path) { return readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("V26.1 Push remains automatic and point updates target only the affected student", () => {
  const assignments = read("app/api/assignments/route.ts");
  const points = read("app/api/rewards/admin/route.ts");
  const notifications = read("app/page.tsx");
  assert.match(assignments, /sendPushToCourse/);
  assert.match(points, /sendPushToStudent\(studentId/);
  assert.match(points, /points-batch:/);
  assert.match(points, /selectedRules\.map/);
  assert.match(notifications, /Gửi thông báo/);
  const student = read("app/student/page.tsx");
  assert.match(student, /view === "rewards"/);
  assert.match(student, /id="student-rewards"/);
});

test("V26.1 student chat and Push settings are viewport-contained on phones and desktop", () => {
  const css = read("app/astryx-taste-deep.css");
  const settings = read("app/student/push-notification-settings.tsx");
  assert.match(css, /student-message-popover\.messenger-student-chat[\s\S]*position:\s*fixed/);
  assert.match(css, /safe-area-inset-bottom/);
  assert.match(css, /student-settings-popover[\s\S]*position:\s*fixed/);
  assert.doesNotMatch(settings, /Không dùng Apple Developer/);
  assert.match(settings, /tự gửi/);
});

test("V26.1 teacher assignment detail includes description", () => {
  const source = read("app/page.tsx");
  assert.match(source, /aria-label="Mô tả bài tập"/);
  assert.match(source, /props\.assignment\.description/);
});

test("V26.1 PDF viewer opens at 100 percent and keeps only manual zoom controls", () => {
  const source = read("app/file-viewer-modal.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(source, /useState\(1\)/);
  assert.match(source, /setFit\("custom"\)/);
  assert.match(source, /ZoomOut/);
  assert.match(source, /ZoomIn/);
  assert.doesNotMatch(source, /Vừa chiều rộng|Vừa trang|file-viewer-fit-controls/);
  assert.doesNotMatch(css, /\.file-viewer-fit-controls/);
});
