import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const ROOT = new URL("../", import.meta.url);
async function text(path) {
  return readFile(new URL(path, ROOT), "utf8");
}

test("teacher analytics adds an on-demand day/week/month engagement table", async () => {
  const page = await text("app/page.tsx");
  const component = await text("app/admin/student-engagement-stats.tsx");
  assert.match(page, /StudentEngagementStats/);
  assert.match(component, /Điểm danh streak & Pomodoro/);
  assert.match(component, /period === "day"/);
  assert.match(component, /period === "week"/);
  assert.match(component, /period === "month"/);
  assert.match(component, /type=\{period === "month" \? "month" : "date"\}/);
  assert.match(component, /Tất cả lớp/);
  assert.match(component, /Tìm tên hoặc mã học sinh/);
  assert.match(component, /payload\?\.periodDayCount/);
});

test("every requested engagement metric is sortable without a new API request", async () => {
  const component = await text("app/admin/student-engagement-stats.tsx");
  for (const key of ["name", "class", "checkins", "currentStreak", "longestStreak", "totalCheckins", "focusMinutes"]) {
    assert.match(component, new RegExp(`toggleSort\\(\\"${key}\\"\\)`));
  }
  assert.match(component, /aria-sort=/);
  assert.match(component, /useMemo/);
});

test("engagement endpoint is admin-only and aggregates only the requested date range", async () => {
  const route = await text("app/api/admin/student-engagement/route.ts");
  assert.match(route, /from "\.\.\/\.\.\/\.\.\/\.\.\/lib\/admin-auth"/);
  assert.match(route, /requireAdmin\(request\)/);
  assert.match(route, /WHERE checkin_date >= \? AND checkin_date <= \?/);
  assert.match(route, /WHERE date_key >= \? AND date_key <= \?/);
  assert.match(route, /COALESCE\(p\.current_streak, 0\)/);
  assert.match(route, /COALESCE\(f\.focus_minutes, 0\)/);
  assert.match(route, /MIN\(checked_at\) AS earliest_period_checkin_at/);
  assert.match(route, /monthEndDateKey/);
  assert.match(route, /naturalPeriodEnd > today \? today : naturalPeriodEnd/);
  assert.match(route, /periodDayCount/);
  assert.match(route, /Cache-Control.*no-store/);
});

test("date-first D1 indexes are additive and deploy is guarded", async () => {
  const migration = await text("drizzle/0008_teacher_engagement_stats_indexes.sql");
  const schema = await text("db/schema.ts");
  const deploy = await text("cap-nhat-cloudflare.ps1");
  assert.match(migration, /CREATE INDEX IF NOT EXISTS `student_daily_checkins_date_student_idx`/);
  assert.match(migration, /CREATE INDEX IF NOT EXISTS `student_focus_sessions_date_student_idx`/);
  assert.doesNotMatch(migration, /\b(?:DROP|DELETE|TRUNCATE)\b/i);
  assert.match(schema, /student_daily_checkins_date_student_idx/);
  assert.match(schema, /student_focus_sessions_date_student_idx/);
  assert.match(deploy, /Test-D1Index/);
  assert.match(deploy, /Migration V8\.2\.4 chua tao index/);
});

test("Astryx/TasteSkill table patterns are preserved for responsive analytics", async () => {
  const css = await text("app/astryx-taste-deep.css");
  assert.match(css, /Astryx table\/filter patterns \+ TasteSkill redesign rule/);
  assert.match(css, /\.engagement-table-scroll[\s\S]*overflow: auto/);
  assert.match(css, /\.engagement-table th:first-child,[\s\S]*position: sticky/);
  assert.match(css, /@media \(max-width: 560px\)/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
});
