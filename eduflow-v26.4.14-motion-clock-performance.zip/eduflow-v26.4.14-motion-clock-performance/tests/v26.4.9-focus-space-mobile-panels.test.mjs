import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

function read(path) { return fs.readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("Task Music and Notes can remain open together on mobile", () => {
  const studio = read("app/student/focus-studio.tsx");
  assert.match(studio, /function togglePanel\(panel: FloatingPanel\)/);
  assert.doesNotMatch(studio, /if \(next && mobile\) \{ setMusicExpanded\(false\); setNotesPanelOpen\(false\); \}/);
  assert.doesNotMatch(studio, /if \(next && mobile\) \{ setTaskPanelOpen\(false\); setNotesPanelOpen\(false\); \}/);
  assert.doesNotMatch(studio, /if \(next && mobile\) \{ setTaskPanelOpen\(false\); setMusicExpanded\(false\); \}/);
  assert.match(studio, /setFrontPanel\(panel\)/);
});

test("portrait panels open centered and landscape panels default to the left", () => {
  const studio = read("app/student/focus-studio.tsx");
  assert.match(studio, /defaultMobilePanelPosition/);
  assert.match(studio, /Math\.round\(\(viewport\.width - width\) \/ 2\)/);
  assert.match(studio, /if \(landscape\)[\s\S]*return \{ x: 10,/);
  assert.match(studio, /placeMobilePanel\("tasks"\)/);
  assert.match(studio, /placeMobilePanel\("music"\)/);
  assert.match(studio, /placeMobilePanel\("notes"\)/);
});

test("mobile rotate button has an iOS/PWA manual landscape fallback", () => {
  const studio = read("app/student/focus-studio.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(studio, /setManualLandscape\(true\)/);
  assert.match(studio, /aria-pressed=\{manualLandscape\}/);
  assert.match(css, /orientation: portrait[\s\S]*focus-space-v2\.manual-landscape[\s\S]*rotate\(90deg\)/);
});

test("Break is manual both after Focus ends and when selecting Break", () => {
  const companion = read("app/student/pet-focus-companion.tsx");
  const timer = read("lib/focus-timer.ts");
  assert.doesNotMatch(companion, /previousMode[\s\S]*sendTimerAction\("resume-break"\)/);
  assert.match(timer, /mutation\.action === "start-break"[\s\S]*mode = 'break', status = 'paused'/);
  assert.match(timer, /ends_at = ''/);
  assert.match(companion, /"Bắt đầu nghỉ"/);
});

test("Spotify floating player uses compact fixed height without black footer", () => {
  const studio = read("app/student/focus-studio.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(studio, /height="152"/);
  assert.match(css, /focus-space-v2 \.focus-spotify-embed[\s\S]*height:\s*152px[\s\S]*max-height:\s*152px/);
});
