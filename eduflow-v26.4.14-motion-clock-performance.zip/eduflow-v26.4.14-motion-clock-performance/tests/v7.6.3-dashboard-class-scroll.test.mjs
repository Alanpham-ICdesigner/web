import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const page = fs.readFileSync(new URL('../app/page.tsx', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../app/redesign.css', import.meta.url), 'utf8');

test('dashboard class results are bounded and scroll without stretching attendance card', () => {
  assert.match(page, /class-performance class-performance-scroll scroll-region/);
  assert.match(css, /\.class-performance-scroll\s*\{[\s\S]*max-height:\s*270px;[\s\S]*overflow-y:\s*auto;/);
  assert.match(css, /\.top-charts \.attendance-card\s*\{[\s\S]*align-self:\s*start;/);
});
