import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("student notifications are global in the header and removed from course tabs", async () => {
  const [page, portal] = await Promise.all([
    read("app/student/page.tsx"),
    read("app/api/student/portal/route.ts"),
  ]);
  assert.doesNotMatch(page, /\["notifications",\s*"Thông báo"/);
  assert.match(page, /Tất cả môn học/);
  assert.match(page, /homeData\.notifications\.map/);
  assert.match(portal, /globalNotifications/);
  assert.match(portal, /notifications: globalNotifications/);
});

test("student and teacher messaging is two-way without a new D1 table", async () => {
  const [studentApi, adminApi, studentPage, adminPage] = await Promise.all([
    read("app/api/student/messages/route.ts"),
    read("app/api/admin/messages/route.ts"),
    read("app/student/page.tsx"),
    read("app/page.tsx"),
  ]);
  assert.match(studentApi, /getStudentSessionId/);
  assert.match(studentApi, /kind:\s*"messages"/);
  assert.match(studentApi, /direction:\s*"student"/);
  assert.match(adminApi, /requireAdmin/);
  assert.match(adminApi, /direction:\s*"teacher"/);
  assert.match(studentPage, /Nhắn tin với giáo viên/);
  assert.match(adminPage, /Tin nhắn học sinh/);
});

test("student course cards summarize every schedule slot instead of only the first slot", async () => {
  const page = await read("app/student/page.tsx");
  assert.match(page, /props\.course\.schedules\.map/);
  assert.match(page, /join\(" · "\)/);
  assert.doesNotMatch(page, /const primarySchedule = props\.course\.schedules\[0\]/);
});

test("teacher can proactively start a direct message thread without choosing a course", async () => {
  const [adminPage, adminRoute, studentPage, studentRoute] = await Promise.all([
    read("app/page.tsx"),
    read("app/api/admin/messages/route.ts"),
    read("app/student/page.tsx"),
    read("app/api/student/messages/route.ts"),
  ]);
  assert.match(adminPage, /teacherMessageContactMap/);
  assert.match(adminPage, /Tìm học sinh/);
  assert.match(adminPage, /teacher-message-conversation-list/);
  assert.doesNotMatch(adminPage, />Môn học<select/);
  assert.match(adminPage, /Bạn có thể gửi tin nhắn đầu tiên/);
  assert.match(adminRoute, /studentEnrollments/);
  assert.match(adminRoute, /direction:\s*"teacher"/);
  assert.doesNotMatch(adminRoute, /classKey\?: string; body\?: string/);
  assert.doesNotMatch(studentPage, /không chia theo môn học/);
  assert.doesNotMatch(studentPage, /student-message-course/);
  assert.match(studentRoute, /direction:\s*"student"/);
});
