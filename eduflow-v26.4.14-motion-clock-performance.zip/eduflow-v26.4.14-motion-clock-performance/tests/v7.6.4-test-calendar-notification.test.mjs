import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("creating a class test calendar also creates a class-scoped student notification", async () => {
  const [route, portal, student] = await Promise.all([
    read("app/api/admin/items/route.ts"),
    read("app/api/student/portal/route.ts"),
    read("app/student/page.tsx"),
  ]);
  assert.match(route, /kind === "calendar"/);
  assert.match(route, /Lịch kiểm tra mới:/);
  assert.match(route, /audience: "all_students"/);
  assert.match(route, /classKey:/);
  assert.match(route, /actionView: "schedule"/);
  assert.match(route, /category: "test_calendar"/);
  assert.match(route, /relatedItemId:/);
  assert.match(portal, /enrollmentKeys\.has\(classKey\)/);
  assert.match(student, /homeData\.notifications\.map/);
  assert.match(student, /TAB_ITEMS\.find/);
});

test("deleting a test calendar removes its automatic notification", async () => {
  const route = await read("app/api/admin/items/route.ts");
  assert.match(route, /existing\[0\]\?\.kind === "calendar"/);
  assert.match(route, /data\.category \|\| ""\) !== "test_calendar"/);
  assert.match(route, /Number\(data\.relatedItemId \|\| 0\) !== payload\.id/);
});
