import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const classHub = await readFile(new URL("app/class-hub.tsx", root), "utf8");

test("student report uses attended sessions ratio instead of attendance percentage", () => {
  assert.match(classHub, /const finalizedAttendance = attendance\.filter/);
  assert.match(classHub, /item\.status === "present" \|\| item\.status === "late" \|\| item\.status === "allowed" \|\| item\.status === "absent"/);
  assert.match(classHub, /const attendedSessions = finalizedAttendance\.filter/);
  assert.match(classHub, /<small>Số buổi học<\/small>/);
  assert.match(classHub, /attendedSessions \+ ' \/ ' \+ totalSessions/);
});

test("makeup section is directly after attendance calendars and before points/comments", () => {
  const attendanceIndex = classHub.indexOf('(options.attendance ? months.map(calendarHtml).join("") : \'\')');
  const makeupIndex = classHub.indexOf('makeupSection +', attendanceIndex);
  const pointsIndex = classHub.indexOf('(options.points ?', makeupIndex);
  assert.ok(attendanceIndex >= 0);
  assert.ok(makeupIndex > attendanceIndex);
  assert.ok(pointsIndex > makeupIndex);
});

test("payment QR is rendered in the top-right report header and not as a bottom section", () => {
  assert.match(classHub, /const headerQr = paymentQr\?\.configured \? '<aside class="pdf-head-qr">/);
  assert.match(classHub, /\.pdf-head-qr\{position:absolute;top:0;right:0/);
  assert.match(classHub, /<\/div>' \+ headerQr \+ '<\/header>/);
  assert.doesNotMatch(classHub, /<section class="report-section payment-qr">/);
});
