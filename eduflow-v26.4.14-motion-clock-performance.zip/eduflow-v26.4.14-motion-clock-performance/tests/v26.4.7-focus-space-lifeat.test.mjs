import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

function read(path) { return fs.readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("Focus Space is portaled to document.body so fullscreen is not clipped by the Pomodoro card", () => {
  const companion = read("app/student/pet-focus-companion.tsx");
  const studio = read("app/student/focus-studio.tsx");
  assert.match(companion, /createPortal\(<FocusStudio[\s\S]*document\.body\)/);
  assert.match(studio, /studioRef\.current\?\.requestFullscreen/);
  assert.doesNotMatch(studio, /document\.documentElement\.requestFullscreen/);
});

test("LifeAt-style Focus Space keeps the clock centered and opens movable Task Music Notes windows from a dock", () => {
  const studio = read("app/student/focus-studio.tsx");
  assert.match(studio, /FOCUS SPACE/);
  assert.match(studio, /focus-space-dock/);
  assert.match(studio, /togglePanel\("tasks"\)/);
  assert.match(studio, /togglePanel\("music"\)/);
  assert.match(studio, /togglePanel\("notes"\)/);
  assert.match(studio, /beginPanelDrag/);
  assert.match(studio, /dockPanel/);
  assert.match(studio, /focus-notes-panel/);
  assert.match(studio, /eduflow-focus-notes/);
  assert.doesNotMatch(studio, /Chọn một task hoặc tập trung tự do/);
  assert.doesNotMatch(studio, /Tắt nhạc/);
});

test("Digital and Flip controls are icon-only and flip animation is deliberately readable", () => {
  const studio = read("app/student/focus-studio.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(studio, /title="Đồng hồ điện tử"[\s\S]*MorphIcon icon=\{DIGITAL_PATH\}/);
  assert.match(studio, /title="Flip clock"[\s\S]*MorphIcon icon=\{FLIP_PATH\}/);
  assert.doesNotMatch(studio, /<span>Digital<\/span>/);
  assert.doesNotMatch(studio, /<span>Flip<\/span>/);
  assert.match(css, /\.focus-space-v2 \.focus-flip-digit[\s\S]*animation-duration:\s*820ms/);
});

test("landscape behavior no longer marks every landscape desktop as manual landscape", () => {
  const studio = read("app/student/focus-studio.tsx");
  assert.doesNotMatch(studio, /if \(query\.matches\) setManualLandscape\(true\)/);
  assert.match(studio, /window\.innerWidth <= 900 \|\| navigator\.maxTouchPoints > 0/);
  assert.match(studio, /orientation\.lock\("landscape"\)/);
});

test("hidden Spotify popup stays mounted instead of adding a stop-music control", () => {
  const studio = read("app/student/focus-studio.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(studio, /aria-hidden=\{!musicExpanded\}/);
  assert.match(studio, /focus-window-hidden/);
  assert.match(css, /focus-media-window\.focus-window-hidden/);
  assert.doesNotMatch(studio, /removeItem\(storageKey\("eduflow-focus-spotify"/);
});
