import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("V26.2.4 student Pomodoro totals include teacher-confirmed outside-web minutes without creating sessions", async () => {
  const route = await read("app/api/student/focus/route.ts");
  assert.match(route, /FROM student_focus_adjustments/);
  assert.match(route, /todayMinutes: todayTrackedMinutes \+ todayManualMinutes/);
  assert.match(route, /weekMinutes: weekTrackedMinutes \+ weekManualMinutes/);
  assert.match(route, /todaySessions: Math\.max\(0, Number\(row\?\.today_sessions\)/);
  assert.match(route, /weekSessions: Math\.max\(0, Number\(row\?\.week_sessions\)/);
});

test("student home shows total minutes plus a concise outside-web confirmation", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  assert.match(component, /todayManualMinutes/);
  assert.match(component, /weekManualMinutes/);
  assert.match(component, /focus-manual-note/);
  assert.match(component, /ngoài web/);
  assert.match(component, /syncWhenFocused = function\(\) \{ void syncFocusState\(true, true\); \}/);
});

test("teacher engagement table uses compact session and manual-time metadata", async () => {
  const component = await read("app/admin/student-engagement-stats.tsx");
  const css = await read("app/astryx-taste-deep.css");
  assert.match(component, /engagement-focus-meta/);
  assert.match(component, /engagement-manual-chip/);
  assert.match(component, />\+\{row\.manualFocusMinutes\}p</);
  assert.doesNotMatch(component, /phiên hoàn tất\{row\.manualFocusMinutes/);
  assert.match(css, /\.engagement-manual-chip/);
});
