import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

function read(path) { return readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("V26.1.2 student message body remains visibly painted in iOS Safari/PWA", () => {
  const student = read("app/student/page.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(student, /className="student-message-body"[^>]*>\{item\.body\}<\/span>/);
  assert.match(css, /\.messenger-student-chat \.student-message-body \{[\s\S]*-webkit-text-fill-color:\s*var\(--text\)/);
  assert.match(css, /@media \(max-width: 700px\) \{[\s\S]*\.messenger-student-chat \.student-message-body \{[\s\S]*display:\s*block !important;[\s\S]*visibility:\s*visible !important;/);
});

test("V26.1.2 PDF regression tests no longer require removed fit controls", () => {
  const legacy = read("tests/v25.3.3-pdf-submit-pomodoro-regression.test.mjs");
  const viewer = read("app/file-viewer-modal.tsx");
  assert.doesNotMatch(legacy, /file-viewer-fit-controls[\s\S]*grid-column/);
  assert.doesNotMatch(viewer, /Vừa chiều rộng|Vừa trang|file-viewer-fit-controls/);
});
