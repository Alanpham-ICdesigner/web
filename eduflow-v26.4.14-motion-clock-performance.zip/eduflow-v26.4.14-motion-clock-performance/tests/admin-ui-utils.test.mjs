import assert from "node:assert/strict";
import test from "node:test";

import {
  ALL_CLASSES_ID,
  filterAndSortAttendance,
  localDateInTimeZone,
  resolveStudentNavigationTarget,
  searchStudents,
  sortPointRules,
} from "../lib/admin-ui-utils.mjs";

test("attendance uses the Vietnam local date and preserves the next calendar day", () => {
  assert.equal(
    localDateInTimeZone(new Date("2026-08-25T17:30:00.000Z")),
    "2026-08-26",
  );
});

test("attendance history filters by class id, supports legacy names, and sorts by date then start time", () => {
  const items = [
    { id: 1, data: { classId: "toan-11", className: "Tên cũ", date: "2026-08-25", startTime: "18:00" } },
    { id: 2, data: { classId: "toan-6-8", className: "TOÁN 6 - 8", date: "2026-08-24", startTime: "18:00" } },
    { id: 3, data: { classId: "toan-11", className: "Toán 11", date: "2026-08-25", startTime: "20:00" } },
    { id: 4, data: { className: "Toán 11", date: "2026-08-23", startTime: "19:00" } },
  ];

  assert.deepEqual(
    filterAndSortAttendance(items, "toan-11", "Toán 11").map(function (item) { return item.id; }),
    [3, 1, 4],
  );
  assert.deepEqual(
    filterAndSortAttendance(items, ALL_CLASSES_ID, "Tất cả lớp").map(function (item) { return item.id; }),
    [3, 1, 2, 4],
  );
});

test("attendance history sorts legacy dd/mm/yyyy dates newest first", () => {
  const items = [
    { id: 1, data: { className: "Toán 12", date: "01/09/2026", startTime: "20:00" } },
    { id: 2, data: { className: "Toán 12", date: "02/09/2026", startTime: "08:00" } },
    { id: 3, data: { className: "Toán 12", date: "02/09/2026", startTime: "18:00" } },
  ];
  assert.deepEqual(
    filterAndSortAttendance(items, ALL_CLASSES_ID, "Tất cả lớp").map(function (item) { return item.id; }),
    [3, 2, 1],
  );
});

test("point rules sort positive, zero, and negative scores without mutating the source", () => {
  const rules = [
    { id: 1, points: 2 },
    { id: 2, points: -3 },
    { id: 3, points: 10 },
    { id: 4, points: -1 },
    { id: 5, points: 5 },
    { id: 6, points: -10 },
    { id: 7, points: 1 },
    { id: 8, points: -5 },
    { id: 9, points: 0 },
  ];
  const originalIds = rules.map(function (rule) { return rule.id; });

  assert.deepEqual(
    sortPointRules(rules).map(function (rule) { return rule.points; }),
    [10, 5, 2, 1, 0, -10, -5, -3, -1],
  );
  assert.deepEqual(rules.map(function (rule) { return rule.id; }), originalIds);

  const withSeven = rules.concat({ id: 10, points: 7 }, { id: 11, points: -7 });
  assert.deepEqual(
    sortPointRules(withSeven).map(function (rule) { return rule.points; }),
    [10, 7, 5, 2, 1, 0, -10, -7, -5, -3, -1],
  );

  const edited = withSeven.map(function (rule) {
    if (rule.id === 1) return { ...rule, points: 8 };
    if (rule.id === 2) return { ...rule, points: -9 };
    return rule;
  });
  assert.deepEqual(
    sortPointRules(edited).map(function (rule) { return rule.points; }),
    [10, 8, 7, 5, 1, 0, -10, -9, -7, -5, -1],
  );
});

test("global search uses every student and normalizes case, accents, code, class, whitespace, and multiple terms", () => {
  const students = [
    { name: "Tạ Minh Lâm", code: "HS1001", className: "Toán 10" },
    { name: "Nguyễn Ngọc Khánh An", code: "HS1002", className: "Toán 10" },
    { name: "Nguyễn Ngọc Khánh Vân", code: "HS1003", className: "Toán 10" },
    { name: "Nguyễn Minh Phúc", code: "HS1824", className: "Toán 11" },
    { name: "Trần Hoàng Phúc", code: "HS1900", className: "Toán 12" },
  ];

  assert.deepEqual(searchStudents(students, "PHÚC").map(function (student) { return student.code; }), ["HS1824", "HS1900"]);
  assert.deepEqual(searchStudents(students, "  phuc  ").map(function (student) { return student.code; }), ["HS1824", "HS1900"]);
  assert.deepEqual(searchStudents(students, "minh phuc").map(function (student) { return student.code; }), ["HS1824"]);
  assert.deepEqual(searchStudents(students, "1824").map(function (student) { return student.code; }), ["HS1824"]);
  assert.deepEqual(searchStudents(students, "toan 11").map(function (student) { return student.code; }), ["HS1824"]);
  assert.deepEqual(searchStudents(students, "xyzabc123"), []);

  const twentyMatches = Array.from({ length: 20 }, function (_, index) {
    return { name: "Học sinh Minh " + index, code: "HS" + index, className: "Toán 11" };
  });
  assert.equal(searchStudents(twentyMatches, "minh").length, 20);
});

test("global search ranks exact and word-prefix name matches before broad substrings", () => {
  const students = [
    { name: "Nguyễn Ngọc Khánh Vân", code: "HS1", className: "Toán 10" },
    { name: "Nguyễn Minh Anh", code: "HS2", className: "Toán 10" },
    { name: "Nguyễn Ngọc Khánh An", code: "HS3", className: "Toán 10" },
  ];
  assert.deepEqual(
    searchStudents(students, "an").map(function (student) { return student.code; }),
    ["HS3", "HS2", "HS1"],
  );
});

test("student search navigation resolves stable student and class identifiers", () => {
  const student = { id: 27, name: "Nguyễn Minh Anh", className: "Toán 12" };
  const classes = [{ id: 12, key: "toan-12", name: "Toán 12" }];
  assert.deepEqual(resolveStudentNavigationTarget(student, classes), {
    studentId: 27,
    classId: "12",
  });
  assert.equal(resolveStudentNavigationTarget({ ...student, id: undefined }, classes), null);
  assert.equal(resolveStudentNavigationTarget(student, []), null);
});
