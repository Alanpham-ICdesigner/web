import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("student home has separate courses and aggregate schedule tabs", async () => {
  const page = await read("app/student/page.tsx");
  assert.match(page, /type HomeTab = "courses" \| "schedule"/);
  assert.match(page, /Các môn học của tôi/);
  assert.match(page, /Lịch học tổng hợp/);
  assert.match(page, /<StudentWeeklyTimetable courses=\{homeData\.courses\} sessions=\{homeData\.sessions\} aggregate/);
});

test("student and teacher timetables support overlap focus and compact TasteSkill layout", async () => {
  const [student, teacher, css] = await Promise.all([read("app/student/page.tsx"), read("app/page.tsx"), read("app/redesign.css")]);
  assert.match(student, /focusedEventKey/);
  assert.match(student, /stackOffset/);
  assert.match(teacher, /focusedScheduleKey/);
  assert.match(teacher, /stackCount/);
  assert.match(css, /\.taste-timetable/);
  assert.match(css, /\.weekly-timetable-event\.active/);
  assert.match(css, /\.weekly-timetable-event\.overlap/);
});

test("make-up badge disappears once that make-up session has attendance data", async () => {
  const [portal, student] = await Promise.all([read("app/api/student/portal/route.ts"), read("app/student/page.tsx")]);
  assert.match(portal, /attendedMakeupSessionIds/);
  assert.match(portal, /!attendedMakeupSessionIds\.has\(item\.id\)/);
  assert.match(portal, /pendingMakeupSessions/);
  assert.match(student, /props\.course\.pendingMakeupSessions/);
});

test("assignment submission never auto-awards competition points", async () => {
  const [route, student] = await Promise.all([read("app/api/student/submissions/route.ts"), read("app/student/page.tsx")]);
  assert.doesNotMatch(route, /pointRules/);
  assert.doesNotMatch(route, /pointTransactions/);
  assert.doesNotMatch(route, /createPointNotification/);
  assert.match(route, /awarded: 0/);
  assert.match(student, /toast\("Đã nộp bài thành công"\)/);
  assert.doesNotMatch(student, /Đã nộp bài và nhận/);
});
