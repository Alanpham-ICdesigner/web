import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("legacy students migrate to unique many-to-many enrollments without destructive SQL", async () => {
  const [schema, migration] = await Promise.all([read("db/schema.ts"), read("drizzle/0005_many_courses_lms.sql")]);
  assert.match(schema, /studentEnrollments/);
  assert.match(schema, /student_enrollments_student_class_unique/);
  assert.match(migration, /INSERT OR IGNORE INTO `student_enrollments`/);
  assert.doesNotMatch(migration, /DROP TABLE|DELETE FROM `students`/i);
});

test("student course access and direct URL access are verified by enrollment on the server", async () => {
  const [portal, helper, attachment] = await Promise.all([
    read("app/api/student/portal/route.ts"),
    read("lib/course-access.ts"),
    read("app/api/assignments/[id]/attachment/route.ts"),
  ]);
  assert.match(portal, /studentCanAccessCourse\(db, studentId, requestedCourseKey\)/);
  assert.match(portal, /status: 403/);
  assert.match(helper, /studentEnrollments\.classKey/);
  assert.match(attachment, /studentCanAccessCourse/);
});

test("student LMS exposes My Courses and course-isolated sections", async () => {
  const page = await read("app/student/page.tsx");
  for (const label of ["Các môn học của tôi", "Tổng quan", "Lịch học", "Thông báo", "Tài liệu", "Bài tập", "Điểm / Quá trình"]) {
    assert.ok(page.includes(label), label);
  }
  assert.match(page, /portal\?courseId=/);
});

test("course schedules support multiple recurring slots and aggregate teacher weeks", async () => {
  const [page, schedules, css] = await Promise.all([
    read("app/page.tsx"),
    read("app/api/course-schedules/route.ts"),
    read("app/redesign.css"),
  ]);
  assert.match(page, /Thêm buổi/);
  assert.match(page, /TeachingScheduleView/);
  assert.match(schedules, /courseSchedules/);
  assert.match(css, /@media \(max-width: 700px\)[\s\S]*\.teaching-week-grid/);
});

test("make-up sessions feed teacher schedule, course portal, attendance, and report", async () => {
  const [sessions, portal, page, report] = await Promise.all([
    read("app/api/course-sessions/route.ts"),
    read("app/api/student/portal/route.ts"),
    read("app/page.tsx"),
    read("app/class-hub.tsx"),
  ]);
  assert.match(sessions, /sessionType/);
  assert.match(portal, /sessions: sessionRows\.filter/);
  assert.match(page, /sessionType: props\.target\?\.sessionType/);
  assert.match(report, /Học bù[\s\S]*sessionDate[\s\S]*startTime[\s\S]*endTime/);
});

test("homework supports R2 upload, teacher grading, and student feedback", async () => {
  const [submission, grading, studentPage] = await Promise.all([
    read("app/api/student/submissions/route.ts"),
    read("app/api/assignments/[id]/submissions/route.ts"),
    read("app/student/page.tsx"),
  ]);
  assert.match(submission, /application\/pdf/);
  assert.match(submission, /bucket\.put/);
  assert.match(grading, /score[\s\S]*feedback[\s\S]*gradedAt/);
  assert.match(studentPage, /submission\.score[\s\S]*submission\.feedback/);
});

test("bank QR is optional report configuration and no tuition or transaction model is added", async () => {
  const [qr, report, schema] = await Promise.all([
    read("app/api/settings/payment-qr/route.ts"),
    read("app/class-hub.tsx"),
    read("db/schema.ts"),
  ]);
  assert.match(qr, /settings\/payment-qr/);
  assert.match(report, /paymentQr\?\.configured/);
  assert.doesNotMatch(schema, /tuition|invoice|paymentTransaction/i);
});

test("deployment keeps the existing Cloudflare Worker, D1, R2, and PowerShell workflow", async () => {
  const [wrangler, updater] = await Promise.all([read("wrangler.jsonc"), read("cap-nhat-cloudflare.ps1")]);
  assert.match(wrangler, /"name": "edumath"/);
  assert.match(wrangler, /"database_name": "eduflow-db"/);
  assert.match(wrangler, /"bucket_name": "eduflow-files"/);
  assert.match(updater, /d1 migrations apply eduflow-db --remote/);
  assert.match(updater, /deploy --config wrangler\.jsonc --keep-vars/);
});
