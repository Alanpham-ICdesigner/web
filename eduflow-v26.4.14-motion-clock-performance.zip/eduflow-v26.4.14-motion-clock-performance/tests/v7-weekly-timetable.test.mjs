import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("student schedule is a seven-day weekly timetable with week navigation and make-up sessions", async () => {
  const [page, css] = await Promise.all([read("app/student/page.tsx"), read("app/redesign.css")]);
  assert.match(page, /function StudentWeeklyTimetable/);
  assert.match(page, /Thứ 2.*Thứ 3.*Thứ 4.*Thứ 5.*Thứ 6.*Thứ 7.*Chủ nhật/s);
  assert.match(page, /Hôm nay/);
  assert.match(page, /props\.sessions\.filter\(function\(item\)/);
  assert.match(page, /item\.sessionDate !== date/);
  assert.match(page, /weekly-timetable-day-column/);
  assert.match(css, /\.weekly-timetable-grid\s*\{[^}]*repeat\(7,/s);
  assert.match(css, /\.weekly-timetable-scroll\s*\{[^}]*overflow-x:\s*auto/s);
});

test("teacher schedule uses the same weekly grid and keeps attendance plus make-up controls", async () => {
  const page = await read("app/page.tsx");
  assert.match(page, /Thời khóa biểu tổng hợp theo tuần/);
  assert.match(page, /weekly-timetable-event teacher-event/);
  assert.match(page, /props\.onAttendance/);
  assert.match(page, /Tạo buổi học bù/);
  assert.match(page, /setSelectedSession\(found\)/);
  assert.match(page, /void removeSession\(found\)/);
});
