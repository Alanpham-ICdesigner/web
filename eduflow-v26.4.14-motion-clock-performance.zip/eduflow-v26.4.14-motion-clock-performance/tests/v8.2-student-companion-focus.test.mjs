import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");
const bytes = (path) => stat(new URL("../" + path, import.meta.url));

test("V8.2 companion migration is additive and isolated from academic records", async () => {
  const sql = await read("drizzle/0006_student_companion_focus.sql");
  assert.match(sql, /CREATE TABLE IF NOT EXISTS `?student_pet_profiles`?/i);
  assert.match(sql, /CREATE TABLE IF NOT EXISTS `?student_daily_checkins`?/i);
  assert.match(sql, /CREATE TABLE IF NOT EXISTS `?student_focus_sessions`?/i);
  assert.match(sql, /student_daily_checkins_student_date_unique.*student_id.*checkin_date/i);
  assert.match(sql, /student_focus_sessions_student_key_unique.*student_id.*session_key/i);
  assert.doesNotMatch(sql, /\bDROP\b|\bTRUNCATE\b|\bDELETE\s+FROM\b|\bALTER\s+TABLE\b/i);
  assert.doesNotMatch(sql, /point_transactions|attendance_records|assignments/i);
});

test("V8.2.3 freeze migration preserves prior use history and switches only the default pet identity", async () => {
  const sql = await read("drizzle/0007_punch_freeze_30_day_cooldown.sql");
  assert.match(sql, /ADD COLUMN `freeze_last_used_date` text DEFAULT '' NOT NULL/i);
  assert.match(sql, /MAX\(`checkin_date`\)/i);
  assert.match(sql, /`used_freeze` = 1/i);
  assert.match(sql, /SET `pet_name` = 'Punch'/i);
  assert.match(sql, /`pet_name` = 'Shinchan'/i);
  assert.match(sql, /SET `pet_slug` = 'punch'/i);
  assert.doesNotMatch(sql, /\bDROP\b|\bTRUNCATE\b|\bDELETE\s+FROM\b/i);
  assert.doesNotMatch(sql, /point_transactions|attendance_records|assignments/i);
});

test("daily streak is server-authoritative, Vietnam-date based, idempotent and uses a rolling 30-day freeze cooldown", async () => {
  const route = await read("app/api/student/pet/route.ts");
  const helper = await read("lib/student-companion.ts");
  assert.match(route, /getStudentSessionId\(request\)/);
  assert.match(helper, /Asia\/Ho_Chi_Minh/);
  assert.match(helper, /FREEZE_COOLDOWN_DAYS = 30/);
  assert.match(helper, /freezeCooldownState/);
  assert.match(helper, /shiftDateKey\(normalized, FREEZE_COOLDOWN_DAYS\)/);
  assert.match(route, /db\.batch\(\[/);
  assert.match(route, /INSERT OR IGNORE INTO student_daily_checkins/);
  assert.match(route, /WHEN last_checkin_date = \? THEN current_streak/);
  assert.match(route, /twoDaysAgo/);
  assert.match(route, /freeze_last_used_date/);
  const freeze = await read("lib/streak-freeze.ts");
  assert.match(route, /reconcileAutomaticStreakFreeze/);
  assert.match(freeze, /Exactly one missed calendar day/);
  assert.match(freeze, /INSERT OR IGNORE INTO student_daily_checkins/);
  assert.match(freeze, /used_freeze\)\s*VALUES \(\?, \?, \?, 1\)/);
  assert.match(freeze, /freeze_last_used_date = \?/);
  assert.match(route, /current_streak % 10 === 0/);
  assert.match(route, /current_streak % 100 === 0/);
  assert.doesNotMatch(route, /vietnamMonthKey/);
});

test("Punch stays bundled locally while students can choose Petdex skins on demand", async () => {
  const route = await read("app/api/student/pet/route.ts");
  const catalog = await read("lib/petdex-catalog.ts");
  const petsRoute = await read("app/api/student/pets/route.ts");
  const metadata = JSON.parse(await read("public/pets/punch/pet.json"));
  const sprite = await bytes("public/pets/punch/spritesheet.webp");
  assert.equal(metadata.id, "punch");
  assert.equal(metadata.displayName, "Punch");
  assert.ok(sprite.size > 2_000_000);
  assert.match(catalog, /https:\/\/petdex\.dev\/api\/manifest/);
  assert.match(catalog, /spritesheetUrl/);
  assert.match(petsRoute, /limit/);
  assert.match(route, /petSlug/);
  assert.match(route, /WHERE student_id = \? AND pet_slug = 'shinchan'/);
  assert.doesNotMatch(route, /WHERE student_id = \? AND pet_slug <> \?/);
});

test("students can rename their pet and switch Petdex skins without changing streak schema", async () => {
  const route = await read("app/api/student/pet/route.ts");
  const component = await read("app/student/pet-focus-companion.tsx");
  assert.match(route, /export async function PATCH\(request: Request\)/);
  assert.match(route, /SET pet_name = \?, updated_at = \?/);
  assert.match(route, /SET pet_slug = \?, updated_at = \?/);
  assert.match(route, /Array\.from\(petName\)\.length/);
  assert.match(route, /Tên pet cần từ 1 đến 24 ký tự/);
  assert.match(component, /method:\s*"PATCH"/);
  assert.match(component, /body:\s*JSON\.stringify\(\{ petName: nextName \}\)/);
  assert.match(component, /aria-label="Đổi tên pet"/);
  assert.match(component, /Chọn pet đồng hành/);
  assert.match(component, /body:\s*JSON\.stringify\(\{ petSlug: choice\.slug \}\)/);
  assert.match(component, /maxLength=\{24\}/);
});

test("focus statistics are separate from streak and academic points", async () => {
  const route = await read("app/api/student/focus/route.ts");
  assert.match(route, /student_focus_sessions/);
  assert.match(route, /INSERT OR IGNORE/);
  assert.match(route, /today_(?:tracked_)?minutes/);
  assert.match(route, /week_(?:tracked_)?minutes/);
  assert.match(route, /minimumElapsedMs/);
  assert.match(route, /Phiên tập trung chưa đủ thời gian để ghi nhận/);
  assert.doesNotMatch(route, /point_transactions|student_daily_checkins|current_streak|attendance/i);
});

test("student companion implements Punch states, server-synced timer and safe controls", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  for (const state of ["idle", "runRight", "runLeft", "waving", "jumping", "failed", "waiting", "running", "review"]) {
    assert.match(component, new RegExp(state));
  }
  assert.match(component, /type ServerTimer/);
  assert.match(component, /serverNow/);
  assert.match(component, /revision:\s*number/);
  assert.match(component, /normalizeServerTimer/);
  assert.match(component, /sendTimerAction/);
  assert.match(component, /\?timerOnly=1/);
  assert.match(component, /setInterval\(function\(\) \{ if \(document\.visibilityState === "visible"\) void syncFocusState\(false, true\); \}, 10_000\)/);
  assert.match(component, /studentStorageKey\(ROAM_STORAGE_KEY, props\.studentId\)/);
  assert.match(component, /\[25, 5\]/);
  assert.match(component, /\[45, 10\]/);
  assert.match(component, /\[50, 10\]/);
  assert.match(component, /\[90, 15\]/);
  assert.match(component, /min="5" max="180"/);
  assert.match(component, /min="1" max="60"/);
  assert.match(component, /\/api\/student\/pet/);
  assert.match(component, /\/api\/student\/focus/);
  assert.match(component, /new Image\(\)/);
  assert.match(component, /spriteLoadState/);
  assert.match(component, /Petdex · \{petData\?\.pet\.displayName \|\| "Punch"\}/);
  assert.doesNotMatch(component, /eduflow-focus-timer-v1/);
  assert.doesNotMatch(component, /\?asset=1/);
  assert.doesNotMatch(component, /pet-progress-ring/);
  assert.doesNotMatch(component, /Quên đúng 1 ngày: hệ thống tự dùng/);
  assert.doesNotMatch(component, /Pomodoro không cộng điểm thi đua và không làm tăng Daily Streak/);
});

test("Punch reacts failed for about 10 seconds on missed check-in and early Pomodoro stop", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  const route = await read("app/api/student/pet/route.ts");
  assert.match(route, /missedCheckin:\s*missedDays > 0/);
  assert.match(route, /missedCheckinDays/);
  assert.match(component, /petData\?\.streak\.missedCheckin/);
  assert.match(component, /celebrate\("failed", 10_000\)/);
  assert.match(component, /function stopTimer\(\)[\s\S]*?celebrate\("failed", 10_000\)/);
  assert.match(component, /if \(!animationLockRef\.current\) setPetAnimation\("idle"\)/);
});

test("freeze cooldown status is shown compactly beside Daily Streak", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  const css = await read("app/astryx-taste-deep.css");
  assert.match(component, /freezeDaysRemaining/);
  assert.match(component, /"Có lại sau " \+ streak\.freezeDaysRemaining \+ " ngày"/);
  assert.match(component, /freezeNextAvailableDate/);
  assert.match(css, /\.freeze-status\s*\{/);
  assert.match(css, /\.freeze-status small\s*\{/);
});

test("pet is mounted only on the student home course dashboard", async () => {
  const page = await read("app/student/page.tsx");
  const matches = page.match(/<PetFocusCompanion\b/g) || [];
  assert.equal(matches.length, 1);
  assert.match(page, /homeTab === "courses" \? <>\{homeData\.student\.id > 0 \? <PetFocusCompanion/);
  assert.match(page, /homeTab === "schedule" \? "Các môn học của tôi" : "Lịch học tổng hợp"|homeTab === "courses" \? "Các môn học của tôi" : "Lịch học tổng hợp"/);
});

test("Pomodoro keeps counting while tab/app is away, syncs by account, and stops at the phase boundary", async () => {
  const component = await read("app/student/pet-focus-companion.tsx");
  const timerLib = await read("lib/focus-timer.ts");
  const route = await read("app/api/student/focus/route.ts");
  assert.match(component, /clockOffsetRef/);
  assert.match(component, /timer\.endAt - serverNowEstimate/);
  assert.match(component, /document\.addEventListener\("visibilitychange", syncWhenVisible\)/);
  assert.match(component, /window\.addEventListener\("focus", syncWhenFocused\)/);
  assert.match(component, /window\.addEventListener\("online", syncWhenFocused\)/);
  assert.match(component, /syncFocusState\(true, true\)/);
  assert.match(route, /getFocusTimer/);
  assert.match(route, /mutateFocusTimer/);
  assert.match(timerLib, /student_focus_timer_state/);
  assert.match(timerLib, /mode = 'break', status = 'paused'/);
  assert.match(timerLib, /INSERT OR IGNORE INTO student_focus_sessions/);
  assert.match(timerLib, /revision = revision \+ 1/);
  assert.doesNotMatch(component, /beforeunload|pagehide|safeStoredTimer|TIMER_STORAGE_KEY/);
});

test("companion UI follows Astryx/Taste responsive and motion guardrails", async () => {
  const css = await read("app/astryx-taste-deep.css");
  const page = await read("app/student/page.tsx");
  assert.match(page, /import PetFocusCompanion from "\.\/pet-focus-companion"/);
  assert.match(page, /<PetFocusCompanion studentId=\{homeData\.student\.id\} toast=\{toast\} \/>/);
  assert.match(css, /\.student-companion\s*\{/);
  assert.match(css, /\.companion-name-editor\s*\{/);
  assert.match(css, /transform 4\.55s linear/);
  assert.match(css, /@media \(max-width: 1160px\)/);
  assert.match(css, /@media \(max-width: 700px\)/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
  assert.match(css, /min-height: 44px/);
  assert.match(css, /var\(--surface/);
  assert.match(css, /var\(--line/);
  assert.doesNotMatch(css, /\.pet-progress-ring/);
});
