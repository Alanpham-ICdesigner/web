import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

function read(path) { return fs.readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("Focus and Break selected mode has a solid purple state", () => {
  const css = read("app/astryx-taste-deep.css");
  assert.match(css, /focus-mode-switch button\.active[\s\S]*background:\s*linear-gradient\([\s\S]*var\(--primary\)/);
  assert.match(css, /focus-mode-switch button\.active:disabled[\s\S]*opacity:\s*1/);
});

test("Spotify compact player is exactly 152px high", () => {
  const studio = read("app/student/focus-studio.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(studio, /height="152"/);
  assert.match(css, /focus-spotify-embed[\s\S]*height:\s*152px[\s\S]*min-height:\s*152px[\s\S]*max-height:\s*152px/);
});

test("manual landscape uses visualViewport dimensions and centered rotation", () => {
  const studio = read("app/student/focus-studio.tsx");
  const css = read("app/astryx-taste-deep.css");
  assert.match(studio, /function syncWorkspaceViewportCssVars\(\)/);
  assert.match(studio, /--focus-visual-width/);
  assert.match(studio, /--focus-visual-height/);
  assert.match(css, /width:\s*var\(--focus-visual-height, 100dvh\)/);
  assert.match(css, /height:\s*var\(--focus-visual-width, 100dvw\)/);
  assert.match(css, /translate\(-50%, -50%\) rotate\(90deg\)/);
});

test("Break remains manual after selecting the Break mode", () => {
  const timer = read("lib/focus-timer.ts");
  assert.match(timer, /mutation\.action === "start-break"[\s\S]*mode = 'break', status = 'paused'/);
  assert.match(timer, /ends_at = ''/);
});
