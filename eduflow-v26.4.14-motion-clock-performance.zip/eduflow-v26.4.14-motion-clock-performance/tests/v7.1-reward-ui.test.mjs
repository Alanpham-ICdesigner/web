import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const student = fs.readFileSync('app/student/page.tsx', 'utf8');
const css = fs.readFileSync('app/redesign.css', 'utf8');

test('student reward cards have an explicit selected state before redeeming', () => {
  assert.match(student, /selectedRewardId/);
  assert.match(student, /className=\{selected \? "selected" : ""\}/);
  assert.match(student, /aria-pressed=\{selected\}/);
  assert.match(student, /Đang chọn/);
  assert.match(student, /Đổi quà đã chọn/);
  assert.match(css, /\.lms-rewards \.lms-reward-options > button\.selected/);
  assert.match(css, /box-shadow:/);
});

test('redemption history overrides the legacy 42px content width', () => {
  assert.match(css, /\.lms-redemptions \.reward-history-scroll > div > span \{[\s\S]*?width: auto !important;/);
  assert.match(css, /grid-template-columns: 30px minmax\(0, 1fr\) max-content/);
  assert.match(css, /\.lms-redemptions \.reward-history-scroll > div > em\.rejected/);
  assert.match(css, /\.lms-redemptions \.reward-history-scroll > div > em\.approved/);
});
