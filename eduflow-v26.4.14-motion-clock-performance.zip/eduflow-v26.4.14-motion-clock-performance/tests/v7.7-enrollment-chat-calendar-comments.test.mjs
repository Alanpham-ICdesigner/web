import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const page = fs.readFileSync(new URL('../app/page.tsx', import.meta.url), 'utf8');
const studentsApi = fs.readFileSync(new URL('../app/api/students/route.ts', import.meta.url), 'utf8');
const portalApi = fs.readFileSync(new URL('../app/api/student/portal/route.ts', import.meta.url), 'utf8');
const messagesApi = fs.readFileSync(new URL('../app/api/admin/messages/route.ts', import.meta.url), 'utf8');
const recordApi = fs.readFileSync(new URL('../app/api/student-records/[id]/route.ts', import.meta.url), 'utf8');
const classDashboardApi = fs.readFileSync(new URL('../app/api/class-dashboard/route.ts', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../app/redesign.css', import.meta.url), 'utf8');

test('student form supports multi-course enrollment and unassigned remains a non-enrollment state', () => {
  assert.match(page, /student-class-picker/);
  assert.match(page, /aria-pressed=\{selected\}/);
  assert.match(page, /classEnrollments:/);
  assert.match(page, /Bỏ chọn tất cả/);
  assert.match(studentsApi, /resolveRequestedEnrollments/);
  assert.match(studentsApi, /desiredByKey/);
  assert.match(studentsApi, /studentEnrollments_student_class_unique|onConflictDoUpdate/);
  assert.match(studentsApi, /isUnassignedClassName/);
  assert.match(portalApi, /name !== "chưa xếp lớp"/);
});

test('teacher can delete a whole conversation', () => {
  assert.match(messagesApi, /export async function DELETE/);
  assert.match(messagesApi, /Number\(data\.studentId \|\| 0\) !== studentId/);
  assert.match(page, /deleteTeacherConversation/);
  assert.match(page, /Xóa cuộc hội thoại/);
});

test('test calendar can show all classes and cycle overlapping events', () => {
  assert.match(page, /Tất cả lịch kiểm tra/);
  assert.match(page, /showAllClasses/);
  assert.match(page, /cycleTestStack/);
  assert.match(page, /test-calendar-stack-count/);
  assert.match(css, /\.test-calendar-event\.stacked/);
});

test('student comments are newest first across admin and student views', () => {
  assert.match(recordApi, /String\(b\.date\)\.localeCompare\(String\(a\.date\)\)/);
  assert.match(portalApi, /String\(b\.date\)\.localeCompare\(String\(a\.date\)\)/);
  assert.match(classDashboardApi, /bDate\.localeCompare\(aDate\)/);
});
