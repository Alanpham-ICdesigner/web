import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const css = await readFile(new URL("../app/redesign.css", import.meta.url), "utf8");
const layout = await readFile(new URL("../app/layout.tsx", import.meta.url), "utf8");

test("the TasteSkill presentation layer is loaded after the historical stylesheet", function () {
  const historical = layout.indexOf('import "./globals.css"');
  const redesign = layout.indexOf('import "./redesign.css"');

  assert.ok(historical >= 0);
  assert.ok(redesign > historical);
});

test("the redesign exposes one semantic token system for light and dark modes", function () {
  for (const token of [
    "--bg",
    "--surface",
    "--surface-2",
    "--text",
    "--text-secondary",
    "--line",
    "--primary",
    "--success",
    "--warning",
    "--danger",
    "--info",
    "--radius-control",
    "--radius-card",
    "--radius-modal",
  ]) {
    assert.match(css, new RegExp(token.replace("--", "--")));
  }

  assert.match(css, /:root\[data-theme="dark"\]/);
});

test("responsive and overflow guardrails cover the requested viewport families", function () {
  for (const width of [1180, 1000, 850, 700, 560, 430]) {
    assert.match(css, new RegExp(`@media \\(max-width: ${width}px\\)`));
  }

  assert.match(css, /max-height: calc\(100dvh - 32px\)/);
  assert.match(css, /\.table-scroll[\s\S]*scrollbar-gutter: stable/);
  assert.match(css, /\.notification-list[\s\S]*overflow: hidden auto/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
});

test("teacher and student surfaces share the same primitives", function () {
  assert.match(css, /\.card,\s*\.student-card/);
  assert.match(css, /\.page-title,\s*\.student-page-title/);
  assert.match(css, /\.sidebar[\s\S]*\.student-body > aside/);
  assert.match(css, /\.login-gateway[\s\S]*\.student-shell/);
});
