import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

function read(path) { return fs.readFileSync(new URL("../" + path, import.meta.url), "utf8"); }

test("Pomodoro custom duration keeps local drafts so desktop and PWA inputs can be edited", () => {
  const companion = read("app/student/pet-focus-companion.tsx");
  assert.match(companion, /focusMinutesDraft/);
  assert.match(companion, /breakMinutesDraft/);
  assert.match(companion, /durationDraftDirty/);
  assert.match(companion, /async function commitCustomDurations/);
  assert.match(companion, /value=\{focusMinutesDraft\}/);
  assert.match(companion, /value=\{breakMinutesDraft\}/);
  assert.match(companion, /Áp dụng/);
  assert.match(companion, /relatedTarget[\s\S]*closest\("\.focus-custom-wrap"\)/);
});

test("student Focus Workspace provides fullscreen clocks landscape wake lock tasks and Spotify", () => {
  const studio = read("app/student/focus-studio.tsx");
  assert.match(studio, /FocusStudio/);
  assert.match(studio, /MorphIcon/);
  assert.match(studio, /FlipClock/);
  assert.match(studio, /requestFullscreen/);
  assert.match(studio, /toggleBrowserFullscreen/);
  assert.match(studio, /orientation\.lock\("landscape"\)/);
  assert.match(studio, /manualLandscape/);
  assert.match(studio, /wakeLock/);
  assert.match(studio, /open\.spotify\.com\/embed/);
  assert.match(studio, /PEACEFUL_PIANO_URL/);
  assert.match(studio, /Thêm việc cần làm/);
  assert.match(studio, /beginTaskEdit/);
  assert.match(studio, /Kéo để sắp xếp/);
});

test("personal Focus tasks are D1-backed and separate from LMS assignments", () => {
  const migration = read("drizzle/0017_focus_workspace_tasks.sql");
  const schema = read("db/schema.ts");
  const api = read("app/api/student/focus/tasks/route.ts");
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `student_focus_tasks`/);
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `student_focus_task_sessions`/);
  assert.match(migration, /ON DELETE cascade/);
  assert.match(schema, /studentFocusTasks = sqliteTable\("student_focus_tasks"/);
  assert.match(schema, /studentFocusTaskSessions = sqliteTable\("student_focus_task_sessions"/);
  assert.match(api, /getStudentSessionId/);
  assert.match(api, /action === "create"/);
  assert.match(api, /action === "reorder"/);
  assert.match(api, /action === "link-session"/);
  assert.match(api, /action === "unlink-session"/);
  assert.doesNotMatch(api, /assignments/);
});

test("a completed server-authoritative focus session increments its linked personal task once", () => {
  const timer = read("lib/focus-timer.ts");
  assert.match(timer, /async function completeLinkedFocusTask/);
  assert.match(timer, /student_focus_task_sessions[\s\S]*completed_at = ''/);
  assert.match(timer, /completed_pomodoros = completed_pomodoros \+ 1/);
  assert.match(timer, /await completeLinkedFocusTask\(db, row\.student_id, row\.session_key/);
});

test("Focus Workspace responsive CSS covers phone portrait landscape fallback and reduced motion", () => {
  const css = read("app/astryx-taste-deep.css");
  assert.match(css, /\.focus-studio\s*\{/);
  assert.match(css, /height:\s*100dvh/);
  assert.match(css, /orientation:\s*landscape/);
  assert.match(css, /\.focus-studio\.manual-landscape/);
  assert.match(css, /\.focus-flip-clock/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test("Morphicons is vendored with its MIT license and deploy script verifies Focus Workspace D1 schema", () => {
  const morphLicense = read("lib/vendor/morphicons/LICENSE");
  const deploy = read("cap-nhat-cloudflare.ps1");
  assert.match(morphLicense, /MIT License/);
  assert.match(deploy, /student_focus_tasks/);
  assert.match(deploy, /student_focus_task_sessions/);
  assert.match(deploy, /student_focus_task_sessions_student_session_unique/);
});
