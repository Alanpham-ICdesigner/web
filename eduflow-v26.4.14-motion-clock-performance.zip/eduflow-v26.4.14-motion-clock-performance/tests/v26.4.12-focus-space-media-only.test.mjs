import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const studio = fs.readFileSync(new URL("../app/student/focus-studio.tsx", import.meta.url), "utf8");
const css = fs.readFileSync(new URL("../app/astryx-taste-deep.css", import.meta.url), "utf8");

test("Music keeps Spotify and YouTube media only", () => {
  assert.match(studio, /Dán link Spotify hoặc YouTube/);
  assert.match(studio, /youtube-nocookie\.com\/embed/);
  assert.match(studio, /open\.spotify\.com\/embed/);
  assert.doesNotMatch(studio, /Âm thanh|AMBIENT_|FocusAmbient|focus-ambient|MusicTab/);
});

test("ambient audio engine is removed from the package", () => {
  assert.equal(fs.existsSync(new URL("../lib/focus-ambient-audio.ts", import.meta.url)), false);
  assert.doesNotMatch(css, /focus-ambient|focus-music-tabs/);
});

test("floating panel dragging still avoids React state updates on every pointer move", () => {
  const moveStart = studio.indexOf("function movePanelDrag");
  const moveEnd = studio.indexOf("function endPanelDrag", moveStart);
  const moveBody = studio.slice(moveStart, moveEnd);
  assert.match(moveBody, /translate3d/);
  assert.doesNotMatch(moveBody, /setTaskPanelPosition|setMusicPanelPosition|setNotesPanelPosition/);
});

test("music window still disappears immediately while mounted media can continue", () => {
  assert.match(css, /focus-media-window\.focus-window-hidden/);
  assert.match(css, /transition: none !important/);
});
