import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const ROOT = new URL("../", import.meta.url);
const read = (path) => fs.readFileSync(new URL(path, ROOT), "utf8");

test("teacher stats refresh remains a data refresh action and exposes visible progress", () => {
  const component = read("app/admin/student-engagement-stats.tsx");
  assert.match(component, /function refreshData\(\)[\s\S]*setManualRefreshing\(true\)[\s\S]*setReloadToken/);
  assert.match(component, /<RefreshCw size=\{16\}/);
  assert.match(component, /disabled=\{manualRefreshing\}/);
  assert.match(component, /aria-busy=\{manualRefreshing\}/);
  assert.match(component, /Làm mới dữ liệu/);
  assert.doesNotMatch(component, /<RotateCcw/);
});

test("TasteSkill toolbar groups filters and refresh without clipping and respects reduced motion", () => {
  const css = read("app/astryx-taste-deep.css");
  assert.match(css, /\.engagement-toolbar-actions\s*\{[\s\S]*grid-template-columns: minmax\(220px, 1fr\) minmax\(150px, 210px\) 38px/);
  assert.match(css, /\.engagement-refresh\.is-refreshing svg[\s\S]*engagement-refresh-spin/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)[\s\S]*engagement-refresh\.is-refreshing svg \{ animation: none; \}/);
  assert.match(css, /@media \(max-width: 560px\)[\s\S]*\.engagement-toolbar-actions[\s\S]*grid-template-columns: minmax\(0, 1fr\) 42px/);
});
