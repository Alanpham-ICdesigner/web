import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL("../" + path, import.meta.url), "utf8");

test("LMS migration remains intact and duplicate-column handling is delegated to updater", async () => {
  const [migration, updater, page, hub] = await Promise.all([
    read("drizzle/0005_many_courses_lms.sql"),
    read("cap-nhat-cloudflare.ps1"),
    read("app/student/page.tsx"),
    read("app/class-hub.tsx"),
  ]);

  assert.match(migration, /CREATE TABLE IF NOT EXISTS `student_enrollments`/);
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `course_schedules`/);
  assert.match(migration, /CREATE TABLE IF NOT EXISTS `course_sessions`/);
  assert.match(migration, /INSERT OR IGNORE INTO `student_enrollments`/);
  assert.match(migration, /`created_at` text NOT NULL/);
  assert.doesNotMatch(migration, /ALTER TABLE `assignment_submissions` ADD `score`/);
  assert.match(updater, /function Ensure-D1Column/);
  assert.match(updater, /function Repair-LegacyStudentEnrollments/);
  assert.match(updater, /-Table "student_enrollments" -Column "class_key"/);
  assert.match(updater, /-Table "student_enrollments" -Column "created_at"/);
  assert.doesNotMatch(updater, /DROP TABLE student_enrollments;/);
  assert.match(updater, /-Table "assignment_submissions" -Column "score" -Definition "real"/);
  assert.match(page, /Các môn học của tôi/);
  assert.match(hub, /EnrollmentModal/);
});
