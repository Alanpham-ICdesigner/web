# EDUFLOW V26.2.4 — Student Manual Pomodoro Sync + Compact Stats

## Sửa lỗi liên kết thống kê Pomodoro bổ sung

- Trước V26.2.4, bảng GV đã cộng `student_focus_adjustments` nhưng API `/api/student/focus` chỉ đọc `student_focus_sessions`, nên học sinh có thể thấy `0 phiên · 0 phút` dù GV đã xác nhận thời gian học ngoài web.
- V26.2.4 cộng phần thủ công vào tổng phút **Hôm nay** và **Tuần này** trên trang học sinh.
- Số `phiên` vẫn chỉ đếm phiên Pomodoro thực sự hoàn thành trên EDUFLOW; thời gian thủ công không tạo phiên giả.
- Trang HS hiển thị thêm dòng nhỏ `+... ngoài web` khi có thời gian được GV xác nhận.

## Tinh gọn giao diện bảng thống kê GV

- Thay chuỗi dài `0 phiên hoàn tất · +45 phút ngoài web` bằng bố cục compact: `0 phiên` + chip `+45p`.
- Tooltip/aria-label của chip vẫn giải thích đây là thời gian học ngoài EDUFLOW do GV xác nhận.
- Giữ nguyên tổng phút lớn ở dòng trên.

## Database / migration

- Không có migration mới.
- Tiếp tục dùng bảng `student_focus_adjustments` của migration `0014_manual_focus_adjustments.sql`.

## Hành vi mong đợi

Ví dụ GV bổ sung 45 phút cho HS trong ngày:

- GV: tổng Pomodoro = 45 phút, `0 phiên` + chip `+45p`.
- HS: `Hôm nay: 0 phiên · 45 phút`, bên dưới có `+45 phút ngoài web`.
- Tuần của HS cũng cộng 45 phút.
- Không tăng số phiên hoàn thành.
