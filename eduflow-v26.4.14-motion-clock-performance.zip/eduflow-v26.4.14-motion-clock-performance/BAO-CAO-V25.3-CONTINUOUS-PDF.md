# EDUFLOW V25.3 — PDF cuộn dọc liên tục

## Thay đổi

- Trình xem PDF trong tab **Tài liệu** của giáo viên và học sinh hiển thị các trang nối tiếp theo chiều dọc.
- Cuộn chuột hoặc vuốt trên điện thoại sẽ chuyển tự nhiên sang trang kế tiếp; không bắt buộc dùng nút điều hướng.
- Trang hiện tại và thumbnail được đồng bộ theo vị trí cuộn.
- Có thể nhấn thumbnail, nhập số trang hoặc dùng nút trước/sau để nhảy nhanh đến trang cần xem.
- Dùng cơ chế dựng trang theo vùng nhìn để hạn chế tải nặng với PDF nhiều trang.
- Phần xem tệp thuộc **Bài tập** giữ nguyên chế độ từng trang như V25.2.

## Phạm vi an toàn

- Không đổi schema D1, dữ liệu, API, phân quyền, R2, route hay quy trình deploy.
- Giữ nguyên nền giao diện Astryx/TasteSkill và hỗ trợ light/dark, desktop/mobile hiện có.
