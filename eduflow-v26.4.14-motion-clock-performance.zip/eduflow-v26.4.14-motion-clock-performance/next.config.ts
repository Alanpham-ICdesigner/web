import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Keep the Server Action transport ceiling above EDUFLOW's own 10 MB limit.
  // Route handlers continue to validate and enforce the stricter application limit.
  experimental: {
    serverActions: {
      bodySizeLimit: "12mb",
    },
  },
};

export default nextConfig;
