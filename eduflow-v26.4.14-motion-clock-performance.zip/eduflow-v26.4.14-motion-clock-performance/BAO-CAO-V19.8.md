# EDUFLOW / PHMT MATH v19.8

## Phạm vi nâng cấp

Phiên bản v19.8 là một đợt nâng cấp UI/UX frontend theo hướng audit-first. Bản này không viết lại project và không thay đổi kiến trúc đang hoạt động.

## Đã cải thiện

- Chuẩn hóa design token dùng cho surface, text phụ, màu trạng thái, radius, focus ring và shadow.
- Tăng khả năng đọc cho các dòng chữ quá nhỏ ở Teacher UI và Student UI.
- Loại bỏ các asset Manrope cũ không còn được tham chiếu; Be Vietnam Pro tiếp tục là font giao diện duy nhất được import.
- Làm rõ cấp bậc page title, section title, card title, label, metadata và action.
- Đồng bộ kích thước, hover, active, focus-visible, disabled của button và form control.
- Cải thiện modal trên màn hình thấp, form trên mobile và vùng bấm cảm ứng.
- Thêm sticky header và hover row cho bảng dữ liệu; giữ chiến lược cuộn ngang trên mobile.
- Giới hạn và chuẩn hóa vùng cuộn cho quy tắc, lịch sử điểm, thông báo và trạng thái tải tệp.
- Đồng bộ light/dark mode cho các surface Student UI còn dùng màu sáng cố định.
- Ghi nhớ theme của Teacher UI; nếu chưa từng chọn thì dùng theme của hệ điều hành.
- Cải thiện mobile safe-area, bottom navigation, toast và tài liệu học sinh.
- Mở rộng focus-visible cho button, link, input, select, textarea và phần tử có tabindex.
- Tôn trọng `prefers-reduced-motion` cho animation, transition và smooth scroll.

## Cố tình giữ nguyên

- Tên PHMT MATH, logo, màu tím thương hiệu và font Be Vietnam Pro.
- Cấu trúc navigation, tên menu, route và URL.
- Authentication và quyền Teacher / Student.
- Business logic, API endpoint và Cloudflare Worker.
- Cloudflare D1, R2, bindings, schema, migrations và dữ liệu.
- Framework, dependencies, package manager và cấu trúc project.

## File nguồn thay đổi trong v19.8

- `app/globals.css`
- `app/page.tsx`
- `app/student/page.tsx`
- `package.json`
- `package-lock.json`
- `HUONG-DAN-CAP-NHAT.txt`
- `cap-nhat-cloudflare.ps1`

Không có file API, database, migration, Worker hay Cloudflare configuration nào được sửa bởi đợt redesign v19.8.
