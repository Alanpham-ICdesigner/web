# EDUFLOW V7.6.1 — Student clean UI

Nền: V7.6 (V7.5 + sửa ngày Dashboard/lời chào/giới tính).

## Web học sinh
Đã bỏ các dòng chú thích phụ màu xám không cần thiết dưới các tiêu đề chính/section để giao diện gọn hơn, gồm trang Các môn học của tôi/Lịch học tổng hợp, Quà có thể đổi, Lịch sử đổi quà, Tổng quan môn học, Lịch kiểm tra, Tài liệu, Bài tập, Điểm/Quá trình học và Nhận xét giáo viên.

Không xóa dữ liệu chức năng: tên giáo viên, phòng, giờ học, trạng thái, mô tả bài tập, điểm, ngày giờ và các thông báo trạng thái vẫn giữ nguyên.

Không có migration D1 mới.
