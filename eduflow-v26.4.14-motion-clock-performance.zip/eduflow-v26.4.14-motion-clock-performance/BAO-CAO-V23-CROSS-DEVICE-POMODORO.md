# EDUFLOW V23 — POMODORO ĐỒNG BỘ LAPTOP + ĐIỆN THOẠI

## Mục tiêu

Nâng Pomodoro từ timer lưu cục bộ trên từng trình duyệt thành timer **server-authoritative theo tài khoản học sinh**:

- Bắt đầu Focus trên laptop → mở cùng tài khoản trên điện thoại thấy đúng phiên và thời gian còn lại.
- Đổi thiết bị không tạo thêm một Pomodoro riêng và không ghi trùng lịch sử.
- Đóng tab / chuyển app / khóa màn hình: phase hiện tại vẫn chạy theo timestamp thực.
- Nếu không còn dashboard nào đang hoạt động và phase hết: dừng đúng tại ranh giới phase.
  - Focus hết → ghi nhận đúng 1 phiên, chuyển sang Break ở trạng thái chờ với đủ thời lượng Break.
  - Break hết → trở về Focus sẵn sàng, không tự chạy phiên tiếp theo.
- Nếu dashboard vẫn đang hiển thị khi Focus hết, flow cũ Focus → Break tự động vẫn được giữ.

## Kiến trúc đồng bộ

### D1 là nguồn trạng thái chuẩn

Migration `drizzle/0009_cross_device_focus_timer.sql` thêm bảng độc lập:

`student_focus_timer_state`

Mỗi học sinh có tối đa 1 row (`student_id` là primary key), gồm:

- `mode`: focus / break
- `status`: idle / running / paused
- `focus_minutes`, `break_minutes`
- `remaining_ms`
- `ends_at`
- `session_key`, `started_at`
- `revision`
- `created_at`, `updated_at`

Không lưu active timer vào bảng điểm, chuyên cần, bài tập hoặc streak.

### Đồng bộ chống xung đột

Mọi thao tác Start / Pause / Resume Break / Stop / Skip / đổi preset gửi `revision` hiện tại lên server.

Server update theo điều kiện:

`WHERE student_id = ? AND revision = ?`

Nếu laptop và điện thoại thao tác gần như cùng lúc, chỉ thao tác dùng revision mới nhất được chấp nhận. Thiết bị còn lại nhận HTTP 409 cùng state mới nhất rồi tự đồng bộ lại. Nhờ vậy không có hai active timer cùng tài khoản.

Client cũng từ chối response có revision cũ hơn state đang hiển thị, tránh trường hợp polling response về trễ ghi đè thao tác vừa bấm.

### Thời gian chuẩn

API trả `serverNow`. Client tính clock offset và hiển thị countdown theo:

`endsAt - (Date.now() + serverOffset)`

Vì vậy đồng hồ điện thoại/laptop lệch vài phút cũng không làm Pomodoro chạy sai.

### Polling có kiểm soát

Khi Dashboard HS đang mở:

- đồng bộ timer mỗi 10 giây;
- đồng bộ ngay khi tab/app trở lại `visible`;
- đồng bộ ngay khi window focus lại;
- đồng bộ khi mạng trở lại `online`.

Polling dùng `?timerOnly=1`, chỉ đọc đúng row timer và không query bảng thống kê Focus mỗi 10 giây. Stats chỉ tải khi cần để hạn chế D1 Rows Read.

## Ranh giới phase và lịch sử

Server tự reconcile khi đọc state đã hết hạn:

- Focus hết: `INSERT OR IGNORE` vào `student_focus_sessions`, sau đó chuyển timer sang Break `paused`.
- Break hết: chuyển timer về Focus `idle`.
- Không bao giờ tự tiêu thụ phase tiếp theo khi không có dashboard đang hoạt động.

Unique key hiện hữu `(student_id, session_key)` tiếp tục đảm bảo một Focus session chỉ được ghi một lần ngay cả khi laptop và điện thoại cùng phát hiện boundary.

Tab Thống kê GV cũng reconcile các timer Focus đã hết trước khi aggregate, nên tổng phút Pomodoro vẫn đúng kể cả học sinh chưa mở lại web sau khi Focus kết thúc.

## D1 / migration

Migration V23 chỉ:

- `CREATE TABLE IF NOT EXISTS student_focus_timer_state`
- `CREATE INDEX IF NOT EXISTS student_focus_timer_running_end_idx`

Không `DROP`, `TRUNCATE`, `DELETE` hay sửa dữ liệu học tập hiện tại.

Index `(status, ends_at)` phục vụ truy vấn timer hết hạn mà không quét toàn bảng.

Script `cap-nhat-cloudflare.ps1` xác minh table, các cột chính và index V23 trước khi deploy Worker mới.

## Astryx + TasteSkill

Lần thay đổi này là logic + data synchronization. Không thay đổi cấu trúc card, spacing, breakpoint, màu, typography hoặc motion hiện tại.

Đã recheck với source `astryx-main` và `taste-skill-main`:

- giữ component stack hiện tại, không rewrite framework;
- không thêm dependency UI;
- không thêm animation layout-triggering;
- Punch vẫn chỉ animate bằng sprite/transform hiện tại;
- giữ `prefers-reduced-motion`;
- control vẫn dùng focus-visible và interaction state hiện hữu;
- không làm thay đổi footprint của card trên desktop/mobile.

## Kiểm thử

- Toàn bộ source/regression tests không cần production artifact: **114/114 PASS**.
- Nhóm V23 cross-device: migration, revision CAS, boundary stop, polling/visibility sync, teacher reconciliation và deploy verification đều PASS.
- TS/TSX thay đổi được transpile syntax bằng TypeScript 5.x: PASS.
- SQLite migration test: table/index tạo thành công; query expired timer dùng `student_focus_timer_running_end_idx`.
- `rendered-html.test.mjs` vẫn cần `dist/server/index.js`, nên chỉ chạy sau bước production build trong workflow deploy trên máy người dùng.

## File thay đổi chính

- `app/student/pet-focus-companion.tsx`
- `app/api/student/focus/route.ts`
- `app/api/admin/student-engagement/route.ts`
- `lib/focus-timer.ts`
- `db/schema.ts`
- `drizzle/0009_cross_device_focus_timer.sql`
- `cap-nhat-cloudflare.ps1`
- tests V23 và cập nhật regression Pomodoro cũ
