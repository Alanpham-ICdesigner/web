# EDUFLOW V7.6 — Dashboard date & gender greeting

Nền: V7.5.

## Sửa lỗi ngày điểm danh Tổng quan
Dashboard trước đây lấy ngày điểm danh mới nhất trong CSDL. Nếu có bản ghi tương lai (ví dụ 24/09/2026), card vẫn hiện ngày đó dù ngày hiện tại là 02/09/2026.

V7.6 dùng `localDateInTimeZone()` với múi giờ `Asia/Ho_Chi_Minh` và chỉ tổng hợp bản ghi đúng ngày hiện tại. Nếu chưa điểm danh trong ngày, donut hiển thị `— / Chưa điểm danh` thay vì `0% Chuyên cần`.

## Lời chào theo giờ và giới tính
Cài đặt hồ sơ có trường `Giới tính`:
- Nam → Thầy
- Nữ → Cô

Lời chào tự động theo giờ Việt Nam:
- 05:00–11:59: Chào buổi sáng
- 12:00–17:59: Chào buổi chiều
- 18:00–04:59: Chào buổi tối

Cấu hình giới tính nằm trong JSON `settings/profile` hiện có, không tạo migration D1.

## Lịch dạy hôm nay
Loại bỏ ngày hard-code. Ngày và thứ lấy theo giờ Việt Nam; chỉ các lịch định kỳ đúng thứ hiện tại được đưa vào card, kèm giờ, phòng, số học sinh và trạng thái đang diễn ra / sắp tới / đã kết thúc.
