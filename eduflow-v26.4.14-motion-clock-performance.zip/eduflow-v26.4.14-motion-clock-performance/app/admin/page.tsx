export { AdminPortal as default } from "../page";
