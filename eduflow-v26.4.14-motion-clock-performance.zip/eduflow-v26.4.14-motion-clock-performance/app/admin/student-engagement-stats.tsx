"use client";

import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Flame,
  History,
  RefreshCw,
  Search,
  Save,
  TimerReset,
  Trophy,
  UserRoundCheck,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { localDateInTimeZone } from "../../lib/admin-ui-utils.mjs";

type PeriodMode = "day" | "week" | "month";
type SortKey = "name" | "class" | "checkins" | "currentStreak" | "longestStreak" | "totalCheckins" | "focusMinutes";
type SortDirection = "asc" | "desc";

type EngagementRow = {
  studentId: number;
  code: string;
  name: string;
  classKeys: string[];
  classNames: string[];
  currentStreak: number;
  longestStreak: number;
  totalCheckins: number;
  lastCheckinDate: string;
  periodCheckins: number;
  latestPeriodCheckin: string;
  earliestPeriodCheckinAt: string;
  trackedFocusMinutes: number;
  manualFocusMinutes: number;
  manualFocusNote: string;
  focusMinutes: number;
  focusSessions: number;
  focusTimerMode: "focus" | "break";
  focusTimerStatus: "idle" | "running" | "paused";
  focusTimerRemainingMs: number;
  focusTimerEndsAt: string;
};

type EngagementPayload = {
  period: PeriodMode;
  anchorDate: string;
  periodStart: string;
  periodEnd: string;
  periodDayCount: number;
  serverNow: string;
  receivedAt: number;
  rows: EngagementRow[];
};

type FocusAdjustmentHistoryRow = {
  id: number;
  studentId: number;
  code: string;
  name: string;
  classKeys: string[];
  classNames: string[];
  date: string;
  previousManualMinutes: number;
  manualMinutes: number;
  deltaMinutes: number;
  trackedFocusMinutes: number;
  focusMinutesAfter: number;
  note: string;
  createdAt: string;
};

type ClassOption = { key: string; name: string };

function normalizeText(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLocaleLowerCase("vi")
    .trim();
}

function dateParts(dateKey: string): number[] {
  return dateKey.split("-").map(Number);
}

function shiftDate(dateKey: string, days: number): string {
  const parts = dateParts(dateKey);
  if (parts.length !== 3 || parts.some(function(value) { return !Number.isFinite(value); })) return dateKey;
  return new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + days)).toISOString().slice(0, 10);
}

function shiftMonth(dateKey: string, months: number): string {
  const parts = dateParts(dateKey);
  if (parts.length !== 3 || parts.some(function(value) { return !Number.isFinite(value); })) return dateKey;
  const target = new Date(Date.UTC(parts[0], parts[1] - 1 + months, 1));
  const lastDay = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(parts[2], lastDay));
  return target.toISOString().slice(0, 10);
}

function formatDate(dateKey: string): string {
  const parts = dateParts(dateKey);
  if (parts.length !== 3 || parts.some(function(value) { return !Number.isFinite(value); })) return dateKey || "—";
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(parts[0], parts[1] - 1, parts[2])));
}

function formatCheckinTime(value: string): string {
  if (!value) return "—";
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "—";
  return new Intl.DateTimeFormat("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "Asia/Ho_Chi_Minh",
  }).format(date);
}

function formatAdjustmentTimestamp(value: string): string {
  if (!value) return "—";
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "—";
  return new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "Asia/Ho_Chi_Minh",
  }).format(date);
}

function formatSignedFocusDuration(deltaMinutes: number): string {
  if (!deltaMinutes) return "0 phút";
  const sign = deltaMinutes > 0 ? "+" : "−";
  return sign + formatFocusDuration(Math.abs(deltaMinutes));
}

function formatCountdown(totalMs: number): string {
  const safeSeconds = Math.max(0, Math.ceil(totalMs / 1000));
  const hours = Math.floor(safeSeconds / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  const seconds = safeSeconds % 60;
  const minuteText = String(minutes).padStart(2, "0");
  const secondText = String(seconds).padStart(2, "0");
  return hours > 0 ? hours + ":" + minuteText + ":" + secondText : minuteText + ":" + secondText;
}

function formatFocusDuration(totalMinutes: number): string {
  const minutes = Math.max(0, Math.round(totalMinutes));
  const hours = Math.floor(minutes / 60);
  const remain = minutes % 60;
  if (!hours) return remain + " phút";
  if (!remain) return hours + " giờ";
  return hours + " giờ " + remain + " phút";
}

function classLabel(row: EngagementRow): string {
  return row.classNames.length ? row.classNames.join(" · ") : "Chưa xếp lớp";
}

function compareRows(a: EngagementRow, b: EngagementRow, key: SortKey): number {
  if (key === "name") return a.name.localeCompare(b.name, "vi", { sensitivity: "base" });
  if (key === "class") return classLabel(a).localeCompare(classLabel(b), "vi", { sensitivity: "base" });
  if (key === "checkins") return a.periodCheckins - b.periodCheckins;
  if (key === "currentStreak") return a.currentStreak - b.currentStreak;
  if (key === "longestStreak") return a.longestStreak - b.longestStreak;
  if (key === "totalCheckins") return a.totalCheckins - b.totalCheckins;
  return a.focusMinutes - b.focusMinutes;
}

function SortButton(props: {
  active: boolean;
  direction: SortDirection;
  label: string;
  onClick: () => void;
}) {
  const Icon = props.active ? (props.direction === "asc" ? ArrowUp : ArrowDown) : ArrowUpDown;
  return (
    <button type="button" className={props.active ? "engagement-sort active" : "engagement-sort"} onClick={props.onClick} aria-label={props.label}>
      <span>{props.label}</span>
      <Icon size={13} aria-hidden="true" />
    </button>
  );
}

function periodWord(period: PeriodMode): string {
  if (period === "week") return "tuần";
  if (period === "month") return "tháng";
  return "ngày";
}

export function StudentEngagementStats(props: { classes: ClassOption[] }) {
  const today = localDateInTimeZone();
  const [period, setPeriod] = useState<PeriodMode>("day");
  const [date, setDate] = useState(today);
  const [query, setQuery] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [sortKey, setSortKey] = useState<SortKey>("currentStreak");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  const [payload, setPayload] = useState<EngagementPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadToken, setReloadToken] = useState(0);
  const [manualRefreshing, setManualRefreshing] = useState(false);
  const [clockNow, setClockNow] = useState(Date.now());
  const [adjustmentStudentId, setAdjustmentStudentId] = useState(0);
  const [adjustmentHours, setAdjustmentHours] = useState("0");
  const [adjustmentExtraMinutes, setAdjustmentExtraMinutes] = useState("0");
  const [adjustmentNote, setAdjustmentNote] = useState("");
  const [adjustmentDirty, setAdjustmentDirty] = useState(false);
  const [adjustmentSaving, setAdjustmentSaving] = useState(false);
  const [adjustmentMessage, setAdjustmentMessage] = useState("");
  const [adjustmentError, setAdjustmentError] = useState("");
  const [adjustmentHistory, setAdjustmentHistory] = useState<FocusAdjustmentHistoryRow[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [historyError, setHistoryError] = useState("");
  const [historyReloadToken, setHistoryReloadToken] = useState(0);
  const payloadRef = useRef<EngagementPayload | null>(null);
  const queryKeyRef = useRef("");

  useEffect(function() {
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      const queryKey = period + ":" + date;
      const backgroundRefresh = queryKeyRef.current === queryKey && Boolean(payloadRef.current);
      setLoading(!backgroundRefresh);
      if (!backgroundRefresh) {
        payloadRef.current = null;
        setPayload(null);
      }
      setError("");
      try {
        const response = await fetch("/api/admin/student-engagement?period=" + period + "&date=" + encodeURIComponent(date), {
          cache: "no-store",
          signal: controller.signal,
        });
        const data = await response.json().catch(function() { return {}; }) as EngagementPayload & { error?: string };
        if (!response.ok) throw new Error(data.error || "Không thể tải thống kê học sinh.");
        if (!cancelled) {
          const next = { ...data, receivedAt: Date.now() };
          payloadRef.current = next;
          queryKeyRef.current = queryKey;
          setPayload(next);
        }
      } catch (loadError) {
        if (controller.signal.aborted) return;
        if (!cancelled && !payloadRef.current) setError(loadError instanceof Error ? loadError.message : "Không thể tải thống kê học sinh.");
      } finally {
        if (!cancelled) {
          setLoading(false);
          setManualRefreshing(false);
        }
      }
    }
    void load();
    return function() {
      cancelled = true;
      controller.abort();
    };
  }, [period, date, reloadToken]);

  useEffect(function() {
    if (period !== "day") return;
    const tick = window.setInterval(function() { setClockNow(Date.now()); }, 1000);
    const sync = window.setInterval(function() { setReloadToken(function(value) { return value + 1; }); }, 10_000);
    return function() {
      window.clearInterval(tick);
      window.clearInterval(sync);
    };
  }, [period]);

  useEffect(function() {
    let cancelled = false;
    const controller = new AbortController();
    async function loadHistory() {
      setHistoryLoading(true);
      setHistoryError("");
      try {
        const response = await fetch("/api/admin/student-engagement?view=adjustment-history&limit=60", {
          cache: "no-store",
          signal: controller.signal,
        });
        const data = await response.json().catch(function() { return {}; }) as { history?: FocusAdjustmentHistoryRow[]; error?: string };
        if (!response.ok) throw new Error(data.error || "Không thể tải lịch sử bổ sung Pomodoro.");
        if (!cancelled) setAdjustmentHistory(Array.isArray(data.history) ? data.history : []);
      } catch (loadError) {
        if (controller.signal.aborted) return;
        if (!cancelled) setHistoryError(loadError instanceof Error ? loadError.message : "Không thể tải lịch sử bổ sung Pomodoro.");
      } finally {
        if (!cancelled) setHistoryLoading(false);
      }
    }
    void loadHistory();
    return function() {
      cancelled = true;
      controller.abort();
    };
  }, [historyReloadToken]);

  const selectedClass = props.classes.find(function(item) { return item.key === classFilter; });
  const rows = useMemo(function() {
    const needle = normalizeText(query);
    return (payload?.rows || [])
      .filter(function(row) {
        if (classFilter !== "all") {
          const keyMatch = row.classKeys.includes(classFilter);
          const nameMatch = selectedClass ? row.classNames.includes(selectedClass.name) : false;
          if (!keyMatch && !nameMatch) return false;
        }
        if (!needle) return true;
        return normalizeText(row.name + " " + row.code + " " + classLabel(row)).includes(needle);
      })
      .slice()
      .sort(function(a, b) {
        const compared = compareRows(a, b, sortKey);
        if (compared !== 0) return sortDirection === "asc" ? compared : -compared;
        return a.name.localeCompare(b.name, "vi", { sensitivity: "base" });
      });
  }, [payload, query, classFilter, selectedClass, sortKey, sortDirection]);

  const visibleAdjustmentHistory = useMemo(function() {
    const needle = normalizeText(query);
    return adjustmentHistory.filter(function(item) {
      if (classFilter !== "all") {
        const keyMatch = item.classKeys.includes(classFilter);
        const nameMatch = selectedClass ? item.classNames.includes(selectedClass.name) : false;
        if (!keyMatch && !nameMatch) return false;
      }
      if (!needle) return true;
      return normalizeText(item.name + " " + item.code + " " + item.classNames.join(" ") + " " + item.note + " " + item.date).includes(needle);
    });
  }, [adjustmentHistory, query, classFilter, selectedClass]);

  const adjustmentStudent = rows.find(function(row) { return row.studentId === adjustmentStudentId; }) || null;

  useEffect(function() {
    if (period !== "day") return;
    if (!rows.length) {
      setAdjustmentStudentId(0);
      if (!adjustmentDirty) {
        setAdjustmentHours("0");
        setAdjustmentExtraMinutes("0");
        setAdjustmentNote("");
      }
      return;
    }
    const selected = rows.find(function(row) { return row.studentId === adjustmentStudentId; }) || rows[0];
    if (selected.studentId !== adjustmentStudentId) {
      setAdjustmentStudentId(selected.studentId);
      setAdjustmentDirty(false);
      setAdjustmentMessage("");
      setAdjustmentError("");
    }
    if (!adjustmentDirty) {
      setAdjustmentHours(String(Math.floor(selected.manualFocusMinutes / 60)));
      setAdjustmentExtraMinutes(String(selected.manualFocusMinutes % 60));
      setAdjustmentNote(selected.manualFocusNote || "");
    }
  }, [period, date, rows, adjustmentStudentId, adjustmentDirty]);

  const summary = useMemo(function() {
    const source = rows;
    const earliestCheckin = source
      .filter(function(row) { return Boolean(row.earliestPeriodCheckinAt); })
      .slice()
      .sort(function(a, b) {
        const time = a.earliestPeriodCheckinAt.localeCompare(b.earliestPeriodCheckinAt);
        return time || a.name.localeCompare(b.name, "vi", { sensitivity: "base" });
      })[0] || null;
    const topStreak = source
      .filter(function(row) { return row.currentStreak > 0; })
      .slice()
      .sort(function(a, b) {
        return b.currentStreak - a.currentStreak || a.name.localeCompare(b.name, "vi", { sensitivity: "base" });
      })[0] || null;
    const topFocus = source
      .filter(function(row) { return row.focusMinutes > 0; })
      .slice()
      .sort(function(a, b) {
        return b.focusMinutes - a.focusMinutes || a.name.localeCompare(b.name, "vi", { sensitivity: "base" });
      })[0] || null;
    return {
      activeStudents: source.filter(function(row) { return row.periodCheckins > 0; }).length,
      checkins: source.reduce(function(total, row) { return total + row.periodCheckins; }, 0),
      earliestCheckin,
      topStreak,
      topFocus,
    };
  }, [rows]);

  function toggleSort(nextKey: SortKey) {
    if (sortKey === nextKey) {
      setSortDirection(function(current) { return current === "asc" ? "desc" : "asc"; });
      return;
    }
    setSortKey(nextKey);
    setSortDirection(nextKey === "name" || nextKey === "class" ? "asc" : "desc");
  }

  function movePeriod(direction: number) {
    setDate(function(current) {
      const next = period === "month" ? shiftMonth(current, direction) : shiftDate(current, direction * (period === "week" ? 7 : 1));
      return next > today ? today : next;
    });
  }

  function refreshData() {
    if (manualRefreshing) return;
    setManualRefreshing(true);
    setReloadToken(function(value) { return value + 1; });
  }

  function chooseAdjustmentStudent(studentId: number) {
    const selected = rows.find(function(row) { return row.studentId === studentId; });
    setAdjustmentStudentId(studentId);
    setAdjustmentDirty(false);
    setAdjustmentMessage("");
    setAdjustmentError("");
    if (selected) {
      setAdjustmentHours(String(Math.floor(selected.manualFocusMinutes / 60)));
      setAdjustmentExtraMinutes(String(selected.manualFocusMinutes % 60));
      setAdjustmentNote(selected.manualFocusNote || "");
    }
  }

  async function saveFocusAdjustment() {
    if (!adjustmentStudent || adjustmentSaving || period !== "day") return;
    const hours = Number(adjustmentHours);
    const extraMinutes = Number(adjustmentExtraMinutes);
    if (!Number.isInteger(hours) || hours < 0 || hours > 24 || !Number.isInteger(extraMinutes) || extraMinutes < 0 || extraMinutes > 59 || (hours === 24 && extraMinutes > 0)) {
      setAdjustmentError("Nhập từ 0 đến 24 giờ; phần phút từ 0 đến 59.");
      setAdjustmentMessage("");
      return;
    }
    const manualMinutes = hours * 60 + extraMinutes;
    if (adjustmentStudent.trackedFocusMinutes + manualMinutes > 1440) {
      setAdjustmentError("Tổng Pomodoro trong ngày không thể vượt quá 24 giờ.");
      setAdjustmentMessage("");
      return;
    }
    setAdjustmentSaving(true);
    setAdjustmentError("");
    setAdjustmentMessage("");
    try {
      const response = await fetch("/api/admin/student-engagement", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId: adjustmentStudent.studentId, date, manualMinutes, note: adjustmentNote }),
      });
      const result = await response.json().catch(function() { return {}; }) as {
        error?: string;
        changed?: boolean;
        notificationCreated?: boolean;
        historyRecorded?: boolean;
        studentId?: number;
        trackedFocusMinutes?: number;
        manualFocusMinutes?: number;
        manualFocusNote?: string;
        focusMinutes?: number;
        focusSessions?: number;
      };
      if (!response.ok) throw new Error(result.error || "Không thể lưu thời gian Pomodoro bổ sung.");
      const current = payloadRef.current;
      if (current && Number(result.studentId) === adjustmentStudent.studentId) {
        const next: EngagementPayload = {
          ...current,
          rows: current.rows.map(function(row) {
            if (row.studentId !== adjustmentStudent.studentId) return row;
            return {
              ...row,
              trackedFocusMinutes: Math.max(0, Number(result.trackedFocusMinutes) || 0),
              manualFocusMinutes: Math.max(0, Number(result.manualFocusMinutes) || 0),
              manualFocusNote: String(result.manualFocusNote || ""),
              focusMinutes: Math.max(0, Number(result.focusMinutes) || 0),
              focusSessions: Math.max(0, Number(result.focusSessions) || 0),
            };
          }),
        };
        payloadRef.current = next;
        setPayload(next);
      }
      const savedManual = Math.max(0, Number(result.manualFocusMinutes) || 0);
      setAdjustmentHours(String(Math.floor(savedManual / 60)));
      setAdjustmentExtraMinutes(String(savedManual % 60));
      setAdjustmentNote(String(result.manualFocusNote || ""));
      setAdjustmentDirty(false);
      if (result.historyRecorded) setHistoryReloadToken(function(value) { return value + 1; });
      setAdjustmentMessage(result.notificationCreated ? "Đã lưu. Thống kê, lịch sử và thông báo học sinh đã được cập nhật." : result.changed ? "Đã lưu vào lịch sử. Số phút không đổi nên không gửi thêm thông báo." : "Dữ liệu không thay đổi.");
    } catch (reason) {
      setAdjustmentError(reason instanceof Error ? reason.message : "Không thể lưu thời gian Pomodoro bổ sung.");
    } finally {
      setAdjustmentSaving(false);
    }
  }

  const currentMonth = today.slice(0, 7);
  const canMoveForward = period === "month" ? date.slice(0, 7) < currentMonth : date < today;
  const pickerValue = period === "month" ? date.slice(0, 7) : date;
  const pickerMax = period === "month" ? currentMonth : today;
  const navigationLabel = periodWord(period);
  const activeLabel = period === "day" ? "Đã check-in" : "Có check-in trong " + navigationLabel;
  const checkinColumnLabel = period === "day" ? "Điểm danh" : "Check-in " + navigationLabel;
  const focusColumnLabel = "Pomodoro " + navigationLabel;
  const periodRangeLabel = payload
    ? period === "week"
      ? "Tuần từ " + formatDate(payload.periodStart) + " đến " + formatDate(payload.periodEnd)
      : period === "month"
        ? "Tháng từ " + formatDate(payload.periodStart) + " đến " + formatDate(payload.periodEnd)
        : "Ngày " + formatDate(payload.periodStart)
    : "";
  const tertiaryTitle = period === "day" ? "Check-in sớm nhất" : "Streak cao nhất";
  const tertiaryValue = period === "day"
    ? summary.earliestCheckin ? summary.earliestCheckin.name + " · " + formatCheckinTime(summary.earliestCheckin.earliestPeriodCheckinAt) : "Chưa có"
    : summary.topStreak ? summary.topStreak.name + " · " + summary.topStreak.currentStreak + " ngày" : "Chưa có";
  const focusLeaderValue = summary.topFocus ? summary.topFocus.name + " · " + summary.topFocus.focusMinutes + " phút" : "Chưa có";

  return (
    <section className="card engagement-stats-card" aria-labelledby="engagement-stats-title">
      <header className="engagement-stats-head">
        <div>
          <span className="engagement-eyebrow"><Flame size={15} /> Hoạt động học tập</span>
          <h2 id="engagement-stats-title">Điểm danh streak & Pomodoro</h2>
          <p>Check-in và Pomodoro theo ngày, tuần hoặc tháng đã chọn; streak hiện tại, kỷ lục và tổng check-in là thành tích toàn thời gian. Không thay đổi điểm học tập hay chuyên cần trên lớp.</p>
        </div>
        <div className="engagement-period-switch" role="group" aria-label="Chọn chu kỳ thống kê">
          <button type="button" className={period === "day" ? "active" : ""} aria-pressed={period === "day"} onClick={function() { setPeriod("day"); }}>Ngày</button>
          <button type="button" className={period === "week" ? "active" : ""} aria-pressed={period === "week"} onClick={function() { setPeriod("week"); }}>Tuần</button>
          <button type="button" className={period === "month" ? "active" : ""} aria-pressed={period === "month"} onClick={function() { setPeriod("month"); }}>Tháng</button>
        </div>
      </header>

      <div className="engagement-toolbar">
        <div className="engagement-date-nav">
          <button type="button" className="icon-button" aria-label={navigationLabel + " trước"} onClick={function() { movePeriod(-1); }}><ChevronLeft size={16} /></button>
          <label className="engagement-date-picker">
            <input
              type={period === "month" ? "month" : "date"}
              value={pickerValue}
              max={pickerMax}
              onChange={function(event) {
                const value = event.target.value;
                if (!value) return setDate(today);
                setDate(period === "month" ? value + "-01" : value);
              }}
              aria-label={period === "month" ? "Tháng thống kê" : "Ngày thống kê"}
            />
          </label>
          <button type="button" className="icon-button" aria-label={navigationLabel + " sau"} disabled={!canMoveForward} onClick={function() { movePeriod(1); }}><ChevronRight size={16} /></button>
          <button type="button" className="engagement-today" onClick={function() { setDate(today); }}>{period === "month" ? "Tháng này" : "Hôm nay"}</button>
        </div>
        <div className="engagement-toolbar-actions">
          <label className="engagement-search">
            <Search size={16} aria-hidden="true" />
            <input value={query} onChange={function(event) { setQuery(event.target.value); }} placeholder="Tìm tên hoặc mã học sinh..." />
          </label>
          <select className="select" value={classFilter} onChange={function(event) { setClassFilter(event.target.value); }} aria-label="Lọc theo lớp">
            <option value="all">Tất cả lớp</option>
            {props.classes.map(function(item) { return <option key={item.key} value={item.key}>{item.name}</option>; })}
          </select>
          <button
            type="button"
            className={manualRefreshing ? "icon-button engagement-refresh is-refreshing" : "icon-button engagement-refresh"}
            title={manualRefreshing ? "Đang làm mới dữ liệu" : "Làm mới dữ liệu"}
            aria-label={manualRefreshing ? "Đang làm mới dữ liệu" : "Làm mới dữ liệu"}
            aria-busy={manualRefreshing}
            disabled={manualRefreshing}
            onClick={refreshData}
          >
            <RefreshCw size={16} aria-hidden="true" />
          </button>
        </div>
      </div>

      <div className="engagement-period-meta engagement-period-meta-count-only engagement-period-meta-with-range">
        <strong className="engagement-period-range"><CalendarDays size={14} />{loading ? "Đang xác định khoảng thời gian..." : periodRangeLabel}</strong>
        <span>{loading ? "Đang tải dữ liệu..." : error ? "Chưa có dữ liệu để hiển thị" : rows.length + " học sinh" + (classFilter === "all" ? "" : " trong lớp đã chọn")}</span>
      </div>

      <div className="engagement-summary" aria-label="Tóm tắt hoạt động" aria-busy={loading}>
        <span><CheckCircle2 size={16} /><small>{activeLabel}</small><strong>{loading || error ? "—" : summary.activeStudents + "/" + rows.length}</strong></span>
        <span><CalendarDays size={16} /><small>Lượt check-in</small><strong>{loading || error ? "—" : summary.checkins}</strong></span>
        <span title={loading || error ? "" : tertiaryValue}><Flame size={16} /><small>{tertiaryTitle}</small><strong>{loading || error ? "—" : tertiaryValue}</strong></span>
        <span title={loading || error ? "" : focusLeaderValue}><TimerReset size={16} /><small>Pomodoro nhiều nhất</small><strong>{loading || error ? "—" : focusLeaderValue}</strong></span>
      </div>

      {error ? (
        <div className="engagement-state error" role="alert">
          <strong>Không tải được thống kê.</strong>
          <span>{error}</span>
          <button type="button" className="button soft" onClick={function() { setReloadToken(function(value) { return value + 1; }); }}>Thử lại</button>
        </div>
      ) : (
        <div className="engagement-table-scroll scroll-region" tabIndex={0} aria-label="Bảng thống kê streak và Pomodoro">
          <table className={period === "day" ? "engagement-table has-live-focus" : "engagement-table"}>
            <thead>
              <tr>
                <th aria-sort={sortKey === "name" ? (sortDirection === "asc" ? "ascending" : "descending") : "none"}><SortButton active={sortKey === "name"} direction={sortDirection} label="Học sinh" onClick={function() { toggleSort("name"); }} /></th>
                <th aria-sort={sortKey === "class" ? (sortDirection === "asc" ? "ascending" : "descending") : "none"}><SortButton active={sortKey === "class"} direction={sortDirection} label="Lớp" onClick={function() { toggleSort("class"); }} /></th>
                <th aria-sort={sortKey === "checkins" ? (sortDirection === "asc" ? "ascending" : "descending") : "none"}><SortButton active={sortKey === "checkins"} direction={sortDirection} label={checkinColumnLabel} onClick={function() { toggleSort("checkins"); }} /></th>
                <th aria-sort={sortKey === "currentStreak" ? (sortDirection === "asc" ? "ascending" : "descending") : "none"}><SortButton active={sortKey === "currentStreak"} direction={sortDirection} label="Streak hiện tại" onClick={function() { toggleSort("currentStreak"); }} /></th>
                <th aria-sort={sortKey === "longestStreak" ? (sortDirection === "asc" ? "ascending" : "descending") : "none"}><SortButton active={sortKey === "longestStreak"} direction={sortDirection} label="Kỷ lục" onClick={function() { toggleSort("longestStreak"); }} /></th>
                <th aria-sort={sortKey === "totalCheckins" ? (sortDirection === "asc" ? "ascending" : "descending") : "none"}><SortButton active={sortKey === "totalCheckins"} direction={sortDirection} label="Tổng check-in" onClick={function() { toggleSort("totalCheckins"); }} /></th>
                <th aria-sort={sortKey === "focusMinutes" ? (sortDirection === "asc" ? "ascending" : "descending") : "none"}><SortButton active={sortKey === "focusMinutes"} direction={sortDirection} label={focusColumnLabel} onClick={function() { toggleSort("focusMinutes"); }} /></th>
                {period === "day" ? <th>Pomodoro hiện tại</th> : null}
              </tr>
            </thead>
            <tbody>
              {loading ? Array.from({ length: 5 }, function(_, index) {
                return <tr className="engagement-skeleton" key={index}>{Array.from({ length: period === "day" ? 8 : 7 }, function(__, cell) { return <td key={cell}><i /></td>; })}</tr>;
              }) : rows.map(function(row) {
                const checked = row.periodCheckins > 0;
                const serverBase = payload ? Date.parse(payload.serverNow) : clockNow;
                const estimatedServerNow = Number.isFinite(serverBase) && payload ? serverBase + (clockNow - payload.receivedAt) : clockNow;
                const endAt = Date.parse(row.focusTimerEndsAt);
                const liveRemainingMs = row.focusTimerStatus === "running" && Number.isFinite(endAt)
                  ? Math.max(0, endAt - estimatedServerNow)
                  : row.focusTimerRemainingMs;
                return (
                  <tr key={row.studentId}>
                    <td className="engagement-student-cell"><strong>{row.name}</strong><small>{row.code}</small></td>
                    <td className="engagement-class-cell" title={classLabel(row)}>{classLabel(row)}</td>
                    <td>
                      {period === "day" ? <span className={checked ? "engagement-checkin yes" : "engagement-checkin no"}>{checked ? "Đã check-in" : "Chưa check-in"}</span> : <strong className="engagement-number">{row.periodCheckins}<small>/{payload?.periodDayCount || (period === "month" ? 30 : 7)} ngày</small></strong>}
                      {period !== "day" && row.latestPeriodCheckin ? <small className="engagement-subline">Gần nhất {formatDate(row.latestPeriodCheckin)}</small> : null}
                    </td>
                    <td><strong className="engagement-number"><Flame size={14} />{row.currentStreak}<small>ngày</small></strong></td>
                    <td><strong className="engagement-number"><Trophy size={14} />{row.longestStreak}<small>ngày</small></strong></td>
                    <td><strong className="engagement-number">{row.totalCheckins}<small>ngày</small></strong></td>
                    <td>
                      <strong className="engagement-number"><Clock3 size={14} />{row.focusMinutes}<small>phút</small></strong>
                      <span className="engagement-focus-meta">
                        <small className="engagement-subline">{row.focusSessions} phiên</small>
                        {row.manualFocusMinutes > 0 ? <span className="engagement-manual-chip" title={row.manualFocusMinutes + " phút học ngoài EDUFLOW được giáo viên xác nhận"} aria-label={"Bổ sung " + row.manualFocusMinutes + " phút ngoài web"}>+{row.manualFocusMinutes}p</span> : null}
                      </span>
                    </td>
                    {period === "day" ? <td>{row.focusTimerStatus === "idle" ? <span className="engagement-live-focus idle">Không hoạt động</span> : <span className={"engagement-live-focus " + row.focusTimerStatus + " " + row.focusTimerMode}><i /><span><strong>{row.focusTimerStatus === "paused" ? "Đang tạm dừng" : row.focusTimerMode === "break" ? "Đang nghỉ" : "Đang tập trung"}</strong><time>{formatCountdown(liveRemainingMs)}</time></span></span>}</td> : null}
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!loading && !rows.length ? <div className="engagement-state"><strong>Chưa có học sinh phù hợp.</strong><span>Đổi lớp, thời gian hoặc từ khóa để xem dữ liệu khác.</span></div> : null}
        </div>
      )}

      {period === "day" ? (
        <div className="engagement-adjustment-panel" aria-labelledby="focus-adjustment-title">
          <div className="engagement-adjustment-head">
            <div>
              <span className="engagement-eyebrow"><UserRoundCheck size={15} /> Xác nhận học ngoài web</span>
              <h3 id="focus-adjustment-title">Bổ sung Pomodoro theo ngày</h3>
              <p>Dùng khi học sinh có học tập trung nhưng không bật EDUFLOW. Phần này chỉ cộng thời gian thống kê, không tạo phiên Pomodoro giả.</p>
            </div>
            <strong className="engagement-adjustment-date"><CalendarDays size={14} />{formatDate(date)}</strong>
          </div>

          <div className="engagement-adjustment-grid">
            <label>
              <span>Học sinh</span>
              <select className="select" value={adjustmentStudentId || ""} disabled={!rows.length || adjustmentSaving} onChange={function(event) { chooseAdjustmentStudent(Number(event.target.value)); }}>
                {!rows.length ? <option value="">Không có học sinh</option> : rows.map(function(row) { return <option key={row.studentId} value={row.studentId}>{row.name} · {row.code}</option>; })}
              </select>
            </label>
            <div className="engagement-adjustment-metric">
              <span>Web ghi nhận</span>
              <strong>{adjustmentStudent ? formatFocusDuration(adjustmentStudent.trackedFocusMinutes) : "—"}</strong>
              <small>{adjustmentStudent ? adjustmentStudent.focusSessions + " phiên hoàn tất" : "Chọn học sinh"}</small>
            </div>
            <fieldset className="engagement-adjustment-time" disabled={!adjustmentStudent || adjustmentSaving}>
              <legend>Thời gian bổ sung ngoài web</legend>
              <label><input type="number" inputMode="numeric" min="0" max="24" step="1" value={adjustmentHours} onChange={function(event) { setAdjustmentHours(event.target.value); setAdjustmentDirty(true); setAdjustmentMessage(""); setAdjustmentError(""); }} /><span>giờ</span></label>
              <label><input type="number" inputMode="numeric" min="0" max="59" step="1" value={adjustmentExtraMinutes} onChange={function(event) { setAdjustmentExtraMinutes(event.target.value); setAdjustmentDirty(true); setAdjustmentMessage(""); setAdjustmentError(""); }} /><span>phút</span></label>
            </fieldset>
            <div className="engagement-adjustment-metric total">
              <span>Tổng sau điều chỉnh</span>
              <strong>{adjustmentStudent ? formatFocusDuration(adjustmentStudent.trackedFocusMinutes + Math.max(0, (Number(adjustmentHours) || 0) * 60 + (Number(adjustmentExtraMinutes) || 0))) : "—"}</strong>
              <small>Cập nhật ngay ở Ngày / Tuần / Tháng</small>
            </div>
            <label className="engagement-adjustment-note">
              <span>Ghi chú <small>(không bắt buộc)</small></span>
              <input type="text" maxLength={240} value={adjustmentNote} disabled={!adjustmentStudent || adjustmentSaving} placeholder="Ví dụ: Học bằng sách tại thư viện" onChange={function(event) { setAdjustmentNote(event.target.value); setAdjustmentDirty(true); setAdjustmentMessage(""); setAdjustmentError(""); }} />
            </label>
            <div className="engagement-adjustment-actions">
              <div className={adjustmentError ? "engagement-adjustment-feedback error" : "engagement-adjustment-feedback"} role="status" aria-live="polite">{adjustmentError || adjustmentMessage || "Khi số phút thay đổi, EDUFLOW tự gửi thông báo và Web Push (nếu đã bật) cho đúng học sinh."}</div>
              <button type="button" className="button primary" disabled={!adjustmentStudent || adjustmentSaving} onClick={function() { void saveFocusAdjustment(); }}><Save size={15} />{adjustmentSaving ? "Đang lưu..." : "Lưu điều chỉnh"}</button>
            </div>
          </div>

          <div className="engagement-adjustment-history" aria-labelledby="focus-adjustment-history-title">
            <div className="engagement-adjustment-history-head">
              <div>
                <span className="engagement-eyebrow"><History size={15} /> Nhật ký điều chỉnh</span>
                <h4 id="focus-adjustment-history-title">Lịch sử bổ sung thời gian</h4>
                <p>Mỗi lần thay đổi được lưu thành một bản ghi riêng. Tổng Ngày / Tuần / Tháng vẫn lấy từ số liệu sau điều chỉnh, không tạo phiên Pomodoro giả.</p>
              </div>
              <span className="engagement-history-count">{visibleAdjustmentHistory.length} cập nhật gần nhất</span>
            </div>

            {historyLoading ? (
              <div className="engagement-history-state"><RefreshCw className="spin" size={16} /><span>Đang tải lịch sử...</span></div>
            ) : historyError ? (
              <div className="engagement-history-state error"><strong>Không tải được lịch sử.</strong><span>{historyError}</span><button type="button" className="text-button" onClick={function() { setHistoryReloadToken(function(value) { return value + 1; }); }}>Thử lại</button></div>
            ) : visibleAdjustmentHistory.length ? (
              <div className="engagement-history-scroll scroll-region" tabIndex={0} aria-label="Lịch sử bổ sung Pomodoro">
                <table className="engagement-history-table">
                  <thead>
                    <tr>
                      <th>Ngày học</th>
                      <th>Học sinh</th>
                      <th>Thay đổi</th>
                      <th>Ngoài web sau lưu</th>
                      <th>Tổng ngày</th>
                      <th>Ghi chú</th>
                      <th>Cập nhật lúc</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visibleAdjustmentHistory.map(function(item) {
                      return (
                        <tr key={item.id}>
                          <td data-label="Ngày học"><strong>{formatDate(item.date)}</strong></td>
                          <td data-label="Học sinh"><strong>{item.name}</strong><small>{item.code}{item.classNames.length ? " · " + item.classNames.join(" · ") : ""}</small></td>
                          <td data-label="Thay đổi"><span className={item.deltaMinutes > 0 ? "engagement-history-delta positive" : item.deltaMinutes < 0 ? "engagement-history-delta negative" : "engagement-history-delta neutral"}>{formatSignedFocusDuration(item.deltaMinutes)}</span></td>
                          <td data-label="Ngoài web sau lưu"><strong>{formatFocusDuration(item.manualMinutes)}</strong><small>{item.previousManualMinutes !== item.manualMinutes ? "Trước: " + formatFocusDuration(item.previousManualMinutes) : "Không đổi thời gian"}</small></td>
                          <td data-label="Tổng ngày"><strong>{formatFocusDuration(item.focusMinutesAfter)}</strong><small>Web: {formatFocusDuration(item.trackedFocusMinutes)}</small></td>
                          <td data-label="Ghi chú"><span className={item.note ? "engagement-history-note" : "engagement-history-note empty"}>{item.note || "Không có ghi chú"}</span></td>
                          <td data-label="Cập nhật lúc"><time dateTime={item.createdAt}>{formatAdjustmentTimestamp(item.createdAt)}</time></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="engagement-history-state"><History size={18} /><strong>Chưa có lịch sử bổ sung thời gian.</strong><span>Bản ghi đầu tiên sẽ xuất hiện ngay sau khi bạn lưu một điều chỉnh.</span></div>
            )}
          </div>
        </div>
      ) : null}
    </section>
  );
}
