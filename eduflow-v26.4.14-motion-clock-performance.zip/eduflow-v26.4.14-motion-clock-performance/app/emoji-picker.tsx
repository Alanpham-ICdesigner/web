"use client";

import { useEffect, useRef, useState } from "react";

const EMOJIS = [
  "😊", "😄", "😂", "🥳", "😍", "🤩", "😎", "🤔",
  "👍", "👏", "🙌", "💪", "✍️", "🙏", "✅", "⭐",
  "🎉", "🎯", "📚", "📝", "💡", "⏰", "🔥", "❤️",
  "💙", "🌟", "🚀", "🍅", "🏆", "📌", "⚠️", "✨",
];

export function EmojiPicker(props: { onPick: (emoji: string) => void; disabled?: boolean; label?: string }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLSpanElement | null>(null);

  useEffect(function() {
    if (!open) return;
    function close(event: PointerEvent) {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    }
    document.addEventListener("pointerdown", close);
    return function() { document.removeEventListener("pointerdown", close); };
  }, [open]);

  return (
    <span className="emoji-picker" ref={rootRef}>
      <button
        type="button"
        className="emoji-picker-trigger"
        disabled={props.disabled}
        aria-label={props.label || "Thêm emoji"}
        aria-expanded={open}
        onClick={function() { setOpen(function(value) { return !value; }); }}
      >
        😊
      </button>
      {open ? <span className="emoji-picker-panel" role="dialog" aria-label="Chọn emoji">
        {EMOJIS.map(function(emoji) {
          return <button key={emoji} type="button" onClick={function() { props.onPick(emoji); setOpen(false); }} aria-label={"Thêm " + emoji}>{emoji}</button>;
        })}
      </span> : null}
    </span>
  );
}
