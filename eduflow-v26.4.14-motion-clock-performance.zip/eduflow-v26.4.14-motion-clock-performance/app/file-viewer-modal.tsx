"use client";

import {
  ChevronLeft,
  ChevronRight,
  Download,
  FileText,
  Image as ImageIcon,
  Maximize2,
  Minimize2,
  PanelLeftClose,
  PanelLeftOpen,
  ZoomIn,
  ZoomOut,
  X,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

export type FileViewerTarget = {
  name: string;
  url: string;
  contentType?: string;
  viewMode?: "paged" | "continuous";
};

type PdfDocument = {
  numPages: number;
  getPage(pageNumber: number): Promise<{
    getViewport(options: { scale: number }): { width: number; height: number };
    render(options: {
      canvas: HTMLCanvasElement;
      canvasContext: CanvasRenderingContext2D;
      viewport: { width: number; height: number };
      transform?: number[];
    }): { promise: Promise<void>; cancel(): void };
  }>;
  destroy(): Promise<void>;
};

function fileKind(target: FileViewerTarget): "pdf" | "image" | "other" {
  const type = String(target.contentType || "").toLowerCase();
  if (type === "application/pdf" || /\.pdf(?:$|[?#])/i.test(target.name)) return "pdf";
  if (type.startsWith("image/") || /\.(?:jpe?g|png|webp)(?:$|[?#])/i.test(target.name)) return "image";
  return "other";
}

function downloadUrl(url: string): string {
  return url + (url.includes("?") ? "&" : "?") + "download=1";
}

function PdfThumbnail(props: { documentValue: PdfDocument; pageNumber: number; active: boolean; select: () => void }) {
  const itemRef = useRef<HTMLButtonElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [visible, setVisible] = useState(props.pageNumber <= 3);

  useEffect(function() {
    const node = itemRef.current;
    if (!node || visible || typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(function(entries) {
      if (entries.some(function(entry) { return entry.isIntersecting; })) setVisible(true);
    }, { rootMargin: "160px" });
    observer.observe(node);
    return function() { observer.disconnect(); };
  }, [visible]);

  useEffect(function() {
    if (props.active) itemRef.current?.scrollIntoView({ block: "nearest" });
  }, [props.active]);

  useEffect(function() {
    const canvas = canvasRef.current;
    if (!visible || !canvas) return;
    let cancelled = false;
    let task: { promise: Promise<void>; cancel(): void } | null = null;
    void props.documentValue.getPage(props.pageNumber).then(function(pdfPage) {
      if (cancelled) return;
      const base = pdfPage.getViewport({ scale: 1 });
      const scale = 104 / base.width;
      const viewport = pdfPage.getViewport({ scale });
      const context = canvas.getContext("2d");
      if (!context) return;
      canvas.width = Math.max(1, Math.floor(viewport.width));
      canvas.height = Math.max(1, Math.floor(viewport.height));
      task = pdfPage.render({ canvas, canvasContext: context, viewport });
      return task.promise;
    }).catch(function(reason) {
      if (String(reason?.name || "") !== "RenderingCancelledException") return;
    });
    return function() {
      cancelled = true;
      task?.cancel();
    };
  }, [props.documentValue, props.pageNumber, visible]);

  return (
    <button ref={itemRef} type="button" className={props.active ? "file-viewer-thumb active" : "file-viewer-thumb"} onClick={props.select} aria-label={"Mở trang " + props.pageNumber} aria-current={props.active ? "page" : undefined}>
      <span>{props.pageNumber}</span>
      <canvas ref={canvasRef} aria-hidden="true" />
    </button>
  );
}

function PdfContinuousPage(props: {
  documentValue: PdfDocument;
  pageNumber: number;
  fit: "width" | "page" | "custom";
  zoom: number;
  containerWidth: number;
  containerHeight: number;
  reportScale: (scale: number) => void;
}) {
  const { documentValue, pageNumber, fit, zoom, containerWidth, containerHeight, reportScale } = props;
  const pageRef = useRef<HTMLElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [nearViewport, setNearViewport] = useState(pageNumber <= 2);
  const [baseSize, setBaseSize] = useState({ width: 595, height: 842 });
  const [rendering, setRendering] = useState(false);

  useEffect(function() {
    const node = pageRef.current;
    if (!node || typeof IntersectionObserver === "undefined") {
      setNearViewport(true);
      return;
    }
    const observer = new IntersectionObserver(function(entries) {
      const entry = entries[0];
      setNearViewport(Boolean(entry?.isIntersecting));
    }, { rootMargin: "900px 0px" });
    observer.observe(node);
    return function() { observer.disconnect(); };
  }, []);

  useEffect(function() {
    let cancelled = false;
    void documentValue.getPage(pageNumber).then(function(pdfPage) {
      if (cancelled) return;
      const viewport = pdfPage.getViewport({ scale: 1 });
      setBaseSize({ width: viewport.width, height: viewport.height });
    }).catch(function() {});
    return function() { cancelled = true; };
  }, [documentValue, pageNumber]);

  const availableWidth = Math.max(240, containerWidth - 44);
  const availableHeight = Math.max(280, containerHeight - 44);
  const calculatedScale = fit === "width"
    ? availableWidth / baseSize.width
    : fit === "page"
      ? Math.min(availableWidth / baseSize.width, availableHeight / baseSize.height)
      : zoom;
  const safeScale = Math.max(.25, Math.min(4, calculatedScale));
  const displayWidth = Math.max(1, Math.floor(baseSize.width * safeScale));
  const displayHeight = Math.max(1, Math.floor(baseSize.height * safeScale));

  useEffect(function() {
    const canvas = canvasRef.current;
    if (!nearViewport || !canvas) {
      if (canvas) {
        canvas.width = 1;
        canvas.height = 1;
      }
      return;
    }
    let cancelled = false;
    let task: { promise: Promise<void>; cancel(): void } | null = null;
    setRendering(true);
    void documentValue.getPage(pageNumber).then(function(pdfPage) {
      if (cancelled) return;
      const viewport = pdfPage.getViewport({ scale: safeScale });
      const outputScale = Math.min(window.devicePixelRatio || 1, 2);
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Trình duyệt không thể tạo vùng hiển thị PDF.");
      canvas.width = Math.max(1, Math.floor(viewport.width * outputScale));
      canvas.height = Math.max(1, Math.floor(viewport.height * outputScale));
      canvas.style.width = Math.floor(viewport.width) + "px";
      canvas.style.height = Math.floor(viewport.height) + "px";
      task = pdfPage.render({
        canvas,
        canvasContext: context,
        viewport,
        transform: outputScale === 1 ? undefined : [outputScale, 0, 0, outputScale, 0, 0],
      });
      reportScale(safeScale);
      return task.promise;
    }).catch(function(reason) {
      if (String(reason?.name || "") !== "RenderingCancelledException") return;
    }).finally(function() { if (!cancelled) setRendering(false); });
    return function() {
      cancelled = true;
      task?.cancel();
    };
  }, [nearViewport, documentValue, pageNumber, reportScale, safeScale]);

  return (
    <section
      ref={pageRef}
      className="file-viewer-continuous-page"
      data-pdf-page={pageNumber}
      aria-label={"Trang " + pageNumber}
      style={{ width: displayWidth, height: displayHeight }}
    >
      <canvas ref={canvasRef} aria-hidden="true" />
      {rendering ? <span className="file-viewer-page-loading" aria-label={"Đang hiển thị trang " + pageNumber} /> : null}
      <small>{pageNumber}</small>
    </section>
  );
}

function ActiveFileViewerModal(props: { target: FileViewerTarget; close: () => void }) {
  const { target, close } = props;
  const kind = fileKind(target);
  const continuous = target?.viewMode === "continuous";
  const modalRef = useRef<HTMLDivElement | null>(null);
  const canvasWrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const documentRef = useRef<PdfDocument | null>(null);
  const renderTaskRef = useRef<{ cancel(): void } | null>(null);
  const renderedScaleRef = useRef(1);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [fit, setFit] = useState<"width" | "page" | "custom">("custom");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [layoutEpoch, setLayoutEpoch] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [thumbnailsOpen, setThumbnailsOpen] = useState(true);
  const [pageInput, setPageInput] = useState("1");
  const [displayScale, setDisplayScale] = useState(1);
  const [pdfDocument, setPdfDocument] = useState<PdfDocument | null>(null);
  const [viewerSize, setViewerSize] = useState({ width: 900, height: 700 });

  useEffect(function() {
    const root = document.documentElement;
    const previousOverflow = root.style.overflow;
    root.style.overflow = "hidden";
    return function() { root.style.overflow = previousOverflow; };
  }, []);

  const reportScale = useCallback(function(scale: number) {
    renderedScaleRef.current = scale;
    setDisplayScale(function(current) { return Math.abs(current - scale) < .005 ? current : scale; });
  }, []);

  const goToPage = useCallback(function(nextPage: number, behavior: ScrollBehavior = "smooth") {
    const safePage = Math.max(1, Math.min(pageCount || 1, nextPage));
    setPage(safePage);
    setPageInput(String(safePage));
    if (!continuous) return;
    const wrap = canvasWrapRef.current;
    const pageNode = wrap?.querySelector<HTMLElement>('[data-pdf-page="' + safePage + '"]');
    if (wrap && pageNode) wrap.scrollTo({ top: Math.max(0, pageNode.offsetTop - 18), behavior });
  }, [continuous, pageCount]);

  useEffect(function() {
    const onKeyDown = function(event: KeyboardEvent) {
      if (event.key === "Escape" && !document.fullscreenElement) close();
      if (kind === "pdf" && event.target instanceof HTMLElement && !event.target.closest("input, button, a")) {
        if (event.key === "ArrowLeft" || event.key === "PageUp") goToPage(page - 1);
        if (event.key === "ArrowRight" || event.key === "PageDown") goToPage(page + 1);
      }
    };
    const onFullscreen = function() { setFullscreen(Boolean(document.fullscreenElement)); };
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("fullscreenchange", onFullscreen);
    return function() {
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("fullscreenchange", onFullscreen);
    };
  }, [target, kind, page, close, goToPage]);

  useEffect(function() {
    if (!continuous) canvasWrapRef.current?.scrollTo({ top: 0, left: 0 });
  }, [page, continuous]);

  useEffect(function() {
    const timer = window.setTimeout(function() {
      setThumbnailsOpen(!window.matchMedia("(max-width: 760px)").matches);
    }, 0);
    return function() { window.clearTimeout(timer); };
  }, [target]);

  useEffect(function() {
    const node = canvasWrapRef.current;
    if (!node || typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(function() {
      setViewerSize({ width: node.clientWidth, height: node.clientHeight });
      setLayoutEpoch(function(value) { return value + 1; });
    });
    observer.observe(node);
    return function() { observer.disconnect(); };
  }, [target, kind]);

  useEffect(function() {
    let cancelled = false;
    const startTimer = window.setTimeout(function() {
      if (cancelled) return;
      setPage(1);
      setPageCount(0);
      setZoom(1);
      setFit("custom");
      setDisplayScale(1);
      setError("");
      if (kind !== "pdf") return;
      setLoading(true);
      void import("pdfjs-dist/build/pdf.mjs").then(async function(pdfjs) {
        pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
        const task = pdfjs.getDocument({ url: target.url, withCredentials: true });
        const documentValue = await task.promise as unknown as PdfDocument;
        if (cancelled) { await documentValue.destroy(); return; }
        documentRef.current = documentValue;
        setPdfDocument(documentValue);
        setPageCount(documentValue.numPages);
      }).catch(function(reason) {
        if (!cancelled) setError(reason instanceof Error ? reason.message : "Không thể mở tệp PDF.");
      }).finally(function() { if (!cancelled) setLoading(false); });
    }, 0);
    return function() {
      cancelled = true;
      window.clearTimeout(startTimer);
      renderTaskRef.current?.cancel();
      renderTaskRef.current = null;
      const current = documentRef.current;
      documentRef.current = null;
      if (current) void current.destroy();
    };
  }, [target, kind]);

  useEffect(function() {
    const documentValue = documentRef.current;
    const canvas = canvasRef.current;
    const wrap = canvasWrapRef.current;
    if (!documentValue || !canvas || !wrap || kind !== "pdf") return;
    let cancelled = false;
    const renderTimer = window.setTimeout(function() {
      if (cancelled) return;
      setLoading(true);
      void documentValue.getPage(page).then(function(pdfPage) {
      if (cancelled) return;
      const base = pdfPage.getViewport({ scale: 1 });
      const width = Math.max(240, wrap.clientWidth - 28);
      const height = Math.max(280, wrap.clientHeight - 28);
      const scale = fit === "width"
        ? width / base.width
        : fit === "page"
          ? Math.min(width / base.width, height / base.height)
          : zoom;
      const safeScale = Math.max(.25, Math.min(4, scale));
      reportScale(safeScale);
      const viewport = pdfPage.getViewport({ scale: safeScale });
      const outputScale = Math.min(window.devicePixelRatio || 1, 2);
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Trình duyệt không thể tạo vùng hiển thị PDF.");
      renderTaskRef.current?.cancel();
      canvas.width = Math.floor(viewport.width * outputScale);
      canvas.height = Math.floor(viewport.height * outputScale);
      canvas.style.width = Math.floor(viewport.width) + "px";
      canvas.style.height = Math.floor(viewport.height) + "px";
      const task = pdfPage.render({
        canvas,
        canvasContext: context,
        viewport,
        transform: outputScale === 1 ? undefined : [outputScale, 0, 0, outputScale, 0, 0],
      });
      renderTaskRef.current = task;
      return task.promise;
      }).catch(function(reason) {
        if (!cancelled && String(reason?.name || "") !== "RenderingCancelledException") {
          setError(reason instanceof Error ? reason.message : "Không thể hiển thị trang PDF.");
        }
      }).finally(function() { if (!cancelled) setLoading(false); });
    }, 0);
    return function() {
      cancelled = true;
      window.clearTimeout(renderTimer);
      renderTaskRef.current?.cancel();
    };
  }, [page, pageCount, zoom, fit, layoutEpoch, kind, continuous, reportScale]);

  function changeZoom(delta: number) {
    setFit("custom");
    setZoom(Math.max(.5, Math.min(3, Number((renderedScaleRef.current + delta).toFixed(2)))));
  }

  function commitPageInput() {
    const next = Math.max(1, Math.min(pageCount || 1, Math.floor(Number(pageInput) || page)));
    goToPage(next);
  }

  function trackContinuousPage() {
    if (!continuous) return;
    const wrap = canvasWrapRef.current;
    if (!wrap) return;
    const wrapRect = wrap.getBoundingClientRect();
    const focusLine = wrapRect.top + Math.min(150, wrapRect.height * .28);
    let closestPage = page;
    let closestDistance = Number.POSITIVE_INFINITY;
    wrap.querySelectorAll<HTMLElement>("[data-pdf-page]").forEach(function(node) {
      const rect = node.getBoundingClientRect();
      const distance = rect.top <= focusLine && rect.bottom >= focusLine
        ? 0
        : Math.min(Math.abs(rect.top - focusLine), Math.abs(rect.bottom - focusLine));
      if (distance < closestDistance) {
        closestDistance = distance;
        closestPage = Number(node.dataset.pdfPage) || closestPage;
      }
    });
    if (closestPage !== page) {
      setPage(closestPage);
      setPageInput(String(closestPage));
    }
  }

  async function toggleFullscreen() {
    if (!document.fullscreenElement) await modalRef.current?.requestFullscreen();
    else await document.exitFullscreen();
  }

  return (
    <div className="file-viewer-overlay" role="presentation" onMouseDown={props.close}>
      <div ref={modalRef} className="file-viewer-modal" role="dialog" aria-modal="true" aria-label={"Xem tệp " + target.name} onMouseDown={function(event) { event.stopPropagation(); }}>
        <header className="file-viewer-head">
          <span className="file-viewer-kind">{kind === "pdf" ? <FileText /> : <ImageIcon />}</span>
          <div><strong title={target.name}>{target.name}</strong><small>{kind === "pdf" ? "Trình xem PDF nội bộ" : kind === "image" ? "Xem ảnh nội bộ" : "Tệp đính kèm"}</small></div>
          <a className="button soft" href={downloadUrl(target.url)}><Download />Tải xuống</a>
          <button type="button" className="icon-button" onClick={function() { void toggleFullscreen(); }} aria-label={fullscreen ? "Thu nhỏ trình xem" : "Mở rộng trình xem"}>{fullscreen ? <Minimize2 /> : <Maximize2 />}</button>
          <button type="button" className="icon-button" onClick={close} aria-label="Đóng trình xem"><X /></button>
        </header>

        {kind === "pdf" ? (
          <>
            <nav className="file-viewer-toolbar" aria-label="Điều khiển PDF">
              <button type="button" className="icon-button file-viewer-sidebar-toggle" onClick={function() { setThumbnailsOpen(function(value) { return !value; }); }} aria-label={thumbnailsOpen ? "Ẩn danh sách trang" : "Hiện danh sách trang"}>{thumbnailsOpen ? <PanelLeftClose /> : <PanelLeftOpen />}</button>
              <div className="file-viewer-page-controls">
                <button type="button" className="icon-button" disabled={page <= 1} onClick={function() { goToPage(page - 1); }} aria-label="Trang trước"><ChevronLeft /></button>
                <label><span>Trang</span><input type="number" min="1" max={pageCount || 1} value={pageInput} onChange={function(event) { setPageInput(event.target.value); }} onBlur={commitPageInput} onKeyDown={function(event) { if (event.key === "Enter") { commitPageInput(); event.currentTarget.blur(); } }} aria-label="Số trang" /><span>/ {pageCount || "..."}</span></label>
                <button type="button" className="icon-button" disabled={!pageCount || page >= pageCount} onClick={function() { goToPage(page + 1); }} aria-label="Trang sau"><ChevronRight /></button>
              </div>
              <i aria-hidden="true" />
              <div className="file-viewer-zoom-controls">
                <button type="button" className="icon-button" onClick={function() { changeZoom(-.15); }} aria-label="Thu nhỏ"><ZoomOut /></button>
                <span>{Math.round(displayScale * 100)}%</span>
                <button type="button" className="icon-button" onClick={function() { changeZoom(.15); }} aria-label="Phóng to"><ZoomIn /></button>
              </div>
            </nav>
            <div className={thumbnailsOpen ? "file-viewer-shell" : "file-viewer-shell thumbnails-closed"}>
              <aside className="file-viewer-thumbnails" aria-label="Danh sách trang PDF">
                {pdfDocument ? Array.from({ length: pageCount }, function(_, index) {
                  const pageNumber = index + 1;
                  return <PdfThumbnail key={pageNumber} documentValue={pdfDocument} pageNumber={pageNumber} active={page === pageNumber} select={function() { goToPage(pageNumber); if (window.matchMedia("(max-width: 760px)").matches) setThumbnailsOpen(false); }} />;
                }) : null}
              </aside>
              <div ref={canvasWrapRef} className={continuous ? "file-viewer-canvas-wrap continuous" : "file-viewer-canvas-wrap"} onScroll={trackContinuousPage}>
                {continuous && pdfDocument ? (
                  <div className="file-viewer-continuous-pages" aria-label={"Tài liệu PDF gồm " + pageCount + " trang"}>
                    {Array.from({ length: pageCount }, function(_, index) {
                      const pageNumber = index + 1;
                      return <PdfContinuousPage key={pageNumber} documentValue={pdfDocument} pageNumber={pageNumber} fit={fit} zoom={zoom} containerWidth={viewerSize.width} containerHeight={viewerSize.height} reportScale={reportScale} />;
                    })}
                  </div>
                ) : <canvas ref={canvasRef} aria-label={"Trang " + page + " của " + pageCount} />}
                {loading && !pageCount ? <div className="file-viewer-loading"><span /><p>Đang mở tài liệu...</p></div> : null}
                {!continuous && loading && pageCount ? <div className="file-viewer-rendering"><span />Đang hiển thị trang {page}</div> : null}
                {error ? <div className="file-viewer-error" role="alert"><FileText /><strong>Không thể mở PDF</strong><p>{error}</p></div> : null}
              </div>
            </div>
          </>
        ) : kind === "image" ? (
          <div className="file-viewer-image-wrap">
            {/* eslint-disable-next-line @next/next/no-img-element -- authenticated and local blob URLs cannot use the image optimizer */}
            <img src={target.url} alt={target.name} onError={function() { setError("Không thể tải ảnh này."); }} />
            {error ? <div className="file-viewer-error" role="alert"><ImageIcon /><strong>Không thể mở ảnh</strong><p>{error}</p></div> : null}
          </div>
        ) : (
          <div className="file-viewer-error"><FileText /><strong>Chưa hỗ trợ xem loại tệp này</strong><p>Bạn vẫn có thể tải tệp xuống bằng nút phía trên.</p></div>
        )}
      </div>
    </div>
  );
}

export function FileViewerModal(props: { target: FileViewerTarget | null; close: () => void }) {
  const [portalHost, setPortalHost] = useState<HTMLElement | null>(null);

  useEffect(function() {
    setPortalHost(document.body);
  }, []);

  if (!props.target || !portalHost) return null;

  // Render at document.body so the fixed viewer cannot be trapped by animated
  // course/page ancestors that keep a transform after their entrance motion.
  // This also prevents overflow clipping by LMS/content containers.
  return createPortal(
    <ActiveFileViewerModal key={props.target.url + "|" + (props.target.viewMode || "paged")} target={props.target} close={props.close} />,
    portalHost,
  );
}
