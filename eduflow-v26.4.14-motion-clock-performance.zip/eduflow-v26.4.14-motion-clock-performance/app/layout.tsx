import type { Metadata, Viewport } from "next";
import "@fontsource/be-vietnam-pro/400.css";
import "@fontsource/be-vietnam-pro/500.css";
import "@fontsource/be-vietnam-pro/600.css";
import "@fontsource/be-vietnam-pro/700.css";
import "@fontsource/be-vietnam-pro/800.css";
import "@fontsource/be-vietnam-pro/900.css";
import "./globals.css";
import "./redesign.css";
import "./astryx-taste.css";
import "./astryx-taste-deep.css";
import "./motion-performance.css";

export const metadata: Metadata = {
  title: "PHMT MATH - Đăng nhập",
  description: "Nền tảng quản lý lớp học, điểm danh, bài tập và kết quả học tập dành cho giáo viên Việt Nam.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "PHMT MATH",
  },
  formatDetection: { telephone: false },
  other: { "codex-preview": "development", "mobile-web-app-capable": "yes" },
  icons: {
    icon: [
      { url: "/icons/favicon-64.png", sizes: "64x64", type: "image/png" },
      { url: "/icons/pwa-192.png", sizes: "192x192", type: "image/png" },
    ],
    shortcut: "/icons/favicon-64.png",
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f5f7fb" },
    { media: "(prefers-color-scheme: dark)", color: "#121625" },
  ],
};

export default function RootLayout(props: Readonly<{ children: React.ReactNode }>) {
  return <html lang="vi"><body>{props.children}</body></html>;
}
