"use client";
/* eslint-disable @next/next/no-img-element -- class logos are user-uploaded R2 objects served by a dynamic API route */

import {
  AlertTriangle,
  BarChart3,
  Bell,
  CalendarClock,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
  Clock3,
  Download,
  Eye,
  EyeOff,
  Coins,
  FileText,
  FolderOpen,
  Gift,
  GraduationCap,
  GripVertical,
  ImagePlus,
  KeyRound,
  LayoutDashboard,
  Menu,
  MessageSquare,
  LogIn,
  LogOut,
  Moon,
  MoreHorizontal,
  NotebookPen,
  Pencil,
  Plus,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Sparkles,
  Sun,
  Trash2,
  TrendingUp,
  Trophy,
  Upload,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import * as XLSX from "xlsx";
import {
  ALL_CLASSES_ID,
  classIdentifier,
  filterAndSortAttendance,
  formatDateKey,
  localDateInTimeZone,
  mondayDateKey,
  normalizeSearchText,
  resolveStudentNavigationTarget,
  searchStudents,
  shiftDateKey,
  sortPointRules,
} from "../lib/admin-ui-utils.mjs";
import { getAssignmentStatus } from "../lib/assignment-status";
import { isAssignmentCompletedStatus, isDraftSubmissionStatus, isStudentSubmittedStatus, isTeacherCompletedStatus } from "../lib/assignment-submission";
import { ClassHubView } from "./class-hub";
import { StudentEngagementStats } from "./admin/student-engagement-stats";
import { FileViewerModal, type FileViewerTarget } from "./file-viewer-modal";
import { EmojiPicker } from "./emoji-picker";

type View =
  | "dashboard"
  | "students"
  | "classes"
  | "teachingSchedule"
  | "attendance"
  | "assignments"
  | "grades"
  | "rewards"
  | "rewardstore"
  | "analytics"
  | "calendar"
  | "documents"
  | "settings";
type StudentRecord = {
  id?: number;
  initials: string;
  name: string;
  code: string;
  className: string;
  classKeys?: string[];
  classNames?: string[];
  enrollments?: { id: number; classKey: string; className: string; status: string }[];
  avg: number;
  attendance: number;
  state: string;
  tone: string;
  phone?: string;
  email?: string;
  hasGrades?: boolean;
  hasAttendance?: boolean;
};
type AssignmentRecord = {
  id?: number;
  title: string;
  className: string;
  classKey?: string;
  description?: string;
  dueDate: string;
  maxScore: number;
  attachmentName?: string;
  attachmentSize?: number;
  status: string;
  submittedCount: number;
  totalStudents: number;
  pendingGradingCount?: number;
};
type AssignmentSubmissionFile = { id: number; fileName: string; fileSize: number; contentType: string };
function formatFileSize(value: number): string {
  if (value < 1024) return value + " B";
  if (value < 1024 * 1024) return (value / 1024).toFixed(1) + " KB";
  return (value / 1024 / 1024).toFixed(1) + " MB";
}
type AssignmentSubmissionStudent = {
  id: number;
  code: string;
  name: string;
  className: string;
  submittedAt: string | null;
  submissionId?: number | null;
  responseText?: string;
  fileName?: string;
  fileSize?: number;
  contentType?: string;
  files?: AssignmentSubmissionFile[];
  status?: string;
  score?: number | null;
  feedback?: string;
  gradedAt?: string | null;
  updatedAt?: string;
};
type AdminItemRecord = {
  id: number;
  key: string;
  title: string;
  data: Record<string, unknown>;
  createdAt?: string;
  updatedAt?: string;
};
type ClassRecord = {
  id?: number;
  key?: string;
  name: string;
  label?: string;
  schedule: string;
  studentCount: number;
  average: number;
  attendance: number;
  openAssignments: number;
  tone: string;
  teacher: string;
  room: string;
  startTime: string;
  endTime: string;
  schedules?: { weekday: number; startTime: string; endTime: string; room?: string }[];
  logoUrl?: string;
  hasGrades?: boolean;
  hasAttendance?: boolean;
};
type AttendanceSession = {
  classId?: string;
  classKey?: string;
  className: string;
  date: string;
  startTime: string;
  endTime: string;
  states: Record<string, string>;
  sessionId?: number;
  sessionType?: "regular" | "makeup";
  storageKey?: string;
};
type CourseSessionRecord = { id: number; classKey: string; className: string; sessionType: "regular" | "makeup"; sessionDate: string; startTime: string; endTime: string; note: string; status: string };
type Assessment = {
  id: string;
  title: string;
  category: string;
  maxScore: number;
  weight: number;
  date: string;
};
type GradebookData = {
  classKey?: string;
  className: string;
  term: string;
  assessments: Assessment[];
  scores: Record<string, Record<string, number | null>>;
};
type TeacherProfile = {
  siteName: string;
  teacherName: string;
  gender: "male" | "female";
  schoolName: string;
  academicYear: string;
  defaultRoom: string;
  logoUrl: string;
  loginQuote: string;
};

const DEFAULT_LOGIN_QUOTE = "Genius is 1% talent and 99% percent hard work";
type DocumentRecord = {
  id: number;
  name: string;
  folder: string;
  size: number;
  contentType: string;
  createdAt: string;
};

type DocumentUploadTask = {
  id: string;
  file: File;
  folder: string;
  progress: number;
  status: "queued" | "uploading" | "success" | "error";
  error?: string;
};
type RewardStudent = {
  id: number;
  code: string;
  name: string;
  className: string;
  points: number;
  hasPin: boolean;
};
type PointRule = {
  id: number;
  title: string;
  trigger: string;
  points: number;
  threshold: number;
  active: boolean;
  createdAt?: string;
};

const pointRuleTriggerLabels: Record<string, string> = {
  manual: "Áp dụng thủ công",
  assignment_streak: "Chuỗi hoàn thành bài",
};
type RewardItem = {
  id: number;
  title: string;
  description: string;
  cost: number;
  stock: number;
  active: boolean;
};
type Redemption = {
  id: number;
  studentName: string;
  studentCode: string;
  rewardTitle: string;
  cost: number;
  status: string;
  createdAt: string;
};
type RewardData = {
  students: RewardStudent[];
  rules: PointRule[];
  rewards: RewardItem[];
  redemptions: Redemption[];
};
type AdminNotification = {
  id: number;
  title: string;
  body: string;
  createdAt: string;
  read: boolean;
  actionView: string;
};
type AdminChatMessage = {
  id: number;
  studentId: number;
  studentCode: string;
  studentName: string;
  classKey: string;
  className: string;
  teacher: string;
  direction: "student" | "teacher";
  body: string;
  createdAt: string;
  read: boolean;
};

function studentBelongsToClass(student: StudentRecord, className: string, classKey?: string): boolean {
  if (classKey && student.classKeys?.includes(classKey)) return true;
  if (student.classNames?.includes(className)) return true;
  return student.className === className;
}

const navItems: {
  id: View;
  label: string;
  icon: typeof LayoutDashboard;
  badge?: string;
}[] = [
  { id: "dashboard", label: "Tổng quan", icon: LayoutDashboard },
  { id: "students", label: "Học sinh", icon: GraduationCap },
  { id: "classes", label: "Lớp học", icon: Users },
  { id: "teachingSchedule", label: "Lịch dạy", icon: CalendarClock },
  { id: "attendance", label: "Điểm danh", icon: ClipboardCheck },
  { id: "assignments", label: "Bài tập", icon: NotebookPen },
  { id: "grades", label: "Điểm số", icon: BarChart3 },
  { id: "rewards", label: "Thi đua & Tích điểm", icon: Trophy },
  { id: "rewardstore", label: "Kho đổi quà", icon: Gift },
  { id: "analytics", label: "Thống kê", icon: TrendingUp },
  { id: "calendar", label: "Lịch kiểm tra", icon: CalendarDays },
  { id: "documents", label: "Tài liệu", icon: FolderOpen },
  { id: "settings", label: "Cài đặt", icon: Settings },
];

const students = [
  {
    initials: "MA",
    name: "Nguyễn Minh Anh",
    code: "HS24001",
    className: "Toán 12A1",
    avg: 8.7,
    attendance: 96,
    state: "Đang học",
    tone: "violet",
  },
  {
    initials: "GH",
    name: "Trần Gia Huy",
    code: "HS24002",
    className: "Toán 12A1",
    avg: 9.1,
    attendance: 98,
    state: "Đang học",
    tone: "blue",
  },
  {
    initials: "KL",
    name: "Lê Khánh Linh",
    code: "HS24003",
    className: "Toán 11A2",
    avg: 7.6,
    attendance: 91,
    state: "Đang học",
    tone: "pink",
  },
  {
    initials: "HN",
    name: "Phạm Hoàng Nam",
    code: "HS24004",
    className: "Toán 12A1",
    avg: 5.4,
    attendance: 76,
    state: "Cần chú ý",
    tone: "orange",
  },
  {
    initials: "NA",
    name: "Võ Ngọc Anh",
    code: "HS24005",
    className: "Toán 10A3",
    avg: 8.2,
    attendance: 94,
    state: "Đang học",
    tone: "green",
  },
  {
    initials: "TH",
    name: "Đỗ Thu Hà",
    code: "HS24006",
    className: "Toán 11A2",
    avg: 6.8,
    attendance: 88,
    state: "Đang học",
    tone: "cyan",
  },
];

function Avatar(props: { initials: string; tone?: string }) {
  return (
    <span className={"avatar avatar-" + (props.tone || "violet")}>
      {props.initials}
    </span>
  );
}

function PageTitle(props: {
  title: string;
  subtitle: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="page-title">
      <div>
        <h1>{props.title}</h1>
        <p>{props.subtitle}</p>
      </div>
      <div className="page-actions">{props.children}</div>
    </div>
  );
}

function hourInTimeZone(value = new Date(), timeZone = "Asia/Ho_Chi_Minh") {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour: "2-digit",
    hourCycle: "h23",
  }).formatToParts(value);
  return Number(parts.find(function (part) { return part.type === "hour"; })?.value || 0);
}

function minutesInTimeZone(value = new Date(), timeZone = "Asia/Ho_Chi_Minh") {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(value);
  const values = Object.fromEntries(parts.map(function (part) { return [part.type, part.value]; }));
  return Number(values.hour || 0) * 60 + Number(values.minute || 0);
}

function greetingForTime(value = new Date()) {
  const hour = hourInTimeZone(value);
  if (hour >= 5 && hour < 12) return "Chào buổi sáng";
  if (hour >= 12 && hour < 18) return "Chào buổi chiều";
  return "Chào buổi tối";
}

function teacherHonorific(gender: TeacherProfile["gender"]) {
  return gender === "female" ? "Cô" : "Thầy";
}

function Dashboard(props: {
  go: (view: View) => void;
  onExportPdf: () => void;
  students: StudentRecord[];
  classes: ClassRecord[];
  assignments: AssignmentRecord[];
  documents: number;
  attendanceStates: Record<string, string>;
  attendanceLabel: string;
  teacherName: string;
  teacherGender: TeacherProfile["gender"];
  siteName: string;
}) {
  const [dashboardNow, setDashboardNow] = useState(function () { return new Date(); });
  useEffect(function () {
    const timer = window.setInterval(function () { setDashboardNow(new Date()); }, 60_000);
    return function () { window.clearInterval(timer); };
  }, []);
  const todayKey = localDateInTimeZone(dashboardNow);
  const todayDate = new Date(todayKey + "T00:00:00Z");
  const todayWeekdayRaw = todayDate.getUTCDay();
  const todayWeekday = todayWeekdayRaw === 0 ? 7 : todayWeekdayRaw;
  const todayLabel = new Intl.DateTimeFormat("vi-VN", {
    timeZone: "Asia/Ho_Chi_Minh",
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(dashboardNow);
  const currentMinutes = minutesInTimeZone(dashboardNow);
  const todayTeachingRows = props.classes.flatMap(function (item) {
    const schedules = item.schedules?.length
      ? item.schedules
      : legacyScheduleWeekdays(item.schedule).map(function (weekday) {
          return { weekday, startTime: item.startTime, endTime: item.endTime, room: item.room };
        });
    return schedules
      .filter(function (schedule) { return schedule.weekday === todayWeekday; })
      .map(function (schedule) {
        return {
          key: String(item.key || item.id || item.name) + "|" + schedule.startTime + "|" + schedule.endTime,
          className: item.name,
          studentCount: item.studentCount,
          room: schedule.room || item.room,
          startTime: schedule.startTime,
          endTime: schedule.endTime,
          schedule: item.schedule,
        };
      });
  }).sort(function (a, b) { return a.startTime.localeCompare(b.startTime) || a.className.localeCompare(b.className, "vi"); });
  const gradedStudents = props.students.filter(function (student) {
    return student.hasGrades;
  });
  const average = gradedStudents.length
    ? (
        gradedStudents.reduce(function (total, student) {
          return total + student.avg;
        }, 0) / gradedStudents.length
      ).toFixed(1)
    : "—";
  const pending = props.assignments.reduce(function (total, item) {
    return total + Math.max(0, item.totalStudents - item.submittedCount);
  }, 0);
  const attendanceCounts = { present: 0, late: 0, allowed: 0, absent: 0 };
  props.students.forEach(function (student) {
    const state = props.attendanceStates[student.code];
    if (state && state in attendanceCounts)
      attendanceCounts[state as keyof typeof attendanceCounts] += 1;
  });
  const markedAttendance = Object.values(attendanceCounts).reduce(function (
    total,
    value,
  ) {
    return total + value;
  }, 0);
  const attendance = markedAttendance
    ? Math.round(
        ((attendanceCounts.present + attendanceCounts.late) /
          markedAttendance) *
          100,
      )
    : 0;
  const attention = props.students
    .filter(function (student) {
      return (
        student.state === "Cần chú ý" ||
        (student.hasGrades && student.avg < 6) ||
        (student.hasAttendance && student.attendance < 80)
      );
    })
    .sort(function (a, b) {
      return a.avg - b.avg;
    });
  const kpis = [
    [
      "Tổng học sinh",
      String(props.students.length),
      "Dữ liệu hiện tại",
      GraduationCap,
      "indigo",
    ],
    [
      "Tổng lớp học",
      String(props.classes.length),
      "Đang quản lý",
      Users,
      "blue",
    ],
    [
      "Tổng bài tập",
      String(props.assignments.length),
      pending + " lượt chưa nộp",
      NotebookPen,
      "orange",
    ],
    [
      "Tổng tài liệu",
      String(props.documents),
      "Đã tải lên",
      FolderOpen,
      "green",
    ],
    [
      "Có mặt hôm nay",
      String(attendanceCounts.present),
      markedAttendance ? attendance + "% chuyên cần" : "Chưa có điểm danh",
      CheckCircle2,
      "green",
    ],
    [
      "Vắng hôm nay",
      String(attendanceCounts.absent),
      attendanceCounts.allowed + " nghỉ có phép",
      X,
      "orange",
    ],
    ["Điểm trung bình", average, "Tính từ sổ điểm", BarChart3, "blue"],
    [
      "Cần chú ý",
      String(attention.length),
      "Theo điểm và chuyên cần",
      AlertTriangle,
      "orange",
    ],
  ] as const;
  return (
    <>
      <PageTitle
        title={greetingForTime(dashboardNow) + ", " + teacherHonorific(props.teacherGender) + " " + props.teacherName}
        subtitle="Đây là những gì đang diễn ra với các lớp học hôm nay."
      >
        <button className="button ghost" onClick={props.onExportPdf}>
          <Download size={17} />
          Xuất báo cáo
        </button>
        <button className="button primary" onClick={() => props.go("students")}>
          <UserPlus size={17} />
          Thêm học sinh
        </button>
      </PageTitle>
      <section className="kpi-grid">
        {kpis.map(function (item) {
          const Icon = item[3];
          return (
            <article className="card kpi-card" key={item[0]}>
              <span className={"icon-box icon-" + item[4]}>
                <Icon size={21} />
              </span>
              <div>
                <small>{item[0]}</small>
                <strong>{item[1]}</strong>
                <p>
                  <TrendingUp size={13} />
                  {item[2]}
                </p>
              </div>
            </article>
          );
        })}
      </section>
      <section className="dashboard-grid top-charts">
        <article className="card panel">
          <div className="card-head">
            <div>
              <h2>Kết quả theo lớp</h2>
              <p>Tự động cập nhật khi thêm, sửa hoặc xóa lớp</p>
            </div>
            <button className="text-button" onClick={() => props.go("classes")}>
              Quản lý lớp <ChevronRight size={14} />
            </button>
          </div>
          <div className="class-performance class-performance-scroll scroll-region" tabIndex={0} aria-label="Danh sách kết quả theo lớp">
            {props.classes.map(function (item) {
              return (
                <div key={item.id || item.key || item.name}>
                  <span>
                    <strong>{item.name}</strong>
                    <small>
                      {item.studentCount} học sinh ·{" "}
                      {item.hasAttendance
                        ? item.attendance + "% chuyên cần"
                        : "chưa điểm danh"}
                    </small>
                  </span>
                  <i>
                    <em
                      style={{
                        width: item.hasGrades
                          ? Math.max(0, Math.min(100, item.average * 10)) + "%"
                          : "0%",
                      }}
                    />
                  </i>
                  <b>{item.hasGrades ? item.average.toFixed(1) : "—"}</b>
                </div>
              );
            })}
            {!props.classes.length ? (
              <div className="dashboard-empty">
                <Users size={24} />
                <p>
                  Chưa có lớp học. Các lớp đã xóa sẽ không còn hiển thị ở đây.
                </p>
              </div>
            ) : null}
          </div>
        </article>
        <article className="card panel attendance-card">
          <div className="card-head">
            <div>
              <h2>{"Điểm danh " + props.attendanceLabel}</h2>
              <p>
                {markedAttendance} lượt đã ghi nhận · {props.classes.length} lớp
              </p>
            </div>
          </div>
          <div
            className="donut"
            style={{
              background:
                "conic-gradient(#35b982 0 " +
                attendance +
                "%,#edf0f5 " +
                attendance +
                "% 100%)",
            }}
          >
            <div>
              <strong>{markedAttendance ? attendance + "%" : "—"}</strong>
              <span>{markedAttendance ? "Chuyên cần" : "Chưa điểm danh"}</span>
            </div>
          </div>
          <div className="attendance-legend">
            <span>
              <i className="green" />
              Có mặt <b>{attendanceCounts.present}</b>
            </span>
            <span>
              <i className="amber" />
              Đi trễ <b>{attendanceCounts.late}</b>
            </span>
            <span>
              <i className="blue" />
              Có phép <b>{attendanceCounts.allowed}</b>
            </span>
            <span>
              <i className="red" />
              Không phép <b>{attendanceCounts.absent}</b>
            </span>
          </div>
          <button
            className="text-button"
            onClick={() => props.go("attendance")}
          >
            Xem chi tiết điểm danh <ChevronRight size={14} />
          </button>
        </article>
      </section>
      <section className="dashboard-grid lower-grid">
        <article className="card panel">
          <div className="card-head">
            <div>
              <h2>Lịch dạy hôm nay</h2>
              <p>{todayLabel}</p>
            </div>
            <button
              className="text-button"
              onClick={() => props.go("teachingSchedule")}
            >
              Xem lịch
            </button>
          </div>
          {todayTeachingRows.slice(0, 4).map(function (item, index) {
            const startParts = item.startTime.split(":").map(Number);
            const endParts = item.endTime.split(":").map(Number);
            const startMinutes = (startParts[0] || 0) * 60 + (startParts[1] || 0);
            const endMinutes = (endParts[0] || 0) * 60 + (endParts[1] || 0);
            const isLive = currentMinutes >= startMinutes && currentMinutes < endMinutes;
            const status = isLive ? "Đang diễn ra" : currentMinutes < startMinutes ? "Sắp tới" : "Đã kết thúc";
            return (
              <div className="schedule-row" key={item.key}>
                <div>
                  <strong>{item.startTime}</strong>
                  <span>{item.endTime}</span>
                </div>
                <i className={"schedule-line line-" + (index % 4)} />
                <p>
                  <strong>{item.className}</strong>
                  <span>
                    {item.room || "Chưa có phòng"} · {item.studentCount} học sinh
                  </span>
                </p>
                <em className={isLive ? "live" : ""}>{status}</em>
              </div>
            );
          })}
          {!todayTeachingRows.length ? (
            <div className="dashboard-empty">
              <CalendarDays size={23} />
              <p>Hôm nay chưa có lịch dạy định kỳ.</p>
            </div>
          ) : null}
        </article>
        <article className="card panel">
          <div className="card-head">
            <div>
              <h2>Học sinh cần chú ý</h2>
              <p>Cảnh báo từ dữ liệu hiện tại</p>
            </div>
            <span className="count">{attention.length}</span>
          </div>
          {attention.slice(0, 4).map(function (student) {
            const reason =
              student.hasGrades && student.avg < 6
                ? "Điểm trung bình " + student.avg
                : student.hasAttendance && student.attendance < 80
                  ? "Chuyên cần chỉ " + student.attendance + "%"
                  : student.state;
            return (
              <div className="person-row" key={student.code}>
                <Avatar initials={student.initials} tone={student.tone} />
                <p>
                  <strong>{student.name}</strong>
                  <span>
                    <AlertTriangle size={12} />
                    {reason}
                  </span>
                </p>
                <button
                  className="icon-button"
                  onClick={() => props.go("students")}
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            );
          })}
          {!attention.length ? (
            <div className="dashboard-empty">
              <CheckCircle2 size={23} />
              <p>Hiện không có học sinh cần cảnh báo.</p>
            </div>
          ) : null}
        </article>
        <article className="card panel">
          <div className="card-head">
            <div>
              <h2>Trạng thái hệ thống</h2>
              <p>Cập nhật ngay sau mỗi thay đổi</p>
            </div>
          </div>
          {[
            [
              props.students.length + " học sinh đang được quản lý",
              "Dữ liệu học sinh",
              "green",
            ],
            [
              props.classes.length + " lớp học hiện có",
              "Dữ liệu lớp học",
              "blue",
            ],
            [
              props.assignments.length + " bài tập hiện có",
              "Dữ liệu bài tập",
              "purple",
            ],
            [props.documents + " tài liệu đã tải lên", "Kho tài liệu", "red"],
          ].map(function (row, index) {
            return (
              <div className="activity-row" key={row[1]}>
                <span className={"activity-icon " + row[2]}>
                  {index === 0 ? (
                    <GraduationCap size={14} />
                  ) : index === 1 ? (
                    <Users size={14} />
                  ) : index === 2 ? (
                    <NotebookPen size={14} />
                  ) : (
                    <FolderOpen size={14} />
                  )}
                </span>
                <p>
                  <strong>{row[0]}</strong>
                  <small>{row[1]}</small>
                </p>
              </div>
            );
          })}
        </article>
      </section>
      <section className="card quick-actions">
        <div>
          <h2>Thao tác nhanh</h2>
          <p>Các công việc thường dùng</p>
        </div>
        <div>
          <button onClick={() => props.go("attendance")}>
            <ClipboardCheck size={18} />
            Điểm danh
          </button>
          <button onClick={() => props.go("assignments")}>
            <Plus size={18} />
            Giao bài
          </button>
          <button onClick={() => props.go("grades")}>
            <BarChart3 size={18} />
            Nhập điểm
          </button>
          <button onClick={() => props.go("documents")}>
            <FolderOpen size={18} />
            Tài liệu
          </button>
        </div>
      </section>
    </>
  );
}

function StudentsView(props: {
  records: StudentRecord[];
  admin: boolean;
  onAdd: () => void;
  onEdit: (student: StudentRecord) => void;
  onSetPin: (student: StudentRecord) => void;
  onDelete: (student: StudentRecord) => void;
  onDeleteAll: () => void;
  onImport: (file: File) => Promise<void>;
  onExportExcel: () => void;
  onExportPdf: () => void;
}) {
  const [query, setQuery] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [stateFilter, setStateFilter] = useState("all");
  const [sort, setSort] = useState("name");
  const fileInput = useRef<HTMLInputElement>(null);
  const classNames = Array.from(
    new Set(
      props.records.flatMap(function (student) {
        return student.classNames?.length ? student.classNames : [student.className];
      }),
    ),
  );
  const filtered = props.records
    .filter(function (student) {
      return (
        (student.name.toLowerCase().includes(query.toLowerCase()) ||
          student.code.toLowerCase().includes(query.toLowerCase())) &&
        (classFilter === "all" || studentBelongsToClass(student, classFilter)) &&
        (stateFilter === "all" || student.state === stateFilter)
      );
    })
    .sort(function (a, b) {
      if (sort === "score") return b.avg - a.avg;
      if (sort === "attendance") return a.attendance - b.attendance;
      return a.name.localeCompare(b.name, "vi");
    });
  return (
    <>
      <PageTitle
        title="Quản lý học sinh"
        subtitle={
          "Điểm lấy từ Sổ điểm; chuyên cần = (có mặt + đi trễ) / tổng buổi đã điểm danh · " +
          props.records.length +
          " học sinh."
        }
      >
        <input
          ref={fileInput}
          hidden
          type="file"
          accept=".xlsx,.xls,.csv"
          onChange={async function (event) {
            const file = event.target.files?.[0];
            if (file) await props.onImport(file);
            event.currentTarget.value = "";
          }}
        />
        <button
          className="button ghost"
          onClick={() =>
            props.admin ? fileInput.current?.click() : props.onAdd()
          }
        >
          <Upload size={17} />
          Nhập Excel
        </button>
        <button className="button ghost" onClick={props.onExportPdf}>
          <FileText size={17} />
          Xuất PDF
        </button>
        <button className="button ghost" onClick={props.onExportExcel}>
          <Download size={17} />
          Xuất Excel
        </button>
        {props.admin && props.records.length ? (
          <button className="button danger" onClick={props.onDeleteAll}>
            <Trash2 size={17} />
            Xóa tất cả
          </button>
        ) : null}
        <button className="button primary" onClick={props.onAdd}>
          <UserPlus size={17} />
          Thêm học sinh
        </button>
      </PageTitle>
      <div className={props.admin ? "admin-strip active" : "admin-strip"}>
        <ShieldCheck size={17} />
        <span>
          {props.admin
            ? "Bạn đang ở chế độ Admin — có thể thêm, sửa và xóa dữ liệu."
            : "Chế độ chỉ xem — đăng nhập Admin để chỉnh sửa dữ liệu."}
        </span>
      </div>
      <div className="card toolbar">
        <label>
          <Search size={17} />
          <input
            value={query}
            onChange={function (event) {
              setQuery(event.target.value);
            }}
            placeholder="Tìm theo tên hoặc mã học sinh..."
          />
        </label>
        <select
          className="select"
          value={classFilter}
          onChange={function (event) {
            setClassFilter(event.target.value);
          }}
        >
          <option value="all">Tất cả lớp</option>
          {classNames.map(function (name) {
            return <option key={name}>{name}</option>;
          })}
        </select>
        <select
          className="select"
          value={stateFilter}
          onChange={function (event) {
            setStateFilter(event.target.value);
          }}
        >
          <option value="all">Mọi trạng thái</option>
          <option>Đang học</option>
          <option>Cần chú ý</option>
          <option>Tạm nghỉ</option>
        </select>
        <select
          className="select"
          value={sort}
          onChange={function (event) {
            setSort(event.target.value);
          }}
        >
          <option value="name">Sắp xếp theo tên</option>
          <option value="score">Điểm cao trước</option>
          <option value="attendance">Chuyên cần thấp trước</option>
        </select>
        <span />
        <button
          className="icon-button"
          title="Xuất Excel"
          onClick={props.onExportExcel}
        >
          <Download size={18} />
        </button>
      </div>
      <div className="card table-card">
        <div className="student-table-scroll scroll-region" tabIndex={0} aria-label="Danh sách học sinh">
        <div className="student-table">
          <div className="table-row table-head">
            <span>Học sinh</span>
            <span>Mã học sinh</span>
            <span>Lớp</span>
            <span>Điểm TB</span>
            <span>Chuyên cần</span>
            <span>Trạng thái</span>
            <span />
          </div>
          {filtered.map(function (student) {
            return (
              <div className="table-row" key={student.code}>
                <span className="student-name">
                  <Avatar initials={student.initials} tone={student.tone} />
                  <strong>{student.name}</strong>
                </span>
                <span>{student.code}</span>
                <span title={(student.classNames || [student.className]).join(", ")}>{(student.classNames || [student.className]).join(", ")}</span>
                <span
                  className={
                    !student.hasGrades
                      ? "score-empty"
                      : student.avg < 6
                        ? "score-low"
                        : "score-good"
                  }
                >
                  {student.hasGrades ? student.avg : "—"}
                </span>
                <span>
                  {student.hasAttendance ? (
                    <>
                      <i className="progress">
                        <em style={{ width: student.attendance + "%" }} />
                      </i>
                      {student.attendance}%
                    </>
                  ) : (
                    <em className="not-calculated">Chưa điểm danh</em>
                  )}
                </span>
                <span>
                  <i
                    className={
                      student.state === "Cần chú ý" ? "dot danger" : "dot"
                    }
                  />
                  {student.state}
                </span>
                <span>
                  {props.admin ? (
                    <span className="row-actions">
                      <button title="Sửa" onClick={() => props.onEdit(student)}>
                        <Pencil size={15} />
                      </button>
                      <button
                        title="Đổi PIN học sinh"
                        onClick={() => props.onSetPin(student)}
                      >
                        <KeyRound size={15} />
                      </button>
                      <button
                        title="Xóa"
                        className="delete"
                        onClick={() => props.onDelete(student)}
                      >
                        <Trash2 size={15} />
                      </button>
                    </span>
                  ) : (
                    <button className="icon-button">
                      <MoreHorizontal size={18} />
                    </button>
                  )}
                </span>
              </div>
            );
          })}
        </div>
        </div>
        <div className="pagination">
          <span>Hiển thị {filtered.length} học sinh</span>
          <div>
            <button>‹</button>
            <b>1</b>
            <button>›</button>
          </div>
        </div>
      </div>
    </>
  );
}

function AttendanceView(props: {
  records: StudentRecord[];
  classes: ClassRecord[];
  items: AdminItemRecord[];
  admin: boolean;
  onSave: (session: AttendanceSession) => Promise<void>;
  onDelete: (item: AdminItemRecord) => void;
  onRequireAdmin: () => void;
  notify: (text: string) => void;
  target?: {
    classId: string;
    className: string;
    date: string;
    startTime: string;
    endTime: string;
    sessionId?: number;
    sessionType: "regular" | "makeup";
  } | null;
}) {
  const newest = props.items.slice().sort(function (a, b) {
    return String(b.updatedAt || b.createdAt || "").localeCompare(
      String(a.updatedAt || a.createdAt || ""),
    );
  })[0];
  const candidateInitialClass = String(
    props.target?.className || newest?.data.className || props.classes[0]?.name || "Tất cả lớp",
  );
  const initialClass =
    candidateInitialClass === "Tất cả lớp" ||
    props.classes.some(function (item) { return item.name === candidateInitialClass; })
      ? candidateInitialClass
      : props.classes[0]?.name || "Tất cả lớp";
  const initialDate = props.target?.date || localDateInTimeZone();
  const classSchedule = props.classes.find(function (item) {
    return item.name === initialClass;
  });
  const initialStart = String(
    props.target?.startTime || newest?.data.startTime || classSchedule?.startTime || "08:00",
  );
  const initialEnd = String(
    props.target?.endTime || newest?.data.endTime || classSchedule?.endTime || "09:30",
  );
  function rosterFor(name: string) {
    const course = props.classes.find(function(item) { return item.name === name; });
    return name === "Tất cả lớp"
      ? props.records
      : props.records.filter(function (student) {
          return studentBelongsToClass(student, name, course?.key || (course?.id ? String(course.id) : undefined));
        });
  }
  function findSaved(name: string, date: string, start: string, end: string) {
    return props.items.find(function (item) {
      return (
        String(item.data.className || "Tất cả lớp") === name &&
        String(item.data.date || "") === date &&
        String(item.data.startTime || "") === start &&
        String(item.data.endTime || "") === end
      );
    });
  }
  function buildStates(name: string, item?: AdminItemRecord) {
    const saved = (item?.data.states || {}) as Record<string, string>;
    const next: Record<string, string> = {};
    rosterFor(name).forEach(function (student) {
      next[student.code] = saved[student.code] || "present";
    });
    return next;
  }
  const [className, setClassName] = useState(initialClass);
  const [date, setDate] = useState(initialDate);
  const [startTime, setStartTime] = useState(initialStart);
  const [endTime, setEndTime] = useState(initialEnd);
  const [states, setStates] = useState(function () {
    return buildStates(
      initialClass,
      findSaved(initialClass, initialDate, initialStart, initialEnd),
    );
  });
  const [historyItem, setHistoryItem] = useState<AdminItemRecord | null>(null);
  const [editingHistory, setEditingHistory] = useState<AdminItemRecord | null>(
    null,
  );
  const roster = rosterFor(className);
  const selectedClass = props.classes.find(function (item) {
    return item.name === className;
  });
  const selectedClassId =
    className === "Tất cả lớp"
      ? ALL_CLASSES_ID
      : selectedClass
        ? classIdentifier(selectedClass)
        : className;
  const historyItems = filterAndSortAttendance(
    props.items,
    selectedClassId,
    className,
  );
  function historyClassName(item: AdminItemRecord) {
    const savedId = String(item.data.classId || item.data.classKey || "").trim();
    const matched = savedId
      ? props.classes.find(function (course) { return classIdentifier(course) === savedId; })
      : undefined;
    const savedName = String(item.data.className || "").trim();
    if (matched?.name) return matched.name;
    if (savedName && savedName !== "Chưa xếp lớp" && savedName !== "Tất cả lớp") return savedName;
    return savedId ? "Lớp " + savedId : "Lớp không còn tồn tại";
  }
  function historyDate(item: AdminItemRecord) {
    const raw = String(item.data.date || "");
    const match = raw.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
    const iso = match
      ? match[3] + "-" + match[2].padStart(2, "0") + "-" + match[1].padStart(2, "0")
      : raw;
    const parsed = /^\d{4}-\d{2}-\d{2}$/.test(iso) ? new Date(iso + "T00:00:00") : null;
    return parsed && !Number.isNaN(parsed.getTime()) ? parsed.toLocaleDateString("vi-VN") : raw;
  }
  function changeSelection(
    nextClass: string,
    nextDate: string,
    nextStart: string,
    nextEnd: string,
  ) {
    setEditingHistory(null);
    setClassName(nextClass);
    setDate(nextDate);
    setStartTime(nextStart);
    setEndTime(nextEnd);
    setStates(
      buildStates(
        nextClass,
        findSaved(nextClass, nextDate, nextStart, nextEnd),
      ),
    );
  }
  function changeClass(nextClass: string) {
    const match = props.classes.find(function (item) {
      return item.name === nextClass;
    });
    const nextStart = match?.startTime || startTime;
    const nextEnd = match?.endTime || endTime;
    changeSelection(nextClass, date, nextStart, nextEnd);
  }
  function allPresent() {
    if (!props.admin) {
      props.onRequireAdmin();
      return;
    }
    const next: Record<string, string> = {};
    roster.forEach(function (student) {
      next[student.code] = "present";
    });
    setStates(next);
    props.notify("Đã đánh dấu tất cả có mặt");
  }
  function setStatus(code: string, status: string) {
    if (!props.admin) {
      props.onRequireAdmin();
      return;
    }
    setStates(Object.assign({}, states, { [code]: status }));
  }
  function loadHistory(item: AdminItemRecord) {
    const nextClass = String(item.data.className || "Tất cả lớp");
    const nextDate = String(item.data.date || initialDate);
    const nextStart = String(item.data.startTime || "08:00");
    const nextEnd = String(item.data.endTime || "09:30");
    setEditingHistory(item);
    setClassName(nextClass);
    setDate(nextDate);
    setStartTime(nextStart);
    setEndTime(nextEnd);
    setStates(buildStates(nextClass, item));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function startNewAttendance() {
    const today = localDateInTimeZone();
    const currentClass = props.classes.find(function (item) {
      return item.name === className;
    });
    const nextStart = currentClass?.startTime || startTime;
    const nextEnd = currentClass?.endTime || endTime;
    setEditingHistory(null);
    setDate(today);
    setStartTime(nextStart);
    setEndTime(nextEnd);
    setStates(
      buildStates(
        className,
        findSaved(className, today, nextStart, nextEnd),
      ),
    );
  }
  const counts: Record<string, number> = {
    present: 0,
    late: 0,
    allowed: 0,
    absent: 0,
  };
  roster.forEach(function (student) {
    const status = states[student.code] || "present";
    counts[status] = (counts[status] || 0) + 1;
  });
  const subtitle =
    new Date(date + "T00:00:00").toLocaleDateString("vi-VN", {
      weekday: "long",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }) +
    " · " +
    startTime +
    "–" +
    endTime;
  return (
    <>
      <PageTitle title="Điểm danh" subtitle={subtitle}>
        <button
          className="button primary"
          onClick={() =>
            props.admin
              ? props.onSave({
                  classId: selectedClassId,
                  classKey: selectedClassId,
                  className,
                  date,
                  startTime,
                  endTime,
                  states,
                  sessionId: props.target?.sessionId,
                  sessionType: props.target?.sessionType,
                  storageKey: editingHistory?.key,
                })
              : props.onRequireAdmin()
          }
        >
          <Check size={17} />
          Lưu điểm danh
        </button>
      </PageTitle>
      {editingHistory ? (
        <div className="editing-attendance-banner">
          <CalendarDays />
          <span>
            <strong>
              Đang chỉnh sửa buổi ngày{" "}
              {new Date(date + "T00:00:00").toLocaleDateString("vi-VN")}
            </strong>
            <small>
              {className} · {startTime}–{endTime}
            </small>
          </span>
          <button type="button" onClick={startNewAttendance}>
            Thoát chế độ sửa
          </button>
        </div>
      ) : null}
      <div className="card attendance-toolbar">
        <label>
          <small>Lớp học</small>
          <select
            value={className}
            onChange={function (event) {
              changeClass(event.target.value);
            }}
          >
            <option>Tất cả lớp</option>
            {props.classes.map(function (item) {
              return <option key={item.id || item.name}>{item.name}</option>;
            })}
          </select>
        </label>
        <label>
          <small>Ngày</small>
          <input
            type="date"
            value={date}
            onChange={function (event) {
              changeSelection(
                className,
                event.target.value,
                startTime,
                endTime,
              );
            }}
          />
        </label>
        <label>
          <small>Giờ bắt đầu</small>
          <input
            type="time"
            value={startTime}
            onChange={function (event) {
              changeSelection(className, date, event.target.value, endTime);
            }}
          />
        </label>
        <label>
          <small>Giờ kết thúc</small>
          <input
            type="time"
            value={endTime}
            onChange={function (event) {
              changeSelection(className, date, startTime, event.target.value);
            }}
          />
        </label>
        <button className="button soft" onClick={allPresent}>
          <CheckCircle2 size={17} />
          Tất cả có mặt
        </button>
      </div>
      <div className="summary-grid">
        {[
          ["present", "Có mặt", Check],
          ["late", "Đi trễ", Clock3],
          ["allowed", "Có phép", FileText],
          ["absent", "Không phép", X],
        ].map(function (item) {
          const Icon = item[2] as typeof Check;
          return (
            <div className="card" key={item[0] as string}>
              <span className={"summary-icon " + item[0]}>
                <Icon size={18} />
              </span>
              <p>
                <strong>{counts[item[0] as string]}</strong>
                <small>{item[1] as string}</small>
              </p>
            </div>
          );
        })}
      </div>
      <div className="card attendance-list">
        <div className="list-head">
          <div>
            <h2>{className}</h2>
            <p>{className === "Tất cả lớp" ? "Danh sách học sinh của tất cả lớp đang quản lý." : "Ngày và giờ có thể thay đổi tự do; mỗi buổi được lưu riêng."}</p>
          </div>
          <span>{roster.length} học sinh</span>
        </div>
        <div className="attendance-roster-scroll scroll-region" tabIndex={0} aria-label="Danh sách điểm danh học sinh">
        {roster.map(function (student, index) {
          return (
            <div className="attendance-row" key={student.code}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <Avatar initials={student.initials} tone={student.tone} />
              <p>
                <strong>{student.name}</strong>
                <small>
                  {student.code} · {student.className}
                </small>
              </p>
              <div>
                {[
                  ["present", "Có mặt", Check],
                  ["late", "Đi trễ", Clock3],
                  ["allowed", "Có phép", FileText],
                  ["absent", "Không phép", X],
                ].map(function (item) {
                  const Icon = item[2] as typeof Check;
                  return (
                    <button
                      key={item[0] as string}
                      className={
                        (states[student.code] || "present") === item[0]
                          ? "selected " + item[0]
                          : ""
                      }
                      onClick={() => setStatus(student.code, item[0] as string)}
                    >
                      <Icon size={14} />
                      {item[1] as string}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
        {!roster.length ? (
          <div className="empty-row">
            <Users size={20} />
            <span>Lớp này chưa có học sinh.</span>
          </div>
        ) : null}
        </div>
      </div>
      <div className="card attendance-history">
        <div className="card-head">
          <div>
            <h2>Lịch sử điểm danh</h2>
            <p>
              Bấm một buổi để xem danh sách chi tiết; sau đó có thể mở lại để
              sửa.
            </p>
          </div>
        </div>
        <div className="attendance-history-scroll scroll-region" tabIndex={0} aria-label="Lịch sử điểm danh">
        {historyItems.map(function (item) {
            return (
              <div key={item.id}>
                <button onClick={() => setHistoryItem(item)}>
                  <CalendarDays size={17} />
                  <span>
                    <strong>{historyDate(item)} · {historyClassName(item)}</strong>
                    <small>
                      {String(item.data.startTime || "")}–{String(item.data.endTime || "")}
                    </small>
                  </span>
                </button>
                {props.admin ? (
                  <button
                    className="icon-button delete"
                    title="Xóa bản điểm danh"
                    onClick={() => props.onDelete(item)}
                  >
                    <Trash2 size={16} />
                  </button>
                ) : null}
              </div>
            );
          })}
        {!historyItems.length ? (
          <div className="empty-row">
            <CalendarDays size={20} />
            <span>Chưa có buổi điểm danh đã lưu.</span>
          </div>
        ) : null}
        </div>
      </div>
      {historyItem ? (
        <div className="modal" onMouseDown={() => setHistoryItem(null)}>
          <section
            className="form-modal attendance-detail-modal"
            onMouseDown={function (event) {
              event.stopPropagation();
            }}
          >
            <div className="modal-head">
              <div>
                <h2>
                  Chi tiết điểm danh ngày{" "}
                  {new Date(
                    String(historyItem.data.date) + "T00:00:00",
                  ).toLocaleDateString("vi-VN")}
                </h2>
                <p>
                  {historyClassName(historyItem)} ·{" "}
                  {String(historyItem.data.startTime || "")}–
                  {String(historyItem.data.endTime || "")}
                </p>
              </div>
              <button
                type="button"
                className="modal-close"
                onClick={() => setHistoryItem(null)}
              >
                <X size={19} />
              </button>
            </div>
            <div className="attendance-detail-list">
              {rosterFor(
                String(historyItem.data.className || "Tất cả lớp"),
              ).map(function (student) {
                const saved = (historyItem.data.states || {}) as Record<
                  string,
                  string
                >;
                const status = saved[student.code] || "present";
                const labels: Record<string, string> = {
                  present: "Có mặt",
                  late: "Đi trễ",
                  allowed: "Có phép",
                  absent: "Không phép",
                };
                return (
                  <div key={student.code}>
                    <Avatar initials={student.initials} tone={student.tone} />
                    <p>
                      <strong>{student.name}</strong>
                      <small>
                        {student.code} · {(student.classNames?.length ? student.classNames : [student.className]).join(", ")}
                      </small>
                    </p>
                    <em className={status}>{labels[status] || status}</em>
                  </div>
                );
              })}
            </div>
            <div className="modal-footer">
              <button
                className="button ghost"
                onClick={() => setHistoryItem(null)}
              >
                Đóng
              </button>
              <button
                className="button primary"
                onClick={() => {
                  loadHistory(historyItem);
                  setHistoryItem(null);
                }}
              >
                Chỉnh sửa buổi ngày{" "}
                {new Date(
                  String(historyItem.data.date) + "T00:00:00",
                ).toLocaleDateString("vi-VN")}
              </button>
            </div>
          </section>
        </div>
      ) : null}
    </>
  );
}

function AssignmentDetailModal(props: {
  assignment: AssignmentRecord;
  close: () => void;
  onRefresh: () => Promise<void>;
}) {
  const [students, setStudents] = useState<AssignmentSubmissionStudent[]>([]);
  const [loading, setLoading] = useState(Boolean(props.assignment.id));
  const [error, setError] = useState(
    props.assignment.id ? "" : "Bài tập chưa được lưu.",
  );
  const [actionError, setActionError] = useState("");
  const [updatingId, setUpdatingId] = useState<number | null>(null);
  const [drafts, setDrafts] = useState<Record<number, { score: string; feedback: string }>>({});
  const dirtyDraftIdsRef = useRef<Set<number>>(new Set());
  const modalActiveRef = useRef(true);
  const submissionLoadSeqRef = useRef(0);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);
  const [editingGrade, setEditingGrade] = useState(false);
  const [viewerTarget, setViewerTarget] = useState<FileViewerTarget | null>(null);

  function mergeSubmissionRecords(records: AssignmentSubmissionStudent[], resetDrafts: boolean) {
    const canonicalRecords = Array.from(new Map(records.map(function(student) { return [student.id, student]; })).values());
    setStudents(canonicalRecords);
    setDrafts(function(current) {
      const next = resetDrafts ? {} as Record<number, { score: string; feedback: string }> : { ...current };
      canonicalRecords.forEach(function(student) {
        if (!resetDrafts && dirtyDraftIdsRef.current.has(student.id)) return;
        next[student.id] = {
          score: student.score === null || student.score === undefined ? "" : String(student.score),
          feedback: student.feedback || "",
        };
      });
      return next;
    });
  }

  async function loadSubmissionStudents(resetDrafts = false) {
    if (!props.assignment.id) return;
    const requestSeq = ++submissionLoadSeqRef.current;
    const response = await fetch("/api/assignments/" + props.assignment.id + "/submissions", { cache: "no-store" });
    const payload = await response.json().catch(function() { return {}; }) as { error?: string; students?: AssignmentSubmissionStudent[] };
    if (!response.ok) throw new Error(payload.error || "Không thể tải chi tiết bài tập.");
    if (modalActiveRef.current && requestSeq === submissionLoadSeqRef.current) mergeSubmissionRecords(payload.students || [], resetDrafts);
  }

  function updateStudentDraft(studentId: number, patch: Partial<{ score: string; feedback: string }>) {
    dirtyDraftIdsRef.current.add(studentId);
    setDrafts(function(current) {
      const base = current[studentId] ?? { score: "", feedback: "" };
      return { ...current, [studentId]: { ...base, ...patch } };
    });
  }

  useEffect(
    function () {
      modalActiveRef.current = true;
      dirtyDraftIdsRef.current.clear();
      submissionLoadSeqRef.current += 1;
      const startTimer = window.setTimeout(function() {
        if (!modalActiveRef.current) return;
        setStudents([]);
        setDrafts({});
        setActionError("");
        setError(props.assignment.id ? "" : "Bài tập chưa được lưu.");
        setLoading(Boolean(props.assignment.id));
        if (!props.assignment.id) return;
        void loadSubmissionStudents(true)
          .catch(function (reason) {
            if (modalActiveRef.current) setError(reason instanceof Error ? reason.message : "Không thể tải chi tiết bài tập.");
          })
          .finally(function () {
            if (modalActiveRef.current) setLoading(false);
          });
      }, 0);
      return function () { window.clearTimeout(startTimer); modalActiveRef.current = false; };
    },
    // Initial snapshot is keyed only by the assignment being viewed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [props.assignment.id],
  );

  useEffect(function() {
    if (!props.assignment.id) return;
    const refresh = function() {
      if (document.visibilityState !== "visible") return;
      void loadSubmissionStudents(false).catch(function() {});
    };
    const onVisibility = function() { if (document.visibilityState === "visible") refresh(); };
    document.addEventListener("visibilitychange", onVisibility);
    return function() { document.removeEventListener("visibilitychange", onVisibility); };
    // Refresh on return only. Continuous polling would spend D1 rows while the teacher is reading or grading.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.assignment.id]);
  async function changeCompletion(student: AssignmentSubmissionStudent, completed: boolean) {
    if (!props.assignment.id) return;
    setUpdatingId(student.id);
    setActionError("");
    try {
      const response = await fetch(
        "/api/assignments/" + props.assignment.id + "/submissions",
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ studentId: student.id, completed, expectedUpdatedAt: student.updatedAt ?? "" }),
        },
      );
      const payload = (await response.json()) as {
        error?: string;
        submittedAt?: string | null;
        submissionId?: number | null;
        status?: string;
      };
      if (!response.ok)
        throw new Error(
          payload.error || "Không thể cập nhật trạng thái bài tập.",
        );
      dirtyDraftIdsRef.current.delete(student.id);
      await loadSubmissionStudents(true);
      void props.onRefresh();
    } catch (reason) {
      setActionError(
        reason instanceof Error
          ? reason.message
          : "Không thể cập nhật trạng thái bài tập.",
      );
    } finally {
      setUpdatingId(null);
    }
  }
  async function saveGrade(student: AssignmentSubmissionStudent) {
    if (!props.assignment.id || !isStudentSubmittedStatus(student.status)) return;
    const draft = drafts[student.id] || { score: "", feedback: "" };
    setUpdatingId(student.id);
    setActionError("");
    try {
      const response = await fetch("/api/assignments/" + props.assignment.id + "/submissions", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId: student.id, score: draft.score === "" ? null : Number(draft.score), feedback: draft.feedback, expectedUpdatedAt: student.updatedAt ?? "" }),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Không thể lưu điểm và nhận xét.");
      setStudents(function(records) {
        return records.map(function (item) {
          return item.id === student.id ? Object.assign({}, item, payload.submission || {}) : item;
        });
      });
      dirtyDraftIdsRef.current.delete(student.id);
      setEditingGrade(false);
      void props.onRefresh();
    } catch (reason) {
      setActionError(reason instanceof Error ? reason.message : "Không thể lưu điểm và nhận xét.");
    } finally {
      setUpdatingId(null);
    }
  }
  const completed = students.filter(function(student) {
    return isAssignmentCompletedStatus(student.status);
  });
  const selectedStudent = students.find(function(student) { return student.id === selectedStudentId; }) || null;
  const normalizedQuery = normalizeSearchText(query);
  const visibleStudents = students.filter(function(student) {
    if (normalizedQuery && !normalizeSearchText(student.name + " " + student.code).includes(normalizedQuery)) return false;
    if (statusFilter === "submitted") return student.status === "submitted";
    if (statusFilter === "graded") return student.status === "graded";
    if (statusFilter === "teacher_completed") return isTeacherCompletedStatus(student.status);
    if (statusFilter === "missing") return !isAssignmentCompletedStatus(student.status);
    return true;
  }).sort(function(a, b) {
    if (sortBy === "latest") return String(b.submittedAt || "").localeCompare(String(a.submittedAt || "")) || a.name.localeCompare(b.name, "vi");
    if (sortBy === "score") {
      const left = a.score === null || a.score === undefined ? -Infinity : a.score;
      const right = b.score === null || b.score === undefined ? -Infinity : b.score;
      return right - left || a.name.localeCompare(b.name, "vi");
    }
    return a.name.localeCompare(b.name, "vi");
  });

  function isFullyGradedSubmission(student: AssignmentSubmissionStudent): boolean {
    return student.status === "graded"
      && student.score !== null
      && student.score !== undefined
      && Boolean(String(student.feedback || "").trim());
  }

  function openStudent(student: AssignmentSubmissionStudent) {
    setSelectedStudentId(student.id);
    setEditingGrade(isStudentSubmittedStatus(student.status) && !isFullyGradedSubmission(student));
    setActionError("");
  }

  function cancelGradeEdit(student: AssignmentSubmissionStudent) {
    dirtyDraftIdsRef.current.delete(student.id);
    setDrafts(function(current) {
      return { ...current, [student.id]: { score: student.score === null || student.score === undefined ? "" : String(student.score), feedback: student.feedback || "" } };
    });
    setEditingGrade(false);
  }

  function statusText(student: AssignmentSubmissionStudent): string {
    if (student.status === "graded") return isFullyGradedSubmission(student) ? "Đã chấm" : "Chờ hoàn tất";
    if (student.status === "submitted") return "Đã nộp";
    if (isTeacherCompletedStatus(student.status)) return "GV đánh dấu hoàn thành";
    if (isDraftSubmissionStatus(student.status)) return "Bản nháp";
    return "Chưa nộp";
  }

  const selectedFiles = selectedStudent
    ? selectedStudent.files?.length
      ? selectedStudent.files
      : selectedStudent.fileName
        ? [{ id: 0, fileName: selectedStudent.fileName, fileSize: selectedStudent.fileSize || 0, contentType: selectedStudent.contentType || "" }]
        : []
    : [];
  return (
    <div className="modal assignment-roster-overlay" onMouseDown={props.close}>
      <section
        className="form-modal assignment-detail-modal assignment-roster-modal"
        onMouseDown={function (event) {
          event.stopPropagation();
        }}
      >
        <div className="modal-head">
          <div>
            <h2>{props.assignment.title}</h2>
            <p>
              {props.assignment.className} · Hạn{" "}
              {new Date(props.assignment.dueDate).toLocaleString("vi-VN")}
              {" · Tối đa " + props.assignment.maxScore + " điểm"}
            </p>
          </div>
          <button type="button" className="modal-close" onClick={props.close}>
            <X size={19} />
          </button>
        </div>
        <section className="assignment-detail-description" aria-label="Mô tả bài tập">
          <strong>Mô tả bài tập</strong>
          <p>{props.assignment.description?.trim() || "Giáo viên chưa thêm mô tả cho bài tập này."}</p>
        </section>
        <div className="assignment-detail-summary">
          <span>
            <CheckCircle2 />
            <strong>{completed.length}</strong>
            <small>Đã hoàn thành</small>
          </span>
          <span>
            <Clock3 />
            <strong>{students.length - completed.length}</strong>
            <small>Chưa hoàn thành</small>
          </span>
          <span>
            <Users />
            <strong>{students.length}</strong>
            <small>Tổng học sinh</small>
          </span>
        </div>
        {actionError ? (
          <div className="form-error">
            <AlertTriangle size={16} />
            {actionError}
          </div>
        ) : null}
        {loading ? (
          <div className="detail-loading">
            <Clock3 />
            Đang tải lịch sử hoàn thành...
          </div>
        ) : error ? (
          <div className="form-error">
            <AlertTriangle size={16} />
            {error}
          </div>
        ) : (
          <div className="assignment-roster-body">
            <div className="assignment-roster-toolbar">
              <label><Search /><input value={query} onChange={function(event) { setQuery(event.target.value); }} placeholder="Tìm tên hoặc mã học sinh" aria-label="Tìm học sinh" /></label>
              <select value={statusFilter} onChange={function(event) { setStatusFilter(event.target.value); }} aria-label="Lọc trạng thái"><option value="all">Tất cả trạng thái</option><option value="submitted">Đã nộp</option><option value="graded">Đã chấm</option><option value="teacher_completed">GV đánh dấu</option><option value="missing">Chưa hoàn thành</option></select>
              <select value={sortBy} onChange={function(event) { setSortBy(event.target.value); }} aria-label="Sắp xếp"><option value="name">Tên A-Z</option><option value="latest">Nộp gần nhất</option><option value="score">Điểm cao nhất</option></select>
            </div>
            <div className="assignment-roster-scroll" tabIndex={0} aria-label="Danh sách bài nộp">
              <table className="assignment-roster-table">
                <thead><tr><th>Học sinh</th><th>Trạng thái</th><th>Lần nộp gần nhất</th><th>Điểm</th><th>Nhận xét</th><th>Thao tác</th></tr></thead>
                <tbody>{visibleStudents.map(function(student) {
                  return <tr key={props.assignment.id + "-" + student.id}>
                    <td data-label="Học sinh"><strong>{student.name}</strong><small>{student.code}</small></td>
                    <td data-label="Trạng thái"><em className={"assignment-status-chip " + String(student.status || "not_submitted")}>{statusText(student)}</em></td>
                    <td data-label="Lần nộp">{student.submittedAt ? new Date(student.submittedAt).toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "short" }) : "-"}</td>
                    <td data-label="Điểm">{student.status === "graded" ? <strong>{student.score ?? "-"} / {props.assignment.maxScore}</strong> : "-"}</td>
                    <td data-label="Nhận xét"><span title={student.feedback || ""}>{student.feedback || "-"}</span></td>
                    <td data-label="Thao tác"><button type="button" className="button tiny soft" onClick={function() { openStudent(student); }}><Eye />Xem</button></td>
                  </tr>;
                })}</tbody>
              </table>
            </div>
            {!visibleStudents.length ? (
              <div className="empty-row">
                <Users />
                <span>{students.length ? "Không có học sinh khớp bộ lọc." : "Lớp này chưa có học sinh."}</span>
              </div>
            ) : null}
          </div>
        )}
        <div className="modal-footer">
          <button className="button primary" onClick={props.close}>
            Đóng
          </button>
        </div>
      </section>
      {selectedStudent ? (
        <div className="submission-grader-overlay" onMouseDown={function() { setSelectedStudentId(null); }}>
          <section className="submission-grader-modal" role="dialog" aria-modal="true" aria-label={"Chấm bài " + selectedStudent.name} onMouseDown={function(event) { event.stopPropagation(); }}>
            <header className="submission-grader-head"><div><small>Chấm bài</small><h2>{selectedStudent.name}</h2><p>{selectedStudent.code}{selectedStudent.submittedAt ? " · Lần nộp " + new Date(selectedStudent.submittedAt).toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "short" }) : " · Chưa có bài nộp"}</p></div><button type="button" className="modal-close" onClick={function() { setSelectedStudentId(null); }} aria-label="Đóng"><X /></button></header>
            <div className="submission-grader-body">
              <section className="submission-work-panel">
                <div className="submission-panel-title"><div><h3>Tệp đã nộp</h3><p>{selectedFiles.length} tệp trong bài hiện tại</p></div><span>{statusText(selectedStudent)}</span></div>
                {selectedFiles.length ? <div className="submission-review-files">{selectedFiles.map(function(file) {
                  const url = file.id ? "/api/submission-files/" + file.id + "/file" : "/api/submissions/" + selectedStudent.submissionId + "/file";
                  return <article key={file.id || file.fileName}><FileText /><div><strong title={file.fileName}>{file.fileName}</strong><small>{formatFileSize(file.fileSize)}</small></div><button type="button" className="button tiny soft" onClick={function() { setViewerTarget({ name: file.fileName, url, contentType: file.contentType }); }}><Eye />Xem</button><a className="icon-button" href={url + "?download=1"} aria-label={"Tải " + file.fileName}><Download /></a></article>;
                })}</div> : <div className="submission-empty-files"><FileText /><p>Học sinh chưa nộp tệp.</p></div>}
                {selectedStudent.responseText && selectedStudent.responseText !== "Đã hoàn thành theo dữ liệu cũ" ? <div className="submission-response-text"><h3>Nội dung trả lời</h3><p>{selectedStudent.responseText}</p></div> : null}
              </section>
              <section className="submission-grade-panel">
                {isStudentSubmittedStatus(selectedStudent.status) ? isFullyGradedSubmission(selectedStudent) && !editingGrade ? (
                  <div className="grade-readonly"><span>Đã chấm</span><strong>{selectedStudent.score ?? "-"} / {props.assignment.maxScore}</strong><p>{selectedStudent.feedback || "Giáo viên chưa ghi nhận xét."}</p><small>{selectedStudent.gradedAt ? "Chấm lúc " + new Date(selectedStudent.gradedAt).toLocaleString("vi-VN") : ""}</small></div>
                ) : (
                  <div className="grade-edit-form"><label><span>Điểm <small>/ {props.assignment.maxScore}</small></span><input type="number" min="0" max={props.assignment.maxScore} step="0.25" value={(drafts[selectedStudent.id] || { score: "", feedback: "" }).score} onChange={function(event) { updateStudentDraft(selectedStudent.id, { score: event.target.value }); }} /></label><label><span>Nhận xét</span><textarea rows={7} value={(drafts[selectedStudent.id] || { score: "", feedback: "" }).feedback} onChange={function(event) { updateStudentDraft(selectedStudent.id, { feedback: event.target.value }); }} placeholder="Nhập nhận xét dành riêng cho học sinh này" /></label></div>
                ) : isTeacherCompletedStatus(selectedStudent.status) ? <div className="grade-readonly teacher-completed"><CheckCircle2 /><strong>GV đã đánh dấu hoàn thành</strong><p>Trạng thái này không tạo bài nộp hoặc tệp giả.</p></div> : <div className="grade-readonly pending"><Clock3 /><strong>Chưa có bài nộp</strong><p>Bạn có thể đánh dấu hoàn thành nếu học sinh đã làm bài ngoài hệ thống.</p></div>}
                {actionError ? <p className="form-error" role="alert">{actionError}</p> : null}
              </section>
            </div>
            <footer className="submission-grader-footer"><button type="button" className="button ghost" onClick={function() { setSelectedStudentId(null); }}>Đóng</button>{isStudentSubmittedStatus(selectedStudent.status) ? isFullyGradedSubmission(selectedStudent) && !editingGrade ? <button type="button" className="button primary" onClick={function() { setEditingGrade(true); }}><Pencil />Chỉnh sửa</button> : <>{selectedStudent.status === "graded" ? <button type="button" className="button soft" disabled={updatingId !== null} onClick={function() { cancelGradeEdit(selectedStudent); }}>Hủy chỉnh sửa</button> : null}<button type="button" className="button primary" disabled={updatingId !== null} onClick={function() { void saveGrade(selectedStudent); }}>{updatingId === selectedStudent.id ? <Clock3 /> : <Check />}{selectedStudent.status === "graded" ? "Lưu thay đổi" : "Lưu kết quả"}</button></> : isTeacherCompletedStatus(selectedStudent.status) ? <button type="button" className="button soft" disabled={updatingId !== null} onClick={function() { void changeCompletion(selectedStudent, false); }}>{updatingId === selectedStudent.id ? <Clock3 /> : <X />}Bỏ đánh dấu hoàn thành</button> : <button type="button" className="button primary" disabled={updatingId !== null} onClick={function() { void changeCompletion(selectedStudent, true); }}>{updatingId === selectedStudent.id ? <Clock3 /> : <Check />}Đánh dấu đã hoàn thành</button>}</footer>
          </section>
        </div>
      ) : null}
      <FileViewerModal target={viewerTarget} close={function() { setViewerTarget(null); }} />
    </div>
  );
}

function AssignmentsView(props: {
  records: AssignmentRecord[];
  admin: boolean;
  onAdd: () => void;
  onEdit: (assignment: AssignmentRecord) => void;
  onDelete: (assignment: AssignmentRecord) => void;
  onDeleteAll: () => void;
  onRefresh: () => Promise<void>;
}) {
  const [tab, setTab] = useState("all");
  const [classFilter, setClassFilter] = useState("all");
  const [detail, setDetail] = useState<AssignmentRecord | null>(null);
  const classNames = Array.from(new Set(props.records.map(function(item) { return item.className; }).filter(Boolean))).sort(function(a, b) { return a.localeCompare(b, "vi"); });
  const classRecords = props.records.filter(function(item) {
    return classFilter === "all" || item.className === classFilter;
  });
  const pendingSubmissionCount = classRecords.reduce(function(total, item) {
    return total + (item.pendingGradingCount || 0);
  }, 0);
  const filtered = classRecords.filter(function (item) {
    if (tab === "open") return item.status === "Đang mở";
    if (tab === "due") return item.status === "Sắp hết hạn";
    if (tab === "closed") return item.status === "Đã kết thúc";
    if (tab === "grading") return (item.pendingGradingCount || 0) > 0;
    return true;
  });
  return (
    <>
      <PageTitle
        title="Bài tập"
        subtitle="Giao bài, theo dõi tiến độ nộp và chấm bài tập."
      >
        {props.admin && props.records.length ? (
          <button className="button danger" onClick={props.onDeleteAll}>
            <Trash2 size={17} />
            Xóa tất cả
          </button>
        ) : null}
        <button className="button primary" onClick={props.onAdd}>
          <Plus size={17} />
          Tạo bài tập
        </button>
      </PageTitle>
      <div className={props.admin ? "admin-strip active" : "admin-strip"}>
        <ShieldCheck size={17} />
        <span>
          {props.admin
            ? "Chế độ Admin đang bật — mọi thay đổi sẽ được lưu."
            : "Đăng nhập Admin để tạo hoặc chỉnh sửa bài tập."}
        </span>
      </div>
      <div className="assignment-controls">
        <div className="tabs assignment-tabs">
          {[
            ["all", "Tất cả"],
            ["open", "Đang mở"],
            ["due", "Sắp hết hạn"],
            ["closed", "Đã kết thúc"],
            ["grading", "Chờ chấm"],
          ].map(function (item) {
            const count = item[0] === "all" ? classRecords.length : item[0] === "grading" ? pendingSubmissionCount : 0;
            return (
              <button
                key={item[0]}
                className={tab === item[0] ? "active" : ""}
                onClick={() => setTab(item[0])}
              >
                {item[1]}
                {(item[0] === "all" || item[0] === "grading") && count > 0 ? <b>{count}</b> : null}
              </button>
            );
          })}
        </div>
        <label className="assignment-class-filter">
          <Users size={16} />
          <select value={classFilter} onChange={function(event) { setClassFilter(event.target.value); }} aria-label="Lọc bài tập theo lớp">
            <option value="all">Tất cả lớp</option>
            {classNames.map(function(name) { return <option key={name} value={name}>{name}</option>; })}
          </select>
        </label>
      </div>
      {filtered.length ? (
        <div className="assignment-grid scroll-region" tabIndex={0} aria-label="Danh sách bài tập">
          {filtered.map(function (item, index) {
            const progress = item.totalStudents
              ? Math.min(
                  100,
                  Math.round((item.submittedCount / item.totalStudents) * 100),
                )
              : 0;
            const color =
              item.status === "Sắp hết hạn"
                ? "orange"
                : item.status === "Đã kết thúc"
                  ? "gray"
                  : index % 2
                    ? "blue"
                    : "green";
            return (
              <article
                className="card assignment-card"
                key={item.id || item.title}
              >
                <div className="assignment-top">
                  <span className={"file-icon " + color}>
                    <FileText size={21} />
                  </span>
                  <em className={"pill " + color}>{item.status}</em>
                  {props.admin ? (
                    <span className="row-actions">
                      <button title="Sửa" aria-label={"Sửa bài tập " + item.title} onClick={() => props.onEdit(item)}>
                        <Pencil size={15} />
                      </button>
                      <button
                        title="Xóa"
                        aria-label={"Xóa bài tập " + item.title}
                        className="delete"
                        onClick={() => props.onDelete(item)}
                      >
                        <Trash2 size={15} />
                      </button>
                    </span>
                  ) : null}
                </div>
                <h2>{item.title}</h2>
                <p>
                  <Users size={14} />
                  {item.className}
                </p>
                <div className="due">
                  <CalendarDays size={15} />
                  <span>Hạn nộp</span>
                  <strong>
                    {new Date(item.dueDate).toLocaleString("vi-VN", {
                      dateStyle: "short",
                      timeStyle: "short",
                    })}
                  </strong>
                </div>
                <div className="submission">
                  <span>
                    Đã nộp{" "}
                    <strong>
                      {item.submittedCount}/{item.totalStudents}
                    </strong>
                  </span>
                  <i>
                    <em style={{ width: progress + "%" }} />
                  </i>
                </div>
                {(item.pendingGradingCount || 0) > 0 ? (
                  <button type="button" className="pending-grading-link" onClick={() => setDetail(item)}>
                    <Clock3 size={15} />
                    <strong>{item.pendingGradingCount}</strong> bài nộp chưa chấm đủ điểm và nhận xét
                  </button>
                ) : null}
                <footer>
                  <span>Điểm tối đa: {item.maxScore}</span>
                  <button className="text-button" onClick={() => setDetail(item)}>
                    Xem chi tiết <ChevronRight size={14} />
                  </button>
                </footer>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="card assignment-empty-state">
          <CheckCircle2 size={24} />
          <strong>{tab === "grading" ? "Đã chấm xong" : "Không có bài tập phù hợp"}</strong>
          <span>{tab === "grading" ? "Hiện không còn bài nộp nào đang chờ đủ điểm và nhận xét." : "Thử đổi trạng thái hoặc lớp đang lọc."}</span>
        </div>
      )}
      {detail ? (
        <AssignmentDetailModal
          assignment={detail}
          close={() => setDetail(null)}
          onRefresh={props.onRefresh}
        />
      ) : null}
    </>
  );
}

function normalizeGradebook(
  item: AdminItemRecord | undefined,
  fallbackClass: string,
  fallbackTerm: string,
  records: StudentRecord[],
): GradebookData {
  if (!item)
    return {
      className: fallbackClass,
      term: fallbackTerm,
      assessments: [],
      scores: {},
    };
  const data = item.data;
  let assessments: Assessment[] = [];
  const scores: Record<string, Record<string, number | null>> = {};
  if (Array.isArray(data.assessments)) {
    assessments = (data.assessments as Record<string, unknown>[]).map(
      function (value, index) {
        return {
          id: String(value.id || "assessment-" + index),
          title: String(value.title || "Bài kiểm tra " + (index + 1)),
          category: String(value.category || "Kiểm tra"),
          maxScore: Math.max(0.1, Number(value.maxScore) || 10),
          weight: Math.max(0, Number(value.weight) || 0),
          date: String(value.date || ""),
        };
      },
    );
    const raw = (data.scores || {}) as Record<
      string,
      Record<string, number | null>
    >;
    Object.keys(raw).forEach(function (code) {
      scores[code] = Object.assign({}, raw[code]);
    });
  } else {
    const labels = ["Bài 1", "Bài 2", "Giữa kỳ", "Cuối kỳ"];
    const weights = Array.isArray(data.weights)
      ? data.weights.map(Number)
      : [20, 30, 20, 30];
    assessments = labels.map(function (title, index) {
      return {
        id: "legacy-" + index,
        title,
        category: index < 2 ? "Kiểm tra" : title,
        maxScore: 10,
        weight: Number(weights[index]) || 0,
        date: "",
      };
    });
    const legacy = (data.scores || {}) as Record<string, number[]>;
    records.forEach(function (student) {
      const row = Array.isArray(legacy[student.code])
        ? legacy[student.code]
        : [];
      scores[student.code] = {};
      assessments.forEach(function (assessment, index) {
        scores[student.code][assessment.id] = Number.isFinite(
          Number(row[index]),
        )
          ? Number(row[index])
          : null;
      });
    });
  }
  return {
    classKey: String(data.classKey || ""),
    className: String(data.className || fallbackClass),
    term: String(data.term || fallbackTerm),
    assessments,
    scores,
  };
}

function normalizedGradeKey(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s*-\s*\d{4}\s*-\s*\d{4}\s*$/, "")
    .replace(/\s+/g, " ")
    .trim();
}

function AssessmentFormModal(props: {
  value: Assessment | null;
  close: () => void;
  save: (assessment: Assessment) => void;
}) {
  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    props.save({
      id: props.value?.id || "assessment-" + Date.now().toString(36),
      title: String(form.get("title") || "Bài kiểm tra"),
      category: String(form.get("category") || "Kiểm tra"),
      maxScore: Math.max(0.1, Number(form.get("maxScore")) || 10),
      weight: Math.max(0, Number(form.get("weight")) || 0),
      date: String(form.get("date") || ""),
    });
  }
  return (
    <div className="modal" onMouseDown={props.close}>
      <form
        className="form-modal compact-modal"
        onSubmit={submit}
        onMouseDown={function (event) {
          event.stopPropagation();
        }}
      >
        <div className="modal-head">
          <div>
            <h2>{props.value ? "Sửa đề mục điểm" : "Thêm bài kiểm tra"}</h2>
            <p>Tên cột, thang điểm và trọng số đều do Admin quyết định.</p>
          </div>
          <button type="button" className="modal-close" onClick={props.close}>
            <X size={19} />
          </button>
        </div>
        <div className="form-grid">
          <label className="wide">
            Tên bài kiểm tra
            <input
              name="title"
              required
              defaultValue={props.value?.title}
              placeholder="Ví dụ: Kiểm tra 15 phút số 1"
            />
          </label>
          <label>
            Loại điểm
            <select
              name="category"
              defaultValue={props.value?.category || "Kiểm tra"}
            >
              <option>Bài tập</option>
              <option>Kiểm tra 15 phút</option>
              <option>Kiểm tra 1 tiết</option>
              <option>Giữa kỳ</option>
              <option>Cuối kỳ</option>
              <option>Tùy chỉnh</option>
            </select>
          </label>
          <label>
            Ngày kiểm tra
            <input name="date" type="date" defaultValue={props.value?.date} />
          </label>
          <label>
            Điểm tối đa
            <input
              name="maxScore"
              type="number"
              min="0.1"
              step="0.1"
              required
              defaultValue={props.value?.maxScore || 10}
            />
          </label>
          <label>
            Trọng số
            <input
              name="weight"
              type="number"
              min="0"
              step="0.1"
              required
              defaultValue={props.value?.weight ?? 10}
            />
          </label>
        </div>
        <div className="modal-footer">
          <button type="button" className="button ghost" onClick={props.close}>
            Hủy
          </button>
          <button className="button primary">
            {props.value ? "Lưu đề mục" : "Thêm cột điểm"}
          </button>
        </div>
      </form>
    </div>
  );
}

function GradesView(props: {
  records: StudentRecord[];
  classes: ClassRecord[];
  items: AdminItemRecord[];
  academicYear: string;
  siteName: string;
  admin: boolean;
  onSave: (data: GradebookData) => Promise<void>;
  onDelete: (item: AdminItemRecord) => void;
  onRequireAdmin: () => void;
  notify: (text: string) => void;
}) {
  const fallbackClass = props.classes[0]?.name || "Tất cả lớp";
  const fallbackTerm = "Học kỳ I - " + props.academicYear;
  const newest = props.items.slice().sort(function (a, b) {
    return String(b.updatedAt || b.createdAt || "").localeCompare(
      String(a.updatedAt || a.createdAt || ""),
    );
  })[0];
  const initial = normalizeGradebook(
    newest,
    fallbackClass,
    fallbackTerm,
    props.records,
  );
  const [className, setClassName] = useState(initial.className);
  const [term, setTerm] = useState(initial.term);
  const [assessments, setAssessments] = useState(initial.assessments);
  const [scores, setScores] = useState(initial.scores);
  const [selectedGradebookId, setSelectedGradebookId] = useState<number | null>(
    newest?.id || null,
  );
  const [editingAssessment, setEditingAssessment] = useState<
    Assessment | null | undefined
  >(undefined);
  const roster =
    className === "Tất cả lớp"
      ? props.records
      : props.records.filter(function (student) {
          const course = props.classes.find(function(item) { return item.name === className; });
          return studentBelongsToClass(student, className, course?.key || (course?.id ? String(course.id) : undefined));
        });
  const currentItem = props.items.find(function (item) {
    return item.id === selectedGradebookId;
  });
  function loadBook(item: AdminItemRecord) {
    const book = normalizeGradebook(
      item,
      fallbackClass,
      fallbackTerm,
      props.records,
    );
    setClassName(book.className);
    setTerm(book.term);
    setAssessments(book.assessments);
    setScores(book.scores);
    setSelectedGradebookId(item.id);
  }
  function startNewBook() {
    setSelectedGradebookId(null);
    setAssessments([]);
    setScores({});
  }
  function switchClass(nextClass: string) {
    const saved = props.items.find(function (item) {
      return (
        String(item.data.className || fallbackClass) === nextClass &&
        String(item.data.term || fallbackTerm) === term
      );
    });
    if (saved) {
      loadBook(saved);
      return;
    }
    setClassName(nextClass);
    startNewBook();
  }
  function saveAssessment(assessment: Assessment) {
    setAssessments(function (items) {
      const exists = items.some(function (item) {
        return item.id === assessment.id;
      });
      return exists
        ? items.map(function (item) {
            return item.id === assessment.id ? assessment : item;
          })
        : items.concat(assessment);
    });
    setEditingAssessment(undefined);
  }
  function removeAssessment(assessment: Assessment) {
    if (!props.admin) {
      props.onRequireAdmin();
      return;
    }
    if (!window.confirm("Xóa cột điểm “" + assessment.title + "”?")) return;
    setAssessments(function (items) {
      return items.filter(function (item) {
        return item.id !== assessment.id;
      });
    });
    setScores(function (current) {
      const next: Record<string, Record<string, number | null>> = {};
      Object.keys(current).forEach(function (code) {
        next[code] = Object.assign({}, current[code]);
        delete next[code][assessment.id];
      });
      return next;
    });
  }
  function changeScore(code: string, assessment: Assessment, value: string) {
    if (!props.admin) {
      props.onRequireAdmin();
      return;
    }
    const parsed =
      value === ""
        ? null
        : Math.max(0, Math.min(assessment.maxScore, Number(value) || 0));
    setScores(function (current) {
      return Object.assign({}, current, {
        [code]: Object.assign({}, current[code] || {}, {
          [assessment.id]: parsed,
        }),
      });
    });
  }
  function averageFor(code: string) {
    let sum = 0,
      total = 0;
    assessments.forEach(function (assessment) {
      const score = scores[code]?.[assessment.id];
      if (score !== null && score !== undefined) {
        sum += (Number(score) / assessment.maxScore) * 10 * assessment.weight;
        total += assessment.weight;
      }
    });
    return total ? sum / total : null;
  }
  function exportExcel() {
    const rows = roster.map(function (student) {
      const row: Record<string, unknown> = {
        "Mã học sinh": student.code,
        "Họ tên": student.name,
        Lớp: (student.classNames || [student.className]).join(", "),
      };
      assessments.forEach(function (assessment) {
        row[assessment.title + " / " + assessment.maxScore] =
          scores[student.code]?.[assessment.id] ?? "";
      });
      row["Trung bình / 10"] = averageFor(student.code)?.toFixed(1) || "";
      return row;
    });
    const sheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "Sổ điểm");
    XLSX.writeFile(
      workbook,
      props.siteName.replace(/[^a-zA-Z0-9À-ỹ]+/g, "_") +
        "_So_diem_" +
        className.replace(/[^a-zA-Z0-9À-ỹ]+/g, "_") +
        ".xlsx",
    );
    props.notify("Đã xuất sổ điểm Excel");
  }
  const weightTotal = assessments.reduce(function (total, item) {
    return total + item.weight;
  }, 0);
  return (
    <>
      <PageTitle title="Sổ điểm linh hoạt" subtitle={term + " · " + className}>
        <button className="button ghost" onClick={exportExcel}>
          <Download size={17} />
          Xuất Excel
        </button>
        {currentItem && props.admin ? (
          <button
            className="button danger"
            onClick={() => props.onDelete(currentItem)}
          >
            <Trash2 size={17} />
            Xóa sổ
          </button>
        ) : null}
        <button
          className="button soft"
          onClick={() =>
            props.admin ? setEditingAssessment(null) : props.onRequireAdmin()
          }
        >
          <Plus size={17} />
          Thêm bài kiểm tra
        </button>
        <button
          className="button primary"
          onClick={() =>
            props.admin
              ? props.onSave({ classKey: props.classes.find(function (item) { return item.name === className; })?.key, className, term, assessments, scores })
              : props.onRequireAdmin()
          }
        >
          <Check size={17} />
          Lưu sổ điểm
        </button>
      </PageTitle>
      <div className={props.admin ? "admin-strip active" : "admin-strip"}>
        <ShieldCheck size={17} />
        <span>
          {props.admin
            ? "Admin có thể thêm, đổi tên, chỉnh thang điểm, trọng số và nhập điểm trực tiếp."
            : "Đăng nhập Admin để chỉnh sửa sổ điểm."}
        </span>
      </div>
      <div className="card grade-toolbar">
        <label>
          <small>Lớp học</small>
          <select
            value={className}
            onChange={function (event) {
              switchClass(event.target.value);
            }}
          >
            <option>Tất cả lớp</option>
            {props.classes.map(function (item) {
              return <option key={item.id || item.name}>{item.name}</option>;
            })}
          </select>
        </label>
        <label>
          <small>Học kỳ / năm học</small>
          <input
            value={term}
            readOnly={!props.admin}
            onChange={function (event) {
              setTerm(event.target.value);
              setSelectedGradebookId(null);
            }}
          />
        </label>
        <label>
          <small>Mở sổ đã lưu</small>
          <select
            value={currentItem?.id || ""}
            onChange={function (event) {
              const item = props.items.find(function (value) {
                return value.id === Number(event.target.value);
              });
              if (item) loadBook(item);
              else startNewBook();
            }}
          >
            <option value="">Tạo sổ mới (chưa lưu)</option>
            {props.items.map(function (item) {
              return (
                <option key={item.id} value={item.id}>
                  {item.title}
                </option>
              );
            })}
          </select>
        </label>
        <div>
          <small>Tổng trọng số</small>
          <strong>{weightTotal}</strong>
        </div>
      </div>
      <div className="card grade-wrap">
        {assessments.length ? (
          <table className="dynamic-grade-table">
          <thead>
            <tr>
              <th className="grade-student">Học sinh</th>
              {assessments.map(function (assessment) {
                return (
                  <th className="grade-assessment" key={assessment.id}>
                    <div className="assessment-head">
                      <strong>{assessment.title}</strong>
                      <small>
                        {assessment.category} · /{assessment.maxScore} · trọng
                        số {assessment.weight}
                      </small>
                      {assessment.date ? (
                        <small>
                          {new Date(
                            assessment.date + "T00:00:00",
                          ).toLocaleDateString("vi-VN")}
                        </small>
                      ) : null}
                      {props.admin ? (
                        <span>
                          <button
                            title="Sửa cột điểm"
                            onClick={() => setEditingAssessment(assessment)}
                          >
                            <Pencil size={13} />
                          </button>
                          <button
                            title="Xóa cột điểm"
                            onClick={() => removeAssessment(assessment)}
                          >
                            <Trash2 size={13} />
                          </button>
                        </span>
                      ) : null}
                    </div>
                  </th>
                );
              })}
              <th className="grade-average">Trung bình</th>
              <th className="grade-classification">Xếp loại</th>
            </tr>
          </thead>
          <tbody>
            {roster.map(function (student) {
              const average = averageFor(student.code);
              return (
                <tr key={student.code}>
                  <td className="grade-student">
                    <span className="student-name">
                      <Avatar initials={student.initials} tone={student.tone} />
                      <p>
                        <strong>{student.name}</strong>
                        <small>{student.code}</small>
                      </p>
                    </span>
                  </td>
                  {assessments.map(function (assessment) {
                    const value = scores[student.code]?.[assessment.id];
                    return (
                      <td className="grade-assessment" key={assessment.id}>
                        <input
                          className="grade-input"
                          aria-label={assessment.title + " của " + student.name}
                          type="number"
                          min="0"
                          max={assessment.maxScore}
                          step="0.1"
                          value={value ?? ""}
                          readOnly={!props.admin}
                          placeholder="—"
                          onChange={function (event) {
                            changeScore(
                              student.code,
                              assessment,
                              event.target.value,
                            );
                          }}
                        />
                        <small className="max-score">
                          /{assessment.maxScore}
                        </small>
                      </td>
                    );
                  })}
                  <td
                    className={
                      "grade-average " +
                      (average !== null && average < 6
                        ? "score-low"
                        : "score-good")
                    }
                  >
                    {average === null ? "—" : average.toFixed(1)}
                  </td>
                  <td className="grade-classification">
                    <em
                      className={
                        average !== null && average < 5
                          ? "pill red"
                          : "pill green"
                      }
                    >
                      {average === null
                        ? "Chưa có điểm"
                        : average >= 8
                          ? "Tốt"
                          : average >= 6.5
                            ? "Khá"
                            : average >= 5
                              ? "Trung bình"
                              : "Cần cải thiện"}
                    </em>
                  </td>
                </tr>
              );
            })}
          </tbody>
          </table>
        ) : (
          <div className="grade-empty-layout">
            <section className="grade-empty-roster">
              <header>Học sinh</header>
              {roster.map(function (student) {
                return (
                  <div key={student.code}>
                    <Avatar initials={student.initials} tone={student.tone} />
                    <p>
                      <strong>{student.name}</strong>
                      <small>{student.code}</small>
                    </p>
                  </div>
                );
              })}
            </section>
            <div className="grade-empty">
              <span>
                <BarChart3 size={28} />
              </span>
              <h2>Chưa có đề mục điểm</h2>
              <p>Admin chọn “Thêm bài kiểm tra” để tạo cột điểm đầu tiên.</p>
              <button
                className="button primary"
                onClick={() =>
                  props.admin
                    ? setEditingAssessment(null)
                    : props.onRequireAdmin()
                }
              >
                <Plus size={16} />
                Thêm bài kiểm tra
              </button>
            </div>
          </div>
        )}
      </div>
      {editingAssessment !== undefined ? (
        <AssessmentFormModal
          key={editingAssessment?.id || "new"}
          value={editingAssessment}
          close={() => setEditingAssessment(undefined)}
          save={saveAssessment}
        />
      ) : null}
    </>
  );
}

function AnalyticsView(props: {
  students: StudentRecord[];
  classes: ClassRecord[];
  assignments: AssignmentRecord[];
  attendanceItems: AdminItemRecord[];
  gradeItems: AdminItemRecord[];
  onExportPdf: () => void;
  go: (view: View) => void;
}) {
  const gradedStudents = props.students.filter(function (student) {
    return student.hasGrades;
  });
  const average = gradedStudents.length
    ? gradedStudents.reduce(function (total, student) {
        return total + student.avg;
      }, 0) / gradedStudents.length
    : 0;
  const bins = [
    {
      label: "Dưới 5",
      color: "red",
      count: gradedStudents.filter(function (student) {
        return student.avg < 5;
      }).length,
    },
    {
      label: "5 – 6.4",
      color: "orange",
      count: gradedStudents.filter(function (student) {
        return student.avg >= 5 && student.avg < 6.5;
      }).length,
    },
    {
      label: "6.5 – 7.9",
      color: "blue",
      count: gradedStudents.filter(function (student) {
        return student.avg >= 6.5 && student.avg < 8;
      }).length,
    },
    {
      label: "8 – 8.9",
      color: "indigo",
      count: gradedStudents.filter(function (student) {
        return student.avg >= 8 && student.avg < 9;
      }).length,
    },
    {
      label: "9 – 10",
      color: "green",
      count: gradedStudents.filter(function (student) {
        return student.avg >= 9;
      }).length,
    },
  ];
  const maxBin = Math.max(
    1,
    ...bins.map(function (bin) {
      return bin.count;
    }),
  );
  const topStudent = gradedStudents.slice().sort(function (a, b) {
    return b.avg - a.avg;
  })[0];
  const classResults = props.classes
    .filter(function (item) {
      return item.hasGrades;
    })
    .map(function (item) {
      return {
        name: item.name,
        average: item.average,
        count: item.studentCount,
      };
    })
    .sort(function (a, b) {
      return b.average - a.average;
    });
  const bestClass = classResults[0];
  const pendingSubmissions = props.assignments.reduce(function (total, item) {
    return total + Math.max(0, item.totalStudents - item.submittedCount);
  }, 0);
  const assessmentCount = props.gradeItems.reduce(function (total, item) {
    return (
      total +
      (Array.isArray(item.data.assessments) ? item.data.assessments.length : 4)
    );
  }, 0);
  const latestAttendanceDate =
    props.attendanceItems
      .map(function (item) {
        return String(item.data.date || "");
      })
      .sort()
      .reverse()[0] || "";
  const latestAttendance: Record<string, string> = {};
  props.attendanceItems
    .filter(function (item) {
      return String(item.data.date || "") === latestAttendanceDate;
    })
    .sort(function (a, b) {
      return String(a.updatedAt || a.createdAt || "").localeCompare(
        String(b.updatedAt || b.createdAt || ""),
      );
    })
    .forEach(function (item) {
      Object.assign(
        latestAttendance,
        (item.data.states || {}) as Record<string, string>,
      );
    });
  const markedCodes = Object.keys(latestAttendance);
  const attended = markedCodes.filter(function (code) {
    return (
      latestAttendance[code] === "present" || latestAttendance[code] === "late"
    );
  }).length;
  const attendedStudents = props.students.filter(function (student) {
    return student.hasAttendance;
  });
  const attendanceRate = markedCodes.length
    ? Math.round((attended / markedCodes.length) * 100)
    : attendedStudents.length
      ? Math.round(
          attendedStudents.reduce(function (total, student) {
            return total + student.attendance;
          }, 0) / attendedStudents.length,
        )
      : 0;
  const alerts: {
    level: "high" | "medium";
    text: string;
    target: View;
    action: string;
  }[] = [];
  props.students.forEach(function (student) {
    const reasons: string[] = [];
    if (student.hasGrades && student.avg < 5)
      reasons.push("điểm trung bình chỉ " + student.avg);
    else if (student.hasGrades && student.avg < 6)
      reasons.push("điểm trung bình " + student.avg);
    if (student.hasAttendance && student.attendance < 80)
      reasons.push("chuyên cần " + student.attendance + "%");
    if (student.state === "Cần chú ý" && !reasons.length)
      reasons.push("đang ở trạng thái cần chú ý");
    if (reasons.length)
      alerts.push({
        level:
          (student.hasGrades && student.avg < 5) ||
          (student.hasAttendance && student.attendance < 70)
            ? "high"
            : "medium",
        text: student.name + " có " + reasons.join(" và ") + ".",
        target: "students",
        action: "Xem học sinh",
      });
  });
  props.assignments.forEach(function (item) {
    const missing = Math.max(0, item.totalStudents - item.submittedCount);
    if (missing > 0)
      alerts.push({
        level: item.status === "Sắp hết hạn" ? "high" : "medium",
        text: "“" + item.title + "” còn " + missing + " học sinh chưa nộp.",
        target: "assignments",
        action: "Xem bài tập",
      });
  });
  markedCodes
    .filter(function (code) {
      return latestAttendance[code] === "absent";
    })
    .forEach(function (code) {
      const student = props.students.find(function (item) {
        return item.code === code;
      });
      if (student)
        alerts.push({
          level: "high",
          text:
            student.name + " vắng không phép trong buổi điểm danh gần nhất.",
          target: "attendance",
          action: "Xem điểm danh",
        });
    });
  const insight = !props.students.length
    ? "Chưa có học sinh để phân tích. Khi Admin thêm dữ liệu, báo cáo này sẽ tự cập nhật."
    : "Hiện có " +
      props.students.length +
      " học sinh" +
      (gradedStudents.length
        ? ", điểm trung bình từ sổ điểm là " + average.toFixed(1)
        : " nhưng chưa có điểm đã lưu") +
      ". " +
      (bestClass
        ? bestClass.name +
          " đang có kết quả cao nhất (" +
          bestClass.average.toFixed(1) +
          "). "
        : "") +
      (alerts.length
        ? alerts.length + " cảnh báo cần theo dõi."
        : "Chưa phát hiện cảnh báo cần ưu tiên.");
  return (
    <>
      <PageTitle
        title="Thống kê & Phân tích"
        subtitle="Số liệu được tính trực tiếp từ các tab quản lý và cập nhật sau mỗi lần lưu."
      >
        <button className="button ghost" onClick={props.onExportPdf}>
          <Download size={17} />
          Tải báo cáo PDF
        </button>
      </PageTitle>
      <div className="summary-grid analytics-summary">
        {[
          [
            "students",
            "Tổng học sinh",
            String(props.students.length),
            GraduationCap,
          ],
          [
            "score",
            "Điểm trung bình",
            gradedStudents.length ? average.toFixed(1) : "—",
            BarChart3,
          ],
          [
            "attendance",
            "Chuyên cần",
            markedCodes.length || attendedStudents.length
              ? attendanceRate + "%"
              : "—",
            ClipboardCheck,
          ],
          ["pending", "Lượt chưa nộp", String(pendingSubmissions), NotebookPen],
        ].map(function (item) {
          const Icon = item[3] as typeof GraduationCap;
          return (
            <div className="card" key={item[0] as string}>
              <span
                className={
                  "summary-icon " +
                  (item[0] === "pending"
                    ? "late"
                    : item[0] === "attendance"
                      ? "present"
                      : "allowed")
                }
              >
                <Icon size={18} />
              </span>
              <p>
                <strong>{item[2] as string}</strong>
                <small>{item[1] as string}</small>
              </p>
            </div>
          );
        })}
      </div>
      <div className="ai-insight">
        <Sparkles size={20} />
        <p>
          <strong>Nhận định tự động từ dữ liệu hiện tại</strong>
          <span>{insight}</span>
        </p>
        <button
          onClick={() =>
            props.go(alerts.length ? alerts[0].target : "students")
          }
        >
          {alerts.length ? "Xử lý cảnh báo" : "Xem học sinh"}
          <ChevronRight size={14} />
        </button>
      </div>
      <div className="analytics-grid">
        <article className="card panel">
          <div className="card-head">
            <div>
              <h2>Phân bố kết quả học tập</h2>
              <p>
                {gradedStudents.length} học sinh đã có điểm · cập nhật từ sổ
                điểm
              </p>
            </div>
          </div>
          <div className="bar-chart">
            {bins.map(function (bin) {
              const height = bin.count
                ? Math.max(8, Math.round((bin.count / maxBin) * 100))
                : 0;
              return (
                <div key={bin.label}>
                  <b>{bin.count}</b>
                  <i>
                    <em
                      className={bin.color}
                      style={{ height: height + "%" }}
                    />
                  </i>
                  <span>{bin.label}</span>
                </div>
              );
            })}
          </div>
        </article>
        <article className="card panel highlights">
          <h2>Điểm nổi bật</h2>
          <div>
            <TrendingUp />
            <p>
              Học sinh có điểm cao nhất
              <strong>
                {topStudent
                  ? topStudent.name + " · " + topStudent.avg.toFixed(1)
                  : "Chưa có điểm đã lưu"}
              </strong>
            </p>
          </div>
          <div>
            <BarChart3 />
            <p>
              Lớp có điểm cao nhất
              <strong>
                {bestClass
                  ? bestClass.name +
                    " · " +
                    bestClass.average.toFixed(1) +
                    " điểm"
                  : "Chưa có điểm theo lớp"}
              </strong>
            </p>
          </div>
          <div>
            <NotebookPen />
            <p>
              Tiến độ học tập
              <strong>
                {pendingSubmissions +
                  " lượt chưa nộp · " +
                  assessmentCount +
                  " đề mục điểm"}
              </strong>
            </p>
          </div>
        </article>
      </div>
      <div className="card alerts">
        <div className="card-head">
          <div>
            <h2>Cảnh báo thông minh</h2>
            <p>
              Tự động tạo từ điểm, chuyên cần, điểm danh và bài tập hiện tại
            </p>
          </div>
          <span className="count">{alerts.length}</span>
        </div>
        {alerts.map(function (alert, index) {
          return (
            <div key={alert.text + index}>
              <em className={alert.level}>
                {alert.level === "high" ? "Cao" : "Vừa"}
              </em>
              <p>{alert.text}</p>
              <button
                className="text-button"
                onClick={() => props.go(alert.target)}
              >
                {alert.action}
                <ChevronRight size={14} />
              </button>
            </div>
          );
        })}
        {!alerts.length ? (
          <div className="analytics-empty">
            <CheckCircle2 size={20} />
            <p>Không có cảnh báo nào từ dữ liệu hiện tại.</p>
          </div>
        ) : null}
      </div>
      <StudentEngagementStats
        classes={props.classes.map(function(item) {
          return { key: item.key || String(item.id || item.name), name: item.name };
        })}
      />
    </>
  );
}

function CalendarView(props: {
  items: AdminItemRecord[];
  classes: ClassRecord[];
  admin: boolean;
  onAdd: () => void;
  onDelete: (item: AdminItemRecord) => void;
}) {
  const today = localDateInTimeZone();
  const [month, setMonth] = useState(today.slice(0, 7));
  const [classKey, setClassKey] = useState(function () {
    const first = props.classes[0];
    return first ? first.key || String(first.id || first.name) : "";
  });
  const [stackIndexes, setStackIndexes] = useState<Record<string, number>>({});
  useEffect(function () {
    if (classKey || !props.classes.length) return;
    const first = props.classes[0];
    const timer = window.setTimeout(function() { setClassKey(first.key || String(first.id || first.name)); }, 0);
    return function() { window.clearTimeout(timer); };
  }, [classKey, props.classes]);
  const showAllClasses = classKey === ALL_CLASSES_ID;
  const selectedClass = showAllClasses ? undefined : (
    props.classes.find(function (item) {
      return (item.key || String(item.id || item.name)) === classKey;
    }) || props.classes[0]
  );
  const monthDate = new Date(month + "-01T00:00:00");
  const year = monthDate.getFullYear();
  const monthIndex = monthDate.getMonth();
  const firstOffset = (monthDate.getDay() + 6) % 7;
  const dayCount = new Date(year, monthIndex + 1, 0).getDate();
  const cells = Array.from(
    { length: Math.ceil((firstOffset + dayCount) / 7) * 7 },
    function (_, index) {
      const day = index - firstOffset + 1;
      return day > 0 && day <= dayCount ? day : null;
    },
  );
  const monthLabel = monthDate.toLocaleDateString("vi-VN", {
    month: "long",
    year: "numeric",
  });
  function move(delta: number) {
    const next = new Date(year, monthIndex + delta, 1);
    setMonth(
      next.getFullYear() + "-" + String(next.getMonth() + 1).padStart(2, "0"),
    );
  }
  function dateFor(item: AdminItemRecord) {
    const explicit = String(item.data.date || "").slice(0, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(explicit)) return explicit;
    const legacyDay = Number(item.data.day);
    if (!Number.isInteger(legacyDay) || legacyDay < 1 || legacyDay > 31) return "";
    const legacyTimestamp = String(item.createdAt || item.updatedAt || "");
    const timestampDate = new Date(legacyTimestamp);
    if (!legacyTimestamp || !Number.isFinite(timestampDate.getTime())) return "";
    return localDateInTimeZone(timestampDate).slice(0, 7) + "-" + String(legacyDay).padStart(2, "0");
  }
  const classItems = props.items.filter(function (item) {
    const itemClassKey = String(item.data.classKey || "");
    const itemClassName = String(item.data.className || "");
    if (showAllClasses) return props.classes.some(function(course) {
      const selectedKey = course.key || String(course.id || course.name);
      return itemClassKey === selectedKey || (!itemClassKey && itemClassName === course.name);
    });
    if (!selectedClass) return false;
    const selectedKey = selectedClass.key || String(selectedClass.id || selectedClass.name);
    return itemClassKey === selectedKey || (!itemClassKey && itemClassName === selectedClass.name);
  });
  function classLabelFor(item: AdminItemRecord) {
    const itemClassKey = String(item.data.classKey || "");
    const itemClassName = String(item.data.className || "");
    return props.classes.find(function(course) { return (course.key || String(course.id || course.name)) === itemClassKey; })?.name || itemClassName || "Chưa rõ lớp";
  }
  function cycleTestStack(stackKey: string, count: number) {
    if (count < 2) return;
    setStackIndexes(function(current) { return { ...current, [stackKey]: ((current[stackKey] || 0) + 1) % count }; });
  }
  return (
    <>
      <PageTitle
        title="Lịch kiểm tra"
        subtitle={
          showAllClasses
            ? "Tất cả lịch kiểm tra · " + monthLabel
            : selectedClass
              ? "Lịch kiểm tra riêng của " + selectedClass.name + " · " + monthLabel
              : "Tạo lớp trước khi thêm lịch kiểm tra."
        }
      >
        <button
          className="button primary"
          onClick={props.onAdd}
          disabled={!props.classes.length}
        >
          <Plus size={17} />
          Tạo lịch kiểm tra
        </button>
      </PageTitle>
      <section className="card test-calendar-shell">
        <header className="test-calendar-toolbar">
          <label>
            <span>Lớp</span>
            <select
              value={classKey}
              onChange={function (event) {
                setClassKey(event.target.value);
              }}
            >
              <option value={ALL_CLASSES_ID}>Tất cả lịch kiểm tra</option>
              {props.classes.map(function (item) {
                const key = item.key || String(item.id || item.name);
                return (
                  <option key={key} value={key}>
                    {item.name}
                  </option>
                );
              })}
            </select>
          </label>
          <div className="calendar-nav taste-calendar-nav">
            <button className="icon-button" onClick={() => move(-1)} aria-label="Tháng trước">
              <ChevronLeft />
            </button>
            <strong>{monthLabel}</strong>
            <button className="icon-button" onClick={() => move(1)} aria-label="Tháng sau">
              <ChevronRight />
            </button>
            <button
              className="button soft"
              onClick={() => setMonth(today.slice(0, 7))}
            >
              Hôm nay
            </button>
          </div>
        </header>
        <div className="test-calendar-scroll" tabIndex={0} aria-label="Lịch kiểm tra theo tháng">
          <div className="calendar-grid test-calendar-grid">
            {["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map(function (day) {
              return <strong key={day}>{day}</strong>;
            })}
            {cells.map(function (day, index) {
              const key = day ? month + "-" + String(day).padStart(2, "0") : "";
              const events = day
                ? classItems.filter(function (item) {
                    return dateFor(item).slice(0, 10) === key;
                  }).sort(function(a, b) { return String(a.data.time || "").localeCompare(String(b.data.time || "")); })
                : [];
              const eventGroups = events.reduce(function(groups, event) {
                const time = String(event.data.time || "Chưa đặt giờ");
                const group = groups.find(function(item) { return item.time === time; });
                if (group) group.items.push(event); else groups.push({ time, items: [event] });
                return groups;
              }, [] as Array<{ time: string; items: AdminItemRecord[] }>);
              return (
                <div
                  className={
                    (!day ? "muted " : "") + (key === today ? "today" : "")
                  }
                  key={index}
                >
                  {day ? <span>{day}</span> : null}
                  {eventGroups.slice(0, 3).map(function (group) {
                    const stackKey = key + "|" + group.time;
                    const activeIndex = (stackIndexes[stackKey] || 0) % group.items.length;
                    const event = group.items[activeIndex];
                    return (
                      <article
                        className={"test-calendar-event" + (group.items.length > 1 ? " stacked" : "")}
                        key={stackKey}
                        title={String(event.data.details || "")}
                        onClick={function() { cycleTestStack(stackKey, group.items.length); }}
                        onDoubleClick={() => props.admin && props.onDelete(event)}
                      >
                        <time>{group.time}{showAllClasses ? " · " + classLabelFor(event) : ""}</time>
                        <strong>{event.title}</strong>
                        {group.items.length > 1 ? <b className="test-calendar-stack-count">{activeIndex + 1}/{group.items.length}</b> : null}
                      </article>
                    );
                  })}
                  {eventGroups.length > 3 ? <small className="test-calendar-more">+{eventGroups.length - 3} khung giờ khác</small> : null}
                </div>
              );
            })}
          </div>
        </div>
      </section>
      <section className="card event-list test-event-list">
        <div className="card-head">
          <div>
            <h2>Lịch kiểm tra đã tạo</h2>
            <p>
              {showAllClasses ? "Đang hiển thị lịch kiểm tra của tất cả lớp." : "Chỉ học sinh thuộc " + (selectedClass?.name || "lớp đang chọn") + " mới nhận lịch kiểm tra này."}
            </p>
          </div>
          <span className="count">{classItems.length}</span>
        </div>
        {classItems
          .slice()
          .sort(function (a, b) {
            return (dateFor(a) + String(a.data.time || "")).localeCompare(
              dateFor(b) + String(b.data.time || ""),
            );
          })
          .map(function (item) {
            return (
              <div key={item.id}>
                <span className="file-icon blue">
                  <CalendarDays size={18} />
                </span>
                <p>
                  <strong>{item.title}</strong>
                  <small>
                    {dateFor(item)
                      ? new Date(dateFor(item) + "T00:00:00").toLocaleDateString("vi-VN")
                      : "Chưa có ngày"}{" "}
                    · {String(item.data.time || "Chưa đặt giờ")}{showAllClasses ? " · " + classLabelFor(item) : ""}
                  </small>
                  {item.data.details ? <small>{String(item.data.details)}</small> : null}
                </p>
                {props.admin ? (
                  <button
                    className="icon-button delete"
                    title="Xóa lịch kiểm tra"
                    onClick={() => props.onDelete(item)}
                  >
                    <Trash2 size={16} />
                  </button>
                ) : null}
              </div>
            );
          })}
        {!classItems.length ? (
          <div className="empty-row test-calendar-empty">
            <CalendarDays />
            <span>{showAllClasses ? "Chưa có lịch kiểm tra nào." : "Chưa có lịch kiểm tra cho lớp này."}</span>
          </div>
        ) : null}
      </section>
    </>
  );
}

function DocumentsView(props: {
  documents: DocumentRecord[];
  folders: AdminItemRecord[];
  classes: ClassRecord[];
  admin: boolean;
  onUpload: (
    file: File,
    folder: string,
    onProgress: (progress: number) => void,
  ) => Promise<void>;
  onDelete: (document: DocumentRecord) => void;
  onCreateFolder: () => void;
  onDeleteFolder: (folderName: string, folderItem?: AdminItemRecord) => Promise<void>;
  onRequireAdmin: () => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [folder, setFolder] = useState("Tài liệu chung");
  const [uploadTasks, setUploadTasks] = useState<DocumentUploadTask[]>([]);
  const [uploadsOpen, setUploadsOpen] = useState(false);
  const [viewerTarget, setViewerTarget] = useState<FileViewerTarget | null>(null);
  const maxFileSize = 10 * 1024 * 1024;
  const hiddenClassFolders = new Set(
    props.folders.filter(function (item) {
      return item.data.hidden === true && item.data.linkedClass === true;
    }).map(function (item) {
      return String(item.data.className || item.title);
    }),
  );
  const visibleFolderRecords = props.folders.filter(function (item) {
    return item.data.hidden !== true;
  });
  const folderNames = Array.from(new Set(
    ["Tài liệu chung"]
      .concat(props.classes.map(function (item) { return item.name; }).filter(function (name) { return !hiddenClassFolders.has(name); }))
      .concat(visibleFolderRecords.map(function (item) { return item.title; })),
  ));
  const effectiveFolder = folderNames.includes(folder) ? folder : "Tài liệu chung";
  const visibleDocuments = props.documents.filter(function (document) {
    return document.folder === effectiveFolder;
  });
  function updateUpload(id: string, patch: Partial<DocumentUploadTask>) {
    setUploadTasks(function (current) {
      return current.map(function (task) {
        return task.id === id ? { ...task, ...patch } : task;
      });
    });
  }
  async function runUpload(task: DocumentUploadTask) {
    updateUpload(task.id, { status: "uploading", progress: 0, error: "" });
    try {
      await props.onUpload(task.file, task.folder, function (progress) {
        updateUpload(task.id, { progress });
      });
      updateUpload(task.id, { status: "success", progress: 100 });
    } catch (error) {
      updateUpload(task.id, {
        status: "error",
        error: error instanceof Error ? error.message : "Không thể tải tài liệu.",
      });
    }
  }
  async function queueUploads(files: File[]) {
    const tasks = files.map(function (file) {
      const tooLarge = file.size > maxFileSize;
      return {
        id: crypto.randomUUID(),
        file,
        folder: effectiveFolder,
        progress: 0,
        status: tooLarge ? "error" : "queued",
        error: tooLarge ? "Tệp vượt quá giới hạn 10 MB." : "",
      } as DocumentUploadTask;
    });
    setUploadTasks(tasks);
    setUploadsOpen(true);
    const pending = tasks.filter(function (task) {
      return task.status === "queued";
    });
    let next = 0;
    async function worker() {
      while (next < pending.length) {
        const task = pending[next++];
        await runUpload(task);
      }
    }
    await Promise.all(
      Array.from({ length: Math.min(3, pending.length) }, function () {
        return worker();
      }),
    );
  }
  function formatSize(size: number) {
    if (size >= 1024 * 1024) return (size / 1024 / 1024).toFixed(1) + " MB";
    if (size >= 1024) return Math.round(size / 1024) + " KB";
    return size + " B";
  }
  return (
    <>
      <PageTitle
        title="Tài liệu học tập"
        subtitle="Lưu trữ và chia sẻ tài liệu theo lớp, chủ đề."
      >
        <button
          className="button ghost"
          onClick={props.admin ? props.onCreateFolder : props.onRequireAdmin}
        >
          <Plus size={17} />
          Tạo thư mục
        </button>
        <input
          ref={input}
          hidden
          type="file"
          multiple
          accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,image/*,video/*"
          onChange={async function (event) {
            const files = Array.from(event.target.files || []);
            if (files.length) await queueUploads(files);
            event.currentTarget.value = "";
          }}
        />
        <button
          className="button primary"
          onClick={() =>
            props.admin ? input.current?.click() : props.onRequireAdmin()
          }
        >
          <Upload size={17} />
          Tải nhiều tài liệu
        </button>
      </PageTitle>
      <div className="card toolbar">
        <label>
          <FolderOpen size={17} />
          <select
            value={effectiveFolder}
            onChange={function (event) {
              setFolder(event.target.value);
            }}
          >
            {folderNames.map(function (name) {
              return <option key={name}>{name}</option>;
            })}
          </select>
        </label>
        <span />
        <small>Tối đa 10 MB/tệp · tải đồng thời 3 tệp</small>
      </div>
      <div className="folder-grid">
        {folderNames.map(function (name) {
          const count = props.documents.filter(function (document) {
            return document.folder === name;
          }).length;
          const item = visibleFolderRecords.find(function (record) {
            return record.title === name;
          });
          return (
            <div className={effectiveFolder === name ? "card folder active" : "card folder"} key={name} role="button" tabIndex={0} onClick={function () { setFolder(name); }} onKeyDown={function (event) { if (event.key === "Enter" || event.key === " ") setFolder(name); }}>
              <FolderOpen size={26} />
              <p>
                <strong>{name}</strong>
                <small>{count} tài liệu</small>
              </p>
              {props.admin && name !== "Tài liệu chung" ? (
                <button className="icon-button delete folder-delete" title={"Xóa thư mục " + name} onClick={function (event) { event.stopPropagation(); void props.onDeleteFolder(name, item); }}><Trash2 size={15} /></button>
              ) : null}
            </div>
          );
        })}
      </div>
      <div className="card files">
        <div className="card-head">
          <div>
            <h2>Tệp đã tải lên</h2>
            <p>Dữ liệu được lưu bền vững trên kho tệp của website.</p>
          </div>
        </div>
        {visibleDocuments.map(function (file, index) {
          const url = "/api/documents/" + file.id;
          const previewable = file.contentType === "application/pdf" || file.contentType.startsWith("image/") || /\.(?:pdf|jpe?g|png|webp)$/i.test(file.name);
          return (
            <div key={file.id}>
              <span className={"file-icon file-" + (index % 4)}>
                <FileText size={19} />
              </span>
              <p>
                <strong title={file.name}>{file.name}</strong>
                <small>
                  {file.folder} · {formatSize(file.size)}
                </small>
              </p>
              <span>
                {new Date(file.createdAt).toLocaleDateString("vi-VN")}
              </span>
              {previewable ? <button type="button" className="icon-button" title="Xem" onClick={function() { setViewerTarget({ name: file.name, url, contentType: file.contentType, viewMode: "continuous" }); }}><Eye size={17} /></button> : null}
              <a className="icon-button" href={url + "?download=1"} title="Tải xuống"><Download size={17} /></a>
              {props.admin ? (
                <button
                  className="icon-button delete"
                  title="Xóa"
                  onClick={() => props.onDelete(file)}
                >
                  <Trash2 size={17} />
                </button>
              ) : null}
            </div>
          );
        })}
        {!visibleDocuments.length ? (
          <div className="empty-row">
            <FileText size={22} />
            <span>Chưa có tài liệu trong thư mục “{effectiveFolder}”.</span>
          </div>
        ) : null}
      </div>
      {uploadsOpen && uploadTasks.length ? (
        <aside className="upload-status-panel" aria-live="polite">
          <header>
            <div>
              <strong>Đang tải tài liệu</strong>
              <small>
                {uploadTasks.filter((task) => task.status === "success").length}/
                {uploadTasks.length} tệp hoàn tất
              </small>
            </div>
            <button
              className="icon-button"
              title="Đóng bảng trạng thái"
              onClick={() => setUploadsOpen(false)}
            >
              <X size={17} />
            </button>
          </header>
          <div className="upload-status-list">
            {uploadTasks.map(function (task) {
              return (
                <div className={"upload-status-item " + task.status} key={task.id}>
                  <span className="upload-state-icon">
                    {task.status === "success" ? (
                      <CheckCircle2 size={18} />
                    ) : task.status === "error" ? (
                      <AlertTriangle size={18} />
                    ) : (
                      <Upload size={18} />
                    )}
                  </span>
                  <div>
                    <strong title={task.file.name}>{task.file.name}</strong>
                    <small>
                      {formatSize(task.file.size)} · {task.status === "queued"
                        ? "Đang chờ"
                        : task.status === "uploading"
                          ? task.progress + "%"
                          : task.status === "success"
                            ? "Hoàn tất"
                            : task.error}
                    </small>
                    <span className="upload-progress-track">
                      <i style={{ width: task.progress + "%" }} />
                    </span>
                  </div>
                  {task.status === "error" && task.file.size <= maxFileSize ? (
                    <button
                      className="upload-retry"
                      onClick={() => void runUpload(task)}
                    >
                      Thử lại
                    </button>
                  ) : null}
                </div>
              );
            })}
          </div>
          <footer>
            {uploadTasks.some(
              (task) => task.status === "queued" || task.status === "uploading",
            )
              ? "Vui lòng giữ trang mở cho đến khi tải xong."
              : "Đã xử lý xong danh sách."}
          </footer>
        </aside>
      ) : null}
      <FileViewerModal target={viewerTarget} close={function() { setViewerTarget(null); }} />
    </>
  );
}

// Retained for backward-compatible simple content modes that may be restored.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function SimpleView(props: {
  view: View;
  items: AdminItemRecord[];
  admin: boolean;
  onAdd: () => void;
  onDelete: (item: AdminItemRecord) => void;
}) {
  const content: Record<string, string[]> = {
    notifications: [
      "Trung tâm thông báo",
      "Gửi thông báo đến học sinh, lớp học hoặc phụ huynh.",
    ],
    notes: [
      "Ghi chú giáo viên",
      "Lưu quan sát và nội dung cần trao đổi về từng học sinh.",
    ],
    settings: [
      "Cài đặt hệ thống",
      "Thiết lập hồ sơ, phân quyền và tùy chọn cho trung tâm.",
    ],
  };
  const item = content[props.view];
  return (
    <>
      <PageTitle title={item[0]} subtitle={item[1]}>
        <button className="button primary" onClick={props.onAdd}>
          <Plus size={17} />
          {props.view === "settings" ? "Thêm cấu hình" : "Thêm mới"}
        </button>
      </PageTitle>
      <div className={props.admin ? "admin-strip active" : "admin-strip"}>
        <ShieldCheck size={17} />
        <span>
          {props.admin
            ? "Các thay đổi sẽ được lưu vào hệ thống."
            : "Đăng nhập Admin để thêm hoặc xóa nội dung."}
        </span>
      </div>
      <div className="settings-layout">
        <aside className="card subnav">
          <button className="active">Tổng quan</button>
          <button>Mới nhất</button>
          <button>Đã lưu</button>
          <button>Lưu trữ</button>
        </aside>
        <section className="card notes-panel">
          {props.items.map(function (record) {
            return (
              <div key={record.id}>
                <span>
                  <MessageSquare size={17} />
                </span>
                <p>
                  <strong>{record.title}</strong>
                  <small>
                    {String(
                      record.data.body ||
                        record.data.value ||
                        record.data.target ||
                        "",
                    )}{" "}
                    ·{" "}
                    {record.createdAt
                      ? new Date(record.createdAt).toLocaleString("vi-VN")
                      : ""}
                  </small>
                </p>
                {props.admin ? (
                  <button
                    className="icon-button delete"
                    onClick={() => props.onDelete(record)}
                  >
                    <Trash2 size={16} />
                  </button>
                ) : (
                  <MoreHorizontal size={17} />
                )}
              </div>
            );
          })}
          {!props.items.length ? (
            <div className="empty-row">
              <MessageSquare size={20} />
              <span>Chưa có nội dung.</span>
            </div>
          ) : null}
        </section>
      </div>
    </>
  );
}

function AdminPinCard() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    setLoading(true);
    setMessage("");
    setError("");
    const form = new FormData(formElement);
    const response = await fetch("/api/admin/change-pin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        currentPin: form.get("currentPin"),
        newPin: form.get("newPin"),
        confirmPin: form.get("confirmPin"),
      }),
    });
    const payload = await response.json();
    if (!response.ok) {
      setError(payload.error || "Không thể đổi PIN Admin.");
      setLoading(false);
      return;
    }
    formElement.reset();
    setMessage("Đã đổi PIN Admin. Lần đăng nhập sau hãy dùng PIN mới.");
    setLoading(false);
  }
  return (
    <form className="card settings-form admin-pin-card" onSubmit={submit}>
      <div className="card-head">
        <div>
          <h2>Đổi PIN Admin</h2>
          <p>
            PIN mới gồm đúng 6 số và có hiệu lực cho lần đăng nhập tiếp theo.
          </p>
        </div>
        <KeyRound size={20} />
      </div>
      <div className="form-grid">
        <label>
          PIN hiện tại
          <input
            name="currentPin"
            type="password"
            inputMode="numeric"
            pattern="\d{6}"
            maxLength={6}
            required
            placeholder="••••••"
          />
        </label>
        <label>
          PIN mới
          <input
            name="newPin"
            type="password"
            inputMode="numeric"
            pattern="\d{6}"
            maxLength={6}
            required
            placeholder="••••••"
          />
        </label>
        <label className="wide">
          Nhập lại PIN mới
          <input
            name="confirmPin"
            type="password"
            inputMode="numeric"
            pattern="\d{6}"
            maxLength={6}
            required
            placeholder="••••••"
          />
        </label>
      </div>
      {error ? (
        <div className="form-error">
          <AlertTriangle size={15} />
          {error}
        </div>
      ) : null}
      {message ? (
        <div className="form-success">
          <CheckCircle2 size={15} />
          {message}
        </div>
      ) : null}
      <div className="modal-footer">
        <button className="button primary" disabled={loading}>
          {loading ? "Đang đổi PIN..." : "Đổi PIN Admin"}
        </button>
      </div>
    </form>
  );
}

function legacyScheduleWeekdays(schedule: string) {
  const normalized = normalizeSearchText(schedule);
  const labels = ["thu 2", "thu 3", "thu 4", "thu 5", "thu 6", "thu 7", "chu nhat"];
  const matches = labels.flatMap(function (label, index) {
    return normalized.includes(label) ? [index + 1] : [];
  });
  return matches.length ? matches : [1];
}

function TeachingScheduleView(props: { classes: ClassRecord[]; admin: boolean; notify: (text: string) => void; onAttendance: (target: { classId: string; className: string; date: string; startTime: string; endTime: string; sessionId?: number; sessionType: "regular" | "makeup" }) => void }) {
  const [weekStart, setWeekStart] = useState(function() { return mondayDateKey(localDateInTimeZone()); });
  const [sessions, setSessions] = useState<CourseSessionRecord[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedSession, setSelectedSession] = useState<CourseSessionRecord | null>(null);
  const [focusedScheduleKey, setFocusedScheduleKey] = useState("");
  const timetableScrollRef = useRef<HTMLDivElement | null>(null);
  function dateAt(offset: number) { return shiftDateKey(weekStart, offset); }
  const weekEnd = dateAt(6);
  async function loadSessions() {
    const response = await fetch("/api/course-sessions?from=" + weekStart + "&to=" + weekEnd, { cache: "no-store" });
    if (response.ok) setSessions((await response.json()).sessions || []);
  }
  useEffect(function() {
    const timer = window.setTimeout(function() { void loadSessions(); }, 0);
    return function() { window.clearTimeout(timer); };
  // The week key intentionally owns this fetch lifecycle.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [weekStart]);
  function moveWeek(delta: number) { setWeekStart(function(current) { return shiftDateKey(current, delta * 7); }); setFocusedScheduleKey(""); }
  async function saveSession(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSaving(true);
    const form = new FormData(event.currentTarget);
    const classKey = String(form.get("classKey") || "");
    const course = props.classes.find(function(item) { return item.key === classKey; });
    const response = await fetch("/api/course-sessions", { method: selectedSession ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: selectedSession?.id, classKey, className: course?.name, sessionType: form.get("sessionType"), sessionDate: form.get("sessionDate"), startTime: form.get("startTime"), endTime: form.get("endTime"), note: form.get("note") }) });
    const payload = await response.json(); setSaving(false);
    if (!response.ok) { props.notify(payload.error || "Không thể lưu buổi học."); return; }
    setModalOpen(false); setSelectedSession(null); await loadSessions(); props.notify(selectedSession ? "Đã cập nhật buổi học" : "Đã tạo buổi học bù");
  }
  async function removeSession(item: CourseSessionRecord) {
    if (!window.confirm("Xóa buổi học " + item.className + " ngày " + new Date(item.sessionDate + "T00:00:00").toLocaleDateString("vi-VN") + "?")) return;
    const response = await fetch("/api/course-sessions", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id }) });
    if (response.ok) { await loadSessions(); props.notify("Đã xóa buổi học"); }
  }
  const days = Array.from({ length: 7 }, function(_, index) {
    const date = dateAt(index);
    const weekday = index + 1;
    const recurring = props.classes.flatMap(function(course) {
      const schedules = course.schedules?.length ? course.schedules : legacyScheduleWeekdays(course.schedule).map(function(day) { return { weekday: day, startTime: course.startTime, endTime: course.endTime, room: course.room }; });
      return schedules.filter(function(item) { return item.weekday === weekday; }).map(function(item) { return { key: "regular-" + (course.key || course.name) + "-" + date + "-" + item.startTime, classKey: course.key || String(course.id || course.name), className: course.name, date, startTime: item.startTime, endTime: item.endTime, room: item.room || course.room, tone: course.tone || "indigo", type: "regular" as "regular" | "makeup", sessionId: undefined as number | undefined, note: "" }; });
    });
    const actual = sessions.filter(function(item) { return item.sessionDate === date; }).map(function(item) {
      const course = props.classes.find(function(courseItem) { return (courseItem.key || String(courseItem.id || courseItem.name)) === item.classKey || courseItem.name === item.className; });
      return { key: "session-" + item.id, classKey: item.classKey, className: item.className, date, startTime: item.startTime, endTime: item.endTime, room: course?.room || "", tone: course?.tone || "indigo", type: item.sessionType, sessionId: item.id, note: item.note };
    });
    const combined = recurring.concat(actual).sort(function(a, b) { return a.startTime.localeCompare(b.startTime) || a.endTime.localeCompare(b.endTime) || a.className.localeCompare(b.className); });
    const items = combined.map(function(item) {
      const itemStart = minutesOfSchedule(item.startTime);
      const itemEnd = Math.max(itemStart + 1, minutesOfSchedule(item.endTime));
      const overlapping = combined.filter(function(other) {
        const otherStart = minutesOfSchedule(other.startTime);
        const otherEnd = Math.max(otherStart + 1, minutesOfSchedule(other.endTime));
        return otherStart < itemEnd && itemStart < otherEnd;
      });
      return { ...item, stackIndex: Math.max(0, overlapping.findIndex(function(other) { return other.key === item.key; })), stackCount: overlapping.length };
    });
    return { date, items };
  });
  function minutesOfSchedule(value: string) { const parts = String(value || "00:00").split(":").map(Number); return Math.max(0, Math.min(24 * 60, (Number(parts[0]) || 0) * 60 + (Number(parts[1]) || 0))); }
  const allWeekItems = days.flatMap(function(day) { return day.items; });
  const earliest = allWeekItems.length ? Math.min.apply(null, allWeekItems.map(function(item) { return minutesOfSchedule(item.startTime); })) : 7 * 60;
  const latest = allWeekItems.length ? Math.max.apply(null, allWeekItems.map(function(item) { return minutesOfSchedule(item.endTime); })) : 22 * 60;
  const rangeStart = Math.max(0, Math.min(6 * 60, Math.floor(Math.max(0, earliest - 60) / 60) * 60));
  let rangeEnd = Math.min(24 * 60, Math.max(23 * 60, Math.ceil(Math.min(24 * 60, latest + 60) / 60) * 60));
  if (rangeEnd - rangeStart < 10 * 60) rangeEnd = Math.min(24 * 60, rangeStart + 10 * 60);
  const pixelsPerMinute = 0.72;
  const bodyHeight = Math.max(320, Math.round((rangeEnd - rangeStart) * pixelsPerMinute));
  const hourMarks = Array.from({ length: Math.floor((rangeEnd - rangeStart) / 60) + 1 }, function(_, index) { return rangeStart + index * 60; });
  useEffect(function() {
    const node = timetableScrollRef.current;
    if (!node) return;
    const target = Math.max(0, (7 * 60 - rangeStart) * pixelsPerMinute - 18);
    const frame = window.requestAnimationFrame(function() { node.scrollTop = target; });
    return function() { window.cancelAnimationFrame(frame); };
  }, [weekStart, rangeStart, pixelsPerMinute]);
  function cycleScheduleFocus(item: (typeof days)[number]["items"][number], dayItems: (typeof days)[number]["items"]) {
    const start = minutesOfSchedule(item.startTime);
    const end = Math.max(start + 1, minutesOfSchedule(item.endTime));
    const overlaps = dayItems.filter(function(other) {
      const otherStart = minutesOfSchedule(other.startTime);
      const otherEnd = Math.max(otherStart + 1, minutesOfSchedule(other.endTime));
      return otherStart < end && start < otherEnd;
    });
    if (overlaps.length <= 1) { setFocusedScheduleKey(item.key); return; }
    const focusedIndex = overlaps.findIndex(function(other) { return other.key === focusedScheduleKey; });
    const clickedIndex = overlaps.findIndex(function(other) { return other.key === item.key; });
    const currentIndex = focusedIndex >= 0 ? focusedIndex : clickedIndex;
    setFocusedScheduleKey(overlaps[(currentIndex + 1) % overlaps.length].key);
  }
  const todayKey = localDateInTimeZone();
  return <>
    <PageTitle title="Lịch dạy" subtitle="Thời khóa biểu tổng hợp theo tuần của tất cả lớp, gồm lịch định kỳ và buổi học bù."><button className="button primary" onClick={function() { setSelectedSession(null); setModalOpen(true); }}><Plus />Tạo buổi học bù</button></PageTitle>
    <section className="weekly-timetable card teacher-weekly-timetable taste-timetable">
      <div className="weekly-timetable-toolbar"><div><button className="icon-button" onClick={function() { moveWeek(-1); }} aria-label="Tuần trước"><ChevronLeft /></button><button className="button soft" onClick={function() { setWeekStart(mondayDateKey(localDateInTimeZone())); setFocusedScheduleKey(""); }}>Hôm nay</button><button className="icon-button" onClick={function() { moveWeek(1); }} aria-label="Tuần sau"><ChevronRight /></button></div><strong>{formatDateKey(weekStart)} - {formatDateKey(weekEnd)}</strong></div>
      <div className="weekly-timetable-scroll" ref={timetableScrollRef} tabIndex={0} aria-label="Lịch dạy theo tuần">
        <div className="weekly-timetable-grid">
          <div className="weekly-timetable-corner">Giờ</div>
          {days.map(function(day, index) { return <div className={"weekly-timetable-day-head" + (day.date === todayKey ? " today" : "")} key={"head-" + day.date}><span>{["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"][index]}</span><strong>{formatDateKey(day.date, "vi-VN", { day: "2-digit", month: "2-digit" })}</strong>{day.date === todayKey ? <em>Hôm nay</em> : null}</div>; })}
          <div className="weekly-timetable-time-axis" style={{ height: bodyHeight }}>{hourMarks.map(function(mark) { return <span key={mark} style={{ top: (mark - rangeStart) * pixelsPerMinute }}>{String(Math.floor(mark / 60)).padStart(2, "0") + ":00"}</span>; })}</div>
          {days.map(function(day) {
            return (
              <div
                className={"weekly-timetable-day-column" + (day.date === todayKey ? " today" : "")}
                style={{ height: bodyHeight }}
                key={day.date}
              >
                {hourMarks.map(function(mark) {
                  return <i className="weekly-timetable-hour-line" key={mark} style={{ top: (mark - rangeStart) * pixelsPerMinute }} />;
                })}
                {day.items.map(function(item) {
                  const start = Math.max(rangeStart, minutesOfSchedule(item.startTime));
                  const end = Math.min(rangeEnd, Math.max(start + 1, minutesOfSchedule(item.endTime)));
                  const isFocused = focusedScheduleKey === item.key;
                  const stacked = (item.stackCount || 1) > 1;
                  const stackOffset = stacked && !isFocused ? (item.stackIndex || 0) * 12 : 0;
                  const naturalHeight = Math.max(58, (end - start) * pixelsPerMinute);
                  const eventHeight = isFocused ? Math.max(124, naturalHeight) : naturalHeight;
                  return (
                    <article
                      role="button"
                      tabIndex={0}
                      aria-pressed={isFocused}
                      aria-label={"Lớp " + item.className + ", " + item.startTime + " đến " + item.endTime + (item.room ? ", phòng " + item.room : "")}
                      onClick={function() { cycleScheduleFocus(item, day.items); }}
                      onKeyDown={function(event) {
                        if (event.key === "Enter" || event.key === " ") {
                          event.preventDefault();
                          cycleScheduleFocus(item, day.items);
                        }
                      }}
                      className={"weekly-timetable-event teacher-event " + item.type + " tone-" + item.tone + (stacked ? " overlap" : "") + (isFocused ? " active" : "")}
                      key={item.key}
                      style={{
                        top: (start - rangeStart) * pixelsPerMinute,
                        height: eventHeight,
                        left: 6 + stackOffset,
                        right: 6,
                        zIndex: isFocused ? 40 : 3 + (item.stackIndex || 0),
                      }}
                    >
                      <div className="event-title-row">
                        <em>{item.type === "makeup" ? "Học bù" : "Lịch dạy"}</em>
                        {stacked ? <b className="overlap-badge">{(item.stackIndex || 0) + 1}/{item.stackCount}</b> : null}
                        {item.sessionId ? (
                          <span className="event-tools">
                            <button
                              type="button"
                              title="Sửa buổi học"
                              onClick={function(event) {
                                event.stopPropagation();
                                const found = sessions.find(function(session) { return session.id === item.sessionId; });
                                if (found) {
                                  setSelectedSession(found);
                                  setModalOpen(true);
                                }
                              }}
                            >
                              <Pencil />
                            </button>
                            <button
                              type="button"
                              title="Xóa buổi học"
                              onClick={function(event) {
                                event.stopPropagation();
                                const found = sessions.find(function(session) { return session.id === item.sessionId; });
                                if (found) void removeSession(found);
                              }}
                            >
                              <Trash2 />
                            </button>
                          </span>
                        ) : null}
                      </div>
                      <strong className="teacher-event-class">{item.className}</strong>
                      <time className="teacher-event-time">{item.startTime} – {item.endTime}</time>
                      <small className="teacher-event-room">{item.room || "Chưa đặt phòng"}</small>
                      {item.note ? <small className="event-note">{item.note}</small> : null}
                      <button
                        type="button"
                        className="event-attendance"
                        onClick={function(event) {
                          event.stopPropagation();
                          props.onAttendance({
                            classId: item.classKey,
                            className: item.className,
                            date: item.date,
                            startTime: item.startTime,
                            endTime: item.endTime,
                            sessionId: item.sessionId,
                            sessionType: item.type,
                          });
                        }}
                      >
                        Điểm danh
                      </button>
                    </article>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
      <footer className="weekly-timetable-legend"><span><i className="regular" />Lịch định kỳ</span><span><i className="makeup" />Học bù / bổ sung</span><small>{allWeekItems.some(function(item) { return (item.stackCount || 1) > 1; }) ? "Có lịch trùng giờ: bấm vào lớp đang ở trên để lần lượt xem lớp phía sau." : "Có thể kéo ngang trên màn hình nhỏ."}</small></footer>
    </section>
    {modalOpen ? <div className="modal" onMouseDown={function() { setModalOpen(false); }}><form className="form-modal makeup-session-modal" onSubmit={saveSession} onMouseDown={function(event) { event.stopPropagation(); }}><div className="modal-head"><div><h2>{selectedSession ? "Sửa buổi học" : "Tạo buổi học bù"}</h2><p>Buổi này không làm thay đổi lịch học định kỳ.</p></div><button type="button" className="modal-close" onClick={function() { setModalOpen(false); }}><X /></button></div><div className="form-grid"><label className="wide">Lớp<select name="classKey" required defaultValue={selectedSession?.classKey || props.classes[0]?.key}>{props.classes.map(function(item) { return <option key={item.key || item.name} value={item.key}>{item.name}</option>; })}</select></label><label>Loại buổi<select name="sessionType" defaultValue={selectedSession?.sessionType || "makeup"}><option value="makeup">Học bù</option><option value="regular">Buổi thường bổ sung</option></select></label><label>Ngày<input name="sessionDate" type="date" required defaultValue={selectedSession?.sessionDate || localDateInTimeZone()} /></label><label>Bắt đầu<input name="startTime" type="time" required defaultValue={selectedSession?.startTime || "18:30"} /></label><label>Kết thúc<input name="endTime" type="time" required defaultValue={selectedSession?.endTime || "20:00"} /></label><label className="wide">Ghi chú<textarea name="note" rows={3} defaultValue={selectedSession?.note || ""} placeholder="Nội dung cần lưu ý" /></label></div><div className="modal-footer"><button type="button" className="button ghost" onClick={function() { setModalOpen(false); }}>Hủy</button><button className="button primary" disabled={saving}>{saving ? "Đang lưu..." : "Lưu buổi học"}</button></div></form></div> : null}
  </>;
}

function PaymentQrSettings(props: { notify: (text: string) => void }) {
  const [meta, setMeta] = useState({ configured: false, bankName: "", accountName: "", accountNumber: "", imageUrl: "" });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [preview, setPreview] = useState("");
  async function load() {
    setLoading(true);
    try {
      const response = await fetch("/api/settings/payment-qr?meta=1", { cache: "no-store" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Không thể tải QR.");
      setMeta(payload);
      setPreview(payload.imageUrl ? payload.imageUrl + "?v=" + Date.now() : "");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Không thể tải QR.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(function () {
    const timer = window.setTimeout(function () { void load(); }, 0);
    return function () { window.clearTimeout(timer); };
  }, []);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/settings/payment-qr", { method: "POST", body: form });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Không thể lưu QR.");
      await load();
      props.notify(meta.configured ? "Đã thay ảnh QR trên báo cáo" : "Đã thêm QR vào báo cáo");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Không thể lưu QR.");
    } finally {
      setSaving(false);
    }
  }
  async function remove() {
    if (!window.confirm("Xóa ảnh QR khỏi các báo cáo in sau này?")) return;
    setSaving(true);
    const response = await fetch("/api/settings/payment-qr", { method: "DELETE" });
    setSaving(false);
    if (!response.ok) { setError("Không thể xóa QR."); return; }
    setMeta({ configured: false, bankName: "", accountName: "", accountNumber: "", imageUrl: "" });
    setPreview("");
    props.notify("Đã xóa QR khỏi báo cáo");
  }
  return (
    <form className="card settings-form payment-qr-card" onSubmit={submit}>
      <div className="card-head">
        <div><h2>QR thanh toán trên báo cáo</h2><p>Chỉ hiển thị khi in báo cáo học tập; không tạo module học phí.</p></div>
      </div>
      {loading ? <div className="detail-loading"><Clock3 />Đang tải cấu hình...</div> : (
        <>
          <div className="payment-qr-preview">
            <span>{preview ? <img src={preview} alt="Xem trước QR thanh toán" /> : <ImagePlus />}</span>
            <label><strong>{meta.configured ? "Thay ảnh QR" : "Chọn ảnh QR"}</strong><small>PNG, JPG hoặc WEBP · tối đa 3 MB</small><input name="file" type="file" accept="image/png,image/jpeg,image/webp" required onChange={function (event) { const file = event.target.files?.[0]; if (file) setPreview(URL.createObjectURL(file)); }} /></label>
          </div>
          <div className="form-grid">
            <label>Tên ngân hàng<input name="bankName" defaultValue={meta.bankName} placeholder="Ví dụ: Vietcombank" /></label>
            <label>Số tài khoản<input name="accountNumber" defaultValue={meta.accountNumber} placeholder="Số tài khoản" /></label>
            <label className="wide">Tên chủ tài khoản<input name="accountName" defaultValue={meta.accountName} placeholder="NGUYEN VAN A" /></label>
          </div>
        </>
      )}
      {error ? <div className="form-error"><AlertTriangle size={16} />{error}</div> : null}
      <div className="modal-footer">
        {meta.configured ? <button type="button" className="button danger" disabled={saving} onClick={function () { void remove(); }}><Trash2 />Xóa QR</button> : null}
        <button className="button primary" disabled={loading || saving}>{saving ? "Đang lưu..." : meta.configured ? "Lưu ảnh thay thế" : "Lưu QR"}</button>
      </div>
    </form>
  );
}

function SettingsView(props: {
  profile: TeacherProfile;
  admin: boolean;
  onSave: (profile: TeacherProfile) => Promise<void>;
  onRequireAdmin: () => void;
  notify: (text: string) => void;
}) {
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(props.profile.logoUrl);
  const [error, setError] = useState("");
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!props.admin) {
      props.onRequireAdmin();
      return;
    }
    setLoading(true);
    setError("");
    const form = new FormData(event.currentTarget);
    let logoUrl = form.get("removeLogo") ? "" : props.profile.logoUrl;
    const logo = form.get("logo");
    if (logo instanceof File && logo.size) {
      const upload = new FormData();
      upload.set("file", logo);
      const response = await fetch("/api/class-logo", {
        method: "POST",
        body: upload,
      });
      const payload = await response.json();
      if (!response.ok) {
        setError(payload.error || "Không thể tải logo.");
        setLoading(false);
        return;
      }
      logoUrl = String(payload.url || "");
    }
    await props.onSave({
      siteName: String(form.get("siteName") || "EduFlow").trim() || "EduFlow",
      teacherName: String(form.get("teacherName") || "Giáo viên"),
      gender: String(form.get("gender") || props.profile.gender || "male") === "female" ? "female" : "male",
      schoolName: String(form.get("schoolName") || ""),
      academicYear: String(form.get("academicYear") || ""),
      defaultRoom: String(form.get("defaultRoom") || ""),
      logoUrl,
      loginQuote:
        String(form.get("loginQuote") || "").trim() || DEFAULT_LOGIN_QUOTE,
    });
    setLoading(false);
  }
  return (
    <>
      <PageTitle
        title="Cài đặt hệ thống"
        subtitle="Đổi tên website, logo, PIN Admin và thông tin dùng chung."
      />
      <div className={props.admin ? "admin-strip active" : "admin-strip"}>
        <ShieldCheck size={17} />
        <span>
          {props.admin
            ? "Tên và logo mới sẽ áp dụng cho trang đăng nhập, Admin và học sinh."
            : "Đăng nhập Admin để thay đổi cấu hình."}
        </span>
      </div>
      <div className="settings-profile-grid">
        <aside className="card profile-preview">
          {props.profile.logoUrl ? (
            <img
              className="profile-site-logo"
              src={props.profile.logoUrl}
              alt={"Logo " + props.profile.siteName}
            />
          ) : (
            <Avatar
              initials={
                props.profile.teacherName
                  .split(" ")
                  .slice(-2)
                  .map(function (word) {
                    return word.charAt(0);
                  })
                  .join("")
                  .toUpperCase() || "GV"
              }
            />
          )}
          <h2>{props.profile.siteName}</h2>
          <p>{props.profile.schoolName || "Chưa đặt tên trường"}</p>
          <span>Quản trị viên</span>
        </aside>
        <form
          key={JSON.stringify(props.profile)}
          className="card settings-form"
          onSubmit={submit}
        >
          <div className="card-head">
            <div>
              <h2>Tên website, logo & hồ sơ</h2>
              <p>Admin có thể đổi các giá trị này bất kỳ lúc nào.</p>
            </div>
          </div>
          <div className="class-logo-field">
            <span>
              {preview ? (
                <img
                  src={preview}
                  alt={"Xem trước logo " + props.profile.siteName}
                />
              ) : (
                <ImagePlus />
              )}
            </span>
            <label>
              <strong>Logo cạnh tên website</strong>
              <small>PNG, JPG, WEBP hoặc GIF · tối đa 3 MB</small>
              <input
                name="logo"
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                onChange={function (event) {
                  const file = event.target.files?.[0];
                  if (file) setPreview(URL.createObjectURL(file));
                }}
              />
            </label>
            {props.profile.logoUrl ? (
              <label className="remove-logo">
                <input
                  name="removeLogo"
                  type="checkbox"
                  onChange={function (event) {
                    setPreview(
                      event.target.checked ? "" : props.profile.logoUrl,
                    );
                  }}
                />
                Xóa logo
              </label>
            ) : null}
          </div>
          {error ? (
            <div className="form-error">
              <AlertTriangle size={16} />
              {error}
            </div>
          ) : null}
          <div className="form-grid">
            <label className="wide">
              Tên website
              <input
                name="siteName"
                required
                maxLength={40}
                readOnly={!props.admin}
                defaultValue={props.profile.siteName}
                placeholder="Ví dụ: Lớp Toán Thầy Minh"
              />
            </label>
            <label className="wide">
              Tên giáo viên
              <input
                name="teacherName"
                required
                readOnly={!props.admin}
                defaultValue={props.profile.teacherName}
              />
            </label>
            <label>
              Giới tính
              <select name="gender" disabled={!props.admin} defaultValue={props.profile.gender}>
                <option value="male">Nam (xưng hô Thầy)</option>
                <option value="female">Nữ (xưng hô Cô)</option>
              </select>
              <small>Dùng để tự động hiển thị lời chào Thầy/Cô trên Tổng quan.</small>
            </label>
            <label className="wide">
              Tên trường / trung tâm
              <input
                name="schoolName"
                readOnly={!props.admin}
                defaultValue={props.profile.schoolName}
                placeholder="Ví dụ: Trung tâm Toán Lan Anh"
              />
            </label>
            <label>
              Năm học
              <input
                name="academicYear"
                readOnly={!props.admin}
                defaultValue={props.profile.academicYear}
                placeholder="2026-2027"
              />
            </label>
            <label>
              Phòng mặc định
              <input
                name="defaultRoom"
                readOnly={!props.admin}
                defaultValue={props.profile.defaultRoom}
                placeholder="P.203"
              />
            </label>
            <label className="wide login-quote-field">
              Câu giới thiệu trang đăng nhập
              <textarea
                name="loginQuote"
                rows={3}
                maxLength={180}
                readOnly={!props.admin}
                defaultValue={props.profile.loginQuote}
                placeholder="Nhập câu muốn hiển thị ở trang đăng nhập"
              />
              <small>Tối đa 180 ký tự. Dấu ngoặc kép sẽ được thêm tự động.</small>
            </label>
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="button ghost"
              onClick={props.onRequireAdmin}
              hidden={props.admin}
            >
              Đăng nhập Admin
            </button>
            <button className="button primary" disabled={loading}>
              {loading ? "Đang lưu..." : "Lưu cài đặt"}
            </button>
          </div>
        </form>
        {props.admin ? <AdminPinCard /> : null}
        {props.admin ? <PaymentQrSettings notify={props.notify} /> : null}
      </div>
    </>
  );
}

function AdminLoginModal(props: {
  close: () => void;
  submit: (pin: string) => Promise<void>;
  error: string;
}) {
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    await props.submit(pin);
    setLoading(false);
  }
  return (
    <div className="modal" onMouseDown={props.close}>
      <form
        className="form-modal pin-modal"
        onSubmit={handleSubmit}
        onMouseDown={function (event) {
          event.stopPropagation();
        }}
      >
        <button type="button" className="modal-close" onClick={props.close}>
          <X size={19} />
        </button>
        <span className="modal-symbol">
          <ShieldCheck size={25} />
        </span>
        <h2>Đăng nhập Admin</h2>
        <p>Nhập mã PIN 6 số để thêm, sửa hoặc xóa dữ liệu.</p>
        <label>
          Mã PIN Admin
          <input
            autoFocus
            required
            inputMode="numeric"
            maxLength={6}
            value={pin}
            onChange={function (event) {
              setPin(event.target.value.replace(/\D/g, ""));
            }}
            placeholder="••••••"
            type="password"
          />
        </label>
        {props.error ? (
          <div className="form-error">
            <AlertTriangle size={15} />
            {props.error}
          </div>
        ) : null}
        <button
          className="button primary submit-button"
          disabled={loading || pin.length !== 6}
        >
          {loading ? "Đang kiểm tra..." : "Đăng nhập Admin"}
        </button>
      </form>
    </div>
  );
}

function StudentFormModal(props: {
  value: StudentRecord | null;
  classes: ClassRecord[];
  defaultClassName?: string;
  close: () => void;
  save: (data: Record<string, unknown>) => Promise<void>;
}) {
  const [loading, setLoading] = useState(false);
  const [selectedClassKeys, setSelectedClassKeys] = useState<string[]>(function() {
    const activeKeys = (props.value?.enrollments || [])
      .filter(function(item) { return item.status === "active"; })
      .map(function(item) { return item.classKey; });
    if (activeKeys.length) return Array.from(new Set(activeKeys));
    const fallbackName = props.defaultClassName || props.value?.className || "";
    const fallback = props.classes.find(function(item) { return item.name === fallbackName; });
    return fallback ? [fallback.key || String(fallback.id || fallback.name)] : [];
  });
  function toggleClass(classKey: string) {
    setSelectedClassKeys(function(current) {
      return current.includes(classKey)
        ? current.filter(function(item) { return item !== classKey; })
        : current.concat(classKey);
    });
  }
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    const form = new FormData(event.currentTarget);
    const selectedClasses = props.classes.filter(function(item) {
      const key = item.key || String(item.id || item.name);
      return selectedClassKeys.includes(key);
    });
    const primaryClass = selectedClasses.find(function(item) {
      return item.name === props.value?.className;
    }) || selectedClasses[0];
    const orderedClasses = primaryClass
      ? [primaryClass].concat(selectedClasses.filter(function(item) { return item !== primaryClass; }))
      : [];
    await props.save({
      id: props.value?.id,
      name: form.get("name"),
      code: form.get("code"),
      classKey: primaryClass?.key || "",
      className: primaryClass?.name || "Chưa xếp lớp",
      classKeys: orderedClasses.map(function(item) { return item.key || String(item.id || item.name); }),
      classEnrollments: orderedClasses.map(function(item) {
        return { classKey: item.key || String(item.id || item.name), className: item.name };
      }),
      averageScore: props.value?.avg || 0,
      attendanceRate: props.value?.attendance || 0,
      status: form.get("status"),
      phone: form.get("phone"),
      email: form.get("email"),
    });
    setLoading(false);
  }
  return (
    <div className="modal" onMouseDown={props.close}>
      <form
        className="form-modal"
        onSubmit={submit}
        onMouseDown={function (event) {
          event.stopPropagation();
        }}
      >
        <div className="modal-head">
          <div>
            <h2>
              {props.value ? "Sửa thông tin học sinh" : "Thêm học sinh mới"}
            </h2>
            <p>Thông tin sẽ được lưu vào hệ thống.</p>
          </div>
          <button type="button" className="modal-close" onClick={props.close} aria-label="Đóng">
            <X size={19} />
          </button>
        </div>
        <div className="computed-note">
          <BarChart3 size={17} />
          <span>
            <strong>Điểm và chuyên cần được tính tự động</strong>
            <small>
              Điểm trung bình lấy từ Sổ điểm; chuyên cần lấy từ các buổi Điểm
              danh nên không thể nhập tay tại đây.
            </small>
          </span>
        </div>
        <div className="form-grid">
          <label className="wide">
            Họ và tên
            <input name="name" required defaultValue={props.value?.name} />
          </label>
          <label>
            Mã học sinh
            <input
              name="code"
              required
              defaultValue={props.value?.code}
              placeholder="HS24007"
            />
          </label>
          <label>
            Trạng thái
            <select
              name="status"
              defaultValue={props.value?.state || "Đang học"}
            >
              <option>Đang học</option>
              <option>Cần chú ý</option>
              <option>Tạm nghỉ</option>
            </select>
          </label>
          <fieldset className="wide student-class-picker">
            <legend>
              <span>Lớp học</span>
              <small>{selectedClassKeys.length ? selectedClassKeys.length + " lớp đã chọn" : "Chưa xếp lớp"}</small>
            </legend>
            <div className="student-class-picker-list" role="group" aria-label="Chọn các lớp học sinh tham gia">
              {props.classes.map(function(item) {
                const key = item.key || String(item.id || item.name);
                const selected = selectedClassKeys.includes(key);
                return (
                  <button
                    key={key}
                    type="button"
                    className={selected ? "selected" : ""}
                    aria-pressed={selected}
                    onClick={function() { toggleClass(key); }}
                  >
                    <span className="student-class-check">{selected ? <Check size={14} /> : null}</span>
                    <span>{item.name}</span>
                  </button>
                );
              })}
              {!props.classes.length ? <p>Chưa có lớp học nào để chọn.</p> : null}
            </div>
            <p className="student-class-picker-help">Có thể chọn nhiều lớp. Bỏ chọn tất cả để chuyển học sinh về trạng thái Chưa xếp lớp.</p>
          </fieldset>
          <label>
            Số điện thoại
            <input name="phone" defaultValue={props.value?.phone} />
          </label>
          <label>
            Email
            <input
              name="email"
              type="email"
              defaultValue={props.value?.email}
            />
          </label>
        </div>
        <div className="modal-footer">
          <button type="button" className="button ghost" onClick={props.close}>
            Hủy
          </button>
          <button className="button primary" disabled={loading}>
            {loading
              ? "Đang lưu..."
              : props.value
                ? "Lưu thay đổi"
                : "Thêm học sinh"}
          </button>
        </div>
      </form>
    </div>
  );
}

function StudentPinModal(props: {
  student: StudentRecord;
  hasPin: boolean;
  close: () => void;
  save: (pin: string) => Promise<void>;
}) {
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  function generatePin() {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    setPin(String(100000 + (values[0] % 900000)));
    setShowPin(true);
    setError("");
  }
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!/^\d{6}$/.test(pin)) {
      setError("PIN học sinh phải gồm đúng 6 chữ số.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await props.save(pin);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Không thể cập nhật PIN học sinh.");
    } finally {
      setLoading(false);
    }
  }
  return (
    <div className="modal" onMouseDown={props.close}>
      <form className="form-modal student-pin-modal" onSubmit={submit} onMouseDown={function(event) { event.stopPropagation(); }}>
        <div className="modal-head">
          <div>
            <h2>{props.hasPin ? "Đổi PIN học sinh" : "Đặt PIN học sinh"}</h2>
            <p>{props.student.name} · {props.student.code}</p>
          </div>
          <button type="button" className="modal-close" onClick={props.close} aria-label="Đóng"><X size={19} /></button>
        </div>
        {props.hasPin ? (
          <div className="credential-security-note">
            <ShieldCheck size={18} />
            <span><strong>PIN hiện tại được mã hóa một chiều</strong><small>Hệ thống không lưu PIN dạng đọc được nên không thể hiển thị lại PIN cũ. Nhập PIN mới để thay thế an toàn.</small></span>
          </div>
        ) : null}
        <label className="student-pin-field">
          <span>PIN mới</span>
          <div>
            <input
              autoFocus
              inputMode="numeric"
              autoComplete="new-password"
              maxLength={6}
              value={pin}
              onChange={function(event) { setPin(event.target.value.replace(/\D/g, "").slice(0, 6)); setError(""); }}
              type={showPin ? "text" : "password"}
              placeholder="6 chữ số"
            />
            <button type="button" className="icon-button" onClick={function() { setShowPin(!showPin); }} aria-label={showPin ? "Ẩn PIN" : "Hiện PIN"} title={showPin ? "Ẩn PIN" : "Hiện PIN"}>
              {showPin ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
        </label>
        <button type="button" className="button soft student-pin-generate" onClick={generatePin}>Tạo PIN 6 số ngẫu nhiên</button>
        {error ? <div className="form-error" role="alert"><AlertTriangle size={15} />{error}</div> : null}
        <div className="modal-footer">
          <button type="button" className="button ghost" onClick={props.close}>Hủy</button>
          <button className="button primary" disabled={loading || pin.length !== 6}>{loading ? "Đang cập nhật..." : "Cập nhật PIN"}</button>
        </div>
      </form>
    </div>
  );
}

function AssignmentFormModal(props: {
  value: AssignmentRecord | null;
  classNames: string[];
  close: () => void;
  save: (data: Record<string, unknown>, file: File | null, removeAttachment: boolean) => Promise<void>;
}) {
  const [loading, setLoading] = useState(false);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    const form = new FormData(event.currentTarget);
    const attachment = form.get("attachment");
    await props.save({
      id: props.value?.id,
      title: form.get("title"),
      className: form.get("className"),
      description: form.get("description"),
      dueDate: form.get("dueDate"),
      maxScore: Number(form.get("maxScore")),
    }, attachment instanceof File && attachment.size ? attachment : null, form.get("removeAttachment") === "on");
    setLoading(false);
  }
  return (
    <div className="modal" onMouseDown={props.close}>
      <form
        className="form-modal"
        onSubmit={submit}
        onMouseDown={function (event) {
          event.stopPropagation();
        }}
      >
        <div className="modal-head">
          <div>
            <h2>{props.value ? "Sửa bài tập" : "Tạo bài tập mới"}</h2>
            <p>Giao bài và thiết lập thời hạn cho lớp.</p>
          </div>
          <button type="button" className="modal-close" onClick={props.close}>
            <X size={19} />
          </button>
        </div>
        <div className="computed-note">
          <Clock3 size={17} />
          <span>
            <strong>Trạng thái và số học sinh được tính tự động</strong>
            <small>
              Còn trên 6 giờ: Đang mở · Còn 6 giờ trở xuống: Sắp hết hạn · Qua
              hạn: Đã kết thúc.
            </small>
          </span>
        </div>
        <div className="form-grid">
          <label className="wide">
            Tên bài tập
            <input
              name="title"
              required
              defaultValue={props.value?.title}
              placeholder="Ví dụ: Khảo sát hàm số"
            />
          </label>
          <label>
            Lớp học
            <select
              name="className"
              defaultValue={
                props.value?.className || props.classNames[0] || "Chưa xếp lớp"
              }
            >
              <option>Chưa xếp lớp</option>
              {props.classNames
                .filter(function (name) {
                  return name !== "Chưa xếp lớp";
                })
                .map(function (name) {
                  return <option key={name}>{name}</option>;
                })}
            </select>
          </label>
          <label>
            Hạn nộp
            <input
              name="dueDate"
              required
              type="datetime-local"
              defaultValue={
                props.value?.dueDate ? props.value.dueDate.slice(0, 16) : ""
              }
            />
          </label>
          <label>
            Điểm tối đa
            <input
              name="maxScore"
              type="number"
              min="0.1"
              step="0.1"
              defaultValue={props.value?.maxScore || 10}
            />
          </label>
          <label className="wide">
            Mô tả
            <textarea
              name="description"
              rows={4}
              defaultValue={props.value?.description}
              placeholder="Nội dung và hướng dẫn làm bài..."
            />
          </label>
          <label className="wide assignment-attachment-field">
            Tệp đính kèm
            <input name="attachment" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" />
            <small>Ảnh hoặc PDF, tối đa 10 MB.</small>
          </label>
          {props.value?.attachmentName ? <label className="wide remove-attachment"><input name="removeAttachment" type="checkbox" />Xóa tệp hiện tại: {props.value.attachmentName}</label> : null}
        </div>
        <div className="modal-footer">
          <button type="button" className="button ghost" onClick={props.close}>
            Hủy
          </button>
          <button className="button primary" disabled={loading}>
            {loading
              ? "Đang lưu..."
              : props.value
                ? "Lưu thay đổi"
                : "Tạo bài tập"}
          </button>
        </div>
      </form>
    </div>
  );
}

function ClassFormModal(props: {
  value: ClassRecord | null;
  defaultTeacher: string;
  close: () => void;
  save: (data: ClassRecord) => Promise<void>;
}) {
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(props.value?.logoUrl || "");
  const [label, setLabel] = useState(props.value?.label || "");
  const [error, setError] = useState("");
  const [schedules, setSchedules] = useState<{ weekday: number; startTime: string; endTime: string; room?: string }[]>(function() {
    if (props.value?.schedules?.length) return props.value.schedules;
    const text = props.value?.schedule || "";
    const matches: Array<[RegExp, number]> = [[/Thứ\s*2/i, 1], [/Thứ\s*3/i, 2], [/Thứ\s*4/i, 3], [/Thứ\s*5/i, 4], [/Thứ\s*6/i, 5], [/Thứ\s*7/i, 6], [/Chủ\s*nhật/i, 7]];
    const days = matches.filter(function(item) { return item[0].test(text); }).map(function(item) { return item[1]; });
    return (days.length ? days : [1]).map(function(weekday) { return { weekday, startTime: props.value?.startTime || "08:00", endTime: props.value?.endTime || "09:30", room: props.value?.room || "" }; });
  });
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const form = new FormData(event.currentTarget);
    if (!schedules.length || schedules.some(function(item) { return !item.startTime || !item.endTime || item.startTime >= item.endTime; })) {
      setError("Mỗi buổi học cần có thứ và khoảng giờ hợp lệ.");
      setLoading(false);
      return;
    }
    let logoUrl = form.get("removeLogo") ? "" : props.value?.logoUrl || "";
    const logo = form.get("logo");
    if (logo instanceof File && logo.size) {
      const upload = new FormData();
      upload.set("file", logo);
      const response = await fetch("/api/class-logo", {
        method: "POST",
        body: upload,
      });
      const payload = await response.json();
      if (!response.ok) {
        setError(payload.error || "Không thể tải logo.");
        setLoading(false);
        return;
      }
      logoUrl = String(payload.url || "");
    }
    await props.save({
      id: props.value?.id,
      key: props.value?.key,
      name: String(form.get("name")),
      label: String(form.get("label") || "").replace(/\s+/g, " ").trim().slice(0, 10),
      teacher: String(form.get("teacher")),
      room: String(form.get("room")),
      schedule: schedules.map(function(item) { return ["", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"][item.weekday]; }).join(" · "),
      startTime: schedules[0].startTime,
      endTime: schedules[0].endTime,
      schedules: schedules.map(function(item) { return { ...item, room: item.room || String(form.get("room")) }; }),
      studentCount: props.value?.studentCount || 0,
      average: props.value?.average || 0,
      attendance: props.value?.attendance || 0,
      openAssignments: props.value?.openAssignments || 0,
      tone: String(form.get("tone")),
      logoUrl,
    });
    setLoading(false);
  }
  return (
    <div className="modal" onMouseDown={props.close}>
      <form
        className="form-modal"
        onSubmit={submit}
        onMouseDown={function (event) {
          event.stopPropagation();
        }}
      >
        <div className="modal-head">
          <div>
            <h2>{props.value ? "Sửa lớp học" : "Tạo lớp học mới"}</h2>
            <p>Admin có thể đổi logo, giáo viên, phòng, lịch và giờ học.</p>
          </div>
          <button type="button" className="modal-close" onClick={props.close}>
            <X size={19} />
          </button>
        </div>
        <div className="computed-note">
          <Sparkles size={17} />
          <span>
            <strong>Sĩ số lớp được tính tự động</strong>
            <small>
              Số học sinh được lấy từ danh sách học sinh thuộc lớp này.
            </small>
          </span>
        </div>
        <div className="class-logo-field">
          <span>
            {preview ? (
              <img src={preview} alt="Xem trước logo lớp" />
            ) : (
              <ImagePlus />
            )}
          </span>
          <label>
            <strong>Logo lớp học</strong>
            <small>PNG, JPG, WEBP hoặc GIF · tối đa 3 MB</small>
            <input
              name="logo"
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              onChange={function (event) {
                const file = event.target.files?.[0];
                if (file) setPreview(URL.createObjectURL(file));
              }}
            />
          </label>
          {props.value?.logoUrl ? (
            <label className="remove-logo">
              <input
                name="removeLogo"
                type="checkbox"
                onChange={function (event) {
                  if (event.target.checked) setPreview("");
                  else setPreview(props.value?.logoUrl || "");
                }}
              />
              Xóa logo hiện tại
            </label>
          ) : null}
        </div>
        {error ? (
          <div className="form-error">
            <AlertTriangle size={16} />
            {error}
          </div>
        ) : null}
        <div className="form-grid">
          <label className="wide">
            Tên lớp
            <input
              name="name"
              required
              defaultValue={props.value?.name}
              placeholder="Ví dụ: Toán 12A1"
            />
          </label>
          <label className="wide class-label-input">
            Nhãn lớp
            <input
              name="label"
              maxLength={10}
              value={label}
              onChange={function (event) {
                setLabel(event.target.value.replace(/[\r\n]/g, "").slice(0, 10));
              }}
              placeholder="Ví dụ: T12 hoặc 12A1"
            />
            <span><small>Tên ngắn hiển thị trên thẻ lớp. Tối đa 10 ký tự.</small><b>{label.length} / 10</b></span>
          </label>
          <label>
            Giáo viên phụ trách
            <input
              name="teacher"
              required
              defaultValue={props.value?.teacher || props.defaultTeacher}
            />
          </label>
          <label>
            Phòng học
            <input
              name="room"
              defaultValue={props.value?.room}
              placeholder="Ví dụ: P.203"
            />
          </label>
          <fieldset className="wide multi-schedule-field">
            <legend>Lịch học</legend>
            <div className="multi-schedule-list">
              {schedules.map(function(item, index) { return <div key={index} className="schedule-form-row"><strong>Buổi {index + 1}</strong><label>Thứ<select value={item.weekday} onChange={function(event) { setSchedules(function(current) { return current.map(function(row, rowIndex) { return rowIndex === index ? { ...row, weekday: Number(event.target.value) } : row; }); }); }}>{[1,2,3,4,5,6,7].map(function(day) { return <option key={day} value={day}>{["", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"][day]}</option>; })}</select></label><label>Bắt đầu<input type="time" value={item.startTime} onChange={function(event) { const value = event.target.value; setSchedules(function(current) { return current.map(function(row, rowIndex) { return rowIndex === index ? { ...row, startTime: value } : row; }); }); }} /></label><label>Kết thúc<input type="time" value={item.endTime} onChange={function(event) { const value = event.target.value; setSchedules(function(current) { return current.map(function(row, rowIndex) { return rowIndex === index ? { ...row, endTime: value } : row; }); }); }} /></label><button type="button" className="icon-button delete" disabled={schedules.length === 1} onClick={function() { setSchedules(function(current) { return current.filter(function(_, rowIndex) { return rowIndex !== index; }); }); }} aria-label={"Xóa buổi " + (index + 1)}><Trash2 /></button></div>; })}
            </div>
            <button type="button" className="button soft add-schedule" onClick={function() { setSchedules(function(current) { const previous = current[current.length - 1]; return current.concat({ weekday: previous ? previous.weekday % 7 + 1 : 1, startTime: previous?.startTime || "08:00", endTime: previous?.endTime || "09:30", room: previous?.room || "" }); }); }}><Plus />Thêm buổi</button>
          </fieldset>
          <label>
            Màu thẻ
            <select name="tone" defaultValue={props.value?.tone || "indigo"}>
              <option value="indigo">Indigo</option>
              <option value="green">Xanh lá</option>
              <option value="orange">Cam</option>
            </select>
          </label>
        </div>
        <div className="modal-footer">
          <button type="button" className="button ghost" onClick={props.close}>
            Hủy
          </button>
          <button className="button primary" disabled={loading}>
            {loading ? "Đang lưu..." : "Lưu lớp học"}
          </button>
        </div>
      </form>
    </div>
  );
}

function ContentFormModal(props: {
  mode: "calendar" | "notifications" | "notes" | "settings";
  classes?: ClassRecord[];
  students?: StudentRecord[];
  close: () => void;
  save: (title: string, data: Record<string, unknown>) => Promise<void>;
}) {
  const [loading, setLoading] = useState(false);
  const [body, setBody] = useState("");
  const labels = {
    calendar: ["Tạo lịch kiểm tra", "Tên bài / nội dung kiểm tra"],
    notifications: ["Gửi thông báo", "Tiêu đề thông báo"],
    notes: ["Thêm ghi chú", "Tiêu đề ghi chú"],
    settings: ["Thêm cấu hình", "Tên cấu hình"],
  } as const;
  const label = labels[props.mode];
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    const form = new FormData(event.currentTarget);
    const data: Record<string, unknown> = {
      body: String(form.get("body") || ""),
    };
    if (props.mode === "calendar") {
      const date = String(form.get("date") || "");
      const selectedClassKey = String(form.get("classKey") || "");
      const selectedClass = (props.classes || []).find(function (item) {
        return (item.key || String(item.id || item.name)) === selectedClassKey;
      });
      data.date = date;
      data.day = Number(date.slice(-2));
      data.time = String(form.get("time") || "");
      data.type = "Kiểm tra";
      data.classKey = selectedClassKey;
      data.className = selectedClass?.name || "";
      data.details = String(form.get("body") || "");
    }
    if (props.mode === "notifications") {
      const target = String(form.get("target") || "all");
      data.body = String(form.get("body") || "");
      data.actionView = "dashboard";
      data.category = "announcement";
      data.automatic = false;
      data.studentReadAt = null;
      data.readByStudentIds = [];
      if (target.startsWith("student:")) {
        const studentId = Number(target.slice("student:".length));
        const student = (props.students || []).find(function(item) { return item.id === studentId; });
        data.audience = "student";
        data.studentId = studentId;
        data.className = student?.className || "";
      } else if (target.startsWith("class:")) {
        const classKey = target.slice("class:".length);
        const selectedClass = (props.classes || []).find(function(item) {
          return (item.key || String(item.id || item.name)) === classKey;
        });
        data.audience = "all_students";
        data.classKey = classKey;
        data.className = selectedClass?.name || "";
      } else {
        data.audience = "all_students";
      }
    }
    if (props.mode === "settings") data.value = String(form.get("body") || "");
    await props.save(String(form.get("title") || ""), data);
    setLoading(false);
  }
  return (
    <div className="modal" onMouseDown={props.close}>
      <form
        className="form-modal"
        onSubmit={submit}
        onMouseDown={function (event) {
          event.stopPropagation();
        }}
      >
        <div className="modal-head">
          <div>
            <h2>{label[0]}</h2>
            <p>
              Nội dung sẽ được lưu bền vững và hiển thị lại sau khi tải trang.
            </p>
          </div>
          <button type="button" className="modal-close" onClick={props.close}>
            <X size={19} />
          </button>
        </div>
        <div className="form-grid">
          <label className="wide">
            {label[1]}
            <input name="title" required />
          </label>
          {props.mode === "calendar" ? (
            <>
              <label className="wide">
                Lớp
                <select name="classKey" required defaultValue={(props.classes?.[0]?.key || String(props.classes?.[0]?.id || props.classes?.[0]?.name || ""))}>
                  {(props.classes || []).map(function (item) {
                    const key = item.key || String(item.id || item.name);
                    return <option key={key} value={key}>{item.name}</option>;
                  })}
                </select>
              </label>
              <label>
                Ngày kiểm tra
                <input
                  name="date"
                  type="date"
                  required
                  defaultValue={localDateInTimeZone()}
                />
              </label>
              <label>
                Giờ
                <input name="time" type="time" defaultValue="08:00" />
              </label>
            </>
          ) : null}
          {props.mode === "notifications" ? (
            <label className="wide">
              Đối tượng
              <select name="target" defaultValue="all">
                <option value="all">Toàn bộ học sinh</option>
                {(props.classes || []).length ? (
                  <optgroup label="Theo lớp">
                    {(props.classes || []).map(function(item) {
                      const key = item.key || String(item.id || item.name);
                      return <option key={"class-" + key} value={"class:" + key}>{item.name}</option>;
                    })}
                  </optgroup>
                ) : null}
                {(props.students || []).length ? (
                  <optgroup label="Theo học sinh">
                    {(props.students || []).map(function(item) {
                      return item.id ? <option key={"student-" + item.id} value={"student:" + item.id}>{item.name} · {item.code}</option> : null;
                    })}
                  </optgroup>
                ) : null}
              </select>
            </label>
          ) : null}
          <label className="wide content-body-field">
            {props.mode === "settings" ? "Giá trị" : props.mode === "calendar" ? "Nội dung / ghi chú kiểm tra" : "Nội dung"}
            <span className="content-body-input">
              <textarea name="body" rows={4} required value={body} onChange={function(event) { setBody(event.target.value); }} />
              {props.mode === "notifications" ? <EmojiPicker onPick={function(emoji) { setBody(function(current) { return current + emoji; }); }} label="Thêm emoji vào thông báo" /> : null}
            </span>
          </label>
        </div>
        <div className="modal-footer">
          <button type="button" className="button ghost" onClick={props.close}>
            Hủy
          </button>
          <button className="button primary" disabled={loading}>
            {loading ? "Đang lưu..." : "Lưu"}
          </button>
        </div>
      </form>
    </div>
  );
}

function RewardsAdminView(props: {
  data: RewardData;
  refresh: () => Promise<void>;
  notify: (text: string) => void;
}) {
  const [ruleForm, setRuleForm] = useState<Partial<PointRule> | null>(null);
  const [rewardForm, setRewardForm] = useState<Partial<RewardItem> | null>(
    null,
  );
  const [selectedStudent, setSelectedStudent] = useState<RewardStudent | null>(
    null,
  );
  const [selectedRuleIds, setSelectedRuleIds] = useState<number[]>([]);
  const [applyingRules, setApplyingRules] = useState(false);
  async function action(body: Record<string, unknown>, success: string) {
    const response = await fetch("/api/rewards/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const payload = await response.json();
    if (!response.ok) {
      props.notify(payload.error || "Không thể thực hiện thao tác.");
      return false;
    }
    await props.refresh();
    props.notify(success);
    return true;
  }
  async function applySelectedRules() {
    if (!selectedStudent || !selectedRuleIds.length || applyingRules) return;
    setApplyingRules(true);
    const ok = await action(
      { action: "apply_rules", studentId: selectedStudent.id, ruleIds: selectedRuleIds },
      "Đã áp dụng " + selectedRuleIds.length + " quy tắc cho " + selectedStudent.name,
    );
    setApplyingRules(false);
    if (ok) {
      setSelectedRuleIds([]);
      setSelectedStudent(null);
    }
  }
  async function saveRule(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const ok = await action(
      {
        action: "save_rule",
        id: ruleForm?.id,
        title: form.get("title"),
        trigger: ruleForm?.trigger || "manual",
        points: Number(form.get("points")),
        threshold: Number(form.get("threshold")),
        active: true,
      },
      ruleForm?.id ? "Đã sửa quy tắc" : "Đã thêm quy tắc",
    );
    if (ok) setRuleForm(null);
  }
  async function saveReward(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const ok = await action(
      {
        action: "save_reward",
        id: rewardForm?.id,
        title: form.get("title"),
        description: form.get("description"),
        cost: Number(form.get("cost")),
        stock: Number(form.get("stock")),
        active: true,
      },
      rewardForm?.id ? "Đã sửa quà" : "Đã thêm quà",
    );
    if (ok) setRewardForm(null);
  }
  const sortedStudents = props.data.students.slice().sort(function (a, b) {
    return b.points - a.points;
  });
  const sortedRules = sortPointRules(props.data.rules);
  const activeRules = sortedRules.filter(function (rule) {
    return rule.active;
  });
  const pending = props.data.redemptions.filter(function (item) {
    return item.status === "pending";
  });
  const total = props.data.students.reduce(function (sum, item) {
    return sum + item.points;
  }, 0);
  return (
    <>
      <PageTitle
        title="Thi đua & Đổi quà"
        subtitle="Điểm được cộng/trừ từ hành động thật; Admin toàn quyền thay đổi quy tắc."
      >
        <button
          className="button ghost"
          onClick={() => setRewardForm({ cost: 20, stock: 10 })}
        >
          <Gift size={17} />
          Thêm quà
        </button>
        <button
          className="button primary"
          onClick={() =>
            setRuleForm({ points: -2, threshold: 1 })
          }
        >
          <Plus size={17} />
          Thêm quy tắc
        </button>
      </PageTitle>
      <section className="reward-kpis">
        <article className="card">
          <Coins />
          <span>
            <small>Tổng điểm đang có</small>
            <strong>{total}</strong>
          </span>
        </article>
        <article className="card">
          <Trophy />
          <span>
            <small>Quy tắc đang bật</small>
            <strong>
              {
                props.data.rules.filter(function (item) {
                  return item.active;
                }).length
              }
            </strong>
          </span>
        </article>
        <article className="card">
          <Gift />
          <span>
            <small>Quà đang mở</small>
            <strong>
              {
                props.data.rewards.filter(function (item) {
                  return item.active;
                }).length
              }
            </strong>
          </span>
        </article>
        <article className="card">
          <ClipboardCheck />
          <span>
            <small>Chờ duyệt đổi quà</small>
            <strong>{pending.length}</strong>
          </span>
        </article>
      </section>
      {ruleForm ? (
        <form className="card reward-editor" onSubmit={saveRule}>
          <div>
            <h2>{ruleForm.id ? "Sửa quy tắc điểm" : "Tạo quy tắc điểm"}</h2>
            <p>
              Nhập tên quy tắc, số lần và số điểm. Dùng số âm để trừ điểm.
            </p>
          </div>
          <label>
            Tên quy tắc
            <input
              name="title"
              required
              defaultValue={ruleForm.title || ""}
              placeholder="Ví dụ: Đi trễ trừ điểm"
            />
          </label>
          <label>
            Sau mỗi số lần
            <input
              name="threshold"
              type="number"
              min="1"
              max="100"
              required
              defaultValue={ruleForm.threshold || 1}
            />
          </label>
          <label>
            Điểm cộng/trừ
            <input
              name="points"
              type="number"
              required
              defaultValue={ruleForm.points ?? -2}
            />
          </label>
          <div className="reward-editor-actions">
            <button
              type="button"
              className="button ghost"
              onClick={() => setRuleForm(null)}
            >
              Hủy
            </button>
            <button className="button primary">Lưu quy tắc</button>
          </div>
        </form>
      ) : null}
      {rewardForm ? (
        <form className="card reward-editor" onSubmit={saveReward}>
          <div>
            <h2>{rewardForm.id ? "Sửa quà tặng" : "Thêm quà tặng"}</h2>
            <p>Học sinh dùng điểm tích lũy để gửi yêu cầu đổi quà.</p>
          </div>
          <label>
            Tên quà
            <input
              name="title"
              required
              defaultValue={rewardForm.title || ""}
              placeholder="Ví dụ: Bút máy"
            />
          </label>
          <label>
            Điểm cần đổi
            <input
              name="cost"
              type="number"
              min="1"
              required
              defaultValue={rewardForm.cost || 20}
            />
          </label>
          <label>
            Số lượng
            <input
              name="stock"
              type="number"
              min="0"
              required
              defaultValue={rewardForm.stock ?? 10}
            />
          </label>
          <label className="wide">
            Mô tả
            <input
              name="description"
              defaultValue={rewardForm.description || ""}
              placeholder="Mô tả ngắn"
            />
          </label>
          <div className="reward-editor-actions">
            <button
              type="button"
              className="button ghost"
              onClick={() => setRewardForm(null)}
            >
              Hủy
            </button>
            <button className="button primary">Lưu quà</button>
          </div>
        </form>
      ) : null}
      <section className="card reward-table">
        <div className="card-head">
          <div>
            <h2>Điểm học sinh</h2>
            <p>Chọn “Áp dụng quy tắc” để mở danh sách quy tắc đang bật.</p>
          </div>
        </div>
        <div className="table-scroll bounded-table-scroll scroll-region">
          <table>
            <thead>
              <tr>
                <th>Hạng</th>
                <th>Học sinh / Tài khoản</th>
                <th>Lớp</th>
                <th>Điểm</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {sortedStudents.map(function (student, index) {
                return (
                  <tr key={student.id}>
                    <td>#{index + 1}</td>
                    <td>
                      <strong>{student.name}</strong>
                      <small>Tài khoản: {student.code}</small>
                    </td>
                    <td>{student.className}</td>
                    <td>
                      <b className="balance">{student.points}</b>
                    </td>
                    <td>
                      <button
                        className="button tiny primary"
                        onClick={() => setSelectedStudent(student)}
                      >
                        <Coins size={14} />
                        Áp dụng quy tắc
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
      <section className="reward-layout">
        <article className="card reward-panel">
          <div className="card-head">
            <div>
              <h2>Quy tắc cộng / trừ điểm</h2>
              <p>
                Điểm chỉ được thay đổi theo các quy tắc đã tạo; không còn nhập
                điểm thủ công.
              </p>
            </div>
          </div>
          <div className="reward-list reward-rule-scroll">
            {sortedRules.map(function (rule) {
              return (
                <div key={rule.id} className={rule.active ? "" : "disabled"}>
                  <span
                    className={
                      rule.points > 0 ? "point-badge plus" : "point-badge minus"
                    }
                  >
                    {rule.points > 0 ? "+" : ""}
                    {rule.points}
                  </span>
                  <p>
                    <strong>{rule.title}</strong>
                    <small>
                      Sau mỗi {rule.threshold} lần · {rule.trigger === "assignment_streak"
                        ? pointRuleTriggerLabels.assignment_streak
                        : pointRuleTriggerLabels.manual}
                    </small>
                  </p>
                  <button
                    className="mini-toggle"
                    onClick={() =>
                      action(
                        {
                          action: "toggle_rule",
                          id: rule.id,
                          active: !rule.active,
                        },
                        rule.active ? "Đã tắt quy tắc" : "Đã bật quy tắc",
                      )
                    }
                  >
                    {rule.active ? "Đang bật" : "Đã tắt"}
                  </button>
                  <button
                    className="icon-button"
                    title="Sửa"
                    onClick={() => setRuleForm(rule)}
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    className="icon-button delete"
                    title="Xóa"
                    onClick={() =>
                      window.confirm("Xóa quy tắc này?") &&
                      action(
                        { action: "delete_rule", id: rule.id },
                        "Đã xóa quy tắc",
                      )
                    }
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              );
            })}
            {!props.data.rules.length ? (
              <div className="empty-row">
                <Sparkles />
                <span>Chưa có quy tắc. Chọn “Thêm quy tắc”.</span>
              </div>
            ) : null}
          </div>
        </article>
        <article className="card reward-panel">
          <div className="card-head">
            <div>
              <h2>Kho quà</h2>
              <p>Điểm đổi và số lượng đều do Admin đặt.</p>
            </div>
          </div>
          <div className="reward-list reward-inventory-scroll scroll-region">
            {props.data.rewards.map(function (reward) {
              return (
                <div
                  key={reward.id}
                  className={reward.active ? "" : "disabled"}
                >
                  <span className="reward-gift">
                    <Gift size={18} />
                  </span>
                  <p>
                    <strong>{reward.title}</strong>
                    <small>
                      {reward.cost} điểm · còn {reward.stock}
                    </small>
                  </p>
                  <button
                    className="mini-toggle"
                    onClick={() =>
                      action(
                        {
                          action: "toggle_reward",
                          id: reward.id,
                          active: !reward.active,
                        },
                        reward.active ? "Đã tạm ngừng quà" : "Đã mở lại quà",
                      )
                    }
                  >
                    {reward.active ? "Đang mở" : "Đã ẩn"}
                  </button>
                  <button
                    className="icon-button"
                    title="Sửa"
                    onClick={() => setRewardForm(reward)}
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    className="icon-button delete"
                    title="Xóa"
                    onClick={() =>
                      window.confirm("Xóa quà này?") &&
                      action(
                        { action: "delete_reward", id: reward.id },
                        "Đã xóa hoặc lưu trữ quà",
                      )
                    }
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              );
            })}
            {!props.data.rewards.length ? (
              <div className="empty-row">
                <Gift />
                <span>Chưa có quà tặng.</span>
              </div>
            ) : null}
          </div>
        </article>
      </section>
      <section className="card reward-table">
        <div className="card-head">
          <div>
            <h2>Yêu cầu đổi quà</h2>
            <p>Điểm và kho đã được giữ chỗ khi học sinh gửi yêu cầu.</p>
          </div>
          <span className="count">{pending.length}</span>
        </div>
        <div className="table-scroll bounded-table-scroll scroll-region">
          <table>
            <thead>
              <tr>
                <th>Học sinh</th>
                <th>Quà</th>
                <th>Điểm</th>
                <th>Thời gian</th>
                <th>Trạng thái</th>
                <th>Xử lý</th>
              </tr>
            </thead>
            <tbody>
              {props.data.redemptions.map(function (item) {
                return (
                  <tr key={item.id}>
                    <td>
                      <strong>{item.studentName}</strong>
                      <small>{item.studentCode}</small>
                    </td>
                    <td>{item.rewardTitle}</td>
                    <td>{item.cost}</td>
                    <td>{new Date(item.createdAt).toLocaleString("vi-VN")}</td>
                    <td>
                      {item.status === "pending"
                        ? "Chờ duyệt"
                        : item.status === "approved"
                          ? "Đã duyệt"
                          : "Đã từ chối"}
                    </td>
                    <td>
                      {item.status === "pending" ? (
                        <>
                          <button
                            className="button tiny primary"
                            onClick={() =>
                              action(
                                {
                                  action: "review_redemption",
                                  id: item.id,
                                  decision: "approved",
                                },
                                "Đã duyệt đổi quà",
                              )
                            }
                          >
                            Duyệt
                          </button>
                          <button
                            className="button tiny danger"
                            onClick={() =>
                              action(
                                {
                                  action: "review_redemption",
                                  id: item.id,
                                  decision: "rejected",
                                },
                                "Đã từ chối và hoàn điểm",
                              )
                            }
                          >
                            Từ chối
                          </button>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
      {selectedStudent ? (
        <div className="modal" onMouseDown={() => { setSelectedStudent(null); setSelectedRuleIds([]); }}>
          <section
            className="form-modal rule-picker"
            onMouseDown={function (event) {
              event.stopPropagation();
            }}
          >
            <div className="modal-head">
              <div>
                <h2>Chọn quy tắc cho {selectedStudent.name}</h2>
                <p>
                  Số dư hiện tại: <strong>{selectedStudent.points} điểm</strong>
                  . Hiển thị đủ <strong>{activeRules.length} quy tắc đang bật</strong>,
                  gồm cả quy tắc thủ công và quy tắc chuỗi hoàn thành bài.
                </p>
              </div>
              <button
                className="modal-close"
                onClick={() => { setSelectedStudent(null); setSelectedRuleIds([]); }}
              >
                <X size={19} />
              </button>
            </div>
            <div className="rule-picker-list">
              {activeRules.map(function (rule) {
                  return (
                    <button
                      key={rule.id}
                      type="button"
                      className={selectedRuleIds.includes(rule.id) ? "selected" : ""}
                      onClick={() => setSelectedRuleIds(function (current) {
                        return current.includes(rule.id)
                          ? current.filter(function (id) { return id !== rule.id; })
                          : current.concat(rule.id);
                      })}
                    >
                      <span
                        className={
                          rule.points > 0
                            ? "point-badge plus"
                            : "point-badge minus"
                        }
                      >
                        {rule.points > 0 ? "+" : ""}
                        {rule.points}
                      </span>
                      <p>
                        <strong>{rule.title}</strong>
                        <small>
                          Sau mỗi {rule.threshold} lần · {pointRuleTriggerLabels[rule.trigger] || pointRuleTriggerLabels.manual}
                        </small>
                      </p>
                      <span className="rule-check" aria-hidden="true">
                        {selectedRuleIds.includes(rule.id) ? <Check size={16} /> : null}
                      </span>
                    </button>
                  );
                })}
              {!activeRules.length ? (
                <div className="empty-row">
                  <Sparkles />
                  <span>Chưa có quy tắc nào đang bật.</span>
                </div>
              ) : null}
            </div>
            <div className="rule-picker-actions">
              <span>Đã chọn: <strong>{selectedRuleIds.length}</strong></span>
              <button type="button" className="button primary" disabled={!selectedRuleIds.length || applyingRules} onClick={() => void applySelectedRules()}>
                {applyingRules ? "Đang áp dụng..." : "Áp dụng quy tắc"}
              </button>
            </div>
          </section>
        </div>
      ) : null}
    </>
  );
}

function RewardStoreAdminView(props: {
  data: RewardData;
  refresh: () => Promise<void>;
  notify: (text: string) => void;
}) {
  const [rewardForm, setRewardForm] = useState<Partial<RewardItem> | null>(
    null,
  );
  async function action(body: Record<string, unknown>, success: string) {
    const response = await fetch("/api/rewards/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const payload = await response.json();
    if (!response.ok) {
      props.notify(payload.error || "Không thể thực hiện thao tác.");
      return false;
    }
    await props.refresh();
    props.notify(success);
    return true;
  }
  async function saveReward(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const ok = await action(
      {
        action: "save_reward",
        id: rewardForm?.id,
        title: form.get("title"),
        description: form.get("description"),
        cost: Number(form.get("cost")),
        stock: Number(form.get("stock")),
        active: rewardForm?.active ?? true,
      },
      rewardForm?.id ? "Đã cập nhật quà và số điểm" : "Đã thêm quà vào kho",
    );
    if (ok) setRewardForm(null);
  }
  const activeRewards = props.data.rewards.filter(function (item) {
    return item.active;
  });
  const pending = props.data.redemptions.filter(function (item) {
    return item.status === "pending";
  });
  const stock = props.data.rewards.reduce(function (total, item) {
    return total + item.stock;
  }, 0);
  return (
    <>
      <PageTitle
        title="Kho đổi quà"
        subtitle="Admin thêm từng phần quà, đặt số điểm cần đổi và số lượng còn lại."
      >
        <button
          className="button primary"
          onClick={() => setRewardForm({ cost: 20, stock: 10, active: true })}
        >
          <Plus size={17} />
          Thêm phần quà
        </button>
      </PageTitle>
      <div className="admin-strip active">
        <Gift size={17} />
        <span>
          Học sinh sẽ thấy ngay các quà đang mở và số điểm tương ứng trên trang
          riêng của mình.
        </span>
      </div>
      <section className="reward-kpis">
        <article className="card">
          <Gift />
          <span>
            <small>Quà đang mở</small>
            <strong>{activeRewards.length}</strong>
          </span>
        </article>
        <article className="card">
          <FolderOpen />
          <span>
            <small>Tổng số lượng</small>
            <strong>{stock}</strong>
          </span>
        </article>
        <article className="card">
          <ClipboardCheck />
          <span>
            <small>Chờ duyệt đổi quà</small>
            <strong>{pending.length}</strong>
          </span>
        </article>
      </section>
      {rewardForm ? (
        <form className="card reward-editor" onSubmit={saveReward}>
          <div>
            <h2>{rewardForm.id ? "Sửa phần quà" : "Thêm phần quà mới"}</h2>
            <p>Điểm cần đổi và số lượng do Admin tự đặt.</p>
          </div>
          <label>
            Tên phần quà
            <input
              name="title"
              required
              defaultValue={rewardForm.title || ""}
              placeholder="Ví dụ: Bút máy"
            />
          </label>
          <label>
            Số điểm cần đổi
            <input
              name="cost"
              type="number"
              min="1"
              required
              defaultValue={rewardForm.cost || 20}
            />
          </label>
          <label>
            Số lượng còn lại
            <input
              name="stock"
              type="number"
              min="0"
              required
              defaultValue={rewardForm.stock ?? 10}
            />
          </label>
          <label className="wide">
            Mô tả
            <input
              name="description"
              defaultValue={rewardForm.description || ""}
              placeholder="Ví dụ: Bút máy màu xanh"
            />
          </label>
          <div className="reward-editor-actions">
            <button
              type="button"
              className="button ghost"
              onClick={() => setRewardForm(null)}
            >
              Hủy
            </button>
            <button className="button primary">
              {rewardForm.id ? "Lưu thay đổi" : "Thêm vào kho"}
            </button>
          </div>
        </form>
      ) : null}
      <section className="card reward-panel reward-store-panel">
        <div className="card-head">
          <div>
            <h2>Danh sách phần quà</h2>
            <p>Sửa điểm, số lượng, ẩn hoặc xóa phần quà bất kỳ lúc nào.</p>
          </div>
          <span className="count">{props.data.rewards.length}</span>
        </div>
        <div className="reward-list reward-inventory-scroll scroll-region">
          {props.data.rewards.map(function (reward) {
            return (
              <div key={reward.id} className={reward.active ? "" : "disabled"}>
                <span className="reward-gift">
                  <Gift size={18} />
                </span>
                <p>
                  <strong>{reward.title}</strong>
                  <small>
                    {reward.cost} điểm · còn {reward.stock} phần
                  </small>
                </p>
                <button
                  className="mini-toggle"
                  onClick={() =>
                    action(
                      {
                        action: "toggle_reward",
                        id: reward.id,
                        active: !reward.active,
                      },
                      reward.active
                        ? "Đã ẩn quà khỏi trang học sinh"
                        : "Đã mở lại phần quà",
                    )
                  }
                >
                  {reward.active ? "Đang mở" : "Đã ẩn"}
                </button>
                <button
                  className="icon-button"
                  title="Sửa phần quà"
                  onClick={() => setRewardForm(reward)}
                >
                  <Pencil size={15} />
                </button>
                <button
                  className="icon-button delete"
                  title="Xóa phần quà"
                  onClick={() =>
                    window.confirm("Xóa phần quà “" + reward.title + "”? ") &&
                    action(
                      { action: "delete_reward", id: reward.id },
                      "Đã xóa hoặc lưu trữ phần quà",
                    )
                  }
                >
                  <Trash2 size={15} />
                </button>
              </div>
            );
          })}
          {!props.data.rewards.length ? (
            <div className="empty-row">
              <Gift />
              <span>Kho chưa có quà. Chọn “Thêm phần quà”.</span>
            </div>
          ) : null}
        </div>
      </section>
      <section className="card reward-table">
        <div className="card-head">
          <div>
            <h2>Yêu cầu đổi quà</h2>
            <p>
              Duyệt để xác nhận đã trao quà; từ chối sẽ hoàn lại điểm và số
              lượng.
            </p>
          </div>
          <span className="count">{pending.length}</span>
        </div>
        <div className="table-scroll bounded-table-scroll scroll-region">
          <table>
            <thead>
              <tr>
                <th>Học sinh</th>
                <th>Phần quà</th>
                <th>Điểm đã dùng</th>
                <th>Thời gian</th>
                <th>Trạng thái</th>
                <th>Xử lý</th>
              </tr>
            </thead>
            <tbody>
              {props.data.redemptions.map(function (item) {
                return (
                  <tr key={item.id}>
                    <td>
                      <strong>{item.studentName}</strong>
                      <small>{item.studentCode}</small>
                    </td>
                    <td>{item.rewardTitle}</td>
                    <td>
                      <b className="balance">{item.cost}</b>
                    </td>
                    <td>{new Date(item.createdAt).toLocaleString("vi-VN")}</td>
                    <td>
                      {item.status === "pending"
                        ? "Chờ duyệt"
                        : item.status === "approved"
                          ? "Đã duyệt"
                          : "Đã từ chối"}
                    </td>
                    <td>
                      {item.status === "pending" ? (
                        <>
                          <button
                            className="button tiny primary"
                            onClick={() =>
                              action(
                                {
                                  action: "review_redemption",
                                  id: item.id,
                                  decision: "approved",
                                },
                                "Đã duyệt đổi quà",
                              )
                            }
                          >
                            Duyệt
                          </button>
                          <button
                            className="button tiny danger"
                            onClick={() =>
                              action(
                                {
                                  action: "review_redemption",
                                  id: item.id,
                                  decision: "rejected",
                                },
                                "Đã từ chối và hoàn điểm",
                              )
                            }
                          >
                            Từ chối
                          </button>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

export function AdminPortal() {
  const [view, setView] = useState<View>("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [navOrder, setNavOrder] = useState<View[]>(navItems.map(function(item) { return item.id; }));
  const [draggedNavId, setDraggedNavId] = useState<View | null>(null);
  const navDidDrag = useRef(false);
  const [dark, setDark] = useState(false);
  const [themeReady, setThemeReady] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSearchIndex, setSelectedSearchIndex] = useState(0);
  const [classNavigationTarget, setClassNavigationTarget] = useState<{
    classId: string;
    studentId: number;
    requestId: number;
  } | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [markingAllNotifications, setMarkingAllNotifications] = useState(false);
  const [teacherMessagesOpen, setTeacherMessagesOpen] = useState(false);
  const [teacherMessages, setTeacherMessages] = useState<AdminChatMessage[]>([]);
  const [teacherMessageThreadKey, setTeacherMessageThreadKey] = useState("");
  const [teacherMessageSearch, setTeacherMessageSearch] = useState("");
  const [teacherMessageDraft, setTeacherMessageDraft] = useState("");
  const teacherMessageThreadRef = useRef<HTMLDivElement | null>(null);
  const [sendingTeacherMessage, setSendingTeacherMessage] = useState(false);
  const [toast, setToast] = useState("");
  useEffect(function() {
    const timer = window.setTimeout(function() {
      try {
        const raw = window.localStorage.getItem("eduflow-admin-nav-order-v1");
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) return;
        const valid = parsed.filter(function(id): id is View { return navItems.some(function(item) { return item.id === id; }); });
        const missing = navItems.map(function(item) { return item.id; }).filter(function(id) { return !valid.includes(id); });
        setNavOrder(valid.concat(missing));
      } catch {}
    }, 0);
    return function() { window.clearTimeout(timer); };
  }, []);
  const [admin, setAdmin] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const [rewardData, setRewardData] = useState<RewardData>({
    students: [],
    rules: [],
    rewards: [],
    redemptions: [],
  });
  const [adminNotifications, setAdminNotifications] = useState<
    AdminNotification[]
  >([]);
  const [loginError, setLoginError] = useState("");
  const [modalType, setModalType] = useState<
    | "login"
    | "student"
    | "studentPin"
    | "assignment"
    | "class"
    | "calendar"
    | "notifications"
    | "settings"
    | null
  >(null);
  const [editingStudent, setEditingStudent] = useState<StudentRecord | null>(
    null,
  );
  const [studentDefaultClass, setStudentDefaultClass] = useState("");
  const [pinStudent, setPinStudent] = useState<StudentRecord | null>(null);
  const [attendanceTarget, setAttendanceTarget] = useState<{
    classId: string;
    className: string;
    date: string;
    startTime: string;
    endTime: string;
    sessionId?: number;
    sessionType: "regular" | "makeup";
  } | null>(null);
  const [editingAssignment, setEditingAssignment] =
    useState<AssignmentRecord | null>(null);
  const [editingClass, setEditingClass] = useState<ClassRecord | null>(null);
  const [assignmentClock, setAssignmentClock] = useState(function () {
    return Date.now();
  });
  const [studentRecords, setStudentRecords] =
    useState<StudentRecord[]>(students);
  const [assignmentRecords, setAssignmentRecords] = useState<
    AssignmentRecord[]
  >([
    {
      title: "Khảo sát hàm số bậc ba",
      className: "Toán 12A1",
      dueDate: "2026-08-11T23:59",
      maxScore: 10,
      status: "Sắp hết hạn",
      submittedCount: 20,
      totalStudents: 25,
    },
    {
      title: "Dãy số và cấp số cộng",
      className: "Toán 11A2",
      dueDate: "2026-08-14T20:00",
      maxScore: 10,
      status: "Đang mở",
      submittedCount: 17,
      totalStudents: 22,
    },
    {
      title: "Hệ thức lượng trong tam giác",
      className: "Toán 10A3",
      dueDate: "2026-08-17T22:00",
      maxScore: 10,
      status: "Đang mở",
      submittedCount: 9,
      totalStudents: 18,
    },
    {
      title: "Bài kiểm tra Hàm số",
      className: "Toán 12A1",
      dueDate: "2026-08-08T20:00",
      maxScore: 10,
      status: "Đã kết thúc",
      submittedCount: 25,
      totalStudents: 25,
    },
  ]);
  const [classRecords, setClassRecords] = useState<ClassRecord[]>([
    {
      name: "Toán 12A1",
      schedule: "Thứ 2 · Thứ 5",
      studentCount: 25,
      average: 8.2,
      attendance: 94,
      openAssignments: 3,
      tone: "indigo",
      teacher: "Lan Anh",
      room: "P.203",
      startTime: "08:00",
      endTime: "09:30",
    },
    {
      name: "Toán 11A2",
      schedule: "Thứ 3 · Thứ 6",
      studentCount: 22,
      average: 7.8,
      attendance: 91,
      openAssignments: 2,
      tone: "green",
      teacher: "Lan Anh",
      room: "P.105",
      startTime: "13:30",
      endTime: "15:00",
    },
    {
      name: "Toán 10A3",
      schedule: "Thứ 4 · Thứ 7",
      studentCount: 18,
      average: 7.5,
      attendance: 96,
      openAssignments: 1,
      tone: "orange",
      teacher: "Lan Anh",
      room: "P.301",
      startTime: "16:00",
      endTime: "17:30",
    },
  ]);
  const [contentItems, setContentItems] = useState<
    Record<string, AdminItemRecord[]>
  >({ attendance: [], grades: [], calendar: [], settings: [], folders: [] });
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const profileItem = (contentItems.settings || []).find(function (item) {
    return item.key === "profile";
  });
  const teacherProfile: TeacherProfile = {
    siteName: String(profileItem?.data.siteName || "EduFlow"),
    teacherName: String(profileItem?.data.teacherName || "Lan Anh"),
    gender: String(profileItem?.data.gender || "male") === "female" ? "female" : "male",
    schoolName: String(profileItem?.data.schoolName || "Trung tâm học tập"),
    academicYear: String(profileItem?.data.academicYear || "2026-2027"),
    defaultRoom: String(profileItem?.data.defaultRoom || "P.203"),
    logoUrl: String(profileItem?.data.logoUrl || ""),
    loginQuote: String(
      profileItem?.data.loginQuote || DEFAULT_LOGIN_QUOTE,
    ),
  };
  const liveStudentRecords = studentRecords.map(function (student) {
    let gradeSum = 0,
      gradeWeight = 0;
    const applicableGradeItems = (contentItems.grades || []).filter(
      function (item) {
        const className = String(item.data.className || student.className);
        return className === "Tất cả lớp" || className === student.className;
      },
    );
    const hasModernGradebook = applicableGradeItems.some(function (item) {
      return Array.isArray(item.data.assessments);
    });
    const seenAssessments = new Set<string>();
    applicableGradeItems.forEach(function (item) {
      if (hasModernGradebook && !Array.isArray(item.data.assessments)) return;
      const book = normalizeGradebook(
        item,
        student.className,
        "Học kỳ I - " + teacherProfile.academicYear,
        studentRecords,
      );
      book.assessments.forEach(function (assessment) {
        const signature =
          normalizedGradeKey(book.term) +
          "|" +
          normalizedGradeKey(assessment.title);
        if (seenAssessments.has(signature)) return;
        seenAssessments.add(signature);
        const score = book.scores[student.code]?.[assessment.id];
        if (
          score !== null &&
          score !== undefined &&
          assessment.maxScore > 0 &&
          assessment.weight > 0
        ) {
          gradeSum +=
            (Number(score) / assessment.maxScore) * 10 * assessment.weight;
          gradeWeight += assessment.weight;
        }
      });
    });
    let attendanceTotal = 0,
      attendancePresent = 0;
    (contentItems.attendance || []).forEach(function (item) {
      const states = (item.data.states || {}) as Record<string, string>;
      const state = states[student.code];
      if (state) {
        attendanceTotal += 1;
        if (state === "present" || state === "late") attendancePresent += 1;
      }
    });
    return Object.assign({}, student, {
      avg: gradeWeight ? Number((gradeSum / gradeWeight).toFixed(1)) : 0,
      attendance: attendanceTotal
        ? Math.round((attendancePresent / attendanceTotal) * 100)
        : 0,
      hasGrades: gradeWeight > 0,
      hasAttendance: attendanceTotal > 0,
    });
  });
  const liveAssignmentRecords = assignmentRecords.map(function (assignment) {
    const classTotal = liveStudentRecords.filter(function (student) {
      return studentBelongsToClass(student, assignment.className, assignment.classKey);
    }).length;
    return Object.assign({}, assignment, {
      totalStudents: classTotal,
      status: getAssignmentStatus(assignment.dueDate, assignmentClock),
    });
  });
  const liveClassRecords = classRecords.map(function (item) {
    const members = liveStudentRecords.filter(function (student) {
      return studentBelongsToClass(student, item.name, item.key || (item.id ? String(item.id) : undefined));
    });
    const codes = new Set(
      members.map(function (student) {
        return student.code;
      }),
    );
    const gradedMembers = members.filter(function (student) {
      return student.hasGrades;
    });
    const average = gradedMembers.length
      ? gradedMembers.reduce(function (total, student) {
          return total + student.avg;
        }, 0) / gradedMembers.length
      : 0;
    let totalMarks = 0,
      presentMarks = 0;
    (contentItems.attendance || []).forEach(function (record) {
      const states = (record.data.states || {}) as Record<string, string>;
      Object.keys(states).forEach(function (code) {
        if (codes.has(code)) {
          totalMarks += 1;
          if (states[code] === "present" || states[code] === "late")
            presentMarks += 1;
        }
      });
    });
    return Object.assign({}, item, {
      studentCount: members.length,
      average: Number(average.toFixed(1)),
      attendance: totalMarks
        ? Math.round((presentMarks / totalMarks) * 100)
        : 0,
      openAssignments: liveAssignmentRecords.filter(function (assignment) {
        return (
          assignment.className === item.name &&
          assignment.status !== "Đã kết thúc"
        );
      }).length,
      hasGrades: gradedMembers.length > 0,
      hasAttendance: totalMarks > 0,
    });
  });
  const hasSearchQuery = Boolean(normalizeSearchText(searchQuery));
  const searchMatches = hasSearchQuery
    ? searchStudents(liveStudentRecords, searchQuery)
    : [];
  const visibleSearchResults = hasSearchQuery
    ? searchMatches.slice(0, 10)
    : liveStudentRecords.slice(0, 3);
  const searchResultCount = visibleSearchResults.length;
  function notify(text: string) {
    setToast(text);
    window.setTimeout(function () {
      setToast("");
    }, 2500);
  }
  function go(next: View) {
    if (next === "classes") setClassNavigationTarget(null);
    if (next === "attendance") setAttendanceTarget(null);
    setView(next);
    setMobileOpen(false);
    if (next === "rewards" || next === "rewardstore") void loadRewards();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function openSearchStudent(student: StudentRecord) {
    const target = resolveStudentNavigationTarget(student, liveClassRecords);
    if (!target) {
      go("students");
      setSearchOpen(false);
      notify("Chưa tìm thấy lớp tương ứng của học sinh này.");
      return;
    }
    setClassNavigationTarget(function (current) {
      return {
        ...target,
        requestId: (current?.requestId || 0) + 1,
      };
    });
    setView("classes");
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
    setSearchOpen(false);
  }
  function initials(name: string) {
    return name
      .split(" ")
      .slice(-2)
      .map(function (word) {
        return word.charAt(0);
      })
      .join("")
      .toUpperCase();
  }
  function openAdminModal(
    next: "student" | "assignment",
    value?: StudentRecord | AssignmentRecord,
  ) {
    if (!admin) {
      setLoginError("");
      setModalType("login");
      return;
    }
    if (next === "student") {
      setStudentDefaultClass("");
      setEditingStudent((value as StudentRecord) || null);
      setModalType("student");
    } else {
      setEditingAssignment((value as AssignmentRecord) || null);
      setModalType("assignment");
    }
  }
  function requireAdmin() {
    setLoginError("");
    setModalType("login");
  }
  function openClassModal(value?: ClassRecord) {
    if (!admin) {
      requireAdmin();
      return;
    }
    setEditingClass(value || null);
    setModalType("class");
  }
  function openContentModal(mode: "calendar" | "notifications" | "settings") {
    if (!admin) {
      requireAdmin();
      return;
    }
    setModalType(mode);
  }
  async function loadData() {
    try {
      const kinds = [
        "classes",
        "attendance",
        "grades",
        "calendar",
        "settings",
        "folders",
      ];
      const fresh = { cache: "no-store" as RequestCache };
      const responses = await Promise.all(
        [
          fetch("/api/students", fresh),
          fetch("/api/assignments", fresh),
          fetch("/api/documents", fresh),
        ].concat(
          kinds.map(function (kind) {
            return fetch("/api/admin/items?kind=" + kind, fresh);
          }),
        ),
      );
      if (responses[0].ok) {
        const payload = await responses[0].json();
        const tones = ["violet", "blue", "pink", "orange", "green", "cyan"];
        setStudentRecords(
          payload.students.map(function (
            row: Record<string, unknown>,
            index: number,
          ) {
            return {
              id: Number(row.id),
              code: String(row.code),
              name: String(row.name),
              className: String(row.className),
              classKeys: Array.isArray(row.classKeys) ? row.classKeys.map(String) : [],
              classNames: Array.isArray(row.classNames) ? row.classNames.map(String) : [String(row.className)],
              enrollments: Array.isArray(row.enrollments) ? row.enrollments as StudentRecord["enrollments"] : [],
              avg: Number(row.averageScore),
              attendance: Number(row.attendanceRate),
              state: String(row.status),
              phone: String(row.phone || ""),
              email: String(row.email || ""),
              initials: initials(String(row.name)),
              tone: tones[index % tones.length],
            };
          }),
        );
      }
      if (responses[1].ok) {
        const payload = await responses[1].json();
        setAssignmentRecords(
          payload.assignments.map(function (row: Record<string, unknown>) {
            return {
              id: Number(row.id),
              title: String(row.title),
              className: String(row.className),
              classKey: String(row.classKey || ""),
              description: String(row.description || ""),
              dueDate: String(row.dueDate),
              maxScore: Number(row.maxScore),
              attachmentName: String(row.attachmentName || ""),
              attachmentSize: Number(row.attachmentSize || 0),
              status: String(row.status),
              submittedCount: Number(row.submittedCount),
              totalStudents: Number(row.totalStudents),
              pendingGradingCount: Number(row.pendingGradingCount || 0),
            };
          }),
        );
      }
      if (responses[2].ok) {
        const payload = await responses[2].json();
        setDocuments(payload.documents as DocumentRecord[]);
      }
      const nextItems: Record<string, AdminItemRecord[]> = {};
      for (let index = 0; index < kinds.length; index += 1) {
        const response = responses[index + 3];
        if (response.ok) {
          const payload = await response.json();
          nextItems[kinds[index]] = payload.items as AdminItemRecord[];
        }
      }
      setContentItems(function (previous) {
        return Object.assign({}, previous, nextItems);
      });
      if (nextItems.classes) {
        setClassRecords(
          nextItems.classes.map(function (item, index) {
            return {
              id: item.id,
              key: item.key,
              name: item.title,
              label: String(item.data.label || ""),
              schedule: String(item.data.schedule || "Chưa xếp lịch"),
              studentCount: Number(item.data.studentCount) || 0,
              average: Number(item.data.average) || 0,
              attendance: Number(item.data.attendance) || 0,
              openAssignments: Number(item.data.openAssignments) || 0,
              tone: String(
                item.data.tone || ["indigo", "green", "orange"][index % 3],
              ),
              teacher: String(item.data.teacher || "Lan Anh"),
              room: String(item.data.room || ""),
              startTime: String(item.data.startTime || "08:00"),
              endTime: String(item.data.endTime || "09:30"),
              schedules: Array.isArray(item.data.schedules)
                ? (item.data.schedules as Record<string, unknown>[]).map(function(schedule) { return { weekday: Number(schedule.weekday), startTime: String(schedule.startTime || ""), endTime: String(schedule.endTime || ""), room: String(schedule.room || "") }; })
                : undefined,
              logoUrl: String(item.data.logoUrl || ""),
            };
          }),
        );
      }
    } catch {
      notify("Đang hiển thị dữ liệu mẫu.");
    }
  }
  async function loadRewards() {
    try {
      const response = await fetch("/api/rewards/admin", { cache: "no-store" });
      if (response.ok) setRewardData((await response.json()) as RewardData);
    } catch {
      notify("Không thể tải dữ liệu thi đua.");
    }
  }
  function setStudentPin(student: StudentRecord) {
    if (!admin || !student.id) {
      requireAdmin();
      return;
    }
    setPinStudent(student);
    setModalType("studentPin");
  }
  async function saveStudentPin(pin: string) {
    if (!pinStudent?.id) throw new Error("Không tìm thấy học sinh cần đổi PIN.");
    const response = await fetch("/api/rewards/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "set_pin", studentId: pinStudent.id, pin }),
    });
    const payload = (await response.json()) as { error?: string };
    if (!response.ok) throw new Error(payload.error || "Không thể đổi PIN học sinh.");
    await loadRewards();
    const studentName = pinStudent.name;
    setPinStudent(null);
    setModalType(null);
    notify("Đã cập nhật PIN cho " + studentName);
  }

  async function loadNotifications() {
    try {
      const response = await fetch("/api/notifications", { cache: "no-store" });
      if (response.ok) {
        const payload = await response.json();
        setAdminNotifications(
          (payload.notifications || []) as AdminNotification[],
        );
      }
    } catch {}
  }
  async function loadTeacherMessages(): Promise<AdminChatMessage[]> {
    try {
      const response = await fetch("/api/admin/messages", { cache: "no-store" });
      if (!response.ok) return [];
      const payload = await response.json() as { messages?: AdminChatMessage[] };
      const rows = Array.isArray(payload.messages) ? payload.messages : [];
      setTeacherMessages(rows);
      return rows;
    } catch { return []; }
  }
  async function markTeacherThreadRead(threadKey: string) {
    const studentId = Number(threadKey || 0);
    if (!studentId) return;
    try {
      await fetch("/api/admin/messages", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ studentId }) });
      setTeacherMessages(function(rows) { return rows.map(function(item) { return item.studentId === studentId && item.direction === "student" ? { ...item, read: true } : item; }); });
    } catch {}
  }
  async function chooseTeacherMessageThread(threadKey: string) {
    setTeacherMessageThreadKey(threadKey);
    await markTeacherThreadRead(threadKey);
  }
  async function toggleTeacherMessages() {
    const next = !teacherMessagesOpen;
    setTeacherMessagesOpen(next);
    setNotificationsOpen(false);
    if (!next) return;
    const rows = await loadTeacherMessages();
    const unread = rows.find(function(item) { return item.direction === "student" && !item.read; });
    const fallbackMessage = rows[rows.length - 1];
    const fallbackContact = teacherMessageContacts[0];
    const preferred = teacherMessageThreadKey || String(unread?.studentId || fallbackMessage?.studentId || fallbackContact?.studentId || "");
    if (preferred) {
      setTeacherMessageThreadKey(preferred);
      await markTeacherThreadRead(preferred);
    }
  }
  async function sendTeacherReply(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const studentId = Number(teacherMessageThreadKey || 0);
    const body = teacherMessageDraft.trim();
    if (!studentId || !body || sendingTeacherMessage) return;
    setSendingTeacherMessage(true);
    try {
      const response = await fetch("/api/admin/messages", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ studentId, body }) });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Không thể gửi tin nhắn.");
      setTeacherMessageDraft("");
      await loadTeacherMessages();
    } catch (reason) { notify(reason instanceof Error ? reason.message : "Không thể gửi tin nhắn."); }
    finally { setSendingTeacherMessage(false); }
  }
  async function deleteTeacherConversation() {
    const studentId = Number(activeTeacherThread?.studentId || teacherMessageThreadKey || 0);
    if (!studentId || !activeTeacherThread) return;
    if (!window.confirm("Xóa toàn bộ cuộc hội thoại với " + activeTeacherThread.studentName + "? Hành động này không thể hoàn tác.")) return;
    try {
      const response = await fetch("/api/admin/messages", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ studentId }) });
      const payload = await response.json().catch(function() { return {}; });
      if (!response.ok) throw new Error(payload.error || "Không thể xóa cuộc hội thoại.");
      setTeacherMessageThreadKey("");
      setTeacherMessageDraft("");
      await loadTeacherMessages();
      notify("Đã xóa cuộc hội thoại với " + activeTeacherThread.studentName);
    } catch (reason) {
      notify(reason instanceof Error ? reason.message : "Không thể xóa cuộc hội thoại.");
    }
  }
  async function readAdminNotification(item: AdminNotification) {
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.id }),
    });
    setAdminNotifications(function (rows) {
      return rows.map(function (row) {
        return row.id === item.id
          ? Object.assign({}, row, { read: true })
          : row;
      });
    });
    setNotificationsOpen(false);
    if (
      navItems.some(function (nav) {
        return nav.id === item.actionView;
      })
    )
      go(item.actionView as View);
  }
  async function readAllAdminNotifications() {
    if (markingAllNotifications) return;
    setMarkingAllNotifications(true);
    try {
      const response = await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ all: true }),
      });
      if (!response.ok) throw new Error("Không thể đánh dấu thông báo.");
      setAdminNotifications(function (rows) {
        return rows.map(function (row) {
          return Object.assign({}, row, { read: true });
        });
      });
    } catch {
      notify("Không thể đánh dấu tất cả thông báo đã đọc.");
    } finally {
      setMarkingAllNotifications(false);
    }
  }
  async function login(pin: string) {
    const response = await fetch("/api/admin/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pin: pin }),
    });
    const payload = await response.json();
    if (!response.ok) {
      setLoginError(payload.error || "Không thể đăng nhập.");
      return;
    }
    setAdmin(true);
    setLoginError("");
    setModalType(null);
    await Promise.all([loadData(), loadRewards(), loadNotifications(), loadTeacherMessages()]);
    notify("Đã bật chế độ Admin");
  }
  async function logout() {
    await fetch("/api/admin/session", { method: "DELETE" });
    setAdmin(false);
    window.location.href = "/";
  }
  async function saveStudent(data: Record<string, unknown>) {
    const response = await fetch("/api/students", {
      method: data.id ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const payload = await response.json();
    if (!response.ok) {
      notify(payload.error || "Không thể lưu học sinh.");
      return;
    }
    setModalType(null);
    await loadData();
    notify(data.id ? "Đã cập nhật học sinh" : "Đã thêm học sinh mới");
  }
  async function deleteStudent(student: StudentRecord) {
    if (
      !student.id ||
      !window.confirm("Bạn có chắc muốn xóa học sinh " + student.name + "?")
    )
      return;
    const response = await fetch("/api/students", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: student.id }),
    });
    if (response.ok) {
      setStudentRecords(function (records) {
        return records.filter(function (item) {
          return item.id !== student.id;
        });
      });
      await loadData();
      notify("Đã xóa học sinh");
    } else notify("Không thể xóa học sinh.");
  }
  async function deleteAllStudents() {
    if (
      !window.confirm(
        "Xóa toàn bộ học sinh? Dữ liệu sẽ không tự xuất hiện lại.",
      )
    )
      return;
    const response = await fetch("/api/students", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ all: true }),
    });
    if (response.ok) {
      setStudentRecords([]);
      await loadData();
      notify("Đã xóa toàn bộ học sinh");
    } else notify("Không thể xóa toàn bộ học sinh.");
  }
  function exportStudentsExcel() {
    const rows = liveStudentRecords.map(function (student) {
      return {
        "Mã học sinh": student.code,
        "Họ tên": student.name,
        Lớp: (student.classNames || [student.className]).join(", "),
        "Điểm trung bình": student.hasGrades ? student.avg : "",
        "Chuyên cần (%)": student.hasAttendance ? student.attendance : "",
        "Trạng thái": student.state,
        "Số điện thoại": student.phone || "",
        Email: student.email || "",
      };
    });
    const sheet = XLSX.utils.json_to_sheet(rows, {
      header: [
        "Mã học sinh",
        "Họ tên",
        "Lớp",
        "Điểm trung bình",
        "Chuyên cần (%)",
        "Trạng thái",
        "Số điện thoại",
        "Email",
      ],
    });
    sheet["!cols"] = [
      { wch: 16 },
      { wch: 26 },
      { wch: 18 },
      { wch: 18 },
      { wch: 18 },
      { wch: 16 },
      { wch: 18 },
      { wch: 28 },
    ];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "Học sinh");
    XLSX.writeFile(
      workbook,
      teacherProfile.siteName.replace(/[^a-zA-Z0-9À-ỹ]+/g, "_") +
        "_Danh_sach_hoc_sinh.xlsx",
    );
    notify("Đã xuất tệp Excel");
  }
  async function importStudentsExcel(file: File) {
    if (!admin) {
      setLoginError("");
      setModalType("login");
      return;
    }
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json<Record<string, unknown>>(
        firstSheet,
        { defval: "" },
      );
      function pick(row: Record<string, unknown>, keys: string[]) {
        for (const key of keys) {
          if (row[key] !== undefined && row[key] !== "") return row[key];
        }
        return "";
      }
      const rows = raw
        .map(function (row) {
          return {
            code: pick(row, [
              "Mã học sinh",
              "Ma hoc sinh",
              "Mã HS",
              "Ma HS",
              "code",
              "Code",
            ]),
            name: pick(row, [
              "Họ tên",
              "Họ và tên",
              "Ho ten",
              "Tên học sinh",
              "name",
              "Name",
            ]),
            className: pick(row, [
              "Lớp",
              "Lop",
              "Lớp học",
              "className",
              "Class",
            ]),
            averageScore: pick(row, [
              "Điểm trung bình",
              "Điểm TB",
              "Diem trung binh",
              "averageScore",
              "Average",
            ]),
            attendanceRate: pick(row, [
              "Chuyên cần (%)",
              "Chuyên cần",
              "Chuyen can",
              "attendanceRate",
              "Attendance",
            ]),
            status: pick(row, ["Trạng thái", "Trang thai", "status", "Status"]),
            phone: pick(row, [
              "Số điện thoại",
              "Điện thoại",
              "So dien thoai",
              "phone",
              "Phone",
            ]),
            email: pick(row, ["Email", "email"]),
          };
        })
        .filter(function (row) {
          return (
            String(row.code).trim() &&
            String(row.name).trim() &&
            String(row.className).trim()
          );
        });
      if (!rows.length) {
        notify("Excel cần có cột Mã học sinh, Họ tên và Lớp.");
        return;
      }
      const response = await fetch("/api/students", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ students: rows }),
      });
      const payload = await response.json();
      if (!response.ok) {
        notify(payload.error || "Không thể nhập Excel.");
        return;
      }
      await loadData();
      notify("Đã nhập " + payload.imported + " học sinh từ Excel");
    } catch {
      notify("Không đọc được tệp Excel. Vui lòng kiểm tra định dạng.");
    }
  }
  function exportStudentsPdf() {
    const popup = window.open("", "_blank");
    if (!popup) {
      notify("Trình duyệt đang chặn cửa sổ xuất PDF.");
      return;
    }
    popup.opener = null;
    function escape(value: unknown) {
      return String(value ?? "").replace(/[&<>\"']/g, function (char) {
        return (
          {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '\"': "&quot;",
            "'": "&#039;",
          } as Record<string, string>
        )[char];
      });
    }
    const safeSiteName = escape(teacherProfile.siteName);
    const rows = liveStudentRecords
      .map(function (student) {
        return (
          "<tr><td>" +
          escape(student.code) +
          "</td><td>" +
          escape(student.name) +
          "</td><td>" +
          escape((student.classNames || [student.className]).join(", ")) +
          "</td><td>" +
          (student.hasGrades ? student.avg : "—") +
          "</td><td>" +
          (student.hasAttendance ? student.attendance + "%" : "—") +
          "</td><td>" +
          escape(student.state) +
          "</td></tr>"
        );
      })
      .join("");
    popup.document.write(
      "<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>" +
        safeSiteName +
        " - Báo cáo học sinh</title><style>@page{size:A4 landscape;margin:14mm}body{font:14px Arial,sans-serif;color:#18213a}h1{margin:0 0 6px}p{color:#64748b;margin:0 0 20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #dbe2ef;padding:9px;text-align:left}th{background:#eef2ff}footer{margin-top:18px;color:#64748b;font-size:12px}</style></head><body><h1>Báo cáo danh sách học sinh</h1><p>" +
        safeSiteName +
        " · " +
        new Date().toLocaleString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh" }) +
        "</p><table><thead><tr><th>Mã học sinh</th><th>Họ tên</th><th>Lớp</th><th>Điểm TB</th><th>Chuyên cần</th><th>Trạng thái</th></tr></thead><tbody>" +
        rows +
        "</tbody></table><footer>Tổng cộng: " +
        liveStudentRecords.length +
        " học sinh</footer><script>window.onload=function(){window.print()}<\/script></body></html>",
    );
    popup.document.close();
    notify("Đã mở bản in — chọn “Lưu dưới dạng PDF”");
  }
  async function saveAssignment(data: Record<string, unknown>, file: File | null, removeAttachment: boolean) {
    const className = String(data.className || "");
    const course = liveClassRecords.find(function(item) { return item.name === className; });
    const totalStudents = liveStudentRecords.filter(function (student) {
      return studentBelongsToClass(student, className, course?.key || (course?.id ? String(course.id) : undefined));
    }).length;
    const response = await fetch("/api/assignments", {
      method: data.id ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.assign({}, data, { totalStudents, classKey: course?.key || "" })),
    });
    const payload = await response.json();
    if (!response.ok) {
      notify(payload.error || "Không thể lưu bài tập.");
      return;
    }
    const assignmentId = Number(payload.assignment?.id || data.id);
    if (assignmentId && removeAttachment) {
      await fetch("/api/assignments/" + assignmentId + "/attachment", { method: "DELETE" });
    }
    if (assignmentId && file) {
      const upload = new FormData();
      upload.set("file", file);
      const uploadResponse = await fetch("/api/assignments/" + assignmentId + "/attachment", { method: "POST", body: upload });
      if (!uploadResponse.ok) {
        const uploadPayload = await uploadResponse.json();
        notify(uploadPayload.error || "Đã lưu bài tập nhưng chưa thể tải tệp đính kèm.");
        return;
      }
    }
    setModalType(null);
    await loadData();
    notify(data.id ? "Đã cập nhật bài tập" : "Đã tạo bài tập mới");
  }
  async function deleteAssignment(assignment: AssignmentRecord) {
    if (
      !assignment.id ||
      !window.confirm(
        "Bạn có chắc muốn xóa bài tập “" + assignment.title + "”?",
      )
    )
      return;
    const response = await fetch("/api/assignments", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: assignment.id }),
    });
    if (response.ok) {
      setAssignmentRecords(function (records) {
        return records.filter(function (item) {
          return item.id !== assignment.id;
        });
      });
      await loadData();
      notify("Đã xóa bài tập");
    } else notify("Không thể xóa bài tập.");
  }
  async function deleteAllAssignments() {
    if (
      !window.confirm("Xóa toàn bộ bài tập? Dữ liệu sẽ không tự xuất hiện lại.")
    )
      return;
    const response = await fetch("/api/assignments", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ all: true }),
    });
    if (response.ok) {
      setAssignmentRecords([]);
      await loadData();
      notify("Đã xóa toàn bộ bài tập");
    } else notify("Không thể xóa toàn bộ bài tập.");
  }
  async function saveClass(item: ClassRecord) {
    const oldName = editingClass?.name;
    const response = await fetch("/api/admin/items", {
      method: item.id ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: item.id,
        kind: "classes",
        key: item.key,
        title: item.name,
        data: {
          schedule: item.schedule,
          label: String(item.label || "").replace(/\s+/g, " ").trim().slice(0, 10),
          studentCount: item.studentCount,
          average: item.average,
          attendance: item.attendance,
          openAssignments: item.openAssignments,
          tone: item.tone,
          teacher: item.teacher,
          room: item.room,
          startTime: item.startTime,
          endTime: item.endTime,
          schedules: item.schedules || [],
          logoUrl: item.logoUrl || "",
        },
      }),
    });
    const payload = await response.json();
    if (!response.ok) {
      notify(payload.error || "Không thể lưu lớp học.");
      return;
    }
    const storedClassKey = String(payload.item?.key || item.key || "");
    const scheduleResponse = await fetch("/api/course-schedules", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ classKey: storedClassKey, className: item.name, schedules: item.schedules || [] }),
    });
    if (!scheduleResponse.ok) {
      const schedulePayload = await scheduleResponse.json();
      notify(schedulePayload.error || "Đã lưu lớp nhưng chưa thể cập nhật lịch học.");
      return;
    }
    if (oldName && oldName !== item.name) {
      await Promise.all(
        liveStudentRecords
          .filter(function (student) {
            return student.className === oldName && student.id;
          })
          .map(function (student) {
            return fetch("/api/students", {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                id: student.id,
                name: student.name,
                code: student.code,
                className: item.name,
                averageScore: student.avg,
                attendanceRate: student.attendance,
                status: student.state,
                phone: student.phone || "",
                email: student.email || "",
              }),
            });
          }),
      );
      const renamedTotal = liveStudentRecords.filter(function (student) {
        return student.className === oldName;
      }).length;
      await Promise.all(
        assignmentRecords
          .filter(function (assignment) {
            return assignment.className === oldName && assignment.id;
          })
          .map(function (assignment) {
            return fetch("/api/assignments", {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                id: assignment.id,
                title: assignment.title,
                className: item.name,
                description: assignment.description || "",
                dueDate: assignment.dueDate,
                maxScore: assignment.maxScore,
                status: assignment.status,
                totalStudents: renamedTotal,
              }),
            });
          }),
      );
      const relatedItems = (contentItems.grades || [])
        .concat(contentItems.attendance || [])
        .filter(function (record) {
          return String(record.data.className || "") === oldName;
        });
      await Promise.all(
        relatedItems.map(function (record) {
          return fetch("/api/admin/items", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              id: record.id,
              title: record.title.replace(oldName, item.name),
              data: Object.assign({}, record.data, { className: item.name }),
            }),
          });
        }),
      );
      await fetch("/api/documents", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fromFolder: oldName, toFolder: item.name }),
      });
      const linkedFolders = (contentItems.folders || []).filter(function (record) {
        return record.title === oldName || String(record.data.className || "") === oldName;
      });
      await Promise.all(linkedFolders.map(function (record) {
        return fetch("/api/admin/items", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: record.id,
            title: item.name,
            data: { ...record.data, className: item.name },
          }),
        });
      }));
    }
    setModalType(null);
    setEditingClass(null);
    await loadData();
    notify(item.id ? "Đã cập nhật lớp học" : "Đã tạo lớp học mới");
  }
  async function deleteClass(item: ClassRecord) {
    if (
      !item.id ||
      !window.confirm(
        "Xóa lớp “" +
          item.name +
          "”? Lịch sử điểm danh của lớp sẽ bị xóa vĩnh viễn; học sinh và dữ liệu học tập còn lại sẽ chuyển sang Chưa xếp lớp.",
      )
    )
      return;
    const response = await fetch("/api/admin/items", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.id }),
    });
    if (response.ok) {
      await Promise.all(
        liveStudentRecords
          .filter(function (student) {
            return studentBelongsToClass(student, item.name, item.key || (item.id ? String(item.id) : undefined)) && student.id;
          })
          .map(function (student) {
            return fetch("/api/enrollments", {
              method: "DELETE",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                studentId: student.id,
                classKey: item.key || String(item.id || item.name),
              }),
            });
          }),
      );
      await Promise.all(
        assignmentRecords
          .filter(function (assignment) {
            return assignment.className === item.name && assignment.id;
          })
          .map(function (assignment) {
            return fetch("/api/assignments", {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                id: assignment.id,
                title: assignment.title,
                className: "Chưa xếp lớp",
                description: assignment.description || "",
                dueDate: assignment.dueDate,
                maxScore: assignment.maxScore,
                status: assignment.status,
                totalStudents: 0,
              }),
            });
          }),
      );
      const relatedGradeItems = (contentItems.grades || []).filter(function (record) {
        return String(record.data.classKey || record.data.classId || "") === String(item.key || item.id || "") || String(record.data.className || "") === item.name;
      });
      await Promise.all(
        relatedGradeItems.map(function (record) {
          return fetch("/api/admin/items", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              id: record.id,
              title: record.title.replace(item.name, "Chưa xếp lớp"),
              data: Object.assign({}, record.data, {
                className: "Chưa xếp lớp",
                classKey: "",
              }),
            }),
          });
        }),
      );
      const relatedAttendanceItems = (contentItems.attendance || []).filter(function (record) {
        return String(record.data.classKey || record.data.classId || "") === String(item.key || item.id || "") || String(record.data.className || "") === item.name;
      });
      await Promise.all(
        relatedAttendanceItems.map(function (record) {
          return fetch("/api/admin/items", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: record.id }),
          });
        }),
      );
      const archived = await ensureDocumentArchiveFolder();
      if (archived) await fetch("/api/documents", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fromFolder: item.name, toFolder: "Tài liệu lưu trữ" }),
      });
      const linkedFolders = (contentItems.folders || []).filter(function (record) {
        return record.title === item.name || String(record.data.className || "") === item.name;
      });
      await Promise.all(linkedFolders.map(function (record) {
        return fetch("/api/admin/items", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: record.id }),
        });
      }));
      setClassRecords(function (records) {
        return records.filter(function (record) {
          return record.id !== item.id;
        });
      });
      await loadData();
      notify("Đã xóa lớp, xóa lịch sử điểm danh và chuyển dữ liệu còn lại sang Chưa xếp lớp");
    } else notify("Không thể xóa lớp học.");
  }
  async function putAdminItem(
    kind: string,
    key: string,
    title: string,
    data: Record<string, unknown>,
    message: string,
  ) {
    const response = await fetch("/api/admin/items", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, key, title, data }),
    });
    const payload = await response.json();
    if (!response.ok) {
      notify(payload.error || "Không thể lưu dữ liệu.");
      return false;
    }
    await loadData();
    notify(message);
    return true;
  }
  async function saveAttendance(session: AttendanceSession) {
    const key =
      session.storageKey ||
      [
        "attendance",
        session.date,
        session.className,
        session.startTime,
        session.endTime,
      ].join("|");
    const attendanceData = Object.assign({}, session);
    delete attendanceData.storageKey;
    const title =
      "Điểm danh " +
      new Date(session.date + "T00:00:00").toLocaleDateString("vi-VN") +
      " · " +
      session.className +
      " · " +
      session.startTime +
      "–" +
      session.endTime;
    await putAdminItem(
      "attendance",
      key,
      title,
      attendanceData,
      "Đã lưu kết quả điểm danh",
    );
  }
  async function saveGrades(data: GradebookData) {
    const key = ["gradebook", data.className, data.term].join("|");
    await putAdminItem(
      "grades",
      key,
      "Sổ điểm " + data.className + " · " + data.term,
      data,
      "Đã lưu sổ điểm; điểm trung bình đã được tính lại tự động",
    );
  }
  async function saveSettings(profile: TeacherProfile) {
    await putAdminItem(
      "settings",
      "profile",
      "Hồ sơ giáo viên",
      profile,
      "Đã cập nhật tên giáo viên và cài đặt",
    );
  }
  async function saveContent(title: string, data: Record<string, unknown>) {
    const mode = modalType;
    if (mode !== "calendar" && mode !== "notifications" && mode !== "settings") return;
    const response = await fetch("/api/admin/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: mode, title, data }),
    });
    const payload = await response.json();
    if (!response.ok) {
      notify(payload.error || "Không thể lưu nội dung.");
      return;
    }
    setModalType(null);
    await loadData();
    notify("Đã lưu nội dung mới");
  }
  async function deleteContent(item: AdminItemRecord) {
    if (!window.confirm("Xóa “" + item.title + "”?")) return;
    const response = await fetch("/api/admin/items", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.id }),
    });
    if (response.ok) {
      await loadData();
      notify("Đã xóa nội dung");
    } else notify("Không thể xóa nội dung.");
  }
  async function deleteAttendance(item: AdminItemRecord) {
    if (
      !window.confirm(
        "Xóa “" + item.title + "”?",
      )
    )
      return;
    const response = await fetch("/api/admin/items", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.id }),
    });
    if (!response.ok) {
      notify("Không thể xóa điểm danh.");
      return;
    }
    await loadData();
    notify("Đã xóa điểm danh");
  }
  async function createFolder() {
    if (!admin) {
      requireAdmin();
      return;
    }
    const title = window.prompt("Tên thư mục mới");
    if (!title?.trim()) return;
    const cleanTitle = title.trim();
    const existing = (contentItems.folders || []).find(function (item) {
      return item.title.toLocaleLowerCase("vi") === cleanTitle.toLocaleLowerCase("vi");
    });
    if (existing?.data.hidden === true && liveClassRecords.some(function (item) { return item.name === cleanTitle; })) {
      const restored = await fetch("/api/admin/items", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: existing.id }) });
      if (restored.ok) { await loadData(); notify("Đã khôi phục thư mục lớp " + cleanTitle); }
      else notify("Không thể khôi phục thư mục lớp.");
      return;
    }
    if (existing || liveClassRecords.some(function (item) { return item.name.toLocaleLowerCase("vi") === cleanTitle.toLocaleLowerCase("vi"); })) {
      notify("Thư mục này đã tồn tại.");
      return;
    }
    const response = await fetch("/api/admin/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: "folders", title: cleanTitle, data: {} }),
    });
    if (response.ok) {
      await loadData();
      notify("Đã tạo thư mục");
    } else notify("Không thể tạo thư mục.");
  }
  async function ensureDocumentArchiveFolder() {
    const existing = (contentItems.folders || []).find(function (item) {
      return item.title === "Tài liệu lưu trữ" && item.data.hidden !== true;
    });
    if (existing) return true;
    const response = await fetch("/api/admin/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: "folders", key: "document-archive", title: "Tài liệu lưu trữ", data: { teacherOnly: true } }),
    });
    return response.ok;
  }
  async function deleteDocumentFolder(folderName: string, folderItem?: AdminItemRecord) {
    if (!admin || folderName === "Tài liệu chung") return;
    const fileCount = documents.filter(function (document) { return document.folder === folderName; }).length;
    const message = fileCount
      ? "Xóa thư mục “" + folderName + "”? " + fileCount + " tài liệu sẽ được chuyển vào Tài liệu lưu trữ và chỉ giáo viên nhìn thấy."
      : "Xóa thư mục “" + folderName + "”?";
    if (!window.confirm(message)) return;
    if (fileCount) {
      const archived = await ensureDocumentArchiveFolder();
      if (!archived) { notify("Không thể tạo thư mục lưu trữ an toàn."); return; }
      const moved = await fetch("/api/documents", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fromFolder: folderName, toFolder: "Tài liệu lưu trữ" }) });
      if (!moved.ok) { notify("Không thể chuyển tài liệu sang thư mục lưu trữ."); return; }
    }
    const linkedClass = liveClassRecords.find(function (item) { return item.name === folderName; });
    let response: Response;
    if (linkedClass) {
      response = await fetch("/api/admin/items", {
        method: folderItem ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(folderItem ? {
          id: folderItem.id,
          title: folderName,
          data: { ...folderItem.data, linkedClass: true, hidden: true, className: folderName, classKey: linkedClass.key || linkedClass.id || linkedClass.name },
        } : {
          kind: "folders",
          key: "hidden-class-folder|" + String(linkedClass.key || linkedClass.id || linkedClass.name),
          title: folderName,
          data: { linkedClass: true, hidden: true, className: folderName, classKey: linkedClass.key || linkedClass.id || linkedClass.name },
        }),
      });
    } else if (folderItem) {
      response = await fetch("/api/admin/items", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: folderItem.id }) });
    } else {
      response = new Response(null, { status: 404 });
    }
    if (!response.ok) { notify("Không thể xóa thư mục."); return; }
    await loadData();
    notify(fileCount ? "Đã xóa thư mục và lưu trữ tài liệu cho giáo viên" : "Đã xóa thư mục");
  }
  async function uploadDocument(
    file: File,
    folder: string,
    onProgress: (progress: number) => void,
  ) {
    if (!admin) {
      requireAdmin();
      throw new Error("Vui lòng đăng nhập Admin.");
    }
    if (file.size > 10 * 1024 * 1024)
      throw new Error("Tệp vượt quá giới hạn 10 MB.");
    const prepareResponse = await fetch("/api/documents/upload-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: file.name,
        size: file.size,
        contentType: file.type || "application/octet-stream",
      }),
    });
    const prepared = (await prepareResponse.json()) as {
      uploadUrl?: string;
      objectKey?: string;
      contentType?: string;
      error?: string;
    };
    if (!prepareResponse.ok || !prepared.uploadUrl || !prepared.objectKey)
      throw new Error(prepared.error || "Không thể chuẩn bị tải trực tiếp R2.");
    await new Promise<void>(function (resolve, reject) {
      const request = new XMLHttpRequest();
      request.open("PUT", prepared.uploadUrl || "");
      request.setRequestHeader(
        "Content-Type",
        prepared.contentType || "application/octet-stream",
      );
      request.upload.onprogress = function (event) {
        if (event.lengthComputable)
          onProgress(Math.min(99, Math.round((event.loaded / event.total) * 100)));
      };
      request.onerror = function () {
        reject(new Error("Mất kết nối khi tải tài liệu."));
      };
      request.onload = function () {
        if (request.status >= 200 && request.status < 300) resolve();
        else
          reject(
            new Error(
              request.status === 403
                ? "R2 từ chối tải lên. Kiểm tra Access Key hoặc CORS."
                : "R2 không thể nhận tệp (mã " + request.status + ").",
            ),
          );
      };
      request.send(file);
    });
    onProgress(99);
    const completeResponse = await fetch("/api/documents/complete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        objectKey: prepared.objectKey,
        name: file.name,
        folder,
        size: file.size,
        contentType: prepared.contentType,
      }),
    });
    const completed = (await completeResponse.json()) as { error?: string };
    if (!completeResponse.ok)
      throw new Error(completed.error || "Không thể ghi nhận tài liệu đã tải.");
    onProgress(100);
    await loadData();
  }
  async function deleteDocument(document: DocumentRecord) {
    if (!window.confirm("Xóa tài liệu “" + document.name + "”?")) return;
    const response = await fetch("/api/documents", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: document.id }),
    });
    if (response.ok) {
      await loadData();
      notify("Đã xóa tài liệu");
    } else notify("Không thể xóa tài liệu.");
  }
  useEffect(function () {
    function handler(event: KeyboardEvent) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setSearchQuery("");
        setSelectedSearchIndex(0);
        setSearchOpen(true);
      }
      if (event.key === "Escape") {
        setSearchOpen(false);
      }
    }
    window.addEventListener("keydown", handler);
    return function () {
      window.removeEventListener("keydown", handler);
    };
  }, []);
  useEffect(
    function () {
      if (!themeReady) return;
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      window.localStorage.setItem("teacher-theme", dark ? "dark" : "light");
    },
    [dark, themeReady],
  );
  useEffect(function () {
    const saved = window.localStorage.getItem("teacher-theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const timer = window.setTimeout(function () {
      setDark(saved ? saved === "dark" : prefersDark);
      setThemeReady(true);
    }, 0);
    return function () {
      window.clearTimeout(timer);
    };
  }, []);
  useEffect(
    function () {
      document.title = teacherProfile.siteName + " - Quản lý học sinh";
    },
    [teacherProfile.siteName],
  );
  useEffect(function () {
    const timer = window.setInterval(function () {
      setAssignmentClock(Date.now());
    }, 60000);
    return function () {
      window.clearInterval(timer);
    };
  }, []);
  // The initial load is deferred so this effect only schedules external synchronization.
  useEffect(function () {
    const timer = window.setTimeout(function () {
      void fetch("/api/admin/session")
        .then(function (response) {
          return response.json();
        })
        .then(async function (payload) {
          if (!payload.admin) {
            window.location.replace("/");
            return;
          }
          setAdmin(true);
          await Promise.all([loadData(), loadRewards(), loadNotifications(), loadTeacherMessages()]);
        })
        .catch(function () {
          window.location.replace("/");
        })
        .finally(function () {
          setAuthChecked(true);
        });
    }, 0);
    return function () {
      window.clearTimeout(timer);
    };
  // Initial authenticated bootstrap is intentionally run once per mount.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(
    function () {
      if (!admin) return;
      const refreshVisible = function () {
        if (document.visibilityState !== "visible") return;
        void Promise.all([loadNotifications(), loadRewards(), loadTeacherMessages()]);
      };
      const timer = window.setInterval(refreshVisible, 8000);
      const onVisibility = function () { if (document.visibilityState === "visible") refreshVisible(); };
      document.addEventListener("visibilitychange", onVisibility);
      return function () {
        window.clearInterval(timer);
        document.removeEventListener("visibilitychange", onVisibility);
      };
    },
    // The interval is recreated only when authentication changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [admin],
  );
  function content() {
    const attendanceItems = contentItems.attendance || [];
    const dashboardAttendanceDate = localDateInTimeZone();
    const attendanceSaved: Record<string, string> = {};
    attendanceItems
      .filter(function (item) {
        return String(item.data.date || "") === dashboardAttendanceDate;
      })
      .sort(function (a, b) {
        return String(a.updatedAt || a.createdAt || "").localeCompare(
          String(b.updatedAt || b.createdAt || ""),
        );
      })
      .forEach(function (item) {
        Object.assign(
          attendanceSaved,
          (item.data.states || {}) as Record<string, string>,
        );
      });
    const attendanceLabel = new Date(dashboardAttendanceDate + "T00:00:00Z").toLocaleDateString("vi-VN", {
      timeZone: "UTC",
      day: "numeric",
      month: "numeric",
      year: "numeric",
    });
    switch (view) {
      case "dashboard":
        return (
          <Dashboard
            go={go}
            onExportPdf={exportStudentsPdf}
            students={liveStudentRecords}
            classes={liveClassRecords}
            assignments={liveAssignmentRecords}
            documents={documents.length}
            attendanceStates={attendanceSaved}
            attendanceLabel={attendanceLabel}
            teacherName={teacherProfile.teacherName}
            teacherGender={teacherProfile.gender}
            siteName={teacherProfile.siteName}
          />
        );
      case "students":
        return (
          <StudentsView
            records={liveStudentRecords}
            admin={admin}
            onAdd={() => openAdminModal("student")}
            onEdit={(student) => openAdminModal("student", student)}
            onSetPin={setStudentPin}
            onDelete={deleteStudent}
            onDeleteAll={deleteAllStudents}
            onImport={importStudentsExcel}
            onExportExcel={exportStudentsExcel}
            onExportPdf={exportStudentsPdf}
          />
        );
      case "classes":
        return (
          <ClassHubView
            key={classNavigationTarget?.requestId || "class-hub"}
            records={liveClassRecords}
            students={liveStudentRecords}
            rewardStudents={rewardData.students}
            navigationTarget={classNavigationTarget}
            admin={admin}
            onAdd={() => openClassModal()}
            onEdit={openClassModal}
            onEditStudent={(student) => openAdminModal("student", student)}
            onCreateStudent={(course) => { setStudentDefaultClass(course.name); setEditingStudent(null); setModalType("student"); }}
            onDelete={deleteClass}
            onRefresh={loadData}
            notify={notify}
          />
        );
      case "attendance":
        return (
          <AttendanceView
            key={
              attendanceItems
                .map(function (item) {
                  return item.updatedAt || item.id;
                })
                .join("|") +
              liveStudentRecords.length +
              liveClassRecords.length +
              (attendanceTarget ? JSON.stringify(attendanceTarget) : "")
            }
            records={liveStudentRecords}
            classes={liveClassRecords}
            items={attendanceItems}
            admin={admin}
            onSave={saveAttendance}
            onDelete={deleteAttendance}
            onRequireAdmin={requireAdmin}
            notify={notify}
            target={attendanceTarget}
          />
        );
      case "teachingSchedule":
        return (
          <TeachingScheduleView
            classes={liveClassRecords}
            admin={admin}
            notify={notify}
            onAttendance={function (target) {
              setAttendanceTarget(target);
              setView("attendance");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        );
      case "assignments":
        return (
          <AssignmentsView
            records={liveAssignmentRecords}
            admin={admin}
            onAdd={() => openAdminModal("assignment")}
            onEdit={(assignment) => openAdminModal("assignment", assignment)}
            onDelete={deleteAssignment}
            onDeleteAll={deleteAllAssignments}
            onRefresh={loadData}
          />
        );
      case "grades":
        return (
          <GradesView
            key={
              (contentItems.grades || [])
                .map(function (item) {
                  return item.updatedAt || item.id;
                })
                .join("|") +
              liveStudentRecords.length +
              liveClassRecords.length
            }
            records={liveStudentRecords}
            classes={liveClassRecords}
            items={contentItems.grades || []}
            academicYear={teacherProfile.academicYear}
            siteName={teacherProfile.siteName}
            admin={admin}
            onSave={saveGrades}
            onDelete={deleteContent}
            onRequireAdmin={requireAdmin}
            notify={notify}
          />
        );
      case "rewards":
        return (
          <RewardsAdminView
            data={rewardData}
            refresh={loadRewards}
            notify={notify}
          />
        );
      case "rewardstore":
        return (
          <RewardStoreAdminView
            data={rewardData}
            refresh={loadRewards}
            notify={notify}
          />
        );
      case "analytics":
        return (
          <AnalyticsView
            students={liveStudentRecords}
            classes={liveClassRecords}
            assignments={liveAssignmentRecords}
            attendanceItems={attendanceItems}
            gradeItems={contentItems.grades || []}
            onExportPdf={exportStudentsPdf}
            go={go}
          />
        );
      case "calendar":
        return (
          <CalendarView
            items={contentItems.calendar || []}
            classes={liveClassRecords}
            admin={admin}
            onAdd={() => openContentModal("calendar")}
            onDelete={deleteContent}
          />
        );
      case "documents":
        return (
          <DocumentsView
            documents={documents}
            folders={contentItems.folders || []}
            classes={liveClassRecords}
            admin={admin}
            onUpload={uploadDocument}
            onDelete={deleteDocument}
            onCreateFolder={createFolder}
            onDeleteFolder={deleteDocumentFolder}
            onRequireAdmin={requireAdmin}
          />
        );
      case "settings":
        return (
          <SettingsView
            profile={teacherProfile}
            admin={admin}
            onSave={saveSettings}
            onRequireAdmin={requireAdmin}
            notify={notify}
          />
        );
      default:
        return (
          <Dashboard
            go={go}
            onExportPdf={exportStudentsPdf}
            students={liveStudentRecords}
            classes={liveClassRecords}
            assignments={liveAssignmentRecords}
            documents={documents.length}
            attendanceStates={attendanceSaved}
            attendanceLabel={attendanceLabel}
            teacherName={teacherProfile.teacherName}
            teacherGender={teacherProfile.gender}
            siteName={teacherProfile.siteName}
          />
        );
    }
  }
  const teacherMessageContactMap = new Map<number, { key: string; studentId: number; studentName: string; studentCode: string; teacher: string }>();
  liveStudentRecords.forEach(function(student) {
    if (!student.id) return;
    const activeEnrollment = (student.enrollments || []).find(function(enrollment) { return enrollment.status === "active"; });
    if (!activeEnrollment) return;
    const classRecord = liveClassRecords.find(function(item) { return (item.key || String(item.id || "")) === activeEnrollment.classKey; });
    teacherMessageContactMap.set(student.id, {
      key: String(student.id),
      studentId: student.id,
      studentName: student.name,
      studentCode: student.code,
      teacher: classRecord?.teacher || teacherProfile.teacherName || "Giáo viên",
    });
  });
  teacherMessages.forEach(function(item) {
    if (!teacherMessageContactMap.has(item.studentId)) teacherMessageContactMap.set(item.studentId, { key: String(item.studentId), studentId: item.studentId, studentName: item.studentName, studentCode: item.studentCode, teacher: item.teacher });
  });
  const teacherMessageContacts = Array.from(teacherMessageContactMap.values()).sort(function(a, b) { return a.studentName.localeCompare(b.studentName, "vi"); });
  const teacherMessageThreadMap = new Map<string, { key: string; studentId: number; studentName: string; studentCode: string; teacher: string; lastAt: string; lastBody: string; unread: number }>();
  teacherMessageContacts.forEach(function(contact) { teacherMessageThreadMap.set(contact.key, { ...contact, lastAt: "", lastBody: "", unread: 0 }); });
  teacherMessages.forEach(function(item) {
    const key = String(item.studentId);
    const current = teacherMessageThreadMap.get(key);
    const unread = (current?.unread || 0) + (item.direction === "student" && !item.read ? 1 : 0);
    if (!current || item.createdAt >= current.lastAt) teacherMessageThreadMap.set(key, { key, studentId: item.studentId, studentName: item.studentName, studentCode: item.studentCode, teacher: item.teacher, lastAt: item.createdAt, lastBody: item.body, unread });
    else teacherMessageThreadMap.set(key, { ...current, unread });
  });
  const teacherMessageThreads = Array.from(teacherMessageThreadMap.values()).sort(function(a, b) {
    if (a.unread !== b.unread) return b.unread - a.unread;
    if (a.lastAt !== b.lastAt) return b.lastAt.localeCompare(a.lastAt);
    return a.studentName.localeCompare(b.studentName, "vi");
  });
  const normalizedTeacherMessageSearch = normalizeSearchText(teacherMessageSearch);
  const visibleTeacherMessageThreads = teacherMessageThreads.filter(function(item) {
    if (!normalizedTeacherMessageSearch) return true;
    return normalizeSearchText(item.studentName + " " + item.studentCode).includes(normalizedTeacherMessageSearch);
  });
  const activeTeacherThread = teacherMessageThreads.find(function(item) { return item.key === teacherMessageThreadKey; }) || teacherMessageThreads[0];
  const activeTeacherConversation = teacherMessages.filter(function(item) { return activeTeacherThread && item.studentId === activeTeacherThread.studentId; });
  const unreadTeacherMessageCount = teacherMessages.filter(function(item) { return item.direction === "student" && !item.read; }).length;
  useEffect(function() {
    if (!teacherMessagesOpen) return;
    const node = teacherMessageThreadRef.current;
    if (!node) return;
    const frame = window.requestAnimationFrame(function() { node.scrollTop = node.scrollHeight; });
    return function() { window.cancelAnimationFrame(frame); };
  }, [teacherMessagesOpen, teacherMessageThreadKey, activeTeacherConversation.length]);
  const orderedNavItems = navOrder.map(function(id) { return navItems.find(function(item) { return item.id === id; }); }).filter(Boolean).concat(navItems.filter(function(item) { return !navOrder.includes(item.id); })) as typeof navItems;

  function saveNavOrder(next: View[]) {
    setNavOrder(next);
    try { window.localStorage.setItem("eduflow-admin-nav-order-v1", JSON.stringify(next)); } catch {}
  }
  function moveNavItem(source: View, target: View) {
    if (source === target) return;
    const current = orderedNavItems.map(function(item) { return item.id; });
    const sourceIndex = current.indexOf(source);
    const targetIndex = current.indexOf(target);
    if (sourceIndex < 0 || targetIndex < 0) return;
    current.splice(sourceIndex, 1);
    current.splice(targetIndex, 0, source);
    saveNavOrder(current);
  }

  if (!authChecked || !admin)
    return (
      <div className="route-loading">
        <span>
          <GraduationCap />
        </span>
        <strong>Đang mở trang Admin...</strong>
      </div>
    );
  return (
    <div className={collapsed ? "app-shell collapsed" : "app-shell"}>
      <a className="skip-link" href="#teacher-main-content">Bỏ qua điều hướng</a>
      <aside className={mobileOpen ? "sidebar mobile-open" : "sidebar"}>
        <div className="brand">
          <span>
            {teacherProfile.logoUrl ? (
              <img
                src={teacherProfile.logoUrl}
                alt={"Logo " + teacherProfile.siteName}
              />
            ) : (
              <GraduationCap size={23} />
            )}
          </span>
          {collapsed ? null : (
            <div>
              <strong>{teacherProfile.siteName}</strong>
              <small>Teacher Workspace</small>
            </div>
          )}
          <button aria-label="Đóng menu" onClick={() => setMobileOpen(false)}>
            <X size={20} />
          </button>
        </div>
        <nav>
          {orderedNavItems.map(function (item) {
            const Icon = item.icon;
            const badge =
              item.id === "assignments"
                ? liveAssignmentRecords.filter(function(assignment) { return assignment.status !== "Đã kết thúc"; }).length
                : 0;
            return (
              <button
                key={item.id}
                draggable={!collapsed}
                data-dragging={draggedNavId === item.id ? "true" : undefined}
                className={view === item.id ? "active" : ""}
                aria-current={view === item.id ? "page" : undefined}
                onDragStart={function(event) { navDidDrag.current = true; setDraggedNavId(item.id); event.dataTransfer.effectAllowed = "move"; event.dataTransfer.setData("text/plain", item.id); }}
                onDragOver={function(event) { if (draggedNavId && draggedNavId !== item.id) { event.preventDefault(); event.dataTransfer.dropEffect = "move"; } }}
                onDrop={function(event) { event.preventDefault(); const source = (draggedNavId || event.dataTransfer.getData("text/plain")) as View; if (source) moveNavItem(source, item.id); setDraggedNavId(null); window.setTimeout(function() { navDidDrag.current = false; }, 0); }}
                onDragEnd={function() { setDraggedNavId(null); window.setTimeout(function() { navDidDrag.current = false; }, 0); }}
                onClick={function() { if (navDidDrag.current) return; go(item.id); }}
                title={collapsed ? item.label : "Giữ và kéo để đổi thứ tự · " + item.label}
              >
                {collapsed ? null : <span className="sidebar-drag-handle" aria-hidden="true"><GripVertical size={13} /></span>}
                <Icon size={19} />
                {collapsed ? null : <span>{item.label}</span>}
                {!collapsed && badge > 0 ? <em>{badge}</em> : null}
              </button>
            );
          })}
        </nav>
        <div className="sidebar-bottom">
          {admin ? (
            <button className="mobile-teacher-logout" onClick={function() { void logout(); }}>
              <LogOut size={17} />
              <span>Đăng xuất</span>
            </button>
          ) : null}
          <button
            className="collapse-button"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? (
              <ChevronRight size={17} />
            ) : (
              <>
                <ChevronLeft size={17} />
                <span>Thu gọn menu</span>
              </>
            )}
          </button>
        </div>
      </aside>
      {mobileOpen ? (
        <button
          className="overlay"
          aria-label="Đóng menu"
          onClick={() => setMobileOpen(false)}
        />
      ) : null}
      <div className="main-area">
        <header className="topbar">
          <button
            className="mobile-menu"
            aria-label="Mở menu"
            onClick={() => setMobileOpen(true)}
          >
            <Menu size={21} />
          </button>
          <button
            className="global-search"
            onClick={() => {
              setSearchQuery("");
              setSelectedSearchIndex(0);
              setSearchOpen(true);
            }}
          >
            <Search size={18} />
            <span>Tìm học sinh, lớp học, bài tập...</span>
            <kbd>Ctrl K</kbd>
          </button>
          <div className="top-actions">
            <button
              className={admin ? "admin-button active" : "admin-button"}
              onClick={() => (admin ? logout() : setModalType("login"))}
            >
              {admin ? (
                <>
                  <ShieldCheck size={16} />
                  Admin
                  <LogOut size={14} />
                </>
              ) : (
                <>
                  <LogIn size={16} />
                  Đăng nhập Admin
                </>
              )}
            </button>
            <div className="teacher-message-wrap">
              <button className="icon-button teacher-message-button" aria-label="Tin nhắn học sinh" title="Tin nhắn học sinh" onClick={() => void toggleTeacherMessages()}>
                <MessageSquare size={19} />
                {unreadTeacherMessageCount ? <b>{unreadTeacherMessageCount}</b> : null}
              </button>
              {teacherMessagesOpen ? <section className="teacher-message-popover messenger-teacher-chat">
                <header><div><strong>Tin nhắn học sinh</strong></div><button aria-label="Đóng tin nhắn" onClick={() => setTeacherMessagesOpen(false)}><X size={17} /></button></header>
                <div className="teacher-message-messenger">
                  <aside className="teacher-message-inbox">
                    <label className="teacher-message-search"><Search size={15} /><input value={teacherMessageSearch} onChange={function(event) { setTeacherMessageSearch(event.target.value); }} placeholder="Tìm học sinh..." /></label>
                    <div className="teacher-message-conversation-list scroll-region">{visibleTeacherMessageThreads.map(function(thread) { return <button type="button" key={thread.key} className={activeTeacherThread?.key === thread.key ? "active" : ""} onClick={function() { void chooseTeacherMessageThread(thread.key); }}><span className="message-contact-avatar">{thread.studentName.split(/\s+/).slice(-2).map(function(part) { return part.charAt(0); }).join("").toUpperCase().slice(0, 2)}</span><span><strong>{thread.studentName}</strong><small>{thread.lastBody || thread.studentCode}</small></span>{thread.unread ? <b>{thread.unread}</b> : thread.lastAt ? <time>{new Date(thread.lastAt).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" })}</time> : null}</button>; })}{!visibleTeacherMessageThreads.length ? <div className="teacher-message-list-empty"><Search /><span>Không tìm thấy học sinh phù hợp.</span></div> : null}</div>
                  </aside>
                  <section className="teacher-message-chat-panel">
                    {activeTeacherThread ? <div className="teacher-message-chat-head"><span className="message-contact-avatar">{activeTeacherThread.studentName.split(/\s+/).slice(-2).map(function(part) { return part.charAt(0); }).join("").toUpperCase().slice(0, 2)}</span><span><strong>{activeTeacherThread.studentName}</strong><small>{activeTeacherThread.studentCode}</small></span><button type="button" className="icon-button delete teacher-message-delete" title="Xóa cuộc hội thoại" aria-label="Xóa cuộc hội thoại" onClick={function() { void deleteTeacherConversation(); }}><Trash2 size={16} /></button></div> : null}
                    <div className="teacher-message-thread" ref={teacherMessageThreadRef}>{activeTeacherConversation.map(function(item) { return <article key={item.id} className={item.direction === "teacher" ? "mine" : "student"}><div><strong>{item.direction === "teacher" ? "Bạn" : item.studentName}</strong><p>{item.body}</p><time>{new Date(item.createdAt).toLocaleString("vi-VN")}</time></div></article>; })}{!activeTeacherConversation.length ? <div className="teacher-message-empty"><MessageSquare /><strong>{activeTeacherThread ? "Chưa có tin nhắn" : "Chọn học sinh"}</strong><span>{activeTeacherThread ? "Bạn có thể gửi tin nhắn đầu tiên cho " + activeTeacherThread.studentName + "." : "Tìm hoặc chọn một học sinh ở danh sách bên trái để bắt đầu."}</span></div> : null}</div>
                    <form className="teacher-message-compose" onSubmit={sendTeacherReply}><div className="message-compose-field"><textarea value={teacherMessageDraft} onChange={(event) => setTeacherMessageDraft(event.target.value)} rows={2} maxLength={4000} disabled={!activeTeacherThread || sendingTeacherMessage} placeholder={activeTeacherThread ? "Nhắn cho " + activeTeacherThread.studentName + "..." : "Chọn học sinh để nhắn tin"} /><EmojiPicker disabled={!activeTeacherThread || sendingTeacherMessage} onPick={function(emoji) { setTeacherMessageDraft(function(current) { return (current + emoji).slice(0, 4000); }); }} label="Thêm emoji vào tin nhắn" /></div><button type="submit" disabled={!activeTeacherThread || !teacherMessageDraft.trim() || sendingTeacherMessage} aria-label="Gửi tin nhắn"><Send size={17} /></button></form>
                  </section>
                </div>
              </section> : null}
            </div>
            <button
              className="icon-button"
              aria-label={dark ? "Chuyển sang giao diện sáng" : "Chuyển sang giao diện tối"}
              title={dark ? "Giao diện sáng" : "Giao diện tối"}
              onClick={() => setDark(!dark)}
            >
              {dark ? <Sun size={19} /> : <Moon size={19} />}
            </button>
            <div className="notice-wrap">
              <button
                className="icon-button notice-button"
                aria-label="Mở thông báo"
                onClick={() => { setNotificationsOpen(!notificationsOpen); setTeacherMessagesOpen(false); }}
              >
                <Bell size={19} />
                {adminNotifications.filter(function (item) {
                  return !item.read;
                }).length ? (
                  <b>
                    {
                      adminNotifications.filter(function (item) {
                        return !item.read;
                      }).length
                    }
                  </b>
                ) : null}
              </button>
              {notificationsOpen ? (
                <div className="notice-popover">
                  <header>
                    <strong>Thông báo</strong>
                    <button
                      aria-label="Đóng thông báo"
                      onClick={() => setNotificationsOpen(false)}
                    >
                      <X size={17} />
                    </button>
                  </header>
                  <div className="notice-action v26-notice-compose">
                    <button
                      className="mark-all"
                      onClick={function() {
                        setNotificationsOpen(false);
                        openContentModal("notifications");
                      }}
                    >
                      <Plus size={15} /> Gửi thông báo
                    </button>
                  </div>
                  {adminNotifications.some(function (item) {
                    return !item.read;
                  }) ? (
                    <div className="notice-action">
                      <button
                        className="mark-all"
                        disabled={markingAllNotifications}
                        onClick={() => void readAllAdminNotifications()}
                      >
                        {markingAllNotifications
                          ? "Đang đánh dấu..."
                          : "Đánh dấu tất cả đã đọc"}
                      </button>
                    </div>
                  ) : null}
                  <div className="notification-list">
                    {adminNotifications.map(function (item) {
                      return (
                        <button
                          className={
                            item.read ? "notice-item" : "notice-item unread"
                          }
                          key={item.id}
                          onClick={() => void readAdminNotification(item)}
                        >
                          <Bell />
                          <span>
                            <strong>{item.title}</strong>
                            <small>{item.body}</small>
                            <time>
                              {new Date(item.createdAt).toLocaleString("vi-VN")}
                            </time>
                          </span>
                        </button>
                      );
                    })}
                    {!adminNotifications.length ? (
                      <p>
                        <CheckCircle2 />
                        <span>
                          <strong>Chưa có thông báo mới</strong>
                          <small>Yêu cầu đổi quà sẽ tự xuất hiện tại đây.</small>
                        </span>
                      </p>
                    ) : null}
                  </div>
                </div>
              ) : null}
            </div>
            <i className="divider" />
            <button className="profile" onClick={() => go("settings")}>
              <Avatar initials={initials(teacherProfile.teacherName) || "GV"} />
              <span>
                <strong>{teacherProfile.teacherName}</strong>
                <small>{admin ? "Quản trị viên" : "Người xem"}</small>
              </span>
              <Settings size={14} />
            </button>
          </div>
        </header>
        <main className="content" id="teacher-main-content">
          <div key={view} className="view-transition">
            {content()}
          </div>
          <footer className="site-footer">
            <span>© 2026 {teacherProfile.siteName}</span>
            <span>Hỗ trợ · Quyền riêng tư · Điều khoản</span>
          </footer>
        </main>
      </div>
      {searchOpen ? (
        <div className="modal" onMouseDown={() => setSearchOpen(false)}>
          <div
            className="search-box"
            onMouseDown={function (event) {
              event.stopPropagation();
            }}
          >
            <label>
              <Search size={20} />
              <input
                autoFocus
                placeholder={"Tìm kiếm trên " + teacherProfile.siteName + "..."}
                value={searchQuery}
                onChange={function (event) {
                  setSearchQuery(event.target.value);
                  setSelectedSearchIndex(0);
                }}
                onKeyDown={function (event) {
                  if (event.key === "ArrowDown") {
                    event.preventDefault();
                    setSelectedSearchIndex(function (current) {
                      return Math.min(current + 1, Math.max(0, searchResultCount - 1));
                    });
                  }
                  if (event.key === "ArrowUp") {
                    event.preventDefault();
                    setSelectedSearchIndex(function (current) {
                      return Math.max(0, current - 1);
                    });
                  }
                  if (event.key === "Enter" && visibleSearchResults[selectedSearchIndex]) {
                    event.preventDefault();
                    openSearchStudent(visibleSearchResults[selectedSearchIndex]);
                  }
                }}
              />
              <kbd>ESC</kbd>
            </label>
            <small>{hasSearchQuery ? "KẾT QUẢ TÌM KIẾM" : "TÌM NHANH"}</small>
            <div className="search-results">
              {visibleSearchResults.map(function (student, index) {
                return (
                  <button
                    key={student.code}
                    className={index === selectedSearchIndex ? "active" : ""}
                    onMouseEnter={() => setSelectedSearchIndex(index)}
                    onClick={() => openSearchStudent(student)}
                  >
                    <Avatar initials={student.initials} tone={student.tone} />
                    <span>
                      <strong>{student.name}</strong>
                      <small>
                        {student.code} · {student.className}
                      </small>
                    </span>
                    <ChevronRight size={16} />
                  </button>
                );
              })}
              {hasSearchQuery && !visibleSearchResults.length ? (
                <div className="search-empty">
                  <strong>Không tìm thấy học sinh phù hợp.</strong>
                  <span>Thử tìm bằng tên, mã học sinh hoặc lớp.</span>
                </div>
              ) : null}
            </div>
            <footer>↑↓ để di chuyển · Enter để chọn</footer>
          </div>
        </div>
      ) : null}
      {modalType === "login" ? (
        <AdminLoginModal
          close={() => setModalType(null)}
          submit={login}
          error={loginError}
        />
      ) : null}
      {modalType === "student" ? (
        <StudentFormModal
          value={editingStudent}
          defaultClassName={studentDefaultClass}
          classes={liveClassRecords}
          close={() => setModalType(null)}
          save={saveStudent}
        />
      ) : null}
      {modalType === "studentPin" && pinStudent ? (
        <StudentPinModal
          student={pinStudent}
          hasPin={Boolean(rewardData.students.find(function(item) { return item.id === pinStudent.id; })?.hasPin)}
          close={function() { setPinStudent(null); setModalType(null); }}
          save={saveStudentPin}
        />
      ) : null}
      {modalType === "assignment" ? (
        <AssignmentFormModal
          value={editingAssignment}
          classNames={liveClassRecords.map(function (item) {
            return item.name;
          })}
          close={() => setModalType(null)}
          save={saveAssignment}
        />
      ) : null}
      {modalType === "class" ? (
        <ClassFormModal
          value={editingClass}
          defaultTeacher={teacherProfile.teacherName}
          close={() => setModalType(null)}
          save={saveClass}
        />
      ) : null}
      {modalType === "calendar" || modalType === "notifications" ? (
        <ContentFormModal
          mode={modalType}
          classes={liveClassRecords}
          students={liveStudentRecords}
          close={() => setModalType(null)}
          save={saveContent}
        />
      ) : null}
      {toast ? (
        <div className="toast">
          <CheckCircle2 size={18} />
          {toast}
        </div>
      ) : null}
    </div>
  );
}

export default function LoginGateway() {
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [brandLogo, setBrandLogo] = useState("");
  const [brandName, setBrandName] = useState("");
  const [loginQuote, setLoginQuote] = useState(DEFAULT_LOGIN_QUOTE);
  const [brandReady, setBrandReady] = useState(false);
  const [standaloneSessionChecked, setStandaloneSessionChecked] = useState(false);

  useEffect(function () {
    const iosNavigator = navigator as Navigator & { standalone?: boolean };
    const standalone = window.matchMedia?.("(display-mode: standalone)").matches === true || iosNavigator.standalone === true;
    if (!standalone) {
      setStandaloneSessionChecked(true);
      return;
    }
    let active = true;
    void fetch("/api/student/session", { cache: "no-store", credentials: "include" })
      .then(function(response) { return response.json(); })
      .then(function(payload) {
        if (!active) return;
        if (payload?.authenticated) {
          window.location.replace("/student?source=pwa");
          return;
        }
        setStandaloneSessionChecked(true);
      })
      .catch(function() {
        if (active) setStandaloneSessionChecked(true);
      });
    return function() { active = false; };
  }, []);

  useEffect(function () {
    void fetch("/api/admin/items?kind=settings", { cache: "no-store" })
      .then(function (response) {
        return response.json();
      })
      .then(function (payload) {
        const profile = (payload.items || []).find(function (
          item: AdminItemRecord,
        ) {
          return item.key === "profile";
        });
        const nextName = String(profile?.data.siteName || "PHMT MATH");
        setBrandLogo(String(profile?.data.logoUrl || ""));
        setBrandName(nextName);
        setLoginQuote(
          String(profile?.data.loginQuote || DEFAULT_LOGIN_QUOTE),
        );
        document.title = nextName + " - Đăng nhập";
      })
      .catch(function () {
        setBrandName("PHMT MATH");
        document.title = "PHMT MATH - Đăng nhập";
      })
      .finally(function () {
        setBrandReady(true);
      });
  }, []);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const adminLogin = username.trim().toLowerCase() === "admin";
    const response = await fetch(
      adminLogin ? "/api/admin/session" : "/api/student/session",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(adminLogin ? { pin } : { code: username, pin }),
      },
    );
    const payload = await response.json().catch(function () {
      return {};
    });
    if (!response.ok) {
      setError(payload.error || "Tên tài khoản hoặc mã PIN không đúng.");
      setLoading(false);
      return;
    }
    window.location.href = adminLogin ? "/admin" : "/student";
  }
  if (!brandReady || !standaloneSessionChecked) {
    return (
      <main className="login-brand-loading" aria-label="Đang tải cổng học tập">
        <span><GraduationCap size={28} /></span>
      </main>
    );
  }
  return (
    <main className="login-gateway">
      <section className="login-welcome">
        <div className="gateway-brand">
          <span>
            {brandLogo ? (
              <img src={brandLogo} alt={"Logo " + brandName} />
            ) : (
              <GraduationCap size={27} />
            )}
          </span>
          <strong>{brandName}</strong>
        </div>
        <div>
          <div className="gateway-portal-title">CỔNG HỌC TẬP</div>
          <blockquote className="gateway-quote">
            “{loginQuote}”
          </blockquote>
        </div>
        <div className="gateway-features">
          <span>
            <CheckCircle2 />
            Quản lý học tập tập trung
          </span>
          <span>
            <TrendingUp />
            Theo dõi tiến độ minh bạch
          </span>
          <span>
            <ShieldCheck />
            Dữ liệu cá nhân được bảo vệ
          </span>
        </div>
      </section>
      <section className="login-side">
        <form onSubmit={submit}>
          <div className="login-mark">
            {brandLogo ? (
              <img src={brandLogo} alt={"Logo " + brandName} />
            ) : (
              <GraduationCap />
            )}
          </div>
          <h2>Đăng nhập {brandName}</h2>
          <p>
            Dùng tài khoản <strong>admin</strong> hoặc mã học sinh do giáo viên
            cấp.
          </p>
          <label>
            Tên tài khoản / Mã học sinh
            <div>
              <Users size={18} />
              <input
                value={username}
                onChange={function (event) {
                  setUsername(event.target.value);
                }}
                required
                autoComplete="username"
                placeholder="HS24001"
              />
            </div>
          </label>
          <label>
            Mã PIN
            <div>
              <KeyRound size={18} />
              <input
                value={pin}
                onChange={function (event) {
                  setPin(event.target.value.replace(/\D/g, "").slice(0, 6));
                }}
                required
                inputMode="numeric"
                autoComplete="current-password"
                placeholder="••••••"
              />
            </div>
          </label>
          {error ? (
            <div className="login-error">
              <AlertTriangle size={16} />
              {error}
            </div>
          ) : null}
          <button disabled={loading}>
            {loading ? "Đang kiểm tra..." : "Đăng nhập"}
            <ChevronRight size={18} />
          </button>
        </form>
      </section>
    </main>
  );
}
