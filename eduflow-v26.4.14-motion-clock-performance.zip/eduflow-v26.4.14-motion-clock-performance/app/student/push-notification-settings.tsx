"use client";

import { BellRing, CheckCircle2, ShieldAlert, Smartphone, XCircle } from "lucide-react";
import { useEffect, useState } from "react";

type PushStatus = "loading" | "enabled" | "disabled" | "blocked" | "unsupported" | "install-required";
type Props = { toast: (message: string) => void };

type NavigatorWithStandalone = Navigator & { standalone?: boolean; setAppBadge?: (count?: number) => Promise<void>; clearAppBadge?: () => Promise<void> };

function base64UrlToUint8Array(value: string): Uint8Array {
  const padding = "=".repeat((4 - value.length % 4) % 4);
  const base64 = (value + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = window.atob(base64);
  return Uint8Array.from(raw, function(character) { return character.charCodeAt(0); });
}

function isIosDevice(): boolean {
  const nav = navigator as NavigatorWithStandalone;
  return /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1) || nav.standalone === true;
}

function isStandalone(): boolean {
  const nav = navigator as NavigatorWithStandalone;
  return window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
}

function supported(): boolean {
  return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
}

async function registerWorker(): Promise<ServiceWorkerRegistration> {
  await navigator.serviceWorker.register("/sw.js", { scope: "/" });
  return navigator.serviceWorker.ready;
}

async function syncSubscription(subscription: PushSubscription): Promise<void> {
  const value = subscription.toJSON();
  const response = await fetch("/api/student/push", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      endpoint: value.endpoint || subscription.endpoint,
      keys: value.keys || {},
      userAgent: navigator.userAgent,
      platform: navigator.platform || "",
    }),
  });
  if (!response.ok) {
    const payload = await response.json().catch(function() { return {}; }) as { error?: string };
    throw new Error(payload.error || "Không thể lưu thiết bị nhận thông báo.");
  }
}

export default function PushNotificationSettings(props: Props) {
  const [status, setStatus] = useState<PushStatus>("loading");
  const [busy, setBusy] = useState(false);

  async function refreshStatus() {
    if (!supported()) { setStatus("unsupported"); return; }
    if (Notification.permission === "denied") { setStatus("blocked"); return; }
    if (isIosDevice() && !isStandalone()) { setStatus("install-required"); return; }
    try {
      const registration = await registerWorker();
      const subscription = await registration.pushManager.getSubscription();
      if (Notification.permission === "granted" && subscription) {
        try {
          await syncSubscription(subscription);
          setStatus("enabled");
        } catch {
          // A browser subscription alone is not enough: the server must know it
          // and have VAPID configured, otherwise background delivery cannot work.
          setStatus("disabled");
        }
      } else {
        setStatus("disabled");
      }
    } catch {
      setStatus("disabled");
    }
  }

  useEffect(function() {
    const timer = window.setTimeout(function() { void refreshStatus(); }, 0);
    return function() { window.clearTimeout(timer); };
  // Run once when the settings panel mounts.
  }, []);

  async function enablePush() {
    if (busy) return;
    if (!supported()) { setStatus("unsupported"); props.toast("Trình duyệt này chưa hỗ trợ Web Push."); return; }
    if (isIosDevice() && !isStandalone()) {
      setStatus("install-required");
      props.toast("Trên iPhone/iPad, hãy Thêm vào Màn hình chính rồi mở PHMT MATH từ biểu tượng đó để bật thông báo.");
      return;
    }
    if (Notification.permission === "denied") { setStatus("blocked"); return; }

    setBusy(true);
    try {
      // Keep the permission prompt directly attached to this user click. This is required by iOS Home Screen Web Push.
      const permission = await Notification.requestPermission();
      if (permission === "denied") { setStatus("blocked"); return; }
      if (permission !== "granted") { setStatus("disabled"); return; }

      const registration = await registerWorker();
      const configResponse = await fetch("/api/student/push", { cache: "no-store" });
      const config = await configResponse.json().catch(function() { return {}; }) as { publicKey?: string; error?: string };
      if (!configResponse.ok || !config.publicKey) throw new Error(config.error || "Web Push chưa được cấu hình trên máy chủ.");
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: base64UrlToUint8Array(config.publicKey) as BufferSource,
        });
      }
      await syncSubscription(subscription);
      setStatus("enabled");
      props.toast("Đã bật thông báo Web Push cho thiết bị này.");
    } catch (error) {
      setStatus(String(Notification.permission) === "denied" ? "blocked" : "disabled");
      props.toast(error instanceof Error ? error.message : "Không thể bật thông báo Web Push.");
    } finally {
      setBusy(false);
    }
  }

  async function disablePush() {
    if (busy || !supported()) return;
    setBusy(true);
    try {
      const registration = await registerWorker();
      const subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        await fetch("/api/student/push", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ endpoint: subscription.endpoint }),
        }).catch(function() {});
        await subscription.unsubscribe();
      }
      setStatus("disabled");
      props.toast("Đã tắt Web Push trên thiết bị này.");
    } catch {
      props.toast("Không thể tắt Web Push. Vui lòng thử lại.");
    } finally {
      setBusy(false);
    }
  }

  const label = status === "enabled" ? "Đã bật" : status === "blocked" ? "Bị trình duyệt chặn" : "Chưa bật";
  const description = status === "enabled"
    ? "Thiết bị này có thể nhận thông báo khi PHMT MATH không mở, tùy giới hạn của hệ điều hành."
    : status === "blocked"
      ? "Quyền thông báo đã bị chặn. Hãy mở cài đặt Safari/hệ thống để cho phép lại rồi quay lại đây."
      : status === "install-required"
        ? "Trên iPhone/iPad: Safari → Chia sẻ → Thêm vào Màn hình chính, sau đó mở PHMT MATH từ biểu tượng mới và bật tại đây."
        : status === "unsupported"
          ? "Trình duyệt hiện tại chưa cung cấp Web Push cho website này. Các chức năng học tập vẫn hoạt động bình thường."
          : "Sau khi bật, EDUFLOW sẽ tự gửi khi có bài tập, lịch kiểm tra, điểm/nhận xét, tin nhắn, thay đổi điểm thi đua và Pomodoro hoàn thành.";
  const StatusIcon = status === "enabled" ? CheckCircle2 : status === "blocked" ? XCircle : status === "install-required" ? Smartphone : BellRing;

  return (
    <div className="student-push-settings">
      <div className="student-push-status-row">
        <span className={"student-push-status-icon " + status}><StatusIcon /></span>
        <div><strong>{label}</strong></div>
        <em className={status === "enabled" ? "enabled" : status === "blocked" ? "blocked" : "disabled"}>{label}</em>
      </div>
      <p>{description}</p>
      {status === "install-required" ? <div className="student-push-ios-note"><Smartphone /><span><strong>iPhone / iPad</strong><small>Web Push chỉ được yêu cầu quyền khi chạy từ biểu tượng đã Add to Home Screen.</small></span></div> : null}
      {status === "blocked" ? <div className="student-push-ios-note warning"><ShieldAlert /><span><strong>Quyền đang bị chặn</strong><small>Website không thể tự mở lại hộp xin quyền sau khi bạn đã chặn.</small></span></div> : null}
      <div className="student-push-actions">
        {status === "enabled"
          ? <button type="button" className="button soft" disabled={busy} onClick={function() { void disablePush(); }}>{busy ? "Đang tắt..." : "Tắt thông báo"}</button>
          : <button type="button" className="button primary" disabled={busy || status === "blocked" || status === "unsupported"} onClick={function() { void enablePush(); }}>{busy ? "Đang bật..." : status === "install-required" ? "Bật sau khi Add to Home Screen" : "Bật thông báo"}</button>}
      </div>
    </div>
  );
}
