"use client";
/* eslint-disable @next/next/no-img-element -- user-uploaded logos and QR images are served by authenticated API routes */

import {
  ArrowLeft,
  BarChart3,
  Bell,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
  Clock3,
  Coins,
  Download,
  Eye,
  ExternalLink,
  FileText,
  FolderOpen,
  Gift,
  GraduationCap,
  History,
  Home,
  LogOut,
  MessageSquare,
  Moon,
  Paperclip,
  Send,
  Settings,
  Sun,
  Trophy,
  UploadCloud,
  X,
} from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { getAssignmentStatus } from "../../lib/assignment-status";
import { isDraftSubmissionStatus, isStudentSubmittedStatus, isTeacherCompletedStatus } from "../../lib/assignment-submission";
import PetFocusCompanion from "./pet-focus-companion";
import PushNotificationSettings from "./push-notification-settings";
import { FileViewerModal, type FileViewerTarget } from "../file-viewer-modal";
import { EmojiPicker } from "../emoji-picker";

type CourseTab = "overview" | "schedule" | "documents" | "assignments" | "progress";
type HomeTab = "courses" | "schedule";
type Schedule = { id: number; weekday: number; startTime: string; endTime: string; room: string };
type Session = { id: number; classKey?: string; className?: string; sessionType: string; sessionDate: string; startTime: string; endTime: string; note: string };
type Course = {
  id: number;
  key: string;
  name: string;
  label: string;
  teacher: string;
  room: string;
  tone: string;
  logoUrl: string;
  schedules: Schedule[];
  upcomingSessions: Session[];
  pendingAssignments: number;
  unreadNotifications: number;
  pendingMakeupSessions?: number;
};
type SubmissionFile = { id: number; fileName: string; fileSize: number; contentType: string };
type DirectSubmissionUpload = { objectKey: string; fileName: string; fileSize: number; contentType: string };
type Submission = { id: number; submittedAt: string; responseText: string; fileName: string; fileSize: number; contentType: string; files?: SubmissionFile[]; status: string; score: number | null; feedback: string; gradedAt: string | null; updatedAt: string };
type Assignment = {
  id: number;
  title: string;
  className: string;
  description: string;
  dueDate: string;
  maxScore: number;
  status: string;
  attachmentName: string;
  attachmentSize: number;
  attachmentType: string;
  teacherCompletedAt?: string | null;
  submission: Submission | null;
};
type ChatMessage = {
  id: number;
  classKey: string;
  className: string;
  teacher: string;
  direction: "student" | "teacher";
  body: string;
  createdAt: string;
  read: boolean;
};
type PortalData = {
  student: { id: number; code: string; name: string; className: string; status: string };
  site: { siteName: string; logoUrl: string; schoolName: string };
  courses: Course[];
  course?: Course;
  points: number;
  average?: number | null;
  attendanceRate?: number | null;
  assignments: Assignment[];
  submissions: number[];
  attendance: { id: number; date: string; startTime: string; endTime: string; status: string; sessionType: string; note: string }[];
  gradebooks: { title: string; term: string; assessments: { id: string; title: string; maxScore: number; weight: number; date: string; score: number | null }[] }[];
  notifications: { id: number; title: string; body: string; createdAt: string; read: boolean; actionView: string; courseKey: string; courseName: string }[];
  calendar: { id: number; title: string; date: string; type: string; details: string }[];
  documents: { id: number; name: string; folder: string; size: number; contentType: string; createdAt: string }[];
  comments: { id: number; content: string; date: string; type: string; creator: string }[];
  sessions: Session[];
  transactions: { id: number; delta: number; reason: string; createdAt: string }[];
  rewards: { id: number; title: string; description: string; cost: number; stock: number; active: boolean }[];
  redemptions: { id: number; rewardTitle: string; cost: number; status: string; createdAt: string }[];
};

const EMPTY: PortalData = {
  student: { id: 0, code: "", name: "", className: "", status: "" },
  site: { siteName: "EduFlow", logoUrl: "", schoolName: "" },
  courses: [], points: 0, assignments: [], submissions: [], attendance: [], gradebooks: [], notifications: [], calendar: [], documents: [], comments: [], sessions: [], transactions: [], rewards: [], redemptions: [],
};
const TAB_ITEMS: Array<[CourseTab, string, typeof Home]> = [
  ["overview", "Tổng quan", Home],
  ["schedule", "Lịch kiểm tra", CalendarDays],
  ["documents", "Tài liệu", FolderOpen],
  ["assignments", "Bài tập", BookOpen],
  ["progress", "Điểm / Quá trình", BarChart3],
];
const ATTENDANCE_LABELS: Record<string, string> = { present: "Có mặt", late: "Đi trễ", allowed: "Vắng có phép", absent: "Vắng không phép" };
const WEEKDAY_LABELS = ["", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"];

function formatDate(value: string): string {
  if (!value) return "Chưa có ngày";
  const date = new Date(value.includes("T") ? value : value + "T00:00:00");
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("vi-VN");
}

function formatDateTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const time = date.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", hour12: false });
  const day = date.toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" });
  return time + " " + day;
}

function RichAssignmentDescription(props: { text: string; className?: string }) {
  const parts = props.text.split(/(https?:\/\/[^\s]+)/g);
  return (
    <p className={props.className || ""}>
      {parts.map(function(part, index) {
        if (!/^https?:\/\//i.test(part)) return <span key={index}>{part}</span>;
        return <a key={index} className="lms-inline-link" href={part} target="_blank" rel="noreferrer noopener" aria-label="Mở liên kết bài tập trong tab mới"><ExternalLink />Mở liên kết</a>;
      })}
    </p>
  );
}

function formatSize(value: number): string {
  if (value < 1024) return value + " B";
  if (value < 1024 * 1024) return (value / 1024).toFixed(1) + " KB";
  return (value / 1024 / 1024).toFixed(1) + " MB";
}

async function responseErrorMessage(response: Response, fallback: string): Promise<string> {
  const text = await response.text().catch(function() { return ""; });
  let message = "";
  if (text) {
    try {
      const payload = JSON.parse(text) as { error?: unknown };
      if (typeof payload.error === "string") message = payload.error;
    } catch {
      if (text.length <= 240 && !/<html/i.test(text)) message = text.trim();
    }
  }
  if (!message && response.status === 413) message = "Tệp bài nộp vượt giới hạn tải lên. Tổng dung lượng tối đa là 10 MB.";
  return message || fallback;
}

function initials(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(-2).map(function(word) { return word.charAt(0); }).join("").toUpperCase();
}

function assignmentLabel(item: Assignment, clock: number): { text: string; tone: string } {
  if (item.submission?.status === "graded") return { text: "Đã chấm", tone: "graded" };
  if (item.submission?.status === "submitted") return { text: "Đã nộp", tone: "submitted" };
  if (isDraftSubmissionStatus(item.submission?.status)) return { text: "Đang chỉnh sửa", tone: "pending" };
  if (item.teacherCompletedAt || isTeacherCompletedStatus(item.submission?.status)) return { text: "GV đánh dấu hoàn thành", tone: "submitted" };
  if (getAssignmentStatus(item.dueDate, clock) === "Đã kết thúc") return { text: "Quá hạn", tone: "overdue" };
  return { text: "Chưa nộp", tone: "pending" };
}

function CourseCard(props: { course: Course; open: (key: string) => void }) {
  const scheduleSummary = props.course.schedules.length ? props.course.schedules.map(function(item) { return WEEKDAY_LABELS[item.weekday] + " " + item.startTime + " - " + item.endTime; }).join(" · ") : "Chưa xếp lịch";
  return (
    <article className={"lms-course-card tone-" + props.course.tone}>
      <div className="lms-course-cover">
        {props.course.logoUrl ? <img src={props.course.logoUrl} alt={"Logo " + props.course.name} /> : <BookOpen />}
        {props.course.label ? <span>{props.course.label}</span> : null}
      </div>
      <div className="lms-course-content">
        <h2>{props.course.name}</h2>
        <p>GV {props.course.teacher}</p>
        <dl>
          <div><dt><CalendarDays /></dt><dd className="lms-course-schedule-summary">{scheduleSummary}</dd></div>
        </dl>
        <div className="lms-course-badges">
          {props.course.pendingAssignments ? <span className="pending">{props.course.pendingAssignments} bài cần nộp</span> : <span className="complete">Đã hoàn thành bài hiện có</span>}
          {props.course.pendingMakeupSessions ? <span className="makeup">Có lịch học bù</span> : null}
        </div>
        <button className="button primary" onClick={function() { props.open(props.course.key); }}>Vào môn học <ChevronRight /></button>
      </div>
    </article>
  );
}



type TimetableEvent = {
  key: string;
  classKey: string;
  startTime: string;
  endTime: string;
  title: string;
  room: string;
  tone: string;
  kind: "regular" | "makeup";
  note?: string;
  stackIndex?: number;
  stackCount?: number;
};

function vietnamTodayKey(): string {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const values: Record<string, string> = {};
  parts.forEach(function(part) { values[part.type] = part.value; });
  return values.year + "-" + values.month + "-" + values.day;
}

function addDateKey(dateKey: string, days: number): string {
  const [year, month, day] = dateKey.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function mondayDateKey(dateKey: string): string {
  const [year, month, day] = dateKey.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  const offset = (date.getUTCDay() + 6) % 7;
  return addDateKey(dateKey, -offset);
}

function minutesOf(value: string): number {
  const [hour, minute] = String(value || "00:00").split(":").map(Number);
  return Math.max(0, Math.min(24 * 60, (Number.isFinite(hour) ? hour : 0) * 60 + (Number.isFinite(minute) ? minute : 0)));
}

function shortDateLabel(dateKey: string): string {
  const [year, month, day] = dateKey.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day)).toLocaleDateString("vi-VN", { timeZone: "UTC", day: "2-digit", month: "2-digit" });
}

function stackTimetableEvents(events: TimetableEvent[]): TimetableEvent[] {
  const sorted = events.slice().sort(function(a, b) { return a.startTime.localeCompare(b.startTime) || a.endTime.localeCompare(b.endTime) || a.title.localeCompare(b.title); });
  const output: TimetableEvent[] = [];
  let group: TimetableEvent[] = [];
  let groupEnd = -1;
  function flush() {
    if (!group.length) return;
    const count = group.length;
    group.forEach(function(item, index) { output.push({ ...item, stackIndex: index, stackCount: count }); });
    group = [];
    groupEnd = -1;
  }
  sorted.forEach(function(item) {
    const start = minutesOf(item.startTime);
    const end = Math.max(start + 1, minutesOf(item.endTime));
    if (group.length && start >= groupEnd) flush();
    group.push(item);
    groupEnd = Math.max(groupEnd, end);
  });
  flush();
  return output;
}

function StudentWeeklyTimetable(props: { course?: Course; courses?: Course[]; sessions: Session[]; aggregate?: boolean }) {
  const today = vietnamTodayKey();
  const [weekStart, setWeekStart] = useState(function() { return mondayDateKey(today); });
  const [focusedEventKey, setFocusedEventKey] = useState("");
  const timetableScrollRef = useRef<HTMLDivElement | null>(null);
  const dayLabels = ["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"];
  const activeCourses = props.courses?.length ? props.courses : props.course ? [props.course] : [];
  const activeKeys = new Set(activeCourses.map(function(course) { return course.key; }));
  const days = Array.from({ length: 7 }, function(_, index) {
    const date = addDateKey(weekStart, index);
    const regular: TimetableEvent[] = activeCourses.flatMap(function(course) {
      return (course.schedules || []).filter(function(item) { return item.weekday === index + 1; }).map(function(item) {
        return { key: "regular-" + course.key + "-" + item.id + "-" + date, classKey: course.key, startTime: item.startTime, endTime: item.endTime, title: course.name, room: item.room || course.room || "", tone: course.tone || "indigo", kind: "regular" as const };
      });
    });
    const special: TimetableEvent[] = props.sessions.filter(function(item) {
      if (item.sessionDate !== date) return false;
      if (!activeCourses.length) return false;
      if (!item.classKey) return activeCourses.length === 1;
      return activeKeys.has(item.classKey);
    }).map(function(item) {
      const course = activeCourses.find(function(candidate) { return candidate.key === item.classKey || candidate.name === item.className; }) || activeCourses[0];
      return { key: "session-" + item.id, classKey: course?.key || item.classKey || "", startTime: item.startTime, endTime: item.endTime, title: course?.name || item.className || "Môn học", room: course?.room || "", tone: course?.tone || "indigo", kind: item.sessionType === "makeup" ? "makeup" as const : "regular" as const, note: item.note };
    });
    return { date, label: dayLabels[index], events: stackTimetableEvents(regular.concat(special)) };
  });
  const allEvents = days.flatMap(function(day) { return day.events; });
  const earliest = allEvents.length ? Math.min.apply(null, allEvents.map(function(item) { return minutesOf(item.startTime); })) : 8 * 60;
  const latest = allEvents.length ? Math.max.apply(null, allEvents.map(function(item) { return minutesOf(item.endTime); })) : 18 * 60;
  const rangeStart = Math.max(0, Math.min(6 * 60, Math.floor(Math.max(0, earliest - 60) / 60) * 60));
  let rangeEnd = Math.min(24 * 60, Math.max(23 * 60, Math.ceil(Math.min(24 * 60, latest + 60) / 60) * 60));
  if (rangeEnd - rangeStart < 10 * 60) rangeEnd = Math.min(24 * 60, rangeStart + 10 * 60);
  const pixelsPerMinute = 0.72;
  const bodyHeight = Math.max(320, Math.round((rangeEnd - rangeStart) * pixelsPerMinute));
  const hourMarks = Array.from({ length: Math.floor((rangeEnd - rangeStart) / 60) + 1 }, function(_, index) { return rangeStart + index * 60; });
  useEffect(function() {
    const node = timetableScrollRef.current;
    if (!node) return;
    const target = Math.max(0, (7 * 60 - rangeStart) * pixelsPerMinute - 18);
    const frame = window.requestAnimationFrame(function() { node.scrollTop = target; });
    return function() { window.cancelAnimationFrame(frame); };
  }, [weekStart, rangeStart, pixelsPerMinute]);
  function cycleEvent(item: TimetableEvent, events: TimetableEvent[]) {
    const start = minutesOf(item.startTime);
    const end = Math.max(start + 1, minutesOf(item.endTime));
    const overlaps = events.filter(function(other) {
      const otherStart = minutesOf(other.startTime);
      const otherEnd = Math.max(otherStart + 1, minutesOf(other.endTime));
      return otherStart < end && start < otherEnd;
    });
    if (overlaps.length <= 1) { setFocusedEventKey(item.key); return; }
    const focusedIndex = overlaps.findIndex(function(other) { return other.key === focusedEventKey; });
    const clickedIndex = overlaps.findIndex(function(other) { return other.key === item.key; });
    const currentIndex = focusedIndex >= 0 ? focusedIndex : clickedIndex;
    setFocusedEventKey(overlaps[(currentIndex + 1) % overlaps.length].key);
  }
  function moveWeek(delta: number) { setWeekStart(function(current) { return addDateKey(current, delta * 7); }); setFocusedEventKey(""); }
  function resetToday() { setWeekStart(mondayDateKey(vietnamTodayKey())); setFocusedEventKey(""); }
  return <section className="weekly-timetable card student-weekly-timetable taste-timetable">
    <div className="weekly-timetable-toolbar"><div><button className="icon-button" onClick={function() { moveWeek(-1); }} aria-label="Tuần trước"><ChevronLeft /></button><button className="button soft" onClick={resetToday}>Hôm nay</button><button className="icon-button" onClick={function() { moveWeek(1); }} aria-label="Tuần sau"><ChevronRight /></button></div><div className="weekly-timetable-range"><small>{props.aggregate ? "Lịch tổng hợp" : props.course?.name || "Lịch học"}</small><strong>{shortDateLabel(weekStart)} - {shortDateLabel(addDateKey(weekStart, 6))}</strong></div></div>
    <div className="weekly-timetable-scroll" ref={timetableScrollRef} tabIndex={0} aria-label="Thời khóa biểu tuần">
      <div className="weekly-timetable-grid">
        <div className="weekly-timetable-corner">Giờ</div>
        {days.map(function(day) { return <div className={"weekly-timetable-day-head" + (day.date === today ? " today" : "")} key={"head-" + day.date}><span>{day.label}</span><strong>{shortDateLabel(day.date)}</strong>{day.date === today ? <em>Hôm nay</em> : null}</div>; })}
        <div className="weekly-timetable-time-axis" style={{ height: bodyHeight }}>{hourMarks.map(function(mark) { const hour = String(Math.floor(mark / 60)).padStart(2, "0") + ":00"; return <span key={mark} style={{ top: (mark - rangeStart) * pixelsPerMinute }}>{hour}</span>; })}</div>
        {days.map(function(day) { return <div className={"weekly-timetable-day-column" + (day.date === today ? " today" : "")} style={{ height: bodyHeight }} key={day.date}>{hourMarks.map(function(mark) { return <i className="weekly-timetable-hour-line" key={mark} style={{ top: (mark - rangeStart) * pixelsPerMinute }} />; })}{day.events.map(function(item) {
          const start = Math.max(rangeStart, minutesOf(item.startTime));
          const end = Math.min(rangeEnd, Math.max(start + 1, minutesOf(item.endTime)));
          const isFocused = focusedEventKey === item.key;
          const stacked = (item.stackCount || 1) > 1;
          const stackOffset = stacked && !isFocused ? (item.stackIndex || 0) * 11 : 0;
          return <article role="button" tabIndex={0} aria-pressed={isFocused} onClick={function() { cycleEvent(item, day.events); }} onKeyDown={function(event) { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); cycleEvent(item, day.events); } }} className={"weekly-timetable-event tone-" + item.tone + " " + item.kind + (stacked ? " overlap" : "") + (isFocused ? " active" : "")} key={item.key} style={{ top: (start - rangeStart) * pixelsPerMinute, height: Math.max(46, (end - start) * pixelsPerMinute), left: 6 + stackOffset, right: 6, zIndex: isFocused ? 30 : 2 + (item.stackIndex || 0) }}><em>{item.kind === "makeup" ? "Học bù" : "Buổi thường"}</em><strong>{item.title}</strong><time>{item.startTime} - {item.endTime}</time>{item.room ? <small>{item.room}</small> : null}{item.note ? <small className="event-note">{item.note}</small> : null}</article>;
        })}</div>; })}
      </div>
    </div>
    <footer className="weekly-timetable-legend"><span><i className="regular" />Buổi thường</span><span><i className="makeup" />Học bù / bổ sung</span><small>{allEvents.some(function(item) { return (item.stackCount || 1) > 1; }) ? "Có lịch trùng giờ: chạm vào lớp đang ở trên để lần lượt xem lớp phía sau." : "Trên điện thoại có thể kéo ngang để xem đủ cả tuần."}</small></footer>
  </section>;
}

function CourseTestCalendar(props: { items: PortalData["calendar"]; courseName?: string }) {
  const today = vietnamTodayKey();
  const [month, setMonth] = useState(today.slice(0, 7));
  const monthDate = new Date(month + "-01T00:00:00");
  const year = monthDate.getFullYear();
  const monthIndex = monthDate.getMonth();
  const firstOffset = (monthDate.getDay() + 6) % 7;
  const dayCount = new Date(year, monthIndex + 1, 0).getDate();
  const tests = props.items.filter(function(item) {
    return String(item.type || "").toLocaleLowerCase("vi").includes("kiểm tra");
  });
  const monthTests = tests.filter(function(item) {
    return item.date.slice(0, 7) === month;
  }).sort(function(a, b) {
    return a.date.localeCompare(b.date);
  });
  const cells = Array.from(
    { length: Math.ceil((firstOffset + dayCount) / 7) * 7 },
    function(_, index) {
      const day = index - firstOffset + 1;
      return day > 0 && day <= dayCount ? day : null;
    },
  );
  const monthLabel = monthDate.toLocaleDateString("vi-VN", { month: "long", year: "numeric" });
  function moveMonth(delta: number) {
    const next = new Date(year, monthIndex + delta, 1);
    setMonth(next.getFullYear() + "-" + String(next.getMonth() + 1).padStart(2, "0"));
  }
  function timeOf(item: PortalData["calendar"][number]) {
    return item.date.includes("T") ? item.date.slice(11, 16) : "";
  }
  return (
    <section className="card lms-test-calendar">
      <header className="lms-test-calendar-toolbar">
        <div>
          <span>Lịch kiểm tra</span>
          <strong>{props.courseName || "Môn học"}</strong>
        </div>
        <nav aria-label="Điều hướng tháng">
          <button className="icon-button" type="button" onClick={function() { moveMonth(-1); }} aria-label="Tháng trước"><ChevronLeft /></button>
          <button className="button soft" type="button" onClick={function() { setMonth(today.slice(0, 7)); }}>Hôm nay</button>
          <button className="icon-button" type="button" onClick={function() { moveMonth(1); }} aria-label="Tháng sau"><ChevronRight /></button>
        </nav>
        <time>{monthLabel}</time>
      </header>
      <div className="lms-test-calendar-scroll" tabIndex={0} aria-label="Lịch kiểm tra theo tháng">
        <div className="lms-test-month-grid">
          {["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map(function(day) {
            return <strong key={day}>{day}</strong>;
          })}
          {cells.map(function(day, index) {
            const key = day ? month + "-" + String(day).padStart(2, "0") : "";
            const dayTests = day ? monthTests.filter(function(item) { return item.date.slice(0, 10) === key; }) : [];
            return (
              <div className={(!day ? "empty " : "") + (key === today ? "today" : "")} key={index}>
                {day ? <span>{day}</span> : null}
                {dayTests.slice(0, 2).map(function(item) {
                  return (
                    <article key={item.id} title={item.details || item.title}>
                      <time>{timeOf(item) || "Cả ngày"}</time>
                      <strong>{item.title}</strong>
                    </article>
                  );
                })}
                {dayTests.length > 2 ? <small>+{dayTests.length - 2}</small> : null}
              </div>
            );
          })}
        </div>
      </div>
      <div className="lms-test-list">
        <header><strong>Trong tháng</strong><span>{monthTests.length} lịch</span></header>
        {monthTests.map(function(item) {
          return (
            <article key={item.id}>
              <span className="test-date-tile"><strong>{item.date.slice(8, 10)}</strong><small>Tháng {Number(item.date.slice(5, 7))}</small></span>
              <div><strong>{item.title}</strong><small>{timeOf(item) ? timeOf(item) + " · " : ""}{item.details || "Không có ghi chú"}</small></div>
            </article>
          );
        })}
        {!monthTests.length ? <div className="lms-inline-empty"><CalendarDays />Chưa có lịch kiểm tra trong tháng này.</div> : null}
      </div>
    </section>
  );
}

function SubmissionModal(props: { assignment: Assignment; teacherName: string; clock: number; close: () => void; submit: (assignment: Assignment, form: FormData) => Promise<void> }) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [removedFileIds, setRemovedFileIds] = useState<number[]>([]);
  const [removeLegacyFile, setRemoveLegacyFile] = useState(false);
  const [viewerTarget, setViewerTarget] = useState<FileViewerTarget | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const maxTotalSize = 10 * 1024 * 1024;
  const selectedTotalSize = selectedFiles.reduce(function(total, file) { return total + file.size; }, 0);
  const submission = props.assignment.submission;
  const submitted = isStudentSubmittedStatus(submission?.status);
  const draft = isDraftSubmissionStatus(submission?.status);
  const teacherCompleted = Boolean(props.assignment.teacherCompletedAt) || isTeacherCompletedStatus(submission?.status);
  const overdue = getAssignmentStatus(props.assignment.dueDate) === "Đã kết thúc";
  const editable = !overdue;
  const existingFiles: SubmissionFile[] = submission?.files?.length
    ? submission.files
    : submission?.fileName
      ? [{ id: 0, fileName: submission.fileName, fileSize: submission.fileSize, contentType: submission.contentType || "" }]
      : [];
  const removedFileIdSet = new Set(removedFileIds);
  const visibleExistingFiles = existingFiles.filter(function(file) { return file.id ? !removedFileIdSet.has(file.id) : !removeLegacyFile; });
  const existingTotalSize = visibleExistingFiles.reduce(function(total, file) { return total + Number(file.fileSize || 0); }, 0);
  const finalTotalSize = existingTotalSize + selectedTotalSize;

  function removeExistingFile(file: SubmissionFile) {
    if (!editable) return;
    if (file.id) setRemovedFileIds(function(current) { return current.includes(file.id) ? current : current.concat(file.id); });
    else setRemoveLegacyFile(true);
  }

  function chooseFiles(event: React.ChangeEvent<HTMLInputElement>) {
    if (!editable) return;
    const added = Array.from(event.currentTarget.files || []);
    setSelectedFiles(function(current) {
      const next = current.slice();
      const keys = new Set(next.map(function(file) { return [file.name, file.size, file.lastModified].join("|"); }));
      added.forEach(function(file) {
        const key = [file.name, file.size, file.lastModified].join("|");
        if (!keys.has(key)) { keys.add(key); next.push(file); }
      });
      const total = existingTotalSize + next.reduce(function(sum, file) { return sum + file.size; }, 0);
      setError(total > maxTotalSize ? "Tổng dung lượng tất cả tệp tối đa 10 MB." : "");
      return next;
    });
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!editable) return;
    setSaving(true);
    setError("");
    const sourceForm = new FormData(event.currentTarget);
    const responseText = String(sourceForm.get("responseText") || "").trim();
    if (finalTotalSize > maxTotalSize) {
      setError("Tổng dung lượng tất cả tệp tối đa 10 MB.");
      setSaving(false);
      return;
    }
    const finalFileCount = selectedFiles.length + visibleExistingFiles.length;
    if (!finalFileCount && !responseText) {
      setError("Vui lòng chọn ít nhất một tệp hoặc nhập câu trả lời.");
      setSaving(false);
      return;
    }
    const form = new FormData();
    form.set("responseText", responseText);
    if (submission) form.set("expectedUpdatedAt", submission.updatedAt || "");
    selectedFiles.forEach(function(file) { form.append("files", file); });
    removedFileIds.forEach(function(id) { form.append("removeFileIds", String(id)); });
    if (removeLegacyFile) form.set("removeLegacyFile", "1");
    try { await props.submit(props.assignment, form); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Không thể nộp bài."); setSaving(false); }
  }

  function openLocalFile(file: File) {
    setViewerTarget({ name: file.name, url: URL.createObjectURL(file), contentType: file.type });
  }

  function closeViewer() {
    if (viewerTarget?.url.startsWith("blob:")) URL.revokeObjectURL(viewerTarget.url);
    setViewerTarget(null);
  }

  const submissionHeading = submission?.status === "graded" ? "Bài đã chấm" : submitted ? "Bài đã nộp" : draft ? "Bài đang chỉnh sửa" : "Bài nộp";
  const submissionTimeLabel = submitted ? "Nộp lúc " : "Lần nộp gần nhất ";
  const status = assignmentLabel(props.assignment, props.clock);

  return (
    <div className="student-detail-overlay" onMouseDown={props.close}>
      <form className="form-modal lms-submission-modal" onSubmit={handleSubmit} onMouseDown={function(event) { event.stopPropagation(); }}>
        <div className="modal-head lms-assignment-modal-head">
          <div><span className={"lms-status " + status.tone}>{status.text}</span><h2>{props.assignment.title}</h2><p>{props.assignment.className} · Hạn <strong>{formatDateTime(props.assignment.dueDate)}</strong> · Tối đa {props.assignment.maxScore} điểm</p></div>
          <button type="button" className="modal-close" onClick={props.close} aria-label="Đóng"><X /></button>
        </div>
        <div className="lms-submission-body">
          <section className="lms-assignment-brief">
            <h3>Yêu cầu</h3>
            <RichAssignmentDescription text={props.assignment.description || "Giáo viên chưa thêm mô tả."} />
            {props.assignment.attachmentName ? <div className="assignment-attachment-actions"><button type="button" className="button soft" onClick={function() { setViewerTarget({ name: props.assignment.attachmentName, url: "/api/assignments/" + props.assignment.id + "/attachment", contentType: props.assignment.attachmentType }); }}><Eye />Xem tệp đề bài</button><a className="button ghost" href={"/api/assignments/" + props.assignment.id + "/attachment?download=1"}><Download />Tải xuống</a></div> : null}
          </section>
          {overdue ? <div className="lms-deadline-lock"><Clock3 /><div><strong>Đã hết hạn nộp bài</strong><p>Hạn nộp: {formatDateTime(props.assignment.dueDate)}. Bạn chỉ có thể xem bài đã nộp và kết quả chấm.</p></div></div> : null}
          {submission ? (
            <section className="lms-existing-submission">
              <div className="lms-existing-submission-head"><div><h3>{submissionHeading}</h3><p>{submissionTimeLabel}{formatDateTime(submission.submittedAt)}</p></div><span>{visibleExistingFiles.length} tệp</span></div>
              {visibleExistingFiles.length ? <div className="lms-existing-files lms-selected-files">{visibleExistingFiles.map(function(file) { const url = file.id ? "/api/submission-files/" + file.id + "/file" : "/api/submissions/" + submission.id + "/file"; return <div key={file.id || file.fileName}><FileText /><span><strong title={file.fileName}>{file.fileName}</strong><small>{formatSize(file.fileSize)}</small></span><div className="lms-file-row-actions"><button type="button" onClick={function() { setViewerTarget({ name: file.fileName, url, contentType: file.contentType }); }}><Eye /><span>Xem</span></button><a href={url + "?download=1"} aria-label={"Tải " + file.fileName}><Download /></a>{editable ? <button type="button" onClick={function() { removeExistingFile(file); }} aria-label={"Xóa tệp " + file.fileName}><X /></button> : null}</div></div>; })}</div> : null}
              {submission.responseText && submission.responseText !== "Đã hoàn thành theo dữ liệu cũ" ? <blockquote>{submission.responseText}</blockquote> : null}
              {submission.status === "graded" ? <div className="lms-grade-result"><span>Kết quả chấm bài</span><strong>{submission.score ?? "Chưa nhập điểm"} / {props.assignment.maxScore}</strong><p>{submission.feedback || "Giáo viên chưa ghi nhận xét."}</p><small>GV: {props.teacherName || "Giáo viên"}{submission.gradedAt ? " · " + formatDateTime(submission.gradedAt) : ""}</small></div> : null}
            </section>
          ) : teacherCompleted ? <section className="lms-existing-submission teacher-completed"><div className="lms-existing-submission-head"><div><h3>GV đánh dấu hoàn thành</h3><p>Hoàn thành ngoài hệ thống, không có tệp bài nộp giả.</p></div><CheckCircle2 /></div></section> : null}
          <label className="lms-response-field"><span>Câu trả lời <small>Không bắt buộc nếu đã chọn tệp</small></span><textarea name="responseText" rows={4} disabled={!editable} defaultValue={submission?.responseText === "Đã hoàn thành theo dữ liệu cũ" ? "" : submission?.responseText || ""} placeholder="Nhập nội dung trả lời hoặc lời nhắn cho giáo viên" /></label>
          <section className="lms-file-field" aria-labelledby="submission-file-title">
            <div className="lms-file-field-head">
              <span className="lms-file-field-icon"><UploadCloud /></span>
              <div><strong id="submission-file-title">{submission ? "Cập nhật tệp bài nộp" : "Tệp bài nộp"}</strong><small>JPG, JPEG, PNG, WEBP hoặc PDF. Tổng tất cả tệp tối đa 10 MB.</small></div>
              <button type="button" className="button soft lms-file-picker" disabled={!editable} onClick={function() { if (fileInputRef.current) { fileInputRef.current.value = ""; fileInputRef.current.click(); } }}><UploadCloud />Thêm tệp</button>
              <input ref={fileInputRef} className="lms-file-input" name="files" type="file" multiple disabled={!editable} accept="image/jpeg,image/png,image/webp,application/pdf" onChange={chooseFiles} />
            </div>
            {selectedFiles.length ? (
              <div className="lms-selected-files">{selectedFiles.map(function(file, index) { return <div key={file.name + "-" + file.lastModified + "-" + index}><FileText /><span><strong title={file.name}>{file.name}</strong><small>{formatSize(file.size)}</small></span><div className="lms-file-row-actions"><button type="button" onClick={function() { openLocalFile(file); }}><Eye /><span>Xem</span></button><button type="button" onClick={function() { setSelectedFiles(function(current) { return current.filter(function(_, fileIndex) { return fileIndex !== index; }); }); }} aria-label={"Bỏ tệp " + file.name}><X /></button></div></div>; })}</div>
            ) : <p className="lms-file-empty">{editable ? "Chưa thêm tệp mới." : "Không thể thay đổi tệp sau thời hạn."}</p>}
            <div className={"lms-file-total" + (finalTotalSize > maxTotalSize ? " over" : "")}><span>{selectedFiles.length + visibleExistingFiles.length} tệp</span><strong>{formatSize(finalTotalSize)} / 10 MB</strong></div>
            {editable && submission && selectedFiles.length ? <small className="lms-file-replace-note">Tệp mới sẽ được thêm vào bài hiện tại. Bạn có thể xóa từng tệp cũ bằng nút × trước khi nộp lại.</small> : null}
          </section>
          {error ? <p className="form-error" role="alert">{error}</p> : null}
        </div>
        <div className="modal-footer"><button type="button" className="button ghost" onClick={props.close}>Đóng</button>{editable ? <button className="button primary" disabled={saving || finalTotalSize > maxTotalSize}><Send />{saving ? "Đang lưu..." : submission ? "Nộp lại" : "Nộp bài"}</button> : null}</div>
      </form>
      <FileViewerModal target={viewerTarget} close={closeViewer} />
    </div>
  );
}

export default function StudentPortal() {
  const [data, setData] = useState<PortalData>(EMPTY);
  const [homeData, setHomeData] = useState<PortalData>(EMPTY);
  const [courseId, setCourseId] = useState("");
  const [homeTab, setHomeTab] = useState<HomeTab>("courses");
  const [tab, setTab] = useState<CourseTab>("overview");
  const [loading, setLoading] = useState(true);
  const [courseLoading, setCourseLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [dark, setDark] = useState(false);
  const [themeReady, setThemeReady] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<PortalData["notifications"][number] | null>(null);
  const [progressDetail, setProgressDetail] = useState<"grades" | "attendance" | "comments" | null>(null);
  const [markingAllNotifications, setMarkingAllNotifications] = useState(false);
  const [messagesOpen, setMessagesOpen] = useState(false);
  const [pushSettingsOpen, setPushSettingsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messageDraft, setMessageDraft] = useState("");
  const studentMessageThreadRef = useRef<HTMLDivElement | null>(null);
  const deepLinkAppliedRef = useRef(false);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [viewerTarget, setViewerTarget] = useState<FileViewerTarget | null>(null);
  const [selectedRewardId, setSelectedRewardId] = useState<number | null>(null);
  const [assignmentClock, setAssignmentClock] = useState(function() { return Date.now(); });

  function toast(text: string) {
    setMessage(text);
    window.setTimeout(function() { setMessage(""); }, 2800);
  }

  async function loadBase() {
    const session = await fetch("/api/student/session", { cache: "no-store", credentials: "include" });
    const sessionData = await session.json();
    if (!sessionData.authenticated) { window.location.replace("/"); return; }
    const response = await fetch("/api/student/portal", { cache: "no-store" });
    if (!response.ok) { window.location.replace("/"); return; }
    const payload = await response.json() as PortalData;
    setHomeData(Object.assign({}, EMPTY, payload));
    if (!courseId) setData(Object.assign({}, EMPTY, payload));
    await loadMessages();
    setLoading(false);
    if (!deepLinkAppliedRef.current) {
      const timer = window.setTimeout(function() { void applyInitialDeepLink(Object.assign({}, EMPTY, payload)); }, 0);
      void timer;
    }
  }

  async function loadMessages() {
    try {
      const response = await fetch("/api/student/messages", { cache: "no-store" });
      if (!response.ok) return;
      const payload = await response.json() as { messages?: ChatMessage[] };
      setMessages(Array.isArray(payload.messages) ? payload.messages : []);
    } catch {}
  }

  async function openCourse(key: string, quiet = false) {
    if (!quiet) setCourseLoading(true);
    const response = await fetch("/api/student/portal?courseId=" + encodeURIComponent(key), { cache: "no-store" });
    const payload = await response.json();
    if (!response.ok) { toast(payload.error || "Không thể mở môn học."); setCourseLoading(false); return null; }
    const normalizedPayload = Object.assign({}, EMPTY, payload) as PortalData;
    setData(normalizedPayload);
    setHomeData(function(current) { return Object.assign({}, current, { courses: payload.courses, notifications: payload.notifications, points: payload.points, rewards: payload.rewards, redemptions: payload.redemptions, transactions: payload.transactions }); });
    setCourseId(key);
    if (!quiet) setTab("overview");
    setCourseLoading(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
    return normalizedPayload;
  }

  async function applyInitialDeepLink(basePayload: PortalData) {
    if (deepLinkAppliedRef.current) return;
    deepLinkAppliedRef.current = true;
    const params = new URLSearchParams(window.location.search);
    const view = String(params.get("view") || "");
    const requestedCourseName = String(params.get("courseName") || "");
    const requestedCourse = String(params.get("courseId") || "") || basePayload.courses.find(function(item) { return item.name === requestedCourseName; })?.key || "";
    const requestedTab = String(params.get("tab") || "");
    const assignmentId = Number(params.get("assignmentId") || 0);

    if (view === "messages") {
      setPushSettingsOpen(false);
      setNotificationsOpen(false);
      setMessagesOpen(true);
      await markMessagesRead();
      await loadMessages();
      return;
    }
    if (view === "notifications") {
      setPushSettingsOpen(false);
      setMessagesOpen(false);
      const notificationId = Number(params.get("notificationId") || 0);
      const notification = notificationId ? basePayload.notifications.find(function(item) { return item.id === notificationId; }) : null;
      if (notification) {
        await readNotification(notification);
      } else {
        setNotificationsOpen(true);
      }
      return;
    }
    if (view === "pomodoro") {
      setCourseId("");
      setHomeTab("courses");
      setData(basePayload);
      window.setTimeout(function() { document.getElementById("student-focus-companion")?.scrollIntoView({ behavior: "smooth", block: "center" }); }, 120);
      return;
    }
    if (view === "rewards") {
      setCourseId("");
      setHomeTab("courses");
      setData(basePayload);
      window.setTimeout(function() { document.getElementById("student-rewards")?.scrollIntoView({ behavior: "smooth", block: "center" }); }, 120);
      return;
    }
    if (!requestedCourse) return;
    const opened = await openCourse(requestedCourse, true);
    if (!opened) return;
    const targetTab = TAB_ITEMS.find(function(item) { return item[0] === requestedTab; });
    if (targetTab) setTab(targetTab[0]);
    if (assignmentId) {
      const assignment = opened.assignments.find(function(item) { return item.id === assignmentId; });
      if (assignment) setSelectedAssignment(assignment);
    }
  }

  useEffect(function() {
    const timer = window.setTimeout(function() { void loadBase(); }, 0);
    return function() { window.clearTimeout(timer); };
  // Initial portal bootstrap is intentionally run once per mount.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(function() {
    if (!("serviceWorker" in navigator)) return;
    void (async function() {
      try {
        await navigator.serviceWorker.register("/sw.js", { scope: "/" });
        const registration = await navigator.serviceWorker.ready;
        // Re-bind an already granted browser subscription to the currently
        // authenticated student. This prevents stale cross-account delivery on
        // shared devices while never showing a permission prompt automatically.
        if ("PushManager" in window && "Notification" in window && Notification.permission === "granted") {
          const subscription = await registration.pushManager.getSubscription();
          if (subscription) {
            const value = subscription.toJSON();
            await fetch("/api/student/push", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                endpoint: value.endpoint || subscription.endpoint,
                keys: value.keys || {},
                userAgent: navigator.userAgent,
                platform: navigator.platform || "",
              }),
            }).catch(function() {});
          }
        }
      } catch {}
    })();
  }, []);
  useEffect(function() {
    const timer = window.setTimeout(function() {
      const saved = window.localStorage.getItem("student-theme");
      setDark(saved === "dark");
      setThemeReady(true);
    }, 0);
    return function() { window.clearTimeout(timer); };
  }, []);
  useEffect(function() {
    if (!themeReady) return;
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    window.localStorage.setItem("student-theme", dark ? "dark" : "light");
  }, [dark, themeReady]);
  useEffect(function() { document.title = data.site.siteName + " - Học sinh"; }, [data.site.siteName]);
  useEffect(function() { const timer = window.setInterval(function() { setAssignmentClock(Date.now()); }, 60_000); return function() { window.clearInterval(timer); }; }, []);
  useEffect(function() {
    const refreshVisible = function() {
      if (document.visibilityState !== "visible") return;
      if (courseId) {
        void openCourse(courseId, true);
        void loadMessages();
      } else {
        // loadBase already refreshes messages; avoid a duplicate request on the home dashboard.
        void loadBase();
      }
    };
    const timer = window.setInterval(refreshVisible, 20_000);
    const onVisibility = function() { if (document.visibilityState === "visible") refreshVisible(); };
    document.addEventListener("visibilitychange", onVisibility);
    return function() { window.clearInterval(timer); document.removeEventListener("visibilitychange", onVisibility); };
  // Refresh only when the selected course changes. Hidden tabs do not burn portal/message reads.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [courseId]);

  async function logout() {
    // Detach this browser endpoint from the current student before deleting the
    // login cookie. Keep the browser subscription itself so a later login can
    // re-bind it without prompting for Notification permission again.
    try {
      if ("serviceWorker" in navigator && "PushManager" in window) {
        const registration = await navigator.serviceWorker.getRegistration("/");
        const subscription = await registration?.pushManager.getSubscription();
        if (subscription) {
          await fetch("/api/student/push", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ endpoint: subscription.endpoint }),
          }).catch(function() {});
        }
      }
      const badgeNavigator = navigator as Navigator & { clearAppBadge?: () => Promise<void> };
      if (typeof badgeNavigator.clearAppBadge === "function") await badgeNavigator.clearAppBadge();
    } catch {}
    await fetch("/api/student/session", { method: "DELETE", credentials: "include" });
    window.location.href = "/";
  }
  function backToCourses() { setCourseId(""); setHomeTab("courses"); setData(homeData); setNotificationsOpen(false); setMessagesOpen(false); setPushSettingsOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); }
  async function submitAssignment(assignment: Assignment, form: FormData) {
    const files = form.getAll("files").filter(function(candidate): candidate is File { return candidate instanceof File && candidate.size > 0; });
    const uploadedFiles: DirectSubmissionUpload[] = [];

    async function cleanupTemporaryUploads() {
      if (!uploadedFiles.length) return;
      await fetch("/api/student/submissions/upload", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assignmentId: assignment.id, objectKeys: uploadedFiles.map(function(file) { return file.objectKey; }) }),
      }).catch(function() {});
    }

    try {
      // Upload each file as a raw stream first. This avoids multipart buffering and keeps 1-10 MB PDF/image submissions reliable on Workers.
      for (const file of files) {
        const query = new URLSearchParams({
          assignmentId: String(assignment.id),
          name: file.name,
          size: String(file.size),
          contentType: file.type || "application/octet-stream",
        });
        const uploadResponse = await fetch("/api/student/submissions/upload?" + query.toString(), {
          method: "PUT",
          headers: { "Content-Type": file.type || "application/octet-stream" },
          body: file,
        });
        const uploadText = await uploadResponse.text().catch(function() { return ""; });
        let uploadPayload: { error?: string; file?: DirectSubmissionUpload } = {};
        try { uploadPayload = uploadText ? JSON.parse(uploadText) as typeof uploadPayload : {}; } catch {}
        if (!uploadResponse.ok || !uploadPayload.file?.objectKey) {
          const message = uploadPayload.error || (uploadResponse.status === 413 ? "Tệp bài nộp vượt giới hạn tải lên. Tổng dung lượng tối đa là 10 MB." : "Không thể tải tệp bài nộp lên. Vui lòng thử lại.");
          throw new Error(message);
        }
        uploadedFiles.push(uploadPayload.file);
      }

      const payload: {
        assignmentId: number;
        responseText: string;
        removeFileIds: number[];
        removeLegacyFile: boolean;
        uploadedFiles: DirectSubmissionUpload[];
        expectedUpdatedAt?: string;
      } = {
        assignmentId: assignment.id,
        responseText: String(form.get("responseText") || ""),
        removeFileIds: form.getAll("removeFileIds").map(Number).filter(function(id) { return Number.isInteger(id) && id > 0; }),
        removeLegacyFile: String(form.get("removeLegacyFile") || "") === "1",
        uploadedFiles,
      };
      if (form.has("expectedUpdatedAt")) payload.expectedUpdatedAt = String(form.get("expectedUpdatedAt") || "");

      const response = await fetch("/api/student/submissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        const message = await responseErrorMessage(response, "Không thể nộp bài. Vui lòng thử lại.");
        throw new Error(message);
      }

      setSelectedAssignment(null);
      toast("Đã nộp bài thành công");
      // Submission is already durable in R2/D1. Refresh course data in the background so the modal does not stay blocked.
      void openCourse(courseId, true).catch(function() {});
    } catch (reason) {
      await cleanupTemporaryUploads();
      throw reason;
    }
  }
  async function redeem(id: number, title: string) {
    if (!window.confirm("Dùng điểm để đổi “" + title + "”?")) return;
    const response = await fetch("/api/student/redeem", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rewardId: id }) });
    const payload = await response.json();
    if (!response.ok) { toast(payload.error || "Không thể đổi quà."); return; }
    setSelectedRewardId(null);
    await loadBase(); toast("Đã gửi yêu cầu đổi quà cho giáo viên");
  }
  async function readNotification(item: PortalData["notifications"][number]) {
    setSelectedNotification(item);
    setNotificationsOpen(false);
    if (item.read) return;
    await fetch("/api/student/notifications", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id }) });
    const markRead = function(current: PortalData) { return { ...current, notifications: current.notifications.map(function(row) { return row.id === item.id ? { ...row, read: true } : row; }) }; };
    setHomeData(markRead);
    setData(markRead);
    setSelectedNotification(function(current) { return current && current.id === item.id ? { ...current, read: true } : current; });
  }
  async function openNotificationAction(item: PortalData["notifications"][number]) {
    const target = TAB_ITEMS.find(function(tabItem) { return tabItem[0] === item.actionView; });
    setSelectedNotification(null);
    if (item.courseKey && target) {
      await openCourse(item.courseKey);
      setTab(target[0]);
      return;
    }
    if (item.actionView === "rewards") {
      setCourseId("");
      setHomeTab("courses");
      setData(homeData);
      window.setTimeout(function() { document.getElementById("student-rewards")?.scrollIntoView({ behavior: "smooth", block: "center" }); }, 100);
    }
  }
  async function readAllNotifications() {
    if (markingAllNotifications) return;
    setMarkingAllNotifications(true);
    try {
      const response = await fetch("/api/student/notifications", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ all: true }) });
      if (!response.ok) throw new Error();
      const markAll = function(current: PortalData) { return { ...current, notifications: current.notifications.map(function(item) { return { ...item, read: true }; }) }; };
      setHomeData(markAll);
      setData(markAll);
    } catch { toast("Không thể đánh dấu thông báo đã đọc."); }
    finally { setMarkingAllNotifications(false); }
  }
  async function markMessagesRead() {
    try {
      await fetch("/api/student/messages", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ all: true }) });
      setMessages(function(rows) { return rows.map(function(item) { return item.direction === "teacher" ? { ...item, read: true } : item; }); });
    } catch {}
  }
  async function sendTeacherMessage(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const body = messageDraft.trim();
    if (!body || sendingMessage) return;
    setSendingMessage(true);
    try {
      const response = await fetch("/api/student/messages", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ body }) });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Không thể gửi tin nhắn.");
      setMessageDraft("");
      await loadMessages();
    } catch (reason) { toast(reason instanceof Error ? reason.message : "Không thể gửi tin nhắn."); }
    finally { setSendingMessage(false); }
  }
  async function toggleMessages() {
    const next = !messagesOpen;
    setMessagesOpen(next);
    setNotificationsOpen(false);
    setPushSettingsOpen(false);
    if (!next) return;
    await markMessagesRead();
    await loadMessages();
  }


  const completed = new Set(data.submissions);
  const unreadCount = homeData.notifications.filter(function(item) { return !item.read; }).length;
  const unreadMessageCount = messages.filter(function(item) { return item.direction === "teacher" && !item.read; }).length;
  const activeConversation = messages;
  const teacherNames = Array.from(new Set((homeData.courses.length ? homeData.courses : data.courses).map(function(item) { return item.teacher; }).filter(Boolean)));
  const chatTeacherLabel = teacherNames.length === 1 ? teacherNames[0] : "Giáo viên";
  useEffect(function() {
    if (!messagesOpen) return;
    const node = studentMessageThreadRef.current;
    if (!node) return;
    const frame = window.requestAnimationFrame(function() { node.scrollTop = node.scrollHeight; });
    return function() { window.cancelAnimationFrame(frame); };
  }, [messagesOpen, activeConversation.length]);
  useEffect(function() {
    if (!messagesOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return function() { document.body.style.overflow = previousOverflow; };
  }, [messagesOpen]);
  useEffect(function() {
    const badgeCount = Math.min(99, unreadCount + unreadMessageCount);
    void (async function() {
      try {
        const badgeNavigator = navigator as Navigator & { setAppBadge?: (count?: number) => Promise<void>; clearAppBadge?: () => Promise<void> };
        if (badgeCount > 0 && typeof badgeNavigator.setAppBadge === "function") await badgeNavigator.setAppBadge(badgeCount);
        else if (badgeCount === 0 && typeof badgeNavigator.clearAppBadge === "function") await badgeNavigator.clearAppBadge();
        if ("serviceWorker" in navigator) {
          const registration = await navigator.serviceWorker.getRegistration("/");
          registration?.active?.postMessage({ type: "SET_BADGE", count: badgeCount });
        }
      } catch {}
    })();
  }, [unreadCount, unreadMessageCount]);
  const pendingAssignments = data.assignments.filter(function(item) { return !completed.has(item.id) && getAssignmentStatus(item.dueDate, assignmentClock) !== "Đã kết thúc"; });
  const nextAssignment = pendingAssignments.slice().sort(function(a, b) { return a.dueDate.localeCompare(b.dueDate); })[0];
  const nextMakeup = data.sessions.filter(function(item) { return item.sessionType === "makeup"; }).sort(function(a, b) { return (a.sessionDate + a.startTime).localeCompare(b.sessionDate + b.startTime); })[0];
  const grades = useMemo(function() { return data.gradebooks.flatMap(function(book) { return book.assessments.map(function(item) { return { ...item, book: book.title }; }); }); }, [data.gradebooks]);
  const gradePreview = grades.slice(0, 4);
  const attendancePreview = data.attendance.slice(0, 4);
  const commentPreview = data.comments.slice(0, 4);

  if (loading) return <div className="route-loading student-loading"><span><GraduationCap /></span><strong>Đang mở trang của bạn...</strong></div>;
  return (
    <div className="student-shell lms-shell">
      <a className="skip-link" href="#student-main-content">Bỏ qua điều hướng</a>
      <header className="lms-topbar">
        <Link href="/" className="student-brand"><span>{data.site.logoUrl ? <img src={data.site.logoUrl} alt={"Logo " + data.site.siteName} /> : <GraduationCap />}</span><strong>{data.site.siteName}</strong></Link>
        <div className="lms-student-actions">
          <span className="student-avatar">{initials(data.student.name)}</span>
          <p><strong>{data.student.name}</strong><small>{data.student.code}</small></p>
          <span className="student-message-wrap">
            <button onClick={function() { void toggleMessages(); }} aria-label="Nhắn tin với giáo viên" title="Nhắn tin với giáo viên"><MessageSquare />{unreadMessageCount ? <b>{unreadMessageCount}</b> : null}</button>
          </span>
          {messagesOpen && typeof document !== "undefined" ? createPortal(
            <section className="student-message-popover messenger-student-chat" role="dialog" aria-modal="true" aria-label="Nhắn tin với giáo viên">
              <header><div><strong>Nhắn tin với giáo viên</strong></div><button onClick={function() { setMessagesOpen(false); }} aria-label="Đóng tin nhắn"><X /></button></header>
              <div className="student-message-contact"><span className="message-contact-avatar"><GraduationCap /></span><span><strong>{chatTeacherLabel}</strong><small>Giáo viên phụ trách</small></span></div>
              <div className="student-message-thread" ref={studentMessageThreadRef}>{activeConversation.map(function(item) { return <article key={item.id} className={item.direction === "student" ? "mine" : "teacher"}><div><strong>{item.direction === "student" ? "Bạn" : item.teacher || chatTeacherLabel}</strong><span className="student-message-body">{item.body}</span><time>{formatDateTime(item.createdAt)}</time></div></article>; })}{!activeConversation.length ? <div className="student-message-empty"><MessageSquare /><strong>Chưa có tin nhắn</strong><span>Bạn có thể nhắn trực tiếp với giáo viên tại đây.</span></div> : null}</div>
              <form className="student-message-compose" onSubmit={sendTeacherMessage}><div className="message-compose-field"><textarea value={messageDraft} onChange={function(event) { setMessageDraft(event.target.value); }} rows={2} maxLength={4000} placeholder={"Nhắn cho " + chatTeacherLabel + "..."} disabled={sendingMessage} /><EmojiPicker disabled={sendingMessage} onPick={function(emoji) { setMessageDraft(function(current) { return (current + emoji).slice(0, 4000); }); }} /></div><button type="submit" disabled={!messageDraft.trim() || sendingMessage} aria-label="Gửi tin nhắn"><Send /></button></form>
            </section>,
            document.body
          ) : null}
          <span className="student-notice-wrap">
            <button onClick={function() { setNotificationsOpen(!notificationsOpen); setMessagesOpen(false); setPushSettingsOpen(false); }} aria-label="Thông báo" title="Thông báo"><Bell />{unreadCount ? <b>{unreadCount}</b> : null}</button>
            {notificationsOpen ? <section className="student-notice-popover"><header><div><strong>Thông báo</strong><small>Tất cả môn học</small></div><button onClick={function() { setNotificationsOpen(false); }}><X /></button></header>{unreadCount ? <div className="notice-action"><button disabled={markingAllNotifications} onClick={function() { void readAllNotifications(); }}>{markingAllNotifications ? "Đang đánh dấu..." : "Đánh dấu tất cả đã đọc"}</button></div> : null}<div className="notification-list">{homeData.notifications.map(function(item) { return <button key={item.id} className={item.read ? "" : "unread"} onClick={function() { void readNotification(item); }}><Bell /><span><strong>{item.title}</strong><small>{item.courseName ? item.courseName + " · " : ""}{item.body}</small><time>{formatDateTime(item.createdAt)}</time></span></button>; })}{!homeData.notifications.length ? <p>Chưa có thông báo.</p> : null}</div></section> : null}
          </span>
          <span className="student-settings-wrap">
            <button onClick={function() { const next = !pushSettingsOpen; setPushSettingsOpen(next); setNotificationsOpen(false); setMessagesOpen(false); }} aria-label="Cài đặt thông báo" title="Cài đặt thông báo"><Settings /></button>
            {pushSettingsOpen ? <section className="student-settings-popover">
              <header><div><strong>NOTIFICATION</strong></div><button onClick={function() { setPushSettingsOpen(false); }} aria-label="Đóng cài đặt"><X /></button></header>
              <PushNotificationSettings toast={toast} />
            </section> : null}
          </span>
          <button onClick={function() { setDark(!dark); }} aria-label={dark ? "Chuyển giao diện sáng" : "Chuyển giao diện tối"}>{dark ? <Sun /> : <Moon />}</button>
          <button onClick={logout} aria-label="Đăng xuất"><LogOut /></button>
        </div>
      </header>

      <main className="lms-main" id="student-main-content">
        {!courseId ? (
          <div className="lms-home">
            <header className="lms-home-heading"><div><span>Không gian học tập</span><h1>{homeTab === "courses" ? "Các môn học của tôi" : "Lịch học tổng hợp"}</h1></div><aside><Coins /><strong>{homeData.points}</strong><span>điểm thi đua</span></aside></header>
            <nav className="lms-home-tabs" aria-label="Không gian học tập"><button className={homeTab === "courses" ? "active" : ""} onClick={function() { setHomeTab("courses"); }}><BookOpen />Các môn học của tôi</button><button className={homeTab === "schedule" ? "active" : ""} onClick={function() { setHomeTab("schedule"); }}><CalendarDays />Lịch học</button></nav>
            {homeTab === "courses" ? <>{homeData.student.id > 0 ? <PetFocusCompanion studentId={homeData.student.id} toast={toast} /> : null}{homeData.courses.length ? <section className="lms-course-grid">{homeData.courses.map(function(course) { return <CourseCard key={course.key} course={course} open={openCourse} />; })}</section> : <section className="card lms-empty"><BookOpen /><h2>Chưa có môn học</h2><p>Tài khoản của bạn chưa được giáo viên thêm vào lớp nào.</p></section>}
            <section className="lms-home-secondary">
              <article id="student-rewards" className="card lms-rewards"><header><div><h2>Quà có thể đổi</h2></div><Gift /></header><div className="lms-reward-options">{homeData.rewards.slice(0, 6).map(function(item) { const selectable = item.stock > 0 && item.cost <= homeData.points; const selected = selectedRewardId === item.id; return <button key={item.id} type="button" className={selected ? "selected" : ""} aria-pressed={selected} disabled={!selectable} onClick={function() { setSelectedRewardId(item.id); }}><Trophy /><span><strong>{item.title}</strong><small>{item.stock > 0 ? item.cost + " điểm" : "Hết quà"}</small></span>{selected ? <em>Đang chọn</em> : null}</button>; })}{!homeData.rewards.length ? <p>Chưa có quà đổi điểm.</p> : null}</div>{selectedRewardId ? (function() { const selected = homeData.rewards.find(function(item) { return item.id === selectedRewardId; }); return selected ? <div className="lms-reward-confirm"><span><small>Quà đang chọn</small><strong>{selected.title}</strong></span><button type="button" className="button primary" onClick={function() { void redeem(selected.id, selected.title); }}><Gift />Đổi quà đã chọn</button></div> : null; })() : null}</article>
              <article className="card lms-redemptions"><header><div><h2>Lịch sử đổi quà</h2></div><History /></header><div className="reward-history-scroll scroll-region">{homeData.redemptions.map(function(item) { return <div key={item.id}><Gift /><span><strong>{item.rewardTitle}</strong><small>{formatDateTime(item.createdAt)} - {item.cost} điểm</small></span><em className={item.status}>{item.status === "approved" ? "Đã duyệt" : item.status === "rejected" ? "Từ chối" : "Đang chờ"}</em></div>; })}{!homeData.redemptions.length ? <p>Chưa có yêu cầu đổi quà.</p> : null}</div></article>
            </section></> : <section className="lms-home-schedule">{homeData.courses.length ? <StudentWeeklyTimetable courses={homeData.courses} sessions={homeData.sessions} aggregate /> : <div className="card lms-empty"><CalendarDays /><h2>Chưa có lịch học</h2><p>Tài khoản của bạn chưa có môn học để tổng hợp lịch.</p></div>}</section>}
          </div>
        ) : courseLoading ? <div className="lms-course-loading"><span /><span /><span /></div> : (
          <div className="lms-course-page">
            <button className="lms-back" onClick={backToCourses}><ArrowLeft />Các môn học</button>
            <header className={"lms-course-hero tone-" + (data.course?.tone || "indigo")}><div className="lms-course-logo">{data.course?.logoUrl ? <img src={data.course.logoUrl} alt={"Logo " + data.course.name} /> : <BookOpen />}</div><div><span>{data.course?.label || "Môn học"}</span><h1>{data.course?.name}</h1><p>GV {data.course?.teacher}{data.course?.room ? " - " + data.course.room : ""}</p></div><aside><strong>{completed.size}/{data.assignments.length} bài đã làm</strong></aside></header>
            <nav className="lms-course-tabs" aria-label="Nội dung môn học">{TAB_ITEMS.map(function(item) { const Icon = item[2]; return <button key={item[0]} className={tab === item[0] ? "active" : ""} onClick={function() { setTab(item[0]); }}><Icon />{item[1]}{item[0] === "assignments" && pendingAssignments.length ? <em>{pendingAssignments.length}</em> : null}</button>; })}</nav>
            <div key={tab} className="student-tab-transition lms-tab-content">
              {tab === "overview" ? <div className="lms-overview-grid">
                <section className="card lms-overview-primary"><header><div><h2>Tổng quan môn học</h2></div><Home /></header><div className="lms-overview-stats"><article><BarChart3 /><span><small>Điểm trung bình</small><strong>{data.average ?? "Chưa có"}</strong></span></article><article><ClipboardCheck /><span><small>Chuyên cần</small><strong>{data.attendanceRate === null || data.attendanceRate === undefined ? "Chưa có" : data.attendanceRate + "%"}</strong></span></article><article><BookOpen /><span><small>Bài cần nộp</small><strong>{pendingAssignments.length}</strong></span></article></div></section>
                <section className="card lms-next-items"><header><h2>Sắp tới</h2><CalendarDays /></header>{nextAssignment ? <button onClick={function() { setSelectedAssignment(nextAssignment); }}><BookOpen /><span><strong>{nextAssignment.title}</strong><small>Hạn {formatDateTime(nextAssignment.dueDate)}</small></span><ChevronRight /></button> : <div className="lms-inline-empty"><CheckCircle2 />Chưa có bài tập gần hạn.</div>}{nextMakeup ? <button onClick={function() { setCourseId(""); setData(homeData); setHomeTab("schedule"); window.scrollTo({ top: 0, behavior: "smooth" }); }}><Clock3 /><span><strong>Học bù {formatDate(nextMakeup.sessionDate)}</strong><small>{nextMakeup.startTime} - {nextMakeup.endTime} · xem trong lịch học tổng hợp</small></span><ChevronRight /></button> : null}</section>
              </div> : null}

              {tab === "schedule" ? <><div className="student-page-title"><div><h1>Lịch kiểm tra</h1></div><span>{data.calendar.filter(function(item) { return String(item.type || "").toLocaleLowerCase("vi").includes("kiểm tra"); }).length} lịch</span></div><CourseTestCalendar items={data.calendar} courseName={data.course?.name} /></> : null}

              {tab === "documents" ? <><div className="student-page-title"><div><h1>Tài liệu</h1></div><span>{data.documents.length} tài liệu</span></div><section className="student-document-list lms-document-list scroll-region" tabIndex={0} aria-label="Danh sách tài liệu học tập">{data.documents.map(function(item, index) { const url = "/api/documents/" + item.id; const previewable = item.contentType === "application/pdf" || item.contentType.startsWith("image/") || /\.(?:pdf|jpe?g|png|webp)$/i.test(item.name); return <article key={item.id}><span className={"document-icon tone-" + (index % 4)}><FileText /></span><div><em>{item.folder}</em><h2 title={item.name}>{item.name}</h2><p>{formatSize(item.size)}</p></div><time>{formatDate(item.createdAt)}</time><div className="student-document-actions">{previewable ? <button type="button" onClick={function() { setViewerTarget({ name: item.name, url, contentType: item.contentType, viewMode: "continuous" }); }}><Eye />Xem</button> : null}<a href={url + "?download=1"}><Download />Tải xuống</a></div></article>; })}{!data.documents.length ? <div className="lms-empty"><FolderOpen /><h2>Chưa có tài liệu</h2><p>Giáo viên chưa đăng tài liệu cho môn này.</p></div> : null}</section></> : null}

              {tab === "assignments" ? <><div className="student-page-title"><div><h1>Bài tập</h1></div><span>{completed.size}/{data.assignments.length} bài đã làm</span></div><section className="lms-assignment-list scroll-region">{data.assignments.map(function(item) { const status = assignmentLabel(item, assignmentClock); return <article className="card" key={item.id}><div className="lms-assignment-icon"><BookOpen /></div><div><span className={"lms-status " + status.tone}>{status.text}</span><h2>{item.title}</h2><RichAssignmentDescription className="assignment-description" text={item.description || "Chưa có mô tả."} /><dl><div><dt>Hạn nộp</dt><dd>{formatDateTime(item.dueDate)}</dd></div><div><dt>Điểm tối đa</dt><dd>{item.maxScore}</dd></div></dl>{item.submission?.status === "graded" ? <div className="lms-inline-grade"><strong>{item.submission.score ?? "-"} / {item.maxScore}</strong><span>{item.submission.feedback || "Đã chấm"}</span></div> : null}</div><div className="lms-assignment-actions">{item.attachmentName ? <button type="button" className="button ghost" onClick={function() { setSelectedAssignment(item); }}><Paperclip />Đề bài</button> : null}<button className="button primary" disabled={status.tone === "overdue" && !item.submission && !item.teacherCompletedAt} onClick={function() { setSelectedAssignment(item); }}>{isStudentSubmittedStatus(item.submission?.status) ? (status.tone === "overdue" ? "Xem bài nộp" : "Xem / nộp lại") : isDraftSubmissionStatus(item.submission?.status) ? "Tiếp tục" : item.teacherCompletedAt ? "Xem trạng thái" : "Nộp bài"}</button></div></article>; })}{!data.assignments.length ? <div className="card lms-empty"><BookOpen /><h2>Chưa có bài tập</h2><p>Giáo viên chưa giao bài cho môn này.</p></div> : null}</section></> : null}

              {tab === "progress" ? <><div className="student-page-title"><div><h1>Điểm / Quá trình học</h1></div></div><section className="lms-progress-grid">
                <article className="card progress-summary-card"><header><div><h2>Điểm học tập</h2><p>Điểm trung bình: {data.average ?? "chưa có"}</p></div><BarChart3 /></header><div className="student-grade-scroll progress-preview-list">{gradePreview.map(function(item) { return <div key={item.book + item.id}><span><strong>{item.title}</strong><small>{item.book} - trọng số {item.weight}%</small></span><b>{item.score === null ? "-" : item.score + " / " + item.maxScore}</b></div>; })}{!grades.length ? <p>Chưa có điểm kiểm tra.</p> : null}</div>{grades.length ? <button type="button" className="progress-detail-button" onClick={function() { setProgressDetail("grades"); }}>Xem chi tiết <span>{grades.length}</span><ChevronRight /></button> : null}</article>
                <article className="card progress-summary-card"><header><div><h2>Điểm danh</h2><p>Chuyên cần: {data.attendanceRate === null || data.attendanceRate === undefined ? "chưa có" : data.attendanceRate + "%"}</p></div><ClipboardCheck /></header><div className="student-attendance-scroll progress-preview-list">{attendancePreview.map(function(item) { return <div key={item.id}><span className={item.status}><Clock3 /></span><p><strong>{ATTENDANCE_LABELS[item.status] || item.status}</strong><small>{formatDate(item.date)} - {item.startTime} đến {item.endTime}{item.sessionType === "makeup" ? " - Học bù" : ""}</small></p></div>; })}{!data.attendance.length ? <p>Chưa có lịch sử điểm danh.</p> : null}</div>{data.attendance.length ? <button type="button" className="progress-detail-button" onClick={function() { setProgressDetail("attendance"); }}>Xem chi tiết <span>{data.attendance.length}</span><ChevronRight /></button> : null}</article>
                <article className="card lms-comments progress-summary-card"><header><div><h2>Nhận xét giáo viên</h2><p>{data.comments.length ? data.comments.length + " nhận xét" : "Chưa có nhận xét"}</p></div><Bell /></header><div className="progress-comment-preview">{commentPreview.map(function(item) { return <article key={item.id}><time>{formatDate(item.date)}</time><div><strong>{item.type}</strong><p>{item.content}</p><small>{item.creator}</small></div></article>; })}{!data.comments.length ? <p>Chưa có nhận xét.</p> : null}</div>{data.comments.length ? <button type="button" className="progress-detail-button" onClick={function() { setProgressDetail("comments"); }}>Xem chi tiết <span>{data.comments.length}</span><ChevronRight /></button> : null}</article>
              </section></> : null}
            </div>
          </div>
        )}
      </main>
      {selectedNotification ? <div className="modal student-notification-detail-backdrop" onMouseDown={function() { setSelectedNotification(null); }}><article className="form-modal student-notification-detail" role="dialog" aria-modal="true" aria-label="Chi tiết thông báo" onMouseDown={function(event) { event.stopPropagation(); }}><div className="modal-head"><div><span className="notification-detail-kicker"><Bell /> Thông báo</span><h2>{selectedNotification.title}</h2><p>{selectedNotification.courseName || "Thông báo chung"} · {formatDateTime(selectedNotification.createdAt)}</p></div><button type="button" className="modal-close" onClick={function() { setSelectedNotification(null); }}><X /></button></div><div className="notification-detail-body">{selectedNotification.body}</div><div className="modal-footer"><button type="button" className="button ghost" onClick={function() { setSelectedNotification(null); }}>Đóng</button>{selectedNotification.courseKey && TAB_ITEMS.some(function(item) { return item[0] === selectedNotification.actionView; }) ? <button type="button" className="button primary" onClick={function() { void openNotificationAction(selectedNotification); }}>Mở mục liên quan <ChevronRight /></button> : null}</div></article></div> : null}
      {progressDetail ? <div className="modal student-progress-detail-backdrop" onMouseDown={function() { setProgressDetail(null); }}><article className="form-modal student-progress-detail" role="dialog" aria-modal="true" aria-label="Chi tiết quá trình học" onMouseDown={function(event) { event.stopPropagation(); }}><div className="modal-head"><div><h2>{progressDetail === "grades" ? "Chi tiết điểm học tập" : progressDetail === "attendance" ? "Lịch sử điểm danh" : "Nhận xét giáo viên"}</h2><p>{data.course?.name || "Môn học"}</p></div><button type="button" className="modal-close" onClick={function() { setProgressDetail(null); }}><X /></button></div><div className="student-progress-detail-list scroll-region">{progressDetail === "grades" ? grades.map(function(item) { return <div className="progress-grade-row" key={item.book + item.id}><span><strong>{item.title}</strong><small>{item.book} · trọng số {item.weight}%</small></span><b>{item.score === null ? "-" : item.score + " / " + item.maxScore}</b></div>; }) : null}{progressDetail === "attendance" ? data.attendance.map(function(item) { return <div className="progress-attendance-row" key={item.id}><span className={item.status}><Clock3 /></span><p><strong>{ATTENDANCE_LABELS[item.status] || item.status}</strong><small>{formatDate(item.date)} · {item.startTime} đến {item.endTime}{item.sessionType === "makeup" ? " · Học bù" : ""}</small>{item.note ? <em>{item.note}</em> : null}</p></div>; }) : null}{progressDetail === "comments" ? data.comments.map(function(item) { return <article className="progress-comment-row" key={item.id}><time>{formatDate(item.date)}</time><div><strong>{item.type}</strong><p>{item.content}</p><small>{item.creator}</small></div></article>; }) : null}</div><div className="modal-footer"><button type="button" className="button primary" onClick={function() { setProgressDetail(null); }}>Đóng</button></div></article></div> : null}
      {selectedAssignment ? <SubmissionModal assignment={selectedAssignment} teacherName={data.course?.teacher || "Giáo viên"} clock={assignmentClock} close={function() { setSelectedAssignment(null); }} submit={submitAssignment} /> : null}
      <FileViewerModal target={viewerTarget} close={function() { setViewerTarget(null); }} />
      {message ? <div className="toast"><CheckCircle2 />{message}</div> : null}
    </div>
  );
}
