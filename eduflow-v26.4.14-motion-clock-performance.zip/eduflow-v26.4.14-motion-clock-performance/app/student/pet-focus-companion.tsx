"use client";

import {
  Check,
  Flame,
  Focus,
  Snowflake,
  PawPrint,
  Pencil,
  RotateCcw,
  Search,
  SkipForward,
  Sparkles,
  Square,
  TimerReset,
  Trophy,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";
import { createPortal } from "react-dom";
import { MorphIcon } from "../../lib/vendor/morphicons/react/index";
import FocusStudio, { type FocusStudioTimer } from "./focus-studio";

type PetAnimation = "idle" | "runRight" | "runLeft" | "waving" | "jumping" | "failed" | "waiting" | "running" | "review";
type TimerMode = "focus" | "break";
type TimerStatus = "idle" | "running" | "paused";

type PetResponse = {
  pet: { slug: string; name: string; displayName: string; spritesheetUrl: string; thumbnailUrl?: string; previewUrl?: string; petJsonUrl: string; sourceUrl: string; tags?: string[]; kind?: string; version?: string; gridRows?: number; available: boolean };
  streak: {
    current: number;
    longest: number;
    totalCheckins: number;
    checkedInToday: boolean;
    lastCheckinDate: string;
    nextMilestone: number;
    milestoneProgress: number;
    freezeAvailable: boolean;
    freezeLastUsedDate: string;
    freezeNextAvailableDate: string;
    freezeDaysRemaining: number;
    freezeProtectedYesterday?: boolean;
    missedCheckin: boolean;
    missedDays: number;
  };
  result?: { changed: boolean; usedFreeze: boolean; milestone: boolean; majorMilestone: boolean; message: string };
};


type PetChoice = {
  slug: string;
  displayName: string;
  spritesheetUrl: string;
  thumbnailUrl?: string;
  previewUrl?: string;
  petJsonUrl: string;
  sourceUrl: string;
  tags?: string[];
  kind: string;
  version: string;
  gridRows?: number;
  available: boolean;
};
type PetCatalogPayload = {
  pets?: PetChoice[];
  total?: number;
  nextOffset?: number | null;
  facets?: { kinds?: string[]; tags?: string[]; versions?: string[] };
  warning?: string;
  error?: string;
};

type FocusStats = {
  todayMinutes: number;
  todayTrackedMinutes: number;
  todayManualMinutes: number;
  todaySessions: number;
  weekMinutes: number;
  weekTrackedMinutes: number;
  weekManualMinutes: number;
  weekSessions: number;
  weekStart: string;
};
type ServerTimer = {
  mode: TimerMode;
  status: TimerStatus;
  running: boolean;
  remainingMs: number;
  duration?: number;
  focusMinutes: number;
  breakMinutes: number;
  endsAt: string;
  sessionKey: string;
  sessionId?: string;
  userId?: number;
  startedAt: string;
  revision: number;
  updatedAt: string;
};
type FocusApiPayload = { timer?: ServerTimer; stats?: FocusStats; serverNow?: string; error?: string };
type TimerState = {
  mode: TimerMode;
  status: TimerStatus;
  running: boolean;
  endAt: number;
  remainingMs: number;
  duration?: number;
  focusMinutes: number;
  breakMinutes: number;
  sessionKey: string;
  sessionId?: string;
  userId?: number;
  startedAt: string;
  revision: number;
  updatedAt: string;
};

type Props = { studentId: number; toast: (message: string) => void };

const ROAM_STORAGE_KEY = "eduflow-pet-roam";
const TIMER_DEFAULT: TimerState = { mode: "focus", status: "idle", running: false, endAt: 0, remainingMs: 25 * 60_000, focusMinutes: 25, breakMinutes: 5, sessionKey: "", startedAt: "", revision: 0, updatedAt: "" };
const FOCUS_PRESETS: Array<[number, number]> = [[25, 5], [45, 10], [50, 10], [90, 15]];
const FOCUS_PLAY_PATH = "M7 4.8v14.4L19 12 7 4.8Z";
const FOCUS_PAUSE_PATH = "M8 5v14M16 5v14";
const FOCUS_EXPAND_PATH = "M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5";
const PET_FRAMES: Record<PetAnimation, { row: number; frames: number }> = {
  idle: { row: 0, frames: 6 },
  runRight: { row: 1, frames: 8 },
  runLeft: { row: 2, frames: 8 },
  waving: { row: 3, frames: 4 },
  jumping: { row: 4, frames: 5 },
  failed: { row: 5, frames: 8 },
  waiting: { row: 6, frames: 6 },
  running: { row: 7, frames: 6 },
  review: { row: 8, frames: 6 },
};

function clamp(value: number, min: number, max: number) { return Math.min(max, Math.max(min, Math.round(value || min))); }
function formatTimer(ms: number) {
  const seconds = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(seconds / 60);
  return String(minutes).padStart(2, "0") + ":" + String(seconds % 60).padStart(2, "0");
}
function formatFocusTotal(minutes: number) {
  if (minutes < 60) return minutes + " phút";
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest ? hours + "g " + rest + "p" : hours + " giờ";
}

function vietnamReminderStage(now = new Date()): "normal" | "waiting" | "danger" {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Ho_Chi_Minh", hour: "2-digit", minute: "2-digit", hour12: false }).formatToParts(now);
  const hour = Number(parts.find(function(part) { return part.type === "hour"; })?.value || 0);
  if (hour >= 22) return "danger";
  if (hour >= 18) return "waiting";
  return "normal";
}

function settledPetAnimation(timer: TimerState): PetAnimation {
  if (timer.running && timer.mode === "focus") return "review";
  if (!timer.running && timer.mode === "focus" && timer.sessionKey) return "waiting";
  if (timer.running && timer.mode === "break") return "running";
  return "idle";
}

function PetSprite(props: { state: PetAnimation; url: string; reducedMotion: boolean; gridRows?: number; label?: string; petId?: string; lazy?: boolean; retryToken?: number; onLoadState?: (state: "loading" | "ready" | "error") => void }) {
  const { url } = props;
  const [assetState, setAssetState] = useState<"loading" | "ready" | "error">(props.url ? "loading" : "error");
  const [shouldLoad, setShouldLoad] = useState(!props.lazy);
  const [automaticRetry, setAutomaticRetry] = useState(0);
  const rootRef = useRef<HTMLSpanElement | null>(null);
  const loadStateCallbackRef = useRef(props.onLoadState);
  const clip = PET_FRAMES[props.state];

  useEffect(function() { loadStateCallbackRef.current = props.onLoadState; }, [props.onLoadState]);

  useEffect(function() {
    setAutomaticRetry(0);
  }, [props.retryToken, url]);

  useEffect(function() {
    if (!props.lazy) return;
    const element = rootRef.current;
    if (!element || typeof IntersectionObserver === "undefined") {
      const fallbackTimer = window.setTimeout(function() { setShouldLoad(true); }, 0);
      return function() { window.clearTimeout(fallbackTimer); };
    }
    const observer = new IntersectionObserver(function(entries) {
      if (!entries.some(function(entry) { return entry.isIntersecting; })) return;
      setShouldLoad(true);
      observer.disconnect();
    }, { rootMargin: "240px 0px" });
    observer.observe(element);
    return function() { observer.disconnect(); };
  }, [props.lazy, url]);

  useEffect(function() {
    let active = true;
    if (!url) {
      const missingTimer = window.setTimeout(function() {
        if (!active) return;
        setAssetState("error");
        loadStateCallbackRef.current?.("error");
      }, 0);
      return function() { active = false; window.clearTimeout(missingTimer); };
    }
    if (!shouldLoad) return function() { active = false; };
    const loadingTimer = window.setTimeout(function() {
      if (!active) return;
      setAssetState("loading");
      loadStateCallbackRef.current?.("loading");
    }, 0);
    const retryUrl = automaticRetry > 0
      ? url + (url.includes("?") ? "&" : "?") + "eduflow_retry=" + String(automaticRetry)
      : url;
    const failOrRetry = function(reason: "timeout" | "error") {
      if (!active) return;
      if (automaticRetry < 1) {
        active = false;
        setAutomaticRetry(1);
        return;
      }
      active = false;
      console.warn("[EDUFLOW Petdex] Sprite " + reason, { petId: props.petId || props.label || "unknown", url });
      setAssetState("error");
      loadStateCallbackRef.current?.("error");
    };
    const timeout = window.setTimeout(function() { failOrRetry("timeout"); }, 12_000);
    const image = new Image();
    image.decoding = "async";
    image.onload = function() {
      if (!active) return;
      window.clearTimeout(timeout);
      setAssetState("ready");
      loadStateCallbackRef.current?.("ready");
    };
    image.onerror = function() {
      window.clearTimeout(timeout);
      failOrRetry("error");
    };
    image.src = retryUrl;
    return function() { active = false; window.clearTimeout(loadingTimer); window.clearTimeout(timeout); image.onload = null; image.onerror = null; };
  }, [automaticRetry, props.label, props.petId, props.retryToken, shouldLoad, url]);

  if (!props.url || assetState !== "ready") return <span ref={rootRef} className={"petdex-fallback " + (assetState === "loading" ? "loading" : "error")} role="img" aria-label={assetState === "loading" ? "Đang tải hình pet" : "Hình pet đang tạm thời không tải được"}><PawPrint /></span>;
  const rows = props.gridRows === 11 ? 11 : 9;
  const frameCount = Math.max(1, clip.frames);
  const trackStyle = {
    width: "800%",
    height: String(rows * 100) + "%",
    top: String(-clip.row * 100) + "%",
    "--pet-frame-shift": String(-Math.max(0, frameCount - 1) * 12.5) + "%",
    "--pet-frame-duration": String(frameCount * 125) + "ms",
    "--pet-frame-steps": String(Math.max(1, frameCount - 1)),
  } as CSSProperties & Record<"--pet-frame-shift" | "--pet-frame-duration" | "--pet-frame-steps", string>;
  return <span ref={rootRef} className={"petdex-sprite" + (!props.reducedMotion && frameCount > 1 ? " is-animated" : "")} role="img" aria-label={(props.label || "Pet") + " - " + props.state}>
    <img key={props.state + ":" + props.url} className="petdex-sprite-track" src={props.url} alt="" draggable={false} decoding="async" style={trackStyle} />
  </span>;
}

function PetThumbnail(props: { src?: string; fallbackSrc?: string; label: string; lazy?: boolean }) {
  const [failed, setFailed] = useState(false);
  const src = failed ? props.fallbackSrc : props.src;
  if (!src) return <span className="petdex-fallback error" role="img" aria-label={props.label}><PawPrint /></span>;
  return <img className="petdex-thumb-image" src={src} alt={props.label} loading={props.lazy ? "lazy" : "eager"} decoding="async" onError={function() { if (!failed && props.fallbackSrc && props.fallbackSrc !== props.src) setFailed(true); }} />;
}

function studentStorageKey(base: string, studentId: number) {
  return base + ":student:" + String(Math.max(0, Math.floor(studentId)));
}

function normalizeServerTimer(input: ServerTimer, serverNow: string): { timer: TimerState; offsetMs: number } {
  const serverNowMs = Date.parse(serverNow);
  const safeServerNow = Number.isFinite(serverNowMs) ? serverNowMs : Date.now();
  const endAt = input.running && input.endsAt ? Date.parse(input.endsAt) : 0;
  const maximum = (input.mode === "focus" ? input.focusMinutes : input.breakMinutes) * 60_000;
  const remainingMs = input.running && Number.isFinite(endAt) && endAt > 0
    ? Math.min(maximum, Math.max(0, endAt - safeServerNow))
    : Math.min(maximum, Math.max(0, Number(input.remainingMs) || 0));
  return {
    offsetMs: safeServerNow - Date.now(),
    timer: {
      mode: input.mode === "break" ? "break" : "focus",
      status: input.status === "running" || input.status === "paused" ? input.status : "idle",
      running: input.status === "running" && input.running === true,
      endAt: Number.isFinite(endAt) ? endAt : 0,
      remainingMs,
      focusMinutes: clamp(input.focusMinutes, 5, 180),
      breakMinutes: clamp(input.breakMinutes, 1, 60),
      sessionKey: String(input.sessionKey || "").slice(0, 80),
      startedAt: String(input.startedAt || ""),
      revision: Math.max(0, Math.floor(Number(input.revision) || 0)),
      updatedAt: String(input.updatedAt || ""),
    },
  };
}

export default function PetFocusCompanion(props: Props) {
  const [petData, setPetData] = useState<PetResponse | null>(null);
  const [focusStats, setFocusStats] = useState<FocusStats>({
    todayMinutes: 0,
    todayTrackedMinutes: 0,
    todayManualMinutes: 0,
    todaySessions: 0,
    weekMinutes: 0,
    weekTrackedMinutes: 0,
    weekManualMinutes: 0,
    weekSessions: 0,
    weekStart: "",
  });
  const [loadingPet, setLoadingPet] = useState(true);
  const [spriteLoadState, setSpriteLoadState] = useState<"loading" | "ready" | "error">("loading");
  const [checkingIn, setCheckingIn] = useState(false);
  const [timer, setTimer] = useState<TimerState>(TIMER_DEFAULT);
  const [timerReady, setTimerReady] = useState(false);
  const [timerSyncing, setTimerSyncing] = useState(false);
  const [petAnimation, setPetAnimation] = useState<PetAnimation>("waving");
  const [streakReminderStage, setStreakReminderStage] = useState<"normal" | "waiting" | "danger">("normal");
  const [roamX, setRoamX] = useState(0);
  const [roamEnabled, setRoamEnabled] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [customOpen, setCustomOpen] = useState(false);
  const [focusExpanded, setFocusExpanded] = useState(false);
  const [focusStudioOpen, setFocusStudioOpen] = useState(false);
  const [selectedFocusTaskId, setSelectedFocusTaskId] = useState<number | null>(null);
  const [focusMinutesDraft, setFocusMinutesDraft] = useState(String(TIMER_DEFAULT.focusMinutes));
  const [breakMinutesDraft, setBreakMinutesDraft] = useState(String(TIMER_DEFAULT.breakMinutes));
  const [durationDraftDirty, setDurationDraftDirty] = useState(false);
  const [renamingPet, setRenamingPet] = useState(false);
  const [petNameDraft, setPetNameDraft] = useState("Punch");
  const [savingPetName, setSavingPetName] = useState(false);
  const [petPickerOpen, setPetPickerOpen] = useState(false);
  const [petChoices, setPetChoices] = useState<PetChoice[]>([]);
  const [petDraft, setPetDraft] = useState<PetChoice | null>(null);
  const [petSearch, setPetSearch] = useState("");
  const [petKind, setPetKind] = useState("");
  const [petTag, setPetTag] = useState("");
  const [petVersion, setPetVersion] = useState("");
  const [petFacets, setPetFacets] = useState<{ kinds: string[]; tags: string[]; versions: string[] }>({ kinds: [], tags: [], versions: [] });
  const [petCatalogTotal, setPetCatalogTotal] = useState(0);
  const [petCatalogNextOffset, setPetCatalogNextOffset] = useState<number | null>(null);
  const [petCatalogLoading, setPetCatalogLoading] = useState(false);
  const [petCatalogError, setPetCatalogError] = useState("");
  const [petCatalogWarning, setPetCatalogWarning] = useState("");
  const [changingPet, setChangingPet] = useState(false);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const petRef = useRef<HTMLDivElement | null>(null);
  const petPickerTriggerRef = useRef<HTMLButtonElement | null>(null);
  const petPickerDialogRef = useRef<HTMLElement | null>(null);
  const petSearchInputRef = useRef<HTMLInputElement | null>(null);
  const petCatalogAbortRef = useRef<AbortController | null>(null);
  const petCatalogRequestRef = useRef(0);
  const changingPetRef = useRef(false);
  const roamDirectionRef = useRef<1 | -1>(1);
  const completingRef = useRef(false);
  const celebrationTimerRef = useRef<number | null>(null);
  const animationLockRef = useRef(false);
  const missedAnimationShownRef = useRef(false);
  const timerRef = useRef<TimerState>(TIMER_DEFAULT);
  const clockOffsetRef = useRef(0);

  const timerActive = timer.status !== "idle" || timer.mode === "break";
  const petName = petData?.pet.name || "Punch";

  useEffect(function() { changingPetRef.current = changingPet; }, [changingPet]);

  function celebrate(animation: PetAnimation, duration = 1800) {
    if (celebrationTimerRef.current) window.clearTimeout(celebrationTimerRef.current);
    animationLockRef.current = true;
    setPetAnimation(animation);
    celebrationTimerRef.current = window.setTimeout(function() {
      animationLockRef.current = false;
      setPetAnimation(settledPetAnimation(timerRef.current));
    }, duration);
  }

  function applyFocusPayload(payload: FocusApiPayload, announceBoundary = false): TimerState | null {
    if (!payload.timer || !payload.serverNow) {
      if (payload.stats) setFocusStats(payload.stats);
      return null;
    }
    const previous = timerRef.current;
    const normalized = normalizeServerTimer(payload.timer, payload.serverNow);
    // Network responses can arrive out of order when a poll overlaps a button action.
    // Never let an older device/server revision overwrite a newer authoritative state.
    if (normalized.timer.revision < previous.revision) return previous;
    clockOffsetRef.current = normalized.offsetMs;
    timerRef.current = normalized.timer;
    setTimer(normalized.timer);
    if (payload.stats) setFocusStats(payload.stats);

    if (announceBoundary && previous.running && previous.mode === "focus" && normalized.timer.mode === "break" && normalized.timer.status === "paused") {
      celebrate("jumping", 1800);
      props.toast("Phiên tập trung đã hoàn thành. Giờ nghỉ đang chờ bạn bắt đầu.");
      if (!payload.stats) void syncFocusState(true, false);
    } else if (announceBoundary && previous.running && previous.mode === "break" && normalized.timer.mode === "focus" && normalized.timer.status === "idle") {
      celebrate("waving", 1700);
      props.toast("Hết giờ nghỉ. Bạn có thể bắt đầu phiên tập trung tiếp theo.");
    }
    return normalized.timer;
  }

  async function syncFocusState(includeStats = false, announceBoundary = false) {
    try {
      const response = await fetch("/api/student/focus" + (includeStats ? "" : "?timerOnly=1"), { cache: "no-store" });
      const payload = await response.json() as FocusApiPayload;
      if (!response.ok) return null;
      return applyFocusPayload(payload, announceBoundary);
    } catch {
      return null;
    }
  }

  async function sendTimerAction(action: "configure" | "start" | "start-break" | "pause" | "resume-break" | "stop" | "skip-break", extra: Record<string, unknown> = {}) {
    if (timerSyncing) return null;
    setTimerSyncing(true);
    try {
      const response = await fetch("/api/student/focus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, revision: timerRef.current.revision, ...extra }),
      });
      const payload = await response.json() as FocusApiPayload;
      if (payload.timer && payload.serverNow) applyFocusPayload(payload, false);
      if (!response.ok) {
        props.toast(payload.error || "Không thể đồng bộ Pomodoro.");
        return null;
      }
      return timerRef.current;
    } catch {
      props.toast("Không thể đồng bộ Pomodoro. Kiểm tra kết nối rồi thử lại.");
      return null;
    } finally {
      setTimerSyncing(false);
    }
  }

  async function loadCompanion() {
    try {
      const [petResponse, focusResponse] = await Promise.all([
        fetch("/api/student/pet", { cache: "no-store" }),
        fetch("/api/student/focus", { cache: "no-store" }),
      ]);
      if (petResponse.ok) {
        const payload = await petResponse.json() as PetResponse;
        setPetData(payload);
        setPetNameDraft(payload.pet.name || "Punch");
      }
      if (focusResponse.ok) {
        const payload = await focusResponse.json() as FocusApiPayload;
        applyFocusPayload(payload, false);
      }
    } finally {
      setTimerReady(true);
      setLoadingPet(false);
    }
  }

  useEffect(function() {
    missedAnimationShownRef.current = false;
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = function() { setReducedMotion(media.matches); };
    const syncWhenVisible = function() {
      if (document.visibilityState === "visible") void syncFocusState(true, true);
    };
    const syncWhenFocused = function() { void syncFocusState(true, true); };
    media.addEventListener?.("change", update);
    document.addEventListener("visibilitychange", syncWhenVisible);
    window.addEventListener("focus", syncWhenFocused);
    window.addEventListener("online", syncWhenFocused);
    const initializeTimer = window.setTimeout(function() {
      update();
      const savedRoam = window.localStorage.getItem(studentStorageKey(ROAM_STORAGE_KEY, props.studentId));
      setRoamEnabled(savedRoam !== "off");
      void loadCompanion();
    }, 0);
    const greetingTimer = window.setTimeout(function() { if (!animationLockRef.current) setPetAnimation("idle"); }, 1500);
    return function() {
      window.clearTimeout(greetingTimer);
      window.clearTimeout(initializeTimer);
      if (celebrationTimerRef.current) window.clearTimeout(celebrationTimerRef.current);
      media.removeEventListener?.("change", update);
      document.removeEventListener("visibilitychange", syncWhenVisible);
      window.removeEventListener("focus", syncWhenFocused);
      window.removeEventListener("online", syncWhenFocused);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.studentId]);

  useEffect(function() {
    if (!timerReady) return;
    const interval = window.setInterval(function() { if (document.visibilityState === "visible") void syncFocusState(false, true); }, 10_000);
    return function() { window.clearInterval(interval); };
  // Ten-second polling keeps a second device current without creating a heavy D1 read loop.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timerReady]);

  useEffect(function() {
    if (!petData?.streak.missedCheckin || petData.streak.checkedInToday || missedAnimationShownRef.current) return;
    missedAnimationShownRef.current = true;
    celebrate("failed", 10_000);
  }, [petData?.streak.checkedInToday, petData?.streak.missedCheckin]);

  useEffect(function() {
    const updateStage = function() {
      setStreakReminderStage(petData?.streak.checkedInToday ? "normal" : vietnamReminderStage());
    };
    updateStage();
    const interval = window.setInterval(updateStage, 30_000);
    return function() { window.clearInterval(interval); };
  }, [petData?.streak.checkedInToday]);

  useEffect(function() {
    if (timerRef.current.running || animationLockRef.current || petData?.streak.checkedInToday) return;
    const frame = window.requestAnimationFrame(function() {
      if (streakReminderStage === "danger") setPetAnimation("failed");
      else if (streakReminderStage === "waiting") setPetAnimation("waiting");
      else setPetAnimation(settledPetAnimation(timerRef.current));
    });
    return function() { window.cancelAnimationFrame(frame); };
  }, [petData?.streak.checkedInToday, streakReminderStage]);

  useEffect(function() {
    timerRef.current = timer;
  }, [timer]);

  useEffect(function() {
    if (durationDraftDirty) return;
    setFocusMinutesDraft(String(timer.focusMinutes));
    setBreakMinutesDraft(String(timer.breakMinutes));
  }, [durationDraftDirty, timer.breakMinutes, timer.focusMinutes]);

  useEffect(function() {
    if (!timer.running || animationLockRef.current) return;
    if (timer.mode === "focus") {
      const stage = stageRef.current;
      const pet = petRef.current;
      if (stage && pet) setRoamX(Math.max(0, (stage.clientWidth - pet.offsetWidth) / 2));
      setPetAnimation("review");
    } else {
      setPetAnimation("running");
    }
  }, [timer.mode, timer.running]);

  useEffect(function() {
    if (!timerReady || !timer.running) return;
    let timeout = 0;
    let active = true;
    const tick = function() {
      if (!active) return;
      const serverNowEstimate = Date.now() + clockOffsetRef.current;
      const remaining = Math.max(0, timer.endAt - serverNowEstimate);
      if (remaining > 0) {
        const nextSecond = Math.ceil(remaining / 1000);
        setTimer(function(current) {
          if (current.endAt !== timer.endAt) return current;
          return Math.ceil(current.remainingMs / 1000) === nextSecond ? current : { ...current, remainingMs: remaining };
        });
        // Align to the visible second boundary. This cuts the old 2 Hz parent
        // re-render loop in half and prevents Focus Space panels/iframes from
        // diffing twice per second while keeping the countdown visually exact.
        const boundary = remaining % 1000;
        timeout = window.setTimeout(tick, Math.max(80, boundary + 18));
        return;
      }
      if (completingRef.current) return;
      completingRef.current = true;
      void syncFocusState(true, true).finally(function() {
        // Focus and Break are deliberately separated: when Focus ends, Break remains
        // paused until the student explicitly presses Bắt đầu nghỉ.
        window.setTimeout(function() { completingRef.current = false; }, 250);
      });
    };
    const syncVisible = function() {
      if (document.visibilityState !== "visible") return;
      window.clearTimeout(timeout);
      tick();
    };
    tick();
    document.addEventListener("visibilitychange", syncVisible);
    return function() {
      active = false;
      window.clearTimeout(timeout);
      document.removeEventListener("visibilitychange", syncVisible);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timer.endAt, timer.mode, timer.running, timerReady]);

  useEffect(function() {
    if (!roamEnabled || reducedMotion || streakReminderStage !== "normal" || (timer.running && timer.mode === "focus")) return;
    const settleTimers: number[] = [];
    const move = function() {
      if (animationLockRef.current || (timerRef.current.running && timerRef.current.mode === "focus")) return;
      const stage = stageRef.current;
      const pet = petRef.current;
      if (!stage || !pet) return;
      const max = Math.max(0, stage.clientWidth - pet.offsetWidth - 28);
      const direction = roamDirectionRef.current;
      setPetAnimation(direction > 0 ? "runRight" : "runLeft");
      setRoamX(direction > 0 ? max : 0);
      roamDirectionRef.current = direction > 0 ? -1 : 1;
      settleTimers.push(window.setTimeout(function() {
        if (!animationLockRef.current) setPetAnimation(function(current) { return current === "runRight" || current === "runLeft" ? "waiting" : current; });
      }, 4600));
    };
    const first = window.setTimeout(move, 700);
    const interval = window.setInterval(move, 6000);
    return function() { window.clearTimeout(first); window.clearInterval(interval); settleTimers.forEach(function(id) { window.clearTimeout(id); }); };
  }, [reducedMotion, roamEnabled, streakReminderStage, timer.mode, timer.running]);

  useEffect(function() {
    if (!petPickerOpen) return;
    const body = document.body;
    const scrollY = window.scrollY;
    const previous = {
      overflow: body.style.overflow,
      position: body.style.position,
      top: body.style.top,
      width: body.style.width,
    };
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : petPickerTriggerRef.current;
    body.style.overflow = "hidden";
    body.style.position = "fixed";
    body.style.top = "-" + scrollY + "px";
    body.style.width = "100%";

    const focusTimer = window.setTimeout(function() { petSearchInputRef.current?.focus(); }, 0);
    const handleKeyDown = function(event: KeyboardEvent) {
      if (event.key === "Escape") {
        event.preventDefault();
        if (!changingPetRef.current) setPetPickerOpen(false);
        return;
      }
      if (event.key !== "Tab") return;
      const dialog = petPickerDialogRef.current;
      if (!dialog) return;
      const focusable = Array.from(dialog.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'))
        .filter(function(element) { return element.offsetParent !== null; });
      if (!focusable.length) {
        event.preventDefault();
        dialog.focus();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return function() {
      window.clearTimeout(focusTimer);
      document.removeEventListener("keydown", handleKeyDown);
      body.style.overflow = previous.overflow;
      body.style.position = previous.position;
      body.style.top = previous.top;
      body.style.width = previous.width;
      window.scrollTo({ top: scrollY, behavior: "instant" });
      previouslyFocused?.focus();
    };
  }, [petPickerOpen]);

  useEffect(function() {
    if (!petPickerOpen) return;
    const debounce = window.setTimeout(function() { void loadPetChoices({ offset: 0 }); }, 320);
    return function() {
      window.clearTimeout(debounce);
      petCatalogAbortRef.current?.abort();
    };
  // The request function reads the latest filter state after the debounce.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [petKind, petPickerOpen, petSearch, petTag, petVersion]);

  function applyPreset(focusMinutes: number, breakMinutes: number) {
    if (timerActive || timerSyncing) return;
    const nextFocus = clamp(focusMinutes, 5, 180);
    const nextBreak = clamp(breakMinutes, 1, 60);
    setFocusMinutesDraft(String(nextFocus));
    setBreakMinutesDraft(String(nextBreak));
    setDurationDraftDirty(false);
    void sendTimerAction("configure", { focusMinutes: nextFocus, breakMinutes: nextBreak });
  }

  async function commitCustomDurations() {
    if (timerActive || timerSyncing) return null;
    if (!focusMinutesDraft.trim() || !breakMinutesDraft.trim()) {
      props.toast("Hãy nhập đủ thời gian Focus và Break.");
      return null;
    }
    const parsedFocus = Number(focusMinutesDraft);
    const parsedBreak = Number(breakMinutesDraft);
    if (!Number.isFinite(parsedFocus) || !Number.isFinite(parsedBreak)) {
      props.toast("Hãy nhập đủ thời gian Focus và Break.");
      return null;
    }
    const nextFocus = clamp(parsedFocus, 5, 180);
    const nextBreak = clamp(parsedBreak, 1, 60);
    setFocusMinutesDraft(String(nextFocus));
    setBreakMinutesDraft(String(nextBreak));
    const result = await sendTimerAction("configure", { focusMinutes: nextFocus, breakMinutes: nextBreak });
    if (result) {
      setDurationDraftDirty(false);
      props.toast("Đã cập nhật thời gian Pomodoro.");
    }
    return result;
  }

  async function configureFocusSpaceDurations(focusMinutes: number, breakMinutes: number) {
    if (timerActive || timerSyncing) return null;
    const nextFocus = clamp(focusMinutes, 5, 180);
    const nextBreak = clamp(breakMinutes, 1, 60);
    setFocusMinutesDraft(String(nextFocus));
    setBreakMinutesDraft(String(nextBreak));
    const result = await sendTimerAction("configure", { focusMinutes: nextFocus, breakMinutes: nextBreak });
    if (result) {
      setDurationDraftDirty(false);
      props.toast("Đã cập nhật thời gian Pomodoro.");
    }
    return result;
  }

  async function enterBreak(): Promise<TimerState | null> {
    if (timerActive || timerSyncing) return null;
    return sendTimerAction("start-break");
  }

  async function linkFocusTaskSession(taskId: number, sessionKey: string) {
    if (!taskId || !sessionKey) return;
    try {
      const response = await fetch("/api/student/focus/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "link-session", taskId, sessionKey }),
      });
      if (!response.ok) {
        const payload = await response.json().catch(function() { return {}; }) as { error?: string };
        props.toast(payload.error || "Phiên Focus vẫn chạy nhưng chưa liên kết được task.");
      }
    } catch {
      props.toast("Phiên Focus vẫn chạy nhưng chưa liên kết được task.");
    }
  }

  async function startFocus(): Promise<TimerState | null> {
    if (timer.mode === "break" || timerSyncing) return null;
    const result = await sendTimerAction("start");
    if (result?.sessionKey && selectedFocusTaskId) await linkFocusTaskSession(selectedFocusTaskId, result.sessionKey);
    return result;
  }

  async function pauseTimer(): Promise<TimerState | null> {
    if (!timer.running || timerSyncing) return null;
    const result = await sendTimerAction("pause");
    setPetAnimation("waiting");
    return result;
  }

  async function resumeBreak(): Promise<TimerState | null> {
    if (timer.mode !== "break" || timer.running || timerSyncing) return null;
    return sendTimerAction("resume-break");
  }

  async function stopTimer(): Promise<TimerState | null> {
    if (timerSyncing) return null;
    const result = await sendTimerAction("stop");
    if (result) celebrate("failed", 10_000);
    return result;
  }

  async function skipBreak(): Promise<TimerState | null> {
    if (timerSyncing) return null;
    const result = await sendTimerAction("skip-break");
    if (result) celebrate("waving", 1300);
    return result;
  }

  async function loadPetChoices(options: { offset?: number; append?: boolean; force?: boolean } = {}) {
    const requestId = petCatalogRequestRef.current + 1;
    petCatalogRequestRef.current = requestId;
    petCatalogAbortRef.current?.abort();
    const controller = new AbortController();
    petCatalogAbortRef.current = controller;
    setPetCatalogLoading(true);
    setPetCatalogError("");
    try {
      const offset = Math.max(0, options.offset || 0);
      const params = new URLSearchParams({ limit: "24", offset: String(offset) });
      const cleaned = petSearch.trim();
      if (cleaned) params.set("q", cleaned);
      if (petKind) params.set("kind", petKind);
      if (petTag) params.set("tag", petTag);
      if (petVersion) params.set("version", petVersion);
      if (options.force) params.set("refresh", "1");
      const response = await fetch("/api/student/pets?" + params.toString(), { cache: "no-store", signal: controller.signal });
      const payload = await response.json() as PetCatalogPayload;
      if (!response.ok) {
        setPetCatalogError(payload.error || "Không thể tải Petdex. Vui lòng thử lại.");
        return;
      }
      if (requestId !== petCatalogRequestRef.current) return;
      const incoming = Array.isArray(payload.pets) ? payload.pets : [];
      setPetChoices(function(current) {
        if (!options.append) return incoming;
        const unique = new Map(current.map(function(item) { return [item.slug, item]; }));
        for (const item of incoming) unique.set(item.slug, item);
        return Array.from(unique.values());
      });
      setPetCatalogTotal(Math.max(0, Number(payload.total) || 0));
      setPetCatalogNextOffset(typeof payload.nextOffset === "number" ? payload.nextOffset : null);
      setPetFacets({
        kinds: Array.isArray(payload.facets?.kinds) ? payload.facets.kinds : [],
        tags: Array.isArray(payload.facets?.tags) ? payload.facets.tags.filter(function(tag) { return tag !== "default" && tag !== "monkey"; }) : [],
        versions: Array.isArray(payload.facets?.versions) ? payload.facets.versions : [],
      });
      setPetCatalogWarning(String(payload.warning || ""));
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      setPetCatalogError("Không thể tải danh sách pet lúc này. Kiểm tra kết nối rồi thử lại.");
    } finally {
      if (requestId === petCatalogRequestRef.current) setPetCatalogLoading(false);
    }
  }

  function openPetPicker() {
    const current = petData?.pet;
    setPetDraft(current ? {
      slug: current.slug,
      displayName: current.displayName,
      spritesheetUrl: current.spritesheetUrl,
      thumbnailUrl: current.thumbnailUrl,
      previewUrl: current.previewUrl,
      petJsonUrl: current.petJsonUrl,
      sourceUrl: current.sourceUrl,
      tags: current.tags,
      kind: current.kind || "",
      version: current.version || "",
      gridRows: current.gridRows,
      available: current.available,
    } : null);
    setPetPickerOpen(true);
  }

  function closePetPicker() {
    if (!changingPetRef.current) setPetPickerOpen(false);
  }

  async function choosePet() {
    const choice = petDraft;
    if (!choice || changingPet || choice.slug === petData?.pet.slug) return;
    setChangingPet(true);
    try {
      const response = await fetch("/api/student/pet", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ petSlug: choice.slug }),
      });
      const payload = await response.json() as PetResponse & { error?: string };
      if (!response.ok) {
        props.toast(payload.error || "Không thể đổi pet.");
        return;
      }
      setPetData(payload);
      setPetDraft({
        ...choice,
        displayName: payload.pet.displayName || choice.displayName,
        spritesheetUrl: payload.pet.spritesheetUrl || choice.spritesheetUrl,
        thumbnailUrl: payload.pet.thumbnailUrl || choice.thumbnailUrl,
        previewUrl: payload.pet.previewUrl || choice.previewUrl,
        petJsonUrl: payload.pet.petJsonUrl || choice.petJsonUrl,
        sourceUrl: payload.pet.sourceUrl || choice.sourceUrl,
        tags: payload.pet.tags || choice.tags,
        kind: payload.pet.kind || choice.kind,
        version: payload.pet.version || choice.version,
        gridRows: payload.pet.gridRows || choice.gridRows,
        available: payload.pet.available,
      });
      setSpriteLoadState("loading");
      setPetPickerOpen(false);
      celebrate("waving", 1700);
      props.toast("Đã đổi pet sang " + (payload.pet.displayName || choice.displayName) + ". Tên " + (payload.pet.name || petName) + " vẫn được giữ nguyên.");
    } catch {
      props.toast("Không thể đổi pet lúc này. Vui lòng thử lại.");
    } finally {
      setChangingPet(false);
    }
  }


  async function savePetName(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (savingPetName) return;
    const nextName = petNameDraft.replace(/\s+/g, " ").trim();
    const count = Array.from(nextName).length;
    if (count < 1 || count > 24) {
      props.toast("Tên pet cần từ 1 đến 24 ký tự.");
      return;
    }
    if (nextName === petName) {
      setPetNameDraft(petName);
      setRenamingPet(false);
      return;
    }
    setSavingPetName(true);
    try {
      const response = await fetch("/api/student/pet", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ petName: nextName }),
      });
      const payload = await response.json() as PetResponse & { error?: string };
      if (!response.ok) {
        props.toast(payload.error || "Không thể đổi tên pet.");
        return;
      }
      setPetData(payload);
      setPetNameDraft(payload.pet.name || nextName);
      setRenamingPet(false);
      props.toast("Đã đổi tên pet thành " + (payload.pet.name || nextName) + ".");
    } catch {
      props.toast("Không thể đổi tên pet lúc này. Vui lòng thử lại.");
    } finally {
      setSavingPetName(false);
    }
  }

  async function checkIn() {
    if (checkingIn || petData?.streak.checkedInToday) return;
    setCheckingIn(true);
    try {
      const response = await fetch("/api/student/pet", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      const payload = await response.json() as PetResponse & { error?: string };
      if (!response.ok) { props.toast(payload.error || "Không thể điểm danh hôm nay."); celebrate("failed", 1400); return; }
      setPetData(function(current) {
        if (!current || payload.pet.available) return payload;
        return { ...payload, pet: current.pet };
      });
      const result = payload.result;
      if (result?.majorMilestone) celebrate("jumping", 2600);
      else if (result?.milestone || result?.changed) celebrate("jumping", 1900);
      if (result?.message) props.toast(result.message);
    } catch {
      props.toast("Không thể kết nối để điểm danh. Vui lòng thử lại.");
      celebrate("failed", 1400);
    } finally {
      setCheckingIn(false);
    }
  }

  function toggleRoam() {
    setRoamEnabled(function(current) {
      const next = !current;
      window.localStorage.setItem(studentStorageKey(ROAM_STORAGE_KEY, props.studentId), next ? "on" : "off");
      if (!next) { setRoamX(0); setPetAnimation("idle"); }
      return next;
    });
  }

  const streak = petData?.streak;
  const milestoneRemaining = streak ? Math.max(0, streak.nextMilestone - streak.current) : 10;
  const milestonePercent = streak ? (streak.current % 10) * 10 : 0;
  const statusCopy = timer.mode === "focus"
    ? timer.running ? petName + " đang học cùng bạn"
      : timer.sessionKey ? "Phiên học đang tạm dừng"
      : !streak?.checkedInToday && streakReminderStage === "danger" ? petName + " đang lo cho chuỗi điểm danh hôm nay"
      : !streak?.checkedInToday && streakReminderStage === "waiting" ? petName + " đang chờ bạn điểm danh hôm nay"
      : streak?.checkedInToday ? petName + " vui vì chuỗi hôm nay đã an toàn"
      : "Sẵn sàng cho một phiên tập trung"
    : timer.running ? "Giờ nghỉ, " + petName + " được đi chơi" : "Giờ nghỉ đang tạm dừng";
  const activePreset = useMemo(function() { return FOCUS_PRESETS.find(function(item) { return item[0] === timer.focusMinutes && item[1] === timer.breakMinutes; }); }, [timer.breakMinutes, timer.focusMinutes]);

  return (
    <section id="student-focus-companion" className="student-companion card" aria-label={petName + ", streak và đồng hồ tập trung"}>
      <div className="companion-stage" ref={stageRef}>
        <header className="companion-stage-head">
          <div className="companion-pet-heading"><span className="companion-kicker"><PawPrint /> Focus pet</span>{renamingPet ? <form className="companion-name-editor" onSubmit={savePetName}><input aria-label="Tên pet" value={petNameDraft} maxLength={24} autoFocus disabled={savingPetName} onChange={function(event: React.ChangeEvent<HTMLInputElement>) { setPetNameDraft(event.target.value); }} /><button type="submit" aria-label="Lưu tên pet" title="Lưu tên" disabled={savingPetName}><Check /></button><button type="button" aria-label="Hủy đổi tên pet" title="Hủy" disabled={savingPetName} onClick={function() { setPetNameDraft(petName); setRenamingPet(false); }}><X /></button></form> : <div className="companion-name-row"><h2>{petName}</h2><button type="button" className="companion-rename-button" aria-label="Đổi tên pet" title="Đổi tên pet" onClick={function() { setPetNameDraft(petName); setRenamingPet(true); }}><Pencil /></button></div>}<p>{statusCopy}</p></div>
          <div className="companion-pet-actions"><button ref={petPickerTriggerRef} type="button" className="companion-pet-change" onClick={openPetPicker} title="Chọn pet khác từ Petdex"><PawPrint aria-hidden="true" />Đổi pet</button><button type="button" className="companion-roam-toggle" onClick={toggleRoam} aria-pressed={roamEnabled} title={roamEnabled ? "Tắt đi dạo" : "Cho pet đi dạo"}>{roamEnabled ? "Đi dạo: bật" : "Đi dạo: tắt"}</button></div>
        </header>
        <div className="companion-playground">
          <div className="pet-walker" ref={petRef} style={{ transform: "translate3d(" + roamX + "px,0,0)" }}>
            <PetSprite state={reducedMotion ? "idle" : petAnimation} url={petData?.pet.spritesheetUrl || ""} gridRows={petData?.pet.gridRows} label={petData?.pet.displayName || petName} petId={petData?.pet.slug || "punch"} reducedMotion={reducedMotion} onLoadState={setSpriteLoadState} />
          </div>
          {loadingPet ? <span className="companion-source-status">Đang gọi pet...</span> : spriteLoadState === "ready" ? <a className="companion-source-status" href={petData?.pet.sourceUrl || "https://petdex.dev/pets/punch"} target="_blank" rel="noreferrer">Petdex · {petData?.pet.displayName || "Punch"}</a> : spriteLoadState === "loading" ? <span className="companion-source-status">Đang tải hình pet...</span> : <span className="companion-source-status warning">Không tải được hình pet</span>}
        </div>
      </div>

      <div className="companion-streak-panel">
        <header><div><span className="companion-kicker"><Flame /> Daily streak</span><h2>Điểm danh mỗi ngày</h2></div>{!streak ? <div className="freeze-status"><span className="freeze-chip used"><Snowflake /> Đang tải</span></div> : <div className="freeze-status" title={streak.freezeAvailable ? "Freeze đang sẵn sàng" : "Freeze có lại vào " + streak.freezeNextAvailableDate}><span className={"freeze-chip " + (streak.freezeAvailable ? "" : "used")}><Snowflake />{streak.freezeAvailable ? "1 Freeze" : "Đã dùng Freeze"}</span><small>{streak.freezeAvailable ? "Sẵn sàng" : "Có lại sau " + streak.freezeDaysRemaining + " ngày"}</small></div>}</header>
        <div className="streak-number"><strong>{streak?.current ?? 0}</strong><span>ngày liên tiếp</span></div>
        <div className="streak-milestone"><div><span>Mốc tiếp theo</span><strong>{streak?.nextMilestone ?? 10} ngày</strong></div><div className="streak-track" aria-label={"Tiến độ tới mốc " + (streak?.nextMilestone ?? 10) + " ngày"}><i style={{ width: milestonePercent + "%" }} /></div><small>{milestoneRemaining === 0 ? "Đã chạm mốc, mốc mới sẽ mở ở lần tiếp theo" : "Còn " + milestoneRemaining + " ngày"}</small></div>
        <div className="streak-meta"><span><Trophy /><small>Kỷ lục</small><strong>{streak?.longest ?? 0} ngày</strong></span><span><Check /><small>Tổng check-in</small><strong>{streak?.totalCheckins ?? 0} ngày</strong></span></div>
        <button type="button" className={"button companion-checkin " + (streak?.checkedInToday ? "done" : "primary")} disabled={loadingPet || checkingIn || Boolean(streak?.checkedInToday)} onClick={function() { void checkIn(); }}>{streak?.checkedInToday ? <><Check />Đã điểm danh hôm nay</> : loadingPet ? <><TimerReset />Đang tải...</> : checkingIn ? <><TimerReset />Đang điểm danh...</> : <><Flame />Điểm danh hôm nay</>}</button>
      </div>

      <div className={"companion-focus-panel" + (focusExpanded ? " expanded" : "") + (timerActive ? " timer-active" : "")}>
        <header><div><span className="companion-kicker"><Focus /> Pomodoro</span><h2>{timer.mode === "focus" ? "Tập trung" : "Nghỉ giải lao"}</h2></div><div className="focus-head-actions"><button type="button" className="focus-fullscreen-trigger" onClick={function() { setFocusStudioOpen(true); }} title="Mở Focus Space"><MorphIcon icon={FOCUS_EXPAND_PATH} size={16} strokeWidth={1.8} spring="snappy" reducedMotion="user" /><span>Focus Space</span></button><button type="button" className="focus-mobile-toggle" aria-expanded={focusExpanded || timerActive} aria-controls="student-focus-body" disabled={timerActive || timerSyncing} onClick={function() { setFocusExpanded(!focusExpanded); }}>{timer.running ? "Đang chạy" : timerActive ? "Đang tạm dừng" : focusExpanded ? "Thu gọn" : timer.focusMinutes + "/" + timer.breakMinutes + " · Mở"}</button></div></header>
        <div className="companion-focus-body" id="student-focus-body">
        <div className="focus-clock" aria-live="polite"><strong>{formatTimer(timer.remainingMs)}</strong><span>{timer.mode === "focus" ? timer.focusMinutes + " phút tập trung" : timer.breakMinutes + " phút nghỉ"}</span></div>
        <div className="focus-presets" aria-label="Mốc thời gian nhanh">{FOCUS_PRESETS.map(function(item) { const selected = Boolean(activePreset && activePreset[0] === item[0] && activePreset[1] === item[1]); return <button type="button" key={item.join("-")} className={selected ? "active" : ""} disabled={timerActive || timerSyncing} onClick={function() { applyPreset(item[0], item[1]); }}>{item[0]}/{item[1]}</button>; })}<button type="button" className={customOpen ? "active" : ""} disabled={timerActive || timerSyncing} onClick={function() { const next = !customOpen; setCustomOpen(next); if (next) { setFocusMinutesDraft(String(timer.focusMinutes)); setBreakMinutesDraft(String(timer.breakMinutes)); setDurationDraftDirty(false); } }}>Tùy chỉnh</button></div>
        {customOpen ? <div className="focus-custom-wrap" onBlur={function(event) { const next = event.relatedTarget as HTMLElement | null; if (durationDraftDirty && !next?.closest(".focus-custom-wrap")) void commitCustomDurations(); }}><div className="focus-custom"><label><span>Focus</span><input type="number" inputMode="numeric" min="5" max="180" value={focusMinutesDraft} disabled={timerActive || timerSyncing} onChange={function(event: React.ChangeEvent<HTMLInputElement>) { setFocusMinutesDraft(event.target.value); setDurationDraftDirty(true); }} onKeyDown={function(event) { if (event.key === "Enter") { event.preventDefault(); void commitCustomDurations(); } }} /><small>5–180 phút</small></label><label><span>Break</span><input type="number" inputMode="numeric" min="1" max="60" value={breakMinutesDraft} disabled={timerActive || timerSyncing} onChange={function(event: React.ChangeEvent<HTMLInputElement>) { setBreakMinutesDraft(event.target.value); setDurationDraftDirty(true); }} onKeyDown={function(event) { if (event.key === "Enter") { event.preventDefault(); void commitCustomDurations(); } }} /><small>1–60 phút</small></label></div><button type="button" className="button soft focus-custom-apply" disabled={timerActive || timerSyncing || !durationDraftDirty} onClick={function() { void commitCustomDurations(); }}>Áp dụng</button></div> : null}
        <div className="focus-actions">
          {timer.mode === "focus" && !timer.running ? <button type="button" className="button primary" disabled={timerSyncing || !timerReady} onClick={startFocus}><MorphIcon icon={FOCUS_PLAY_PATH} size={18} strokeWidth={1.8} spring="snappy" reducedMotion="user" />{timer.sessionKey ? "Tiếp tục" : "Bắt đầu"}</button> : null}
          {timer.mode === "break" && !timer.running ? <button type="button" className="button soft" disabled={timerSyncing || !timerReady} onClick={resumeBreak}><MorphIcon icon={FOCUS_PLAY_PATH} size={18} strokeWidth={1.8} spring="snappy" reducedMotion="user" />{timer.remainingMs >= timer.breakMinutes * 60_000 - 1000 ? "Bắt đầu nghỉ" : "Tiếp tục nghỉ"}</button> : null}
          {timer.running ? <button type="button" className="button soft" disabled={timerSyncing || !timerReady} onClick={pauseTimer}><MorphIcon icon={FOCUS_PAUSE_PATH} size={18} strokeWidth={1.8} spring="snappy" reducedMotion="user" />Tạm dừng</button> : null}
          {timerActive ? <button type="button" className="button ghost" disabled={timerSyncing || !timerReady} onClick={stopTimer}><Square />Kết thúc</button> : <button type="button" className="button ghost" disabled={timerSyncing || !timerReady} onClick={function() { applyPreset(timer.focusMinutes, timer.breakMinutes); }}><RotateCcw />Đặt lại</button>}
          {timer.mode === "break" ? <button type="button" className="button ghost" disabled={timerSyncing || !timerReady} onClick={skipBreak}><SkipForward />Bỏ qua nghỉ</button> : null}
        </div>
        <div className="focus-stats">
          <span className={focusStats.todayManualMinutes > 0 ? "has-manual" : ""}>
            <Sparkles />
            <small>Hôm nay</small>
            <strong>{focusStats.todaySessions} phiên · {formatFocusTotal(focusStats.todayMinutes)}</strong>
            {focusStats.todayManualMinutes > 0 ? <em className="focus-manual-note" title="Thời gian học ngoài EDUFLOW đã được giáo viên xác nhận">+{formatFocusTotal(focusStats.todayManualMinutes)} ngoài web</em> : null}
          </span>
          <span className={focusStats.weekManualMinutes > 0 ? "has-manual" : ""}>
            <TimerReset />
            <small>Tuần này</small>
            <strong>{focusStats.weekSessions} phiên · {formatFocusTotal(focusStats.weekMinutes)}</strong>
            {focusStats.weekManualMinutes > 0 ? <em className="focus-manual-note" title="Tổng thời gian học ngoài EDUFLOW đã được giáo viên xác nhận trong tuần">+{formatFocusTotal(focusStats.weekManualMinutes)} ngoài web</em> : null}
          </span>
        </div>
        </div>
      </div>

      {focusStudioOpen && typeof document !== "undefined" ? createPortal(<FocusStudio
        studentId={props.studentId}
        open={true}
        timer={timer as FocusStudioTimer}
        stats={focusStats}
        timerReady={timerReady}
        timerSyncing={timerSyncing}
        reducedMotion={reducedMotion}
        selectedTaskId={selectedFocusTaskId}
        onSelectedTaskChange={setSelectedFocusTaskId}
        onStart={startFocus}
        onPause={pauseTimer}
        onResumeBreak={resumeBreak}
        onStop={stopTimer}
        onSkipBreak={skipBreak}
        onEnterBreak={enterBreak}
        onConfigure={configureFocusSpaceDurations}
        onClose={function() { setFocusStudioOpen(false); }}
        toast={props.toast}
      />, document.body) : null}

      {petPickerOpen && typeof document !== "undefined" ? createPortal(<div className="pet-picker-backdrop" role="presentation" onClick={function(event) { if (event.target === event.currentTarget) closePetPicker(); }}>
        <section ref={petPickerDialogRef} className="pet-picker-dialog" role="dialog" aria-modal="true" aria-labelledby="pet-picker-title" aria-describedby="pet-picker-description" tabIndex={-1}>
          <header className="pet-picker-head">
            <div className="pet-picker-title-wrap">
              <span className="companion-kicker"><PawPrint aria-hidden="true" /> Petdex</span>
              <h2 id="pet-picker-title">Chọn pet đồng hành</h2>
              <p id="pet-picker-description">Chọn một pet để xem trước, sau đó xác nhận sử dụng.</p>
            </div>
            <div className="pet-picker-current" aria-live="polite">
              <span className="pet-picker-current-preview"><PetSprite state="idle" url={petDraft?.spritesheetUrl || petData?.pet.spritesheetUrl || ""} gridRows={petDraft?.gridRows || petData?.pet.gridRows} label={petDraft?.displayName || petData?.pet.displayName || "Punch"} petId={petDraft?.slug || petData?.pet.slug || "punch"} reducedMotion={true} /></span>
              <span><small>Pet đang chọn</small><strong>{petDraft?.displayName || petData?.pet.displayName || "Punch"}</strong></span>
            </div>
            <button type="button" className="pet-picker-close" aria-label="Đóng cửa sổ chọn pet" disabled={changingPet} onClick={closePetPicker}><X aria-hidden="true" /></button>
          </header>

          <div className="pet-picker-tools">
            <form className="pet-picker-search" role="search" onSubmit={function(event) { event.preventDefault(); void loadPetChoices({ offset: 0 }); }}>
              <Search aria-hidden="true" />
              <input ref={petSearchInputRef} value={petSearch} onChange={function(event) { setPetSearch(event.target.value); }} placeholder="Tìm theo tên hoặc từ khóa" aria-label="Tìm pet" autoComplete="off" />
              {petSearch ? <button type="button" className="pet-search-clear" aria-label="Xóa từ khóa tìm kiếm" onClick={function() { setPetSearch(""); }}><X aria-hidden="true" /></button> : null}
              <button type="submit" className="pet-search-submit" disabled={petCatalogLoading}>Tìm</button>
            </form>
            <div className="pet-picker-filters" aria-label="Bộ lọc pet">
              <div className="pet-filter-row">
                <span className="pet-filter-label">LOẠI</span>
                <div className="pet-kind-chips" role="group" aria-label="Loại pet">
                  <button type="button" className={!petKind ? "active" : ""} aria-pressed={!petKind} onClick={function() { setPetKind(""); }}>Tất cả</button>
                  {petFacets.kinds.map(function(kind) { const label = kind === "character" ? "Nhân vật" : kind === "creature" ? "Sinh vật" : kind === "object" ? "Đồ vật" : kind; return <button type="button" key={kind} className={petKind === kind ? "active" : ""} aria-pressed={petKind === kind} onClick={function() { setPetKind(kind); }}>{label}</button>; })}
                </div>
              </div>
              {petFacets.tags.length ? <div className="pet-filter-row"><span className="pet-filter-label">TÍNH CÁCH</span><div className="pet-kind-chips" role="group" aria-label="Tính cách pet"><button type="button" className={!petTag ? "active" : ""} aria-pressed={!petTag} onClick={function() { setPetTag(""); }}>Tất cả</button>{petFacets.tags.slice(0, 12).map(function(tag) { return <button type="button" key={tag} className={petTag === tag ? "active" : ""} aria-pressed={petTag === tag} onClick={function() { setPetTag(tag); }}>{tag}</button>; })}</div></div> : null}
              {petFacets.versions.length > 1 ? <div className="pet-filter-row"><span className="pet-filter-label">PHIÊN BẢN</span><div className="pet-kind-chips" role="group" aria-label="Phiên bản pet"><button type="button" className={!petVersion ? "active" : ""} aria-pressed={!petVersion} onClick={function() { setPetVersion(""); }}>Tất cả</button>{petFacets.versions.map(function(version) { return <button type="button" key={version} className={petVersion === version ? "active" : ""} aria-pressed={petVersion === version} onClick={function() { setPetVersion(version); }}>{version.toUpperCase()}</button>; })}</div></div> : null}
            </div>
          </div>

          <div className="pet-picker-meta" role="status">
            <span>{petCatalogLoading && !petChoices.length ? "Đang tải Petdex..." : petCatalogTotal > petChoices.length ? "Hiển thị " + petChoices.length + "/" + petCatalogTotal + " pet" : petChoices.length + " pet"}</span>
            {petCatalogWarning ? <button type="button" onClick={function() { void loadPetChoices({ offset: 0, force: true }); }}>Petdex gián đoạn, thử lại</button> : null}
          </div>

          <div className="pet-picker-scroll" tabIndex={0} aria-label="Danh sách pet">
            {petCatalogError ? <div className="pet-picker-error" role="alert"><PawPrint aria-hidden="true" /><strong>Chưa tải được danh sách pet</strong><span>{petCatalogError}</span><button type="button" onClick={function() { void loadPetChoices({ offset: 0, force: true }); }}>Thử lại</button></div> : null}
            {!petCatalogError ? <div className="pet-picker-grid">
              {petCatalogLoading && petChoices.length === 0 ? Array.from({ length: 8 }, function(_, index) { return <div className="pet-choice-skeleton" aria-hidden="true" key={index}><i /><span /><small /></div>; }) : null}
              {petChoices.map(function(choice) {
                const selected = choice.slug === petDraft?.slug;
                const active = choice.slug === petData?.pet.slug;
                return <article className="pet-choice-shell" key={choice.slug}>
                  <button type="button" className={"pet-choice" + (selected ? " selected" : "")} disabled={changingPet} aria-pressed={selected} onClick={function() { setPetDraft(choice); }}>
                    <span className="pet-choice-preview"><PetSprite state="idle" url={choice.spritesheetUrl} gridRows={choice.gridRows} label={choice.displayName} petId={choice.slug} reducedMotion={true} lazy={true} /></span>
                    <span className="pet-choice-copy"><strong title={choice.displayName}>{choice.displayName}</strong><small>{active ? "Đang sử dụng" : choice.kind === "character" ? "Nhân vật" : choice.kind === "creature" ? "Sinh vật" : choice.kind === "object" ? "Đồ vật" : choice.kind || "Petdex"}</small></span>
                    <span className="pet-choice-version">{(choice.version || "v1").toUpperCase()}</span>
                    {selected ? <i><Check aria-hidden="true" /></i> : null}
                  </button>
                </article>;
              })}
              {!petCatalogLoading && petChoices.length === 0 ? <div className="pet-picker-empty"><PawPrint aria-hidden="true" /><strong>Không tìm thấy pet</strong><span>Thử từ khóa hoặc bộ lọc khác.</span></div> : null}
            </div> : null}
            {!petCatalogError && petCatalogNextOffset !== null ? <button type="button" className="pet-picker-load-more" disabled={petCatalogLoading} onClick={function() { void loadPetChoices({ offset: petCatalogNextOffset, append: true }); }}>{petCatalogLoading ? "Đang tải thêm..." : "Xem thêm pet"}</button> : null}
          </div>

          <footer className="pet-picker-footer">
            <button type="button" className="button ghost" disabled={changingPet} onClick={closePetPicker}>Hủy</button>
            <button type="button" className="button primary" disabled={changingPet || !petDraft || petDraft.slug === petData?.pet.slug} onClick={function() { void choosePet(); }}>{changingPet ? "Đang lưu..." : petDraft?.slug === petData?.pet.slug ? "Pet đang được sử dụng" : "Sử dụng Pet này"}</button>
          </footer>
        </section>
      </div>, document.body) : null}
    </section>
  );
}
