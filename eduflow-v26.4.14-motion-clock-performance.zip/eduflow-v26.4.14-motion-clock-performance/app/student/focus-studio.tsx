"use client";

import {
  Check,
  ChevronDown,
  ChevronUp,
  Clock3,
  GripVertical,
  Headphones,
  ListTodo,
  Music2,
  Moon,
  Sun,
  Pencil,
  Plus,
  RotateCw,
  MoveHorizontal,
  Settings2,
  SkipForward,
  StickyNote,
  Square,
  Trash2,
  Youtube,
} from "lucide-react";
import { memo, useEffect, useMemo, useRef, useState } from "react";
import { MorphIcon } from "../../lib/vendor/morphicons/react/index";

type TimerMode = "focus" | "break";
type TimerStatus = "idle" | "running" | "paused";
export type FocusStudioTimer = {
  mode: TimerMode;
  status: TimerStatus;
  running: boolean;
  remainingMs: number;
  focusMinutes: number;
  breakMinutes: number;
  sessionKey: string;
};
export type FocusStudioStats = {
  todayMinutes: number;
  todaySessions: number;
  weekMinutes: number;
  weekSessions: number;
};
export type FocusTask = {
  id: number;
  title: string;
  done: boolean;
  sortOrder: number;
  targetPomodoros: number;
  completedPomodoros: number;
  completedAt: string;
  createdAt: string;
  updatedAt: string;
};

type TaskPayload = { tasks?: FocusTask[]; activeTaskId?: number | null; error?: string };

type Props = {
  studentId: number;
  open: boolean;
  timer: FocusStudioTimer;
  stats: FocusStudioStats;
  timerReady: boolean;
  timerSyncing: boolean;
  reducedMotion: boolean;
  selectedTaskId: number | null;
  onSelectedTaskChange: (taskId: number | null) => void;
  onStart: () => Promise<FocusStudioTimer | null>;
  onPause: () => Promise<FocusStudioTimer | null>;
  onResumeBreak: () => Promise<FocusStudioTimer | null>;
  onStop: () => Promise<FocusStudioTimer | null>;
  onSkipBreak: () => Promise<FocusStudioTimer | null>;
  onEnterBreak: () => Promise<FocusStudioTimer | null>;
  onConfigure: (focusMinutes: number, breakMinutes: number) => Promise<FocusStudioTimer | null>;
  onClose: () => void;
  toast: (message: string) => void;
};

type ClockStyle = "digital" | "flip";
type FloatingPanel = "tasks" | "music" | "notes";
type PanelPosition = { x: number; y: number };
type MediaProvider = "spotify" | "youtube";

const PEACEFUL_PIANO_URL = "https://open.spotify.com/playlist/37i9dQZF1DX4sWSpwq3LiO";


const PLAY_PATH = "M7 4.8v14.4L19 12 7 4.8Z";
const PAUSE_PATH = "M8 5v14M16 5v14";
const EXPAND_PATH = "M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5";
const COMPRESS_PATH = "M8 8H3V3M16 8h5V3M8 16H3v5M16 16h5v5";
const SQUARE_PATH = "M5 5h14v14H5Z";
const CHECK_PATH = "M5 12.5 9.3 17 19 7";
const DIGITAL_PATH = "M4 6h16v12H4V6ZM8 10h2M14 10h2M8 14h2M14 14h2";
const FLIP_PATH = "M4 5h7v6H4V5ZM13 5h7v6h-7V5ZM4 13h7v6H4v-6ZM13 13h7v6h-7v-6Z";
const TASKS_PATH = "M4 6h2v2H4V6Zm5 0h11M4 11h2v2H4v-2Zm5 0h11M4 16h2v2H4v-2Zm5 0h11";
const MUSIC_PATH = "M9 18V6l10-2v12M9 10l10-2M6 20a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm10-1a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z";
const NOTES_PATH = "M5 3h10l4 4v14H5V3Zm10 0v5h5M8 12h8M8 16h6";
const CLOSE_PATH = "M6 6l12 12M18 6 6 18";

function storageKey(base: string, studentId: number) {
  return base + ":student:" + String(Math.max(0, Math.floor(studentId)));
}

function formatTimer(ms: number) {
  const seconds = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(seconds / 60);
  return String(minutes).padStart(2, "0") + ":" + String(seconds % 60).padStart(2, "0");
}

function formatFocusTotal(minutes: number) {
  if (minutes < 60) return minutes + " phút";
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest ? hours + "g " + rest + "p" : hours + " giờ";
}

function spotifyEmbedUrl(input: string): string {
  const value = input.trim();
  if (!value) return "";
  const match = value.match(/(?:open\.spotify\.com\/(?:intl-[a-z]{2}\/)?|spotify:)(playlist|album|track|artist|show|episode)[\/:]([A-Za-z0-9]+)/i);
  if (!match) return "";
  return "https://open.spotify.com/embed/" + match[1].toLowerCase() + "/" + match[2] + "?utm_source=generator&theme=0";
}

function spotifyContentUrl(input: string): string {
  const value = input.trim();
  if (!value) return "";
  const match = value.match(/(?:open\.spotify\.com\/(?:intl-[a-z]{2}\/)?|spotify:)(playlist|album|track|artist|show|episode)[\/:]([A-Za-z0-9]+)/i);
  if (!match) return "";
  return "https://open.spotify.com/" + match[1].toLowerCase() + "/" + match[2];
}

function youtubeEmbedUrl(input: string): string {
  const value = input.trim();
  if (!value) return "";
  try {
    const url = new URL(value);
    const hostname = url.hostname.replace(/^www\./, "");
    if (hostname === "youtu.be") {
      const videoId = url.pathname.split("/").filter(Boolean)[0] || "";
      return videoId ? "https://www.youtube-nocookie.com/embed/" + encodeURIComponent(videoId) + "?playsinline=1&rel=0" : "";
    }
    if (hostname.endsWith("youtube.com")) {
      const listId = url.searchParams.get("list");
      const videoId = url.searchParams.get("v");
      if (videoId) return "https://www.youtube-nocookie.com/embed/" + encodeURIComponent(videoId) + (listId ? "?list=" + encodeURIComponent(listId) + "&playsinline=1&rel=0" : "?playsinline=1&rel=0");
      if (listId) return "https://www.youtube-nocookie.com/embed/videoseries?list=" + encodeURIComponent(listId) + "&playsinline=1&rel=0";
      const shorts = url.pathname.match(/^\/shorts\/([^/?#]+)/);
      if (shorts?.[1]) return "https://www.youtube-nocookie.com/embed/" + encodeURIComponent(shorts[1]) + "?playsinline=1&rel=0";
    }
  } catch {}
  return "";
}

function parseMediaEmbed(input: string): { provider: MediaProvider; url: string } | null {
  const spotify = spotifyEmbedUrl(input);
  if (spotify) return { provider: "spotify", url: spotify };
  const youtube = youtubeEmbedUrl(input);
  if (youtube) return { provider: "youtube", url: youtube };
  return null;
}

const FlipDigit = memo(function FlipDigit(props: { digit: string; reducedMotion: boolean }) {
  const currentRef = useRef(props.digit);
  const [frame, setFrame] = useState({ previous: props.digit, current: props.digit, flipping: false });

  useEffect(function() {
    if (props.reducedMotion) {
      currentRef.current = props.digit;
      setFrame({ previous: props.digit, current: props.digit, flipping: false });
      return;
    }
    if (props.digit === currentRef.current) return;
    const previous = currentRef.current;
    currentRef.current = props.digit;
    setFrame({ previous, current: props.digit, flipping: true });
    const timer = window.setTimeout(function() {
      setFrame(function(current) {
        return current.current === props.digit
          ? { previous: current.current, current: current.current, flipping: false }
          : current;
      });
    }, 340);
    return function() { window.clearTimeout(timer); };
  }, [props.digit, props.reducedMotion]);

  return <span className={"focus-flip-digit" + (props.reducedMotion ? " reduced" : "")}>
    <span className="focus-flip-half focus-flip-top"><span>{frame.current}</span></span>
    <span className="focus-flip-half focus-flip-bottom"><span>{frame.flipping ? frame.previous : frame.current}</span></span>
    {frame.flipping ? <>
      <span className="focus-flip-leaf focus-flip-leaf-top"><span>{frame.previous}</span></span>
      <span className="focus-flip-leaf focus-flip-leaf-bottom"><span>{frame.current}</span></span>
    </> : null}
  </span>;
});

const FlipClock = memo(function FlipClock(props: { value: string; reducedMotion: boolean }) {
  const [minutes, seconds] = props.value.split(":");
  return <div className="focus-flip-clock" aria-label={props.value} role="timer">
    <span className="focus-flip-group">{minutes.split("").map(function(digit, index) { return <FlipDigit key={"m-" + index} digit={digit} reducedMotion={props.reducedMotion} />; })}</span>
    <span className="focus-flip-colon" aria-hidden="true"><i /><i /></span>
    <span className="focus-flip-group">{seconds.split("").map(function(digit, index) { return <FlipDigit key={"s-" + index} digit={digit} reducedMotion={props.reducedMotion} />; })}</span>
  </div>;
});

const DigitalClock = memo(function DigitalClock(props: { value: string }) {
  return <strong className="focus-digital-digits" aria-label={props.value} role="timer">
    {Array.from(props.value).map(function(character, index) {
      if (character === ":") return <span className="focus-digital-separator" aria-hidden="true" key={"separator-" + index}>:</span>;
      return <span className="focus-digital-slot" aria-hidden="true" key={"digit-" + index}>{character}</span>;
    })}
  </strong>;
});

export default function FocusStudio(props: Props) {
  const [tasks, setTasks] = useState<FocusTask[]>([]);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [taskDraft, setTaskDraft] = useState("");
  const [showCompleted, setShowCompleted] = useState(false);
  const [clockStyle, setClockStyle] = useState<ClockStyle>("digital");
  const [focusTheme, setFocusTheme] = useState<"light" | "dark">("light");
  const [timerSettingsOpen, setTimerSettingsOpen] = useState(false);
  const [focusMinutesDraft, setFocusMinutesDraft] = useState(String(props.timer.focusMinutes));
  const [breakMinutesDraft, setBreakMinutesDraft] = useState(String(props.timer.breakMinutes));
  const [durationDirty, setDurationDirty] = useState(false);
  const [mediaUrl, setMediaUrl] = useState("");
  const [mediaDraft, setMediaDraft] = useState("");
  const [spotifyFrameRevision, setSpotifyFrameRevision] = useState(0);
  const [musicExpanded, setMusicExpanded] = useState(false);
  const [notesPanelOpen, setNotesPanelOpen] = useState(false);
  const [notesDraft, setNotesDraft] = useState("");
  const [manualLandscape, setManualLandscape] = useState(false);
  const [browserFullscreen, setBrowserFullscreen] = useState(false);
  const [wakeLockActive, setWakeLockActive] = useState(false);
  const [taskPanelOpen, setTaskPanelOpen] = useState(false);
  const [frontPanel, setFrontPanel] = useState<FloatingPanel>("tasks");
  const [taskPanelPosition, setTaskPanelPosition] = useState<PanelPosition>({ x: 18, y: 86 });
  const [musicPanelPosition, setMusicPanelPosition] = useState<PanelPosition>({ x: 0, y: 86 });
  const [notesPanelPosition, setNotesPanelPosition] = useState<PanelPosition>({ x: 0, y: 86 });
  const [editingTaskId, setEditingTaskId] = useState<number | null>(null);
  const [editingTaskTitle, setEditingTaskTitle] = useState("");
  const studioRef = useRef<HTMLElement | null>(null);
  const taskPanelRef = useRef<HTMLElement | null>(null);
  const musicPanelRef = useRef<HTMLElement | null>(null);
  const notesPanelRef = useRef<HTMLElement | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<{ id: number; pointerId: number; changed: boolean } | null>(null);
  const panelDragRef = useRef<{ panel: FloatingPanel; pointerId: number; startX: number; startY: number; originX: number; originY: number; currentX: number; currentY: number; width: number; height: number } | null>(null);
  const openOrderRef = useRef<FocusTask[]>([]);
  const wakeLockRef = useRef<{ release: () => Promise<void>; released?: boolean } | null>(null);
  const enteredFullscreenRef = useRef(false);

  const openTasks = useMemo(function() { return tasks.filter(function(task) { return !task.done; }); }, [tasks]);
  const completedTasks = useMemo(function() { return tasks.filter(function(task) { return task.done; }); }, [tasks]);
  const timerValue = formatTimer(props.timer.remainingMs);

  useEffect(function() {
    openOrderRef.current = openTasks;
  }, [openTasks]);

  async function loadTasks(silent = false) {
    if (!silent) setTasksLoading(true);
    try {
      const response = await fetch("/api/student/focus/tasks", { cache: "no-store" });
      const payload = await response.json() as TaskPayload;
      if (!response.ok) {
        if (!silent) props.toast(payload.error || "Không thể tải danh sách việc cần làm.");
        return;
      }
      const next = Array.isArray(payload.tasks) ? payload.tasks : [];
      setTasks(next);
      const serverActive = Math.max(0, Number(payload.activeTaskId) || 0) || null;
      if (serverActive) props.onSelectedTaskChange(serverActive);
      else if (props.selectedTaskId && !next.some(function(task) { return task.id === props.selectedTaskId && !task.done; })) props.onSelectedTaskChange(null);
    } catch {
      if (!silent) props.toast("Không thể đồng bộ task. Kiểm tra kết nối rồi thử lại.");
    } finally {
      if (!silent) setTasksLoading(false);
    }
  }

  function applyTaskPayload(payload: TaskPayload) {
    const next = Array.isArray(payload.tasks) ? payload.tasks : [];
    setTasks(next);
    if (payload.activeTaskId) props.onSelectedTaskChange(Number(payload.activeTaskId));
    else if (props.selectedTaskId && !next.some(function(task) { return task.id === props.selectedTaskId && !task.done; })) props.onSelectedTaskChange(null);
  }

  async function addTask() {
    const title = taskDraft.replace(/\s+/g, " ").trim();
    if (!title) return;
    setTasksLoading(true);
    try {
      const response = await fetch("/api/student/focus/tasks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "create", title, targetPomodoros: 1 }) });
      const payload = await response.json() as TaskPayload;
      if (!response.ok) { props.toast(payload.error || "Không thể thêm task."); return; }
      setTaskDraft("");
      applyTaskPayload(payload);
    } catch {
      props.toast("Không thể thêm task lúc này.");
    } finally {
      setTasksLoading(false);
    }
  }

  async function patchTask(id: number, changes: Record<string, unknown>): Promise<boolean> {
    try {
      const response = await fetch("/api/student/focus/tasks", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, ...changes }) });
      const payload = await response.json() as TaskPayload;
      if (!response.ok) { props.toast(payload.error || "Không thể cập nhật task."); return false; }
      applyTaskPayload(payload);
      if (changes.done === true && props.selectedTaskId === id) await syncTaskSession(null);
      return true;
    } catch {
      props.toast("Không thể cập nhật task lúc này.");
      return false;
    }
  }

  async function syncTaskSession(taskId: number | null) {
    const sessionKey = props.timer.mode === "focus" ? props.timer.sessionKey : "";
    if (!sessionKey) return;
    try {
      const response = await fetch("/api/student/focus/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(taskId ? { action: "link-session", taskId, sessionKey } : { action: "unlink-session", sessionKey }),
      });
      if (!response.ok) {
        const payload = await response.json().catch(function() { return {}; }) as { error?: string };
        props.toast(payload.error || "Chưa đồng bộ được task với phiên Focus hiện tại.");
      }
    } catch {
      props.toast("Chưa đồng bộ được task với phiên Focus hiện tại.");
    }
  }

  async function selectFocusTask(taskId: number | null) {
    props.onSelectedTaskChange(taskId);
    await syncTaskSession(taskId);
  }


  function beginTaskEdit(task: FocusTask) {
    setEditingTaskId(task.id);
    setEditingTaskTitle(task.title);
  }

  async function saveTaskEdit() {
    if (!editingTaskId) return;
    const title = editingTaskTitle.replace(/\s+/g, " ").trim();
    if (!title) {
      props.toast("Tên task không được để trống.");
      return;
    }
    const id = editingTaskId;
    if (await patchTask(id, { title })) {
      setEditingTaskId(null);
      setEditingTaskTitle("");
    }
  }

  async function deleteTask(id: number) {
    try {
      const response = await fetch("/api/student/focus/tasks?id=" + encodeURIComponent(String(id)), { method: "DELETE" });
      const payload = await response.json() as TaskPayload;
      if (!response.ok) { props.toast(payload.error || "Không thể xóa task."); return; }
      applyTaskPayload(payload);
    } catch {
      props.toast("Không thể xóa task lúc này.");
    }
  }

  async function saveTaskOrder(nextOpenTasks: FocusTask[]) {
    try {
      const response = await fetch("/api/student/focus/tasks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "reorder", ids: nextOpenTasks.map(function(task) { return task.id; }) }) });
      const payload = await response.json() as TaskPayload;
      if (response.ok) applyTaskPayload(payload);
    } catch {
      void loadTasks(true);
    }
  }

  function beginPointerDrag(event: React.PointerEvent<HTMLButtonElement>, taskId: number) {
    if (event.button !== 0 && event.pointerType === "mouse") return;
    dragRef.current = { id: taskId, pointerId: event.pointerId, changed: false };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function movePointerDrag(event: React.PointerEvent<HTMLButtonElement>) {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const targetElement = document.elementFromPoint(event.clientX, event.clientY)?.closest<HTMLElement>("[data-focus-task-id]");
    if (!targetElement) return;
    const targetId = Number(targetElement.dataset.focusTaskId || 0);
    if (!targetId || targetId === drag.id) return;
    setTasks(function(current) {
      const open = current.filter(function(task) { return !task.done; });
      const completed = current.filter(function(task) { return task.done; });
      const from = open.findIndex(function(task) { return task.id === drag.id; });
      const to = open.findIndex(function(task) { return task.id === targetId; });
      if (from < 0 || to < 0 || from === to) return current;
      const next = open.slice();
      const [item] = next.splice(from, 1);
      next.splice(to, 0, item);
      drag.changed = true;
      openOrderRef.current = next;
      return next.concat(completed);
    });
  }

  function endPointerDrag(event: React.PointerEvent<HTMLButtonElement>) {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    dragRef.current = null;
    if (drag.changed) void saveTaskOrder(openOrderRef.current);
  }

  function panelPositionKey(panel: FloatingPanel) {
    return storageKey("eduflow-focus-panel-" + panel, props.studentId);
  }

  function getPanelElement(panel: FloatingPanel) {
    if (panel === "tasks") return taskPanelRef.current;
    if (panel === "music") return musicPanelRef.current;
    return notesPanelRef.current;
  }

  function getPanelPosition(panel: FloatingPanel) {
    if (panel === "tasks") return taskPanelPosition;
    if (panel === "music") return musicPanelPosition;
    return notesPanelPosition;
  }

  function clampPanelPosition(panel: FloatingPanel, position: PanelPosition): PanelPosition {
    const element = getPanelElement(panel);
    const viewport = workspaceViewport();
    const fallback = panelFallbackSize(panel);
    const width = element?.offsetWidth || Math.min(fallback.width, Math.max(280, viewport.width - 20));
    const height = element?.offsetHeight || fallback.height;
    const mobile = isMobileWorkspace() || manualLandscape;
    const safe = mobile ? 10 : 14;
    const top = mobile ? 58 : 78;
    return {
      x: Math.max(safe, Math.min(position.x, Math.max(safe, viewport.width - width - safe))),
      y: Math.max(top, Math.min(position.y, Math.max(top, viewport.height - height - safe))),
    };
  }

  function savePanelPosition(panel: FloatingPanel, position: PanelPosition) {
    try { window.localStorage.setItem(panelPositionKey(panel), JSON.stringify(position)); } catch {}
  }

  function setPanelPosition(panel: FloatingPanel, position: PanelPosition, persist = false) {
    const next = clampPanelPosition(panel, position);
    if (panel === "tasks") setTaskPanelPosition(next);
    else if (panel === "music") setMusicPanelPosition(next);
    else setNotesPanelPosition(next);
    if (persist) savePanelPosition(panel, next);
  }

  function beginPanelDrag(event: React.PointerEvent<HTMLElement>, panel: FloatingPanel) {
    if (event.button !== 0 && event.pointerType === "mouse") return;
    const element = getPanelElement(panel);
    if (!element) return;
    const rect = element.getBoundingClientRect();
    const origin = getPanelPosition(panel);
    setFrontPanel(panel);
    element.classList.add("is-dragging");
    element.style.willChange = "transform";
    panelDragRef.current = {
      panel,
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      originX: origin.x,
      originY: origin.y,
      currentX: origin.x,
      currentY: origin.y,
      width: rect.width,
      height: rect.height,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function movePanelDrag(event: React.PointerEvent<HTMLElement>) {
    const drag = panelDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const element = getPanelElement(drag.panel);
    if (!element) return;
    const viewport = workspaceViewport();
    const mobile = isMobileWorkspace() || manualLandscape;
    const safe = mobile ? 10 : 14;
    const top = mobile ? 58 : 78;
    const rawX = drag.originX + (event.clientX - drag.startX);
    const rawY = drag.originY + (event.clientY - drag.startY);
    const x = Math.max(safe, Math.min(rawX, Math.max(safe, viewport.width - drag.width - safe)));
    const y = Math.max(top, Math.min(rawY, Math.max(top, viewport.height - drag.height - safe)));
    drag.currentX = x;
    drag.currentY = y;
    element.style.transform = "translate3d(" + (x - drag.originX) + "px," + (y - drag.originY) + "px,0) scale(1.006)";
  }

  function endPanelDrag(event: React.PointerEvent<HTMLElement>) {
    const drag = panelDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    panelDragRef.current = null;
    const element = getPanelElement(drag.panel);
    const next = clampPanelPosition(drag.panel, { x: drag.currentX, y: drag.currentY });
    if (element) {
      element.style.left = next.x + "px";
      element.style.top = next.y + "px";
      element.style.transform = "";
      element.style.willChange = "";
      element.classList.remove("is-dragging");
    }
    if (drag.panel === "tasks") setTaskPanelPosition(next);
    else if (drag.panel === "music") setMusicPanelPosition(next);
    else setNotesPanelPosition(next);
    savePanelPosition(drag.panel, next);
  }

  function dockPanel(panel: FloatingPanel) {
    const element = getPanelElement(panel);
    const width = element?.offsetWidth || 360;
    const current = getPanelPosition(panel);
    const viewport = workspaceViewport();
    const safe = isMobileWorkspace() || manualLandscape ? 10 : 16;
    const left = safe;
    const right = Math.max(safe, viewport.width - width - safe);
    const next = { x: Math.abs(current.x - left) < Math.abs(current.x - right) ? right : left, y: current.y };
    setFrontPanel(panel);
    setPanelPosition(panel, next, true);
  }

  function closePanel(panel: FloatingPanel) {
    if (panel === "tasks") setTaskPanelOpen(false);
    else if (panel === "music") setMusicExpanded(false);
    else setNotesPanelOpen(false);
  }

  function isMobileWorkspace() {
    const viewportWidth = window.visualViewport?.width || window.innerWidth;
    const viewportHeight = window.visualViewport?.height || window.innerHeight;
    return Math.min(viewportWidth, viewportHeight) <= 760 && Math.max(viewportWidth, viewportHeight) <= 1024;
  }

  function panelFallbackSize(panel: FloatingPanel) {
    if (panel === "tasks") return { width: 360, height: 520 };
    if (panel === "music") return { width: 410, height: 520 };
    return { width: 360, height: 430 };
  }

  function workspaceViewport() {
    const viewportWidth = window.visualViewport?.width || window.innerWidth;
    const viewportHeight = window.visualViewport?.height || window.innerHeight;
    const rotatedFallback = manualLandscape && window.matchMedia("(orientation: portrait)").matches;
    return rotatedFallback
      ? { width: viewportHeight, height: viewportWidth }
      : { width: viewportWidth, height: viewportHeight };
  }

  function defaultMobilePanelPosition(panel: FloatingPanel): PanelPosition {
    const viewport = workspaceViewport();
    const element = getPanelElement(panel);
    const fallback = panelFallbackSize(panel);
    const width = Math.min(element?.offsetWidth || fallback.width, Math.max(280, viewport.width - 20));
    const height = Math.min(element?.offsetHeight || fallback.height, Math.max(220, viewport.height - 82));
    const landscape = manualLandscape || window.matchMedia("(orientation: landscape)").matches;
    if (landscape) {
      const orderOffset = panel === "tasks" ? 0 : panel === "music" ? 18 : 36;
      return { x: 10, y: Math.min(60 + orderOffset, Math.max(60, viewport.height - height - 10)) };
    }
    return {
      x: Math.max(10, Math.round((viewport.width - width) / 2)),
      y: Math.max(62, Math.round((viewport.height - height) / 2)),
    };
  }

  function placeMobilePanel(panel: FloatingPanel) {
    if (!isMobileWorkspace() && !manualLandscape) return;
    window.requestAnimationFrame(function() {
      setPanelPosition(panel, defaultMobilePanelPosition(panel), false);
    });
  }

  function togglePanel(panel: FloatingPanel) {
    setFrontPanel(panel);
    if (panel === "tasks") {
      setTaskPanelOpen(function(current) {
        const next = !current;
        if (next) placeMobilePanel("tasks");
        return next;
      });
      return;
    }
    if (panel === "music") {
      setMusicExpanded(function(current) {
        const next = !current;
        if (next) placeMobilePanel("music");
        return next;
      });
      return;
    }
    setNotesPanelOpen(function(current) {
      const next = !current;
      if (next) placeMobilePanel("notes");
      return next;
    });
  }

  function syncWorkspaceViewportCssVars() {
    const element = studioRef.current;
    if (!element) return;
    const viewport = window.visualViewport;
    const width = Math.max(1, viewport?.width || window.innerWidth);
    const height = Math.max(1, viewport?.height || window.innerHeight);
    element.style.setProperty("--focus-visual-width", width + "px");
    element.style.setProperty("--focus-visual-height", height + "px");
  }

  async function requestLandscape() {
    syncWorkspaceViewportCssVars();
    const orientation = (screen as Screen & { orientation?: ScreenOrientation & { lock?: (orientation: string) => Promise<void>; unlock?: () => void } }).orientation;
    const mobileLike = window.innerWidth <= 900 || navigator.maxTouchPoints > 0;
    if (!mobileLike) return;

    if (manualLandscape) {
      setManualLandscape(false);
      try { orientation?.unlock?.(); } catch {}
      return;
    }

    try {
      if (!document.fullscreenElement && studioRef.current?.requestFullscreen) {
        await studioRef.current.requestFullscreen({ navigationUI: "hide" } as FullscreenOptions);
        enteredFullscreenRef.current = true;
        setBrowserFullscreen(true);
      }
      if (orientation && typeof orientation.lock === "function") {
        await orientation.lock("landscape");
        setManualLandscape(false);
        return;
      }
    } catch {}

    if (!window.matchMedia("(orientation: landscape)").matches) {
      syncWorkspaceViewportCssVars();
      setManualLandscape(true);
      props.toast("Đã bật chế độ ngang của Focus Space.");
    } else {
      setManualLandscape(false);
    }
  }

  async function toggleBrowserFullscreen() {
    try {
      if (document.fullscreenElement) {
        if (document.exitFullscreen) await document.exitFullscreen();
        enteredFullscreenRef.current = false;
        setBrowserFullscreen(false);
        return;
      }
      const target = studioRef.current;
      if (target?.requestFullscreen) {
        await target.requestFullscreen({ navigationUI: "hide" } as FullscreenOptions);
        enteredFullscreenRef.current = true;
        setBrowserFullscreen(true);
        return;
      }
      // iOS Safari/PWA has no standard Fullscreen API. The portal layer already
      // owns the visual viewport, so immersive mode is a safe CSS fallback.
      setBrowserFullscreen(function(current) { return !current; });
    } catch {
      setBrowserFullscreen(function(current) { return !current; });
    }
  }

  async function releaseWakeLock() {
    const lock = wakeLockRef.current;
    wakeLockRef.current = null;
    setWakeLockActive(false);
    if (lock && !lock.released) {
      try { await lock.release(); } catch {}
    }
  }

  async function requestWakeLock() {
    if (!("wakeLock" in navigator) || !props.timer.running || !props.open) return;
    try {
      const manager = (navigator as Navigator & { wakeLock?: { request: (type: "screen") => Promise<{ release: () => Promise<void>; released?: boolean }> } }).wakeLock;
      if (!manager) return;
      await releaseWakeLock();
      wakeLockRef.current = await manager.request("screen");
      setWakeLockActive(true);
    } catch {
      setWakeLockActive(false);
    }
  }

  useEffect(function() {
    if (!props.open) return;
    const clock = window.localStorage.getItem(storageKey("eduflow-focus-clock", props.studentId));
    if (clock === "flip" || clock === "digital") setClockStyle(clock);
    const savedTheme = window.localStorage.getItem(storageKey("eduflow-focus-theme", props.studentId));
    const inheritedTheme = document.documentElement.dataset.theme === "dark" ? "dark" : "light";
    setFocusTheme(savedTheme === "dark" || savedTheme === "light" ? savedTheme : inheritedTheme);
    setTimerSettingsOpen(false);
    setFocusMinutesDraft(String(props.timer.focusMinutes));
    setBreakMinutesDraft(String(props.timer.breakMinutes));
    setDurationDirty(false);
    const savedMedia = window.localStorage.getItem(storageKey("eduflow-focus-media", props.studentId)) || window.localStorage.getItem(storageKey("eduflow-focus-spotify", props.studentId)) || "";
    setMediaUrl(savedMedia);
    setMediaDraft(savedMedia);
    setNotesDraft(window.localStorage.getItem(storageKey("eduflow-focus-notes", props.studentId)) || "");
    setTaskPanelOpen(false);
    setMusicExpanded(false);
    setNotesPanelOpen(false);
    const savedTask = Number(window.localStorage.getItem(storageKey("eduflow-focus-task", props.studentId)) || 0);
    if (!props.selectedTaskId && savedTask > 0) props.onSelectedTaskChange(savedTask);
    const readPosition = function(panel: FloatingPanel, fallback: PanelPosition) {
      try {
        const parsed = JSON.parse(window.localStorage.getItem(panelPositionKey(panel)) || "null") as PanelPosition | null;
        if (parsed && Number.isFinite(parsed.x) && Number.isFinite(parsed.y)) return parsed;
      } catch {}
      return fallback;
    };
    const portraitMobile = window.innerWidth <= 760 && !window.matchMedia("(orientation: landscape)").matches;
    const taskWidth = Math.min(360, Math.max(290, window.innerWidth - 20));
    const musicWidth = Math.min(410, Math.max(290, window.innerWidth - 20));
    const notesWidth = Math.min(360, Math.max(290, window.innerWidth - 20));
    const taskFallback = portraitMobile
      ? { x: Math.max(10, Math.round((window.innerWidth - taskWidth) / 2)), y: 86 }
      : { x: 18, y: 84 };
    const musicFallback = portraitMobile
      ? { x: Math.max(10, Math.round((window.innerWidth - musicWidth) / 2)), y: 104 }
      : { x: window.innerWidth <= 900 ? 18 : Math.max(10, window.innerWidth - musicWidth - 18), y: 84 };
    const notesFallback = portraitMobile
      ? { x: Math.max(10, Math.round((window.innerWidth - notesWidth) / 2)), y: 122 }
      : { x: window.innerWidth <= 900 ? 18 : Math.max(10, Math.round((window.innerWidth - notesWidth) / 2)), y: 112 };
    setTaskPanelPosition(readPosition("tasks", taskFallback));
    setMusicPanelPosition(readPosition("music", musicFallback));
    setNotesPanelPosition(readPosition("notes", notesFallback));
    void loadTasks(false);
    const interval = window.setInterval(function() { if (document.visibilityState === "visible") void loadTasks(true); }, 15_000);
    return function() { window.clearInterval(interval); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.open, props.studentId]);

  useEffect(function() {
    if (!props.open) return;
    if (props.selectedTaskId) window.localStorage.setItem(storageKey("eduflow-focus-task", props.studentId), String(props.selectedTaskId));
    else window.localStorage.removeItem(storageKey("eduflow-focus-task", props.studentId));
  }, [props.open, props.selectedTaskId, props.studentId]);

  useEffect(function() {
    if (!props.open || !props.timer.running) { void releaseWakeLock(); return; }
    void requestWakeLock();
    const visible = function() { if (document.visibilityState === "visible") void requestWakeLock(); };
    document.addEventListener("visibilitychange", visible);
    return function() { document.removeEventListener("visibilitychange", visible); void releaseWakeLock(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.open, props.timer.running]);

  useEffect(function() {
    if (!props.open) return;
    const query = window.matchMedia("(orientation: landscape)");
    const update = function() {
      syncWorkspaceViewportCssVars();
      const mobile = isMobileWorkspace() || manualLandscape;
      if (mobile) {
        if (taskPanelOpen) setTaskPanelPosition(defaultMobilePanelPosition("tasks"));
        if (musicExpanded) setMusicPanelPosition(defaultMobilePanelPosition("music"));
        if (notesPanelOpen) setNotesPanelPosition(defaultMobilePanelPosition("notes"));
        return;
      }
      setTaskPanelPosition(function(current) { return clampPanelPosition("tasks", current); });
      setMusicPanelPosition(function(current) { return clampPanelPosition("music", current); });
      setNotesPanelPosition(function(current) { return clampPanelPosition("notes", current); });
    };
    query.addEventListener?.("change", update);
    window.addEventListener("resize", update);
    window.visualViewport?.addEventListener("resize", update);
    window.setTimeout(update, 0);
    return function() {
      query.removeEventListener?.("change", update);
      window.removeEventListener("resize", update);
      window.visualViewport?.removeEventListener("resize", update);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.open, manualLandscape, taskPanelOpen, musicExpanded, notesPanelOpen]);

  useEffect(function() {
    if (!props.open) return;
    const update = function() { setBrowserFullscreen(Boolean(document.fullscreenElement)); };
    document.addEventListener("fullscreenchange", update);
    update();
    return function() { document.removeEventListener("fullscreenchange", update); };
  }, [props.open]);

  useEffect(function() {
    if (!props.open) return;
    const body = document.body;
    const html = document.documentElement;
    syncWorkspaceViewportCssVars();
    const previousBodyOverflow = body.style.overflow;
    const previousHtmlOverflow = html.style.overflow;
    body.style.overflow = "hidden";
    html.style.overflow = "hidden";
    const onKeyDown = function(event: KeyboardEvent) {
      if (event.key === "Escape") props.onClose();
    };
    document.addEventListener("keydown", onKeyDown);
    return function() {
      document.removeEventListener("keydown", onKeyDown);
      body.style.overflow = previousBodyOverflow;
      html.style.overflow = previousHtmlOverflow;
      const orientation = (screen as Screen & { orientation?: ScreenOrientation & { unlock?: () => void } }).orientation;
      try { orientation?.unlock?.(); } catch {}
      if (enteredFullscreenRef.current && document.fullscreenElement && document.exitFullscreen) {
        void document.exitFullscreen().catch(function() {});
      }
      enteredFullscreenRef.current = false;
      void releaseWakeLock();
    };
  // `onClose` is intentionally read from the current render while the dialog is open.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.open]);

  useEffect(function() {
    if (durationDirty) return;
    setFocusMinutesDraft(String(props.timer.focusMinutes));
    setBreakMinutesDraft(String(props.timer.breakMinutes));
  }, [durationDirty, props.timer.breakMinutes, props.timer.focusMinutes]);

  if (!props.open) return null;

  const mediaEmbed = parseMediaEmbed(mediaUrl);
  const mainDisabled = props.timerSyncing || !props.timerReady;

  return <section ref={studioRef} data-focus-theme={focusTheme} className={"focus-studio focus-space-v2" + (manualLandscape ? " manual-landscape" : "") + (browserFullscreen ? " immersive" : "")} role="dialog" aria-modal="true" aria-label="Focus Space">
    <header className="focus-studio-topbar">
      <div className="focus-studio-brand"><strong>FOCUS SPACE</strong></div>
      <div className="focus-studio-toolbar focus-utility-toolbar" aria-label="Công cụ Focus Space">
        <button type="button" className={"focus-studio-tool icon-only" + (clockStyle === "digital" ? " active" : "")} onClick={function() { setClockStyle("digital"); window.localStorage.setItem(storageKey("eduflow-focus-clock", props.studentId), "digital"); }} title="Đồng hồ điện tử" aria-label="Đồng hồ điện tử" aria-pressed={clockStyle === "digital"}><MorphIcon icon={DIGITAL_PATH} size={19} strokeWidth={1.8} reducedMotion="user" /></button>
        <button type="button" className={"focus-studio-tool icon-only" + (clockStyle === "flip" ? " active" : "")} onClick={function() { setClockStyle("flip"); window.localStorage.setItem(storageKey("eduflow-focus-clock", props.studentId), "flip"); }} title="Flip clock" aria-label="Flip clock" aria-pressed={clockStyle === "flip"}><MorphIcon icon={FLIP_PATH} size={19} strokeWidth={1.8} reducedMotion="user" /></button>
        <button type="button" className={"focus-studio-tool icon-only" + (timerSettingsOpen ? " active" : "")} onClick={function() { setTimerSettingsOpen(!timerSettingsOpen); }} title="Chỉnh thời gian" aria-label="Chỉnh thời gian"><Settings2 /></button>
        <button type="button" className="focus-studio-tool icon-only" onClick={function() { const next = focusTheme === "dark" ? "light" : "dark"; setFocusTheme(next); window.localStorage.setItem(storageKey("eduflow-focus-theme", props.studentId), next); }} title={focusTheme === "dark" ? "Giao diện sáng" : "Giao diện tối"} aria-label={focusTheme === "dark" ? "Giao diện sáng" : "Giao diện tối"}>{focusTheme === "dark" ? <Sun /> : <Moon />}</button>
        <button type="button" className={"focus-studio-tool icon-only" + (browserFullscreen ? " active" : "")} onClick={function() { void toggleBrowserFullscreen(); }} title={browserFullscreen ? "Thoát toàn màn hình" : "Toàn màn hình"} aria-label={browserFullscreen ? "Thoát toàn màn hình" : "Toàn màn hình"}><MorphIcon icon={browserFullscreen ? COMPRESS_PATH : EXPAND_PATH} size={19} strokeWidth={1.8} spring="snappy" reducedMotion="user" /></button>
        <button type="button" className={"focus-studio-tool icon-only focus-landscape-button" + (manualLandscape ? " active" : "")} onClick={requestLandscape} title={manualLandscape ? "Trở về màn hình dọc" : "Xoay ngang trên điện thoại"} aria-label={manualLandscape ? "Trở về màn hình dọc" : "Xoay ngang trên điện thoại"} aria-pressed={manualLandscape}><RotateCw /></button>
        <button type="button" className="focus-studio-tool icon-only focus-close-button" onClick={props.onClose} title="Thoát Focus Space" aria-label="Thoát Focus Space"><MorphIcon icon={CLOSE_PATH} size={19} strokeWidth={1.8} spring="snappy" reducedMotion="user" /></button>
      </div>
    </header>

    {timerSettingsOpen ? <section className="focus-timer-settings" aria-label="Cài đặt Pomodoro">
      <header><strong>Thời gian</strong><button type="button" onClick={function() { setTimerSettingsOpen(false); }} aria-label="Đóng cài đặt"><MorphIcon icon={CLOSE_PATH} size={15} strokeWidth={1.9} reducedMotion="user" /></button></header>
      <div className="focus-duration-presets">{[[25,5],[45,10],[50,10],[90,15]].map(function(item) { return <button key={item.join("-")} type="button" disabled={props.timer.status !== "idle" || props.timer.mode !== "focus" || props.timerSyncing} onClick={function() { setFocusMinutesDraft(String(item[0])); setBreakMinutesDraft(String(item[1])); setDurationDirty(true); }}>{item[0]}/{item[1]}</button>; })}</div>
      <div className="focus-duration-fields">
        <label><span>Focus</span><input type="number" inputMode="numeric" min="5" max="180" value={focusMinutesDraft} disabled={props.timer.status !== "idle" || props.timer.mode !== "focus" || props.timerSyncing} onChange={function(event) { setFocusMinutesDraft(event.target.value); setDurationDirty(true); }} /></label>
        <label><span>Break</span><input type="number" inputMode="numeric" min="1" max="60" value={breakMinutesDraft} disabled={props.timer.status !== "idle" || props.timer.mode !== "focus" || props.timerSyncing} onChange={function(event) { setBreakMinutesDraft(event.target.value); setDurationDirty(true); }} /></label>
      </div>
      <button type="button" className="focus-duration-apply" disabled={!durationDirty || props.timer.status !== "idle" || props.timer.mode !== "focus" || props.timerSyncing} onClick={async function() { const focus = Number(focusMinutesDraft); const rest = Number(breakMinutesDraft); if (!Number.isFinite(focus) || !Number.isFinite(rest)) { props.toast("Hãy nhập đủ thời gian Focus và Break."); return; } const result = await props.onConfigure(focus, rest); if (result) { setDurationDirty(false); setFocusMinutesDraft(String(result.focusMinutes)); setBreakMinutesDraft(String(result.breakMinutes)); } }}>Áp dụng</button>
    </section> : null}

    <div className="focus-studio-grid">
      <main className="focus-timer-stage">
        <div className="focus-timer-aura" aria-hidden="true" />
        <div className="focus-mode-switch" aria-label="Chế độ Pomodoro">
          <button type="button" className={props.timer.mode === "focus" ? "active" : ""} disabled={props.timer.running || props.timerSyncing} onClick={function() { if (props.timer.mode === "break") void props.onSkipBreak(); }}>Focus</button>
          <button type="button" className={props.timer.mode === "break" ? "active" : ""} disabled={props.timer.running || props.timerSyncing} onClick={function() { if (props.timer.mode === "focus") void props.onEnterBreak(); }}>Break</button>
        </div>
        <div className={"focus-studio-clock " + clockStyle} aria-live="polite">
          {clockStyle === "flip" ? <FlipClock value={timerValue} reducedMotion={props.reducedMotion} /> : <DigitalClock value={timerValue} />}
        </div>
        <div className="focus-studio-main-actions">
          {props.timer.mode === "focus" ? <button type="button" className="focus-studio-play" disabled={mainDisabled} onClick={function() { void (props.timer.running ? props.onPause() : props.onStart()); }}><MorphIcon icon={props.timer.running ? PAUSE_PATH : PLAY_PATH} size={30} strokeWidth={1.8} spring="snappy" reducedMotion="user" /><span>{props.timer.running ? "Tạm dừng" : props.timer.sessionKey ? "Tiếp tục" : "Bắt đầu"}</span></button> : <button type="button" className="focus-studio-play" disabled={mainDisabled} onClick={function() { void (props.timer.running ? props.onPause() : props.onResumeBreak()); }}><MorphIcon icon={props.timer.running ? PAUSE_PATH : PLAY_PATH} size={30} strokeWidth={1.8} spring="snappy" reducedMotion="user" /><span>{props.timer.running ? "Tạm dừng" : props.timer.remainingMs >= props.timer.breakMinutes * 60_000 - 1000 ? "Bắt đầu nghỉ" : "Tiếp tục nghỉ"}</span></button>}
          <button type="button" className="focus-studio-round-action" disabled={mainDisabled} onClick={function() { void props.onStop(); }} title="Kết thúc phiên"><MorphIcon icon={SQUARE_PATH} size={19} strokeWidth={1.8} reducedMotion="user" /></button>
          {props.timer.mode === "break" ? <button type="button" className="focus-studio-round-action" disabled={mainDisabled} onClick={function() { void props.onSkipBreak(); }} title="Bỏ qua giờ nghỉ"><SkipForward /></button> : null}
        </div>
        <div className="focus-studio-metrics">
          <span><Clock3 /><small>Hôm nay</small><strong>{props.stats.todaySessions} phiên · {formatFocusTotal(props.stats.todayMinutes)}</strong></span>
          <span><Settings2 /><small>Tuần này</small><strong>{props.stats.weekSessions} phiên · {formatFocusTotal(props.stats.weekMinutes)}</strong></span>
        </div>
        <span className="focus-wakelock-dot" data-active={wakeLockActive ? "true" : "false"} aria-hidden="true" />
      </main>

      {taskPanelOpen ? <aside ref={taskPanelRef} className="focus-task-panel focus-floating-window" style={{ left: taskPanelPosition.x, top: taskPanelPosition.y, zIndex: frontPanel === "tasks" ? 30 : 20 }} onPointerDown={function() { setFrontPanel("tasks"); }}>
        <header className="focus-window-titlebar" onPointerDown={function(event) { beginPanelDrag(event, "tasks"); }} onPointerMove={movePanelDrag} onPointerUp={endPanelDrag} onPointerCancel={endPanelDrag}>
          <div><ListTodo /><strong>Việc cần làm</strong></div>
          <nav onPointerDown={function(event) { event.stopPropagation(); }}>
            <button type="button" className="focus-window-action" title="Đưa sang trái/phải" aria-label="Đưa bảng việc cần làm sang trái hoặc phải" onClick={function() { dockPanel("tasks"); }}><MoveHorizontal /></button>
            <button type="button" className="focus-window-action" title="Đóng" aria-label="Đóng việc cần làm" onClick={function() { closePanel("tasks"); }}><MorphIcon icon={CLOSE_PATH} size={16} strokeWidth={1.9} reducedMotion="user" /></button>
          </nav>
        </header>
        <div className="focus-task-panel-body">
          <form className="focus-task-add" onSubmit={function(event) { event.preventDefault(); void addTask(); }}>
            <Plus aria-hidden="true" />
            <input value={taskDraft} maxLength={180} placeholder="Thêm việc cần làm..." aria-label="Thêm việc cần làm" disabled={tasksLoading} onChange={function(event) { setTaskDraft(event.target.value); }} />
            <button type="submit" disabled={tasksLoading || !taskDraft.trim()}>Thêm</button>
          </form>
          <div ref={listRef} className="focus-task-list" aria-live="polite">
            {!openTasks.length && !tasksLoading ? <div className="focus-task-empty"><Check /><strong>Chưa có việc cần làm</strong></div> : null}
            {openTasks.map(function(task) {
              const active = props.selectedTaskId === task.id;
              return <article className={"focus-task-row" + (active ? " active" : "")} key={task.id} data-focus-task-id={task.id}>
                <button type="button" className="focus-task-check" onClick={function() { void patchTask(task.id, { done: true }); }} aria-label={"Hoàn thành " + task.title}><MorphIcon icon={task.done ? CHECK_PATH : SQUARE_PATH} size={18} strokeWidth={1.8} reducedMotion="user" /></button>
                {editingTaskId === task.id ? <form className="focus-task-edit" onSubmit={function(event) { event.preventDefault(); void saveTaskEdit(); }}>
                  <input autoFocus value={editingTaskTitle} maxLength={180} aria-label="Sửa tên task" onChange={function(event) { setEditingTaskTitle(event.target.value); }} onKeyDown={function(event) { if (event.key === "Escape") { event.stopPropagation(); setEditingTaskId(null); setEditingTaskTitle(""); } }} />
                  <button type="submit" aria-label="Lưu tên task"><Check /></button>
                </form> : <button type="button" className="focus-task-select" aria-pressed={active} onClick={function() { void selectFocusTask(active ? null : task.id); }} title={active ? "Bỏ chọn task đang tập trung" : "Tập trung vào task này"}>
                  <span className="focus-task-title">{task.title}</span>
                  <small><b>{task.completedPomodoros}</b> phiên{active ? " · đang tập trung" : ""}</small>
                </button>}
                <div className="focus-task-row-actions">
                  <button type="button" className="focus-task-edit-button" aria-label={"Sửa " + task.title} title="Sửa task" onClick={function() { beginTaskEdit(task); }}><Pencil /></button>
                  <button type="button" className="focus-task-drag" aria-label={"Kéo để sắp xếp " + task.title} title="Kéo để sắp xếp" onPointerDown={function(event) { beginPointerDrag(event, task.id); }} onPointerMove={movePointerDrag} onPointerUp={endPointerDrag} onPointerCancel={endPointerDrag}><GripVertical /></button>
                  <button type="button" className="focus-task-delete" aria-label={"Xóa " + task.title} onClick={function() { void deleteTask(task.id); }}><Trash2 /></button>
                </div>
              </article>;
            })}
          </div>
          {completedTasks.length ? <div className="focus-task-completed">
            <button type="button" onClick={function() { setShowCompleted(!showCompleted); }} aria-expanded={showCompleted}><Check />Đã hoàn thành ({completedTasks.length}){showCompleted ? <ChevronUp /> : <ChevronDown />}</button>
            {showCompleted ? <div>{completedTasks.map(function(task) { return <article key={task.id}><button type="button" aria-label="Mở lại task" onClick={function() { void patchTask(task.id, { done: false }); }}><MorphIcon icon={CHECK_PATH} size={17} strokeWidth={1.8} reducedMotion="user" /></button><span>{task.title}</span><small>{task.completedPomodoros} phiên</small><button type="button" aria-label="Xóa task" onClick={function() { void deleteTask(task.id); }}><Trash2 /></button></article>; })}</div> : null}
          </div> : null}
        </div>
      </aside> : null}

      <aside ref={musicPanelRef} aria-hidden={!musicExpanded} className={"focus-music-panel focus-floating-window focus-media-window" + (musicExpanded ? "" : " focus-window-hidden")} style={{ left: musicPanelPosition.x, top: musicPanelPosition.y, zIndex: frontPanel === "music" ? 30 : 20 }} onPointerDown={function() { if (musicExpanded) setFrontPanel("music"); }}>
        <header className="focus-window-titlebar" onPointerDown={function(event) { beginPanelDrag(event, "music"); }} onPointerMove={movePanelDrag} onPointerUp={endPanelDrag} onPointerCancel={endPanelDrag}>
          <div><Headphones /><strong>Nhạc</strong></div>
          <nav onPointerDown={function(event) { event.stopPropagation(); }}>
            <button type="button" className="focus-window-action" title="Đưa sang trái/phải" aria-label="Đưa bảng nhạc sang trái hoặc phải" onClick={function() { dockPanel("music"); }}><MoveHorizontal /></button>
            <button type="button" className="focus-window-action" title="Đóng" aria-label="Đóng bảng nhạc" onClick={function() { closePanel("music"); }}><MorphIcon icon={CLOSE_PATH} size={16} strokeWidth={1.9} reducedMotion="user" /></button>
          </nav>
        </header>
        <div className="focus-music-body lifeat-music-body">
          <div className="focus-media-pane">
            {mediaEmbed ? <div className={"focus-media-player-shell " + mediaEmbed.provider}>
              {mediaEmbed.provider === "spotify" ? <iframe key={mediaEmbed.url + ":" + spotifyFrameRevision} className="focus-spotify-embed" title="Spotify player" src={mediaEmbed.url} width="100%" height="152" frameBorder="0" loading="eager" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" allowFullScreen /> : <iframe className="focus-youtube-embed" title="YouTube player" src={mediaEmbed.url} height="220" loading="lazy" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" allowFullScreen />}
            </div> : <button type="button" className="focus-media-preset" onClick={function() { setMediaUrl(PEACEFUL_PIANO_URL); setMediaDraft(PEACEFUL_PIANO_URL); window.localStorage.setItem(storageKey("eduflow-focus-media", props.studentId), PEACEFUL_PIANO_URL); }}><Music2 /><span>Peaceful Piano</span></button>}
            {mediaEmbed?.provider === "spotify" ? <div className="focus-spotify-mobile-actions">
              <a href={spotifyContentUrl(mediaUrl)} target="_blank" rel="noopener noreferrer">Mở Spotify</a>
              <button type="button" onClick={function() { setSpotifyFrameRevision(function(value) { return value + 1; }); }}>Tải lại player</button>
            </div> : null}
            <form className="focus-spotify-form focus-media-link-form" onSubmit={function(event) { event.preventDefault(); const parsed = parseMediaEmbed(mediaDraft); if (!parsed) { props.toast("Link Spotify hoặc YouTube chưa hợp lệ."); return; } const value = mediaDraft.trim(); setMediaUrl(value); window.localStorage.setItem(storageKey("eduflow-focus-media", props.studentId), value); }}>
              {parseMediaEmbed(mediaDraft)?.provider === "youtube" ? <Youtube /> : <Music2 />}
              <input value={mediaDraft} placeholder="Dán link Spotify hoặc YouTube" aria-label="Link Spotify hoặc YouTube" onChange={function(event) { setMediaDraft(event.target.value); }} />
              <button type="submit">Mở</button>
            </form>
          </div>
        </div>
      </aside>

      {notesPanelOpen ? <aside ref={notesPanelRef} className="focus-notes-panel focus-floating-window" style={{ left: notesPanelPosition.x, top: notesPanelPosition.y, zIndex: frontPanel === "notes" ? 30 : 20 }} onPointerDown={function() { setFrontPanel("notes"); }}>
        <header className="focus-window-titlebar" onPointerDown={function(event) { beginPanelDrag(event, "notes"); }} onPointerMove={movePanelDrag} onPointerUp={endPanelDrag} onPointerCancel={endPanelDrag}>
          <div><StickyNote /><strong>Ghi chú</strong></div>
          <nav onPointerDown={function(event) { event.stopPropagation(); }}>
            <button type="button" className="focus-window-action" title="Đưa sang trái/phải" aria-label="Đưa ghi chú sang trái hoặc phải" onClick={function() { dockPanel("notes"); }}><MoveHorizontal /></button>
            <button type="button" className="focus-window-action" title="Đóng" aria-label="Đóng ghi chú" onClick={function() { closePanel("notes"); }}><MorphIcon icon={CLOSE_PATH} size={16} strokeWidth={1.9} reducedMotion="user" /></button>
          </nav>
        </header>
        <div className="focus-notes-body">
          <textarea value={notesDraft} maxLength={6000} placeholder="Ghi nhanh..." aria-label="Ghi chú Focus Space" onChange={function(event) { const value = event.target.value; setNotesDraft(value); try { window.localStorage.setItem(storageKey("eduflow-focus-notes", props.studentId), value); } catch {} }} />
        </div>
      </aside> : null}
    </div>

    <nav className="focus-space-dock" aria-label="Focus Space">
      <button type="button" className={taskPanelOpen ? "active" : ""} aria-pressed={taskPanelOpen} onClick={function() { togglePanel("tasks"); }}><MorphIcon icon={TASKS_PATH} size={21} strokeWidth={1.8} spring="snappy" reducedMotion="user" /><span>Task</span></button>
      <button type="button" className={musicExpanded ? "active" : ""} aria-pressed={musicExpanded} onClick={function() { togglePanel("music"); }}><MorphIcon icon={MUSIC_PATH} size={21} strokeWidth={1.8} spring="snappy" reducedMotion="user" /><span>Music</span></button>
      <button type="button" className={notesPanelOpen ? "active" : ""} aria-pressed={notesPanelOpen} onClick={function() { togglePanel("notes"); }}><MorphIcon icon={NOTES_PATH} size={21} strokeWidth={1.8} spring="snappy" reducedMotion="user" /><span>Notes</span></button>
    </nav>
  </section>;
}
