"use client";
/* eslint-disable @next/next/no-img-element -- class logos are user-uploaded R2 objects served by an authenticated API */

import {
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  BookOpen,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
  Clock3,
  Coins,
  FileText,
  GraduationCap,
  MessageSquare,
  Pencil,
  Plus,
  RefreshCw,
  Trash2,
  UserRound,
  Users,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";

export type ClassHubStudent = {
  id?: number;
  initials: string;
  name: string;
  code: string;
  className: string;
  classKeys?: string[];
  classNames?: string[];
  avg: number;
  attendance: number;
  state: string;
  tone: string;
  phone?: string;
  email?: string;
  hasGrades?: boolean;
  hasAttendance?: boolean;
};

export type ClassHubClass = {
  id?: number;
  key?: string;
  name: string;
  label?: string;
  schedule: string;
  studentCount: number;
  average: number;
  attendance: number;
  openAssignments: number;
  tone: string;
  teacher: string;
  room: string;
  startTime: string;
  endTime: string;
  schedules?: { weekday: number; startTime: string; endTime: string; room?: string }[];
  logoUrl?: string;
  hasGrades?: boolean;
  hasAttendance?: boolean;
};

type LatestComment = { id: number; content: string; date: string; type: string };
type ClassSummary = { points: Record<string, number>; latestComments: Record<string, LatestComment> };
type GradeRecord = { id: string; date: string; title: string; category: string; maxScore: number; score: number; term: string };
type AttendanceRecord = { id: number; date: string; startTime: string; endTime: string; status: string; arrivalTime: string; note: string; sessionType?: string; sessionId?: number };
type PointRecord = { id: number; delta: number; reason: string; source: string; actor: string; createdAt: string; date: string };
type CommentRecord = { id: number; content: string; date: string; type: string; creator: string; createdAt: string };
type StudentDetail = {
  student: { id: number; code: string; name: string; className: string; status: string; phone: string; email: string };
  classInfo: { key: string; name: string; label: string; teacher: string; room: string; schedule: string; startTime: string; endTime: string };
  grades: GradeRecord[];
  attendance: AttendanceRecord[];
  points: PointRecord[];
  pointBalance: number;
  comments: CommentRecord[];
  sessions: Array<{ id: number; sessionType: string; sessionDate: string; startTime: string; endTime: string; note: string }>;
  teacherName: string;
};
type DetailTab = "overview" | "grades" | "attendance" | "points" | "comments" | "activity";
type TimeFilter = { preset: "7" | "30" | "month" | "all" | "custom"; from: string; to: string };
type ReportOptions = { overview: boolean; grades: boolean; attendance: boolean; points: boolean; comments: boolean };

const attendanceMeta: Record<string, { label: string; short: string; className: string }> = {
  present: { label: "Có mặt đúng giờ", short: "✓", className: "present" },
  late: { label: "Đi trễ", short: "!", className: "late" },
  allowed: { label: "Vắng có phép", short: "P", className: "allowed" },
  absent: { label: "Vắng không phép", short: "×", className: "absent" },
  none: { label: "Không có lịch học", short: "—", className: "none" },
  unmarked: { label: "Chưa điểm danh", short: "?", className: "unmarked" },
};

const APP_TIME_ZONE = "Asia/Ho_Chi_Minh";

const CLASS_WEEKDAY_LABELS = ["", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"];

function classScheduleSummary(course: ClassHubClass): string {
  if (course.schedules?.length) {
    return course.schedules
      .map(function (item) {
        const day = CLASS_WEEKDAY_LABELS[item.weekday] || "Buổi học";
        return day + " " + item.startTime + "–" + item.endTime;
      })
      .join(" · ");
  }
  return [course.schedule, course.startTime && course.endTime ? course.startTime + "–" + course.endTime : ""]
    .filter(Boolean)
    .join(" · ");
}

function appToday(value = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: APP_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(value);
  const values = Object.fromEntries(parts.map(function (part) { return [part.type, part.value]; }));
  return values.year + "-" + values.month + "-" + values.day;
}

function localDate(value = new Date()): string {
  const year = value.getFullYear();
  const month = String(value.getMonth() + 1).padStart(2, "0");
  const day = String(value.getDate()).padStart(2, "0");
  return year + "-" + month + "-" + day;
}

function shiftAppDateKey(dateKey: string, days: number): string {
  const parts = dateKey.split("-").map(Number);
  if (parts.length !== 3 || parts.some(function(value) { return !Number.isFinite(value); })) return dateKey;
  return new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + days)).toISOString().slice(0, 10);
}

function parseDate(value: string): Date {
  const parts = value.split("-").map(Number);
  return new Date(parts[0] || 1970, (parts[1] || 1) - 1, parts[2] || 1);
}

function displayDate(value: string): string {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? parseDate(value).toLocaleDateString("vi-VN") : "Chưa có ngày";
}

function displayDateTime(value: string): string {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString("vi-VN");
}

function fallbackLabel(className: string): string {
  const words = className.trim().split(/\s+/).filter(Boolean);
  return (words[words.length - 1] || className || "Lớp").slice(0, 10);
}

function classLabel(item: ClassHubClass): string {
  return String(item.label || "").trim() || fallbackLabel(item.name);
}

function classIdentity(item: ClassHubClass): string {
  return String(item.id ?? item.key ?? item.name);
}

function studentInCourse(student: ClassHubStudent, course: ClassHubClass): boolean {
  if (course.key && student.classKeys?.includes(course.key)) return true;
  if (student.classNames?.includes(course.name)) return true;
  return student.className === course.name;
}

function EnrollmentModal(props: { course: ClassHubClass; students: ClassHubStudent[]; close: () => void; refresh: () => Promise<void>; createStudent: () => void; notify: (text: string) => void }) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<number[]>([]);
  const [saving, setSaving] = useState(false);
  const normalized = query.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  const visible = props.students.filter(function(student) {
    if (!normalized) return true;
    return [student.name, student.code, ...(student.classNames || [student.className])].join(" ").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().includes(normalized);
  });
  async function addSelected() {
    if (!selected.length || saving) return;
    setSaving(true);
    const response = await fetch("/api/enrollments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ classKey: props.course.key, className: props.course.name, studentIds: selected }) });
    const payload = await response.json();
    if (!response.ok) { props.notify(payload.error || "Không thể thêm học sinh vào lớp."); setSaving(false); return; }
    await props.refresh();
    props.notify("Đã thêm " + payload.added + " học sinh vào lớp");
    props.close();
  }
  return createPortal(<div className="modal" onMouseDown={props.close}><section className="form-modal enrollment-modal" role="dialog" aria-modal="true" onMouseDown={function(event) { event.stopPropagation(); }}><div className="modal-head"><div><h2>Thêm học sinh vào {props.course.name}</h2><p>Tìm tài khoản có sẵn và chọn một hoặc nhiều học sinh.</p></div><button className="modal-close" onClick={props.close}><X /></button></div><div className="enrollment-modal-body"><label className="enrollment-search"><span>Tìm theo tên hoặc mã học sinh</span><input value={query} onChange={function(event) { setQuery(event.target.value); }} placeholder="Ví dụ: An hoặc HS24001" autoFocus /></label><div className="enrollment-candidates scroll-region">{visible.map(function(student) { const joined = studentInCourse(student, props.course); const id = Number(student.id); const checked = selected.includes(id); return <label key={student.code} className={joined ? "joined" : ""}><input type="checkbox" disabled={joined || !id} checked={joined || checked} onChange={function(event) { setSelected(function(current) { return event.target.checked ? current.concat(id) : current.filter(function(value) { return value !== id; }); }); }} /><span className={"mini-avatar avatar-" + student.tone}>{student.initials}</span><span><strong>{student.name}</strong><small>{student.code} - {(student.classNames || [student.className]).join(", ")}</small></span><em>{joined ? "Đã tham gia" : checked ? "Đã chọn" : "Có thể thêm"}</em></label>; })}{!visible.length ? <div className="class-empty-inline"><UserRound /><p>Không tìm thấy học sinh phù hợp.</p></div> : null}</div><button type="button" className="button soft enrollment-create" onClick={props.createStudent}><UserRound />Tạo học sinh mới</button></div><div className="modal-footer"><button className="button ghost" onClick={props.close}>Hủy</button><button className="button primary" disabled={!selected.length || saving} onClick={function() { void addSelected(); }}>{saving ? "Đang thêm..." : "Thêm " + selected.length + " học sinh"}</button></div></section></div>, document.body);
}

function rangeFor(filter: TimeFilter): { from: string; to: string } | null {
  if (filter.preset === "all") return null;
  if (filter.preset === "custom") return filter.from && filter.to ? { from: filter.from, to: filter.to } : null;
  const to = appToday();
  if (filter.preset === "month") return { from: to.slice(0, 7) + "-01", to };
  const days = filter.preset === "7" ? 6 : 29;
  return { from: shiftAppDateKey(to, -days), to };
}

function isInRange(date: string, filter: TimeFilter): boolean {
  const range = rangeFor(filter);
  if (!range) return filter.preset === "all" || Boolean(date);
  return Boolean(date && date >= range.from && date <= range.to);
}

function scheduledDays(schedule: string): Set<number> {
  const result = new Set<number>();
  const normalized = schedule.toLowerCase();
  for (let day = 2; day <= 7; day += 1) {
    if (new RegExp("thứ\\s*" + day).test(normalized)) result.add(day - 1);
  }
  if (/chủ\s*nhật|\bcn\b/.test(normalized)) result.add(0);
  return result;
}

function monthLabel(month: string): string {
  const [year, number] = month.split("-");
  return "Tháng " + number + "/" + year;
}

function changeMonth(month: string, delta: number): string {
  const [year, number] = month.split("-").map(Number);
  return localDate(new Date(year, number - 1 + delta, 1)).slice(0, 7);
}

function monthCells(month: string): Array<{ date: string; day: number } | null> {
  const [year, number] = month.split("-").map(Number);
  const first = new Date(year, number - 1, 1);
  const count = new Date(year, number, 0).getDate();
  const leading = (first.getDay() + 6) % 7;
  const cells: Array<{ date: string; day: number } | null> = Array.from({ length: leading }, function () { return null; });
  for (let day = 1; day <= count; day += 1) cells.push({ date: localDate(new Date(year, number - 1, day)), day });
  while (cells.length % 7) cells.push(null);
  return cells;
}

function statusForDate(date: string, records: AttendanceRecord[], schedule: string): string {
  const record = records.find(function (item) { return item.date === date; });
  if (record) return record.status;
  const days = scheduledDays(schedule);
  return days.has(parseDate(date).getDay()) ? "unmarked" : "none";
}

function escapeHtml(value: unknown): string {
  return String(value ?? "").replace(/[&<>"']/g, function (char) {
    return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" } as Record<string, string>)[char];
  });
}

function TimeFilterBar(props: { value: TimeFilter; onChange: (next: TimeFilter) => void }) {
  return (
    <div className="class-history-filter" aria-label="Lọc theo thời gian">
      <select value={props.value.preset} onChange={function (event) { props.onChange({ ...props.value, preset: event.target.value as TimeFilter["preset"] }); }}>
        <option value="7">7 ngày gần nhất</option>
        <option value="30">30 ngày gần nhất</option>
        <option value="month">Tháng này</option>
        <option value="all">Tất cả</option>
        <option value="custom">Khoảng ngày tùy chọn</option>
      </select>
      {props.value.preset === "custom" ? (
        <>
          <input aria-label="Từ ngày" type="date" value={props.value.from} onChange={function (event) { props.onChange({ ...props.value, from: event.target.value }); }} />
          <span>đến</span>
          <input aria-label="Đến ngày" type="date" value={props.value.to} onChange={function (event) { props.onChange({ ...props.value, to: event.target.value }); }} />
        </>
      ) : null}
    </div>
  );
}

function AttendanceCalendar(props: { records: AttendanceRecord[]; schedule: string; month: string; setMonth: (month: string) => void }) {
  const [selectedDate, setSelectedDate] = useState("");
  const cells = monthCells(props.month);
  const selected = props.records.find(function (item) { return item.date === selectedDate; });
  const selectedStatus = selectedDate ? statusForDate(selectedDate, props.records, props.schedule) : "";
  return (
    <section className="student-attendance-calendar">
      <header>
        <button className="icon-button" aria-label="Tháng trước" onClick={function () { props.setMonth(changeMonth(props.month, -1)); setSelectedDate(""); }}><ChevronLeft size={18} /></button>
        <div><h3>{monthLabel(props.month)}</h3><p>Lịch điểm danh theo tháng</p></div>
        <button className="icon-button" aria-label="Tháng sau" onClick={function () { props.setMonth(changeMonth(props.month, 1)); setSelectedDate(""); }}><ChevronRight size={18} /></button>
      </header>
      <div className="attendance-calendar-grid">
        {["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map(function (day) { return <strong key={day}>{day}</strong>; })}
        {cells.map(function (cell, index) {
          if (!cell) return <span className="calendar-blank" key={"blank-" + index} />;
          const status = statusForDate(cell.date, props.records, props.schedule);
          const meta = attendanceMeta[status] || attendanceMeta.unmarked;
          const isToday = cell.date === appToday();
          return (
            <button key={cell.date} className={"attendance-day " + meta.className + (selectedDate === cell.date ? " selected" : "")} onClick={function () { setSelectedDate(cell.date); }} aria-label={displayDate(cell.date) + ": " + meta.label}>
              <span className={"attendance-day-date" + (isToday ? " today" : "")} aria-current={isToday ? "date" : undefined}>{cell.day}</span><b aria-hidden="true">{meta.short}</b><small>{meta.label}</small>
            </button>
          );
        })}
      </div>
      <div className="attendance-calendar-legend">
        {["present", "late", "allowed", "absent", "none", "unmarked"].map(function (status) {
          const meta = attendanceMeta[status];
          return <span className={meta.className} key={status}><b>{meta.short}</b>{meta.label}</span>;
        })}
      </div>
      {selectedDate ? (
        <div className="attendance-day-detail" aria-live="polite">
          <div><strong>{parseDate(selectedDate).toLocaleDateString("vi-VN", { weekday: "long", day: "2-digit", month: "2-digit", year: "numeric" })}</strong><span className={attendanceMeta[selectedStatus]?.className}>{attendanceMeta[selectedStatus]?.short} {attendanceMeta[selectedStatus]?.label}</span></div>
          {selected ? (
            <dl>
              <div><dt>Lịch học</dt><dd>{selected.startTime || "—"}–{selected.endTime || "—"}</dd></div>
              <div><dt>Có mặt lúc</dt><dd>{selected.arrivalTime || "Chưa có dữ liệu giờ vào"}</dd></div>
              <div><dt>Ghi chú</dt><dd>{selected.note || "Không có ghi chú"}</dd></div>
            </dl>
          ) : <p>{selectedStatus === "unmarked" ? "Buổi học này chưa được điểm danh." : "Ngày này không có lịch học."}</p>}
        </div>
      ) : null}
    </section>
  );
}

function CommentsPanel(props: { studentId: number; courseId: string; comments: CommentRecord[]; reload: () => Promise<void>; notify: (text: string) => void }) {
  const [content, setContent] = useState("");
  const [date, setDate] = useState(appToday());
  const [type, setType] = useState("Theo ngày");
  const [editing, setEditing] = useState<CommentRecord | null>(null);
  const [saving, setSaving] = useState(false);
  const presets = ["Có tiến bộ", "Chăm chỉ", "Hoàn thành bài đầy đủ", "Cần tập trung hơn", "Cần cải thiện chuyên cần"];
  async function save() {
    if (!content.trim() || saving) return;
    setSaving(true);
    const response = await fetch("/api/student-records/" + props.studentId + "?courseId=" + encodeURIComponent(props.courseId), {
      method: editing ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ commentId: editing?.id, content, date, type }),
    });
    const payload = await response.json();
    setSaving(false);
    if (!response.ok) { props.notify(payload.error || "Không thể lưu nhận xét."); return; }
    setContent(""); setEditing(null); setDate(appToday()); setType("Theo ngày");
    await props.reload();
    props.notify(editing ? "Đã cập nhật nhận xét" : "Đã thêm nhận xét");
  }
  async function remove(comment: CommentRecord) {
    if (!window.confirm("Xóa nhận xét ngày " + displayDate(comment.date) + "?")) return;
    const response = await fetch("/api/student-records/" + props.studentId, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ commentId: comment.id }) });
    if (!response.ok) { props.notify("Không thể xóa nhận xét."); return; }
    await props.reload(); props.notify("Đã xóa nhận xét");
  }
  return (
    <div className="student-comments-layout">
      <section className="card comment-composer">
        <div><h3>{editing ? "Sửa nhận xét" : "Thêm nhận xét"}</h3><p>Nhận xét của giáo viên được lưu riêng cho học sinh này.</p></div>
        <div className="comment-presets">{presets.map(function (preset) { return <button key={preset} onClick={function () { setContent(preset); }}>{preset}</button>; })}</div>
        <textarea aria-label="Nội dung nhận xét" maxLength={2000} rows={5} value={content} onChange={function (event) { setContent(event.target.value); }} placeholder="Nhập nhận xét cho học sinh..." />
        <div className="comment-fields">
          <label>Ngày<input type="date" value={date} onChange={function (event) { setDate(event.target.value); }} /></label>
          <label>Loại<select value={type} onChange={function (event) { setType(event.target.value); }}><option>Theo ngày</option><option>Tổng hợp tuần</option><option>Tổng hợp tháng</option></select></label>
          <span>{content.length} / 2000</span>
        </div>
        <footer>
          {editing ? <button className="button ghost" onClick={function () { setEditing(null); setContent(""); setDate(appToday()); setType("Theo ngày"); }}>Hủy sửa</button> : null}
          <button className="button primary" disabled={!content.trim() || saving} onClick={function () { void save(); }}><MessageSquare size={16} />{saving ? "Đang lưu..." : editing ? "Lưu thay đổi" : "Thêm nhận xét"}</button>
        </footer>
      </section>
      <section className="comment-history">
        {props.comments.map(function (comment) {
          return <article className="card" key={comment.id}><header><div><strong>{displayDate(comment.date)}</strong><span>{comment.type}</span></div><div><button className="icon-button" title="Sửa nhận xét" onClick={function () { setEditing(comment); setContent(comment.content); setDate(comment.date); setType(comment.type); }}><Pencil size={15} /></button><button className="icon-button delete" title="Xóa nhận xét" onClick={function () { void remove(comment); }}><Trash2 size={15} /></button></div></header><p>{comment.content}</p><small>{comment.creator} · {displayDateTime(comment.createdAt)}</small></article>;
        })}
        {!props.comments.length ? <div className="card class-empty-inline"><MessageSquare size={24} /><p>Chưa có nhận xét</p></div> : null}
      </section>
    </div>
  );
}

function StudentProfile(props: { student: ClassHubStudent; detail: StudentDetail; tab: DetailTab; setTab: (tab: DetailTab) => void; back: () => void; editStudent: () => void; openReport: () => void; reload: () => Promise<void>; notify: (text: string) => void }) {
  const [filter, setFilter] = useState<TimeFilter>({ preset: "all", from: "", to: "" });
  const newestMonth = props.detail.attendance.map(function (item) { return item.date.slice(0, 7); }).filter(Boolean).sort().reverse()[0] || appToday().slice(0, 7);
  const [month, setMonth] = useState(newestMonth);
  const grades = props.detail.grades.filter(function (item) { return isInRange(item.date, filter); });
  const points = props.detail.points.filter(function (item) { return isInRange(item.date, filter); });
  const comments = props.detail.comments.filter(function (item) { return isInRange(item.date, filter); });
  const tabs: Array<[DetailTab, string]> = [["overview", "Tổng quan"], ["grades", "Điểm học tập"], ["attendance", "Điểm danh"], ["points", "Cộng / trừ điểm"], ["comments", "Nhận xét"], ["activity", "Hoạt động"]];
  const activity = useMemo(function () {
    const rows = ([] as Array<{ key: string; date: string; title: string; detail: string; type: string }>).concat(
      props.detail.grades.map(function (item) { return { key: "g" + item.id, date: item.date, title: item.title, detail: item.score + " / " + item.maxScore + " · " + item.category, type: "grade" }; }),
      props.detail.attendance.map(function (item) { const meta = attendanceMeta[item.status] || attendanceMeta.unmarked; return { key: "a" + item.id, date: item.date, title: meta.label, detail: item.startTime + "–" + item.endTime, type: "attendance" }; }),
      props.detail.points.map(function (item) { return { key: "p" + item.id, date: item.date, title: (item.delta > 0 ? "+" : "") + item.delta + " điểm", detail: item.reason, type: item.delta > 0 ? "plus" : "minus" }; }),
      props.detail.comments.map(function (item) { return { key: "c" + item.id, date: item.date, title: "Nhận xét giáo viên", detail: item.content, type: "comment" }; }),
    );
    return rows.filter(function (item) { return isInRange(item.date, filter); }).sort(function (a, b) { return b.date.localeCompare(a.date); });
  }, [props.detail, filter]);
  return (
    <div className="class-student-profile">
      <div className="class-detail-breadcrumb"><button onClick={props.back}><ArrowLeft size={16} />Danh sách học sinh</button><span>/</span><strong>{props.student.name}</strong></div>
      <header className="card student-profile-head">
        <span className={"student-profile-avatar avatar-" + props.student.tone}>{props.student.initials}</span>
        <div><span>Hồ sơ học sinh</span><h1>{props.student.name}</h1><p>{props.student.code} · {props.detail.classInfo.name} · {props.student.state}</p></div>
        <div><button className="button ghost" onClick={props.editStudent}><Pencil size={16} />Sửa học sinh</button><button className="button primary" onClick={props.openReport}><FileText size={16} />Xuất báo cáo</button></div>
      </header>
      <nav className="class-profile-tabs" aria-label="Hồ sơ học sinh">{tabs.map(function (item) { return <button className={props.tab === item[0] ? "active" : ""} key={item[0]} onClick={function () { props.setTab(item[0]); }}>{item[1]}</button>; })}</nav>
      {props.tab !== "overview" && props.tab !== "attendance" ? <TimeFilterBar value={filter} onChange={setFilter} /> : null}
      {props.tab === "overview" ? (
        <div className="student-overview-grid">
          <article className="card"><span className="blue"><BarChart3 /></span><small>Điểm TB học tập</small><strong>{props.student.hasGrades ? props.student.avg.toFixed(1) : "—"}</strong><em>{props.student.hasGrades ? "Thang điểm 10" : "Chưa có dữ liệu điểm học tập"}</em></article>
          <article className="card"><span className="green"><ClipboardCheck /></span><small>Chuyên cần</small><strong>{props.student.hasAttendance ? props.student.attendance + "%" : "—"}</strong><em>{props.detail.attendance.length ? props.detail.attendance.length + " buổi đã ghi nhận" : "Chưa có dữ liệu điểm danh"}</em></article>
          <article className="card"><span className="orange"><Coins /></span><small>Cộng / trừ hiện tại</small><strong>{props.detail.pointBalance > 0 ? "+" : ""}{props.detail.pointBalance}</strong><em>{props.detail.points.length ? props.detail.points.length + " thay đổi" : "Chưa có lịch sử cộng/trừ điểm"}</em></article>
          <article className="card overview-latest-comment"><span className="purple"><MessageSquare /></span><small>Nhận xét gần nhất</small><strong>{props.detail.comments[0]?.content || "Chưa có nhận xét"}</strong><em>{props.detail.comments[0] ? displayDate(props.detail.comments[0].date) : "Giáo viên chưa thêm nhận xét"}</em></article>
        </div>
      ) : null}
      {props.tab === "grades" ? (
        <section className="card profile-data-card"><header><div><h2>Điểm học tập</h2><p>Điểm số trong sổ điểm của riêng học sinh.</p></div></header>{grades.length ? <div className="table-scroll"><table><thead><tr><th>Ngày</th><th>Loại bài</th><th>Nội dung</th><th>Điểm</th><th>Học kỳ</th></tr></thead><tbody>{grades.map(function (item) { return <tr key={item.id}><td>{displayDate(item.date)}</td><td>{item.category}</td><td><strong>{item.title}</strong></td><td><b className="academic-score">{item.score} / {item.maxScore}</b></td><td>{item.term || "—"}</td></tr>; })}</tbody></table></div> : <div className="class-empty-inline"><BarChart3 /><p>Chưa có dữ liệu điểm học tập</p></div>}</section>
      ) : null}
      {props.tab === "attendance" ? <AttendanceCalendar records={props.detail.attendance} schedule={props.detail.classInfo.schedule} month={month} setMonth={setMonth} /> : null}
      {props.tab === "points" ? (
        <section className="card profile-data-card"><header><div><h2>Lịch sử cộng / trừ điểm</h2><p>Số dư hiện tại: <strong>{props.detail.pointBalance > 0 ? "+" : ""}{props.detail.pointBalance}</strong></p></div></header>{points.length ? <div className="table-scroll"><table><thead><tr><th>Ngày</th><th>Thay đổi</th><th>Lý do / Quy tắc</th><th>Người thực hiện</th></tr></thead><tbody>{points.map(function (item) { return <tr key={item.id}><td>{displayDateTime(item.createdAt)}</td><td><b className={item.delta >= 0 ? "point-change plus" : "point-change minus"}>{item.delta > 0 ? "+" : ""}{item.delta}</b></td><td>{item.reason}</td><td>{item.actor}</td></tr>; })}</tbody></table></div> : <div className="class-empty-inline"><Coins /><p>Chưa có lịch sử cộng/trừ điểm</p></div>}</section>
      ) : null}
      {props.tab === "comments" ? <CommentsPanel studentId={props.detail.student.id} courseId={props.detail.classInfo.key} comments={comments} reload={props.reload} notify={props.notify} /> : null}
      {props.tab === "activity" ? (
        <section className="card student-activity-card"><header><h2>Hoạt động</h2><p>Timeline tổng hợp từ điểm học tập, điểm danh, cộng/trừ và nhận xét.</p></header>{activity.length ? <div className="student-activity-list">{activity.map(function (item) { return <article key={item.key} className={item.type}><time>{displayDate(item.date)}</time><span /><div><strong>{item.title}</strong><p>{item.detail}</p></div></article>; })}</div> : <div className="class-empty-inline"><Clock3 /><p>Chưa có hoạt động trong khoảng thời gian này</p></div>}</section>
      ) : null}
    </div>
  );
}

function reportRange(detail: StudentDetail, filter: TimeFilter): { from: string; to: string } {
  const selected = rangeFor(filter);
  if (selected) return selected;
  const dates = ([] as string[]).concat(detail.grades.map(function (item) { return item.date; }), detail.attendance.map(function (item) { return item.date; }), detail.points.map(function (item) { return item.date; }), detail.comments.map(function (item) { return item.date; }), (detail.sessions || []).map(function(item) { return item.sessionDate; })).filter(function (item) { return /^\d{4}-\d{2}-\d{2}$/.test(item); }).sort();
  return { from: dates[0] || appToday(), to: dates[dates.length - 1] || appToday() };
}

async function printStudentReport(detail: StudentDetail, filter: TimeFilter, options: ReportOptions, notify: (message: string) => void) {
  const popup = window.open("", "_blank");
  if (!popup) { notify("Trình duyệt đang chặn cửa sổ xuất PDF."); return; }
  popup.opener = null;
  popup.document.write('<!doctype html><html lang="vi"><body style="font-family:Arial,sans-serif;padding:24px">Đang chuẩn bị báo cáo...</body></html>');
  let paymentQr: { configured: boolean; bankName: string; accountName: string; accountNumber: string; imageUrl: string } | null = null;
  try { const response = await fetch("/api/settings/payment-qr?meta=1", { cache: "no-store" }); if (response.ok) paymentQr = await response.json(); } catch {}
  const range = reportRange(detail, filter);
  const grades = detail.grades.filter(function (item) { return isInRange(item.date, filter); });
  const attendance = detail.attendance.filter(function (item) { return isInRange(item.date, filter); });
  const points = detail.points.filter(function (item) { return isInRange(item.date, filter); });
  const comments = detail.comments.filter(function (item) { return isInRange(item.date, filter); });
  const makeupSessions = (detail.sessions || []).filter(function(item) { return item.sessionType === "makeup" && isInRange(item.sessionDate, filter); });
  const stylesheetLinks = Array.from(document.querySelectorAll<HTMLLinkElement>('link[rel="stylesheet"]')).map(function (link) { return '<link rel="stylesheet" href="' + escapeHtml(link.href) + '">'; }).join("");
  function calendarHtml(month: string) {
    const cells = monthCells(month);
    return '<section class="report-section report-calendar"><h2>Điểm danh — ' + escapeHtml(monthLabel(month)) + '</h2><div class="pdf-calendar"><div class="pdf-week">' + ["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map(function (day) { return "<b>" + day + "</b>"; }).join("") + '</div><div class="pdf-days">' + cells.map(function (cell) {
      if (!cell) return '<span class="blank"></span>';
      const status = statusForDate(cell.date, attendance, detail.classInfo.schedule);
      const meta = attendanceMeta[status] || attendanceMeta.unmarked;
      const record = attendance.find(function (item) { return item.date === cell.date; });
      return '<span class="' + meta.className + '"><i>' + cell.day + '</i><strong>' + meta.short + '</strong><small>' + (record?.arrivalTime ? escapeHtml(record.arrivalTime) : escapeHtml(meta.label)) + '</small></span>';
    }).join("") + '</div></div><div class="pdf-legend">' + ["present", "late", "allowed", "absent", "none", "unmarked"].map(function (status) { const meta = attendanceMeta[status]; return '<span class="' + meta.className + '"><b>' + meta.short + '</b> ' + escapeHtml(meta.label) + '</span>'; }).join("") + '</div></section>';
  }
  const months: string[] = [];
  let cursor = range.from.slice(0, 7);
  const last = range.to.slice(0, 7);
  while (cursor <= last) { months.push(cursor); cursor = changeMonth(cursor, 1); }
  const finalizedAttendance = attendance.filter(function (item) { return item.status === "present" || item.status === "late" || item.status === "allowed" || item.status === "absent"; });
  const attendedSessions = finalizedAttendance.filter(function (item) { return item.status === "present" || item.status === "late"; }).length;
  const totalSessions = finalizedAttendance.length;
  const makeupSection = '<section class="report-section report-makeup"><h2>Buổi học bù</h2>' + (makeupSessions.length ? '<table><thead><tr><th>Ngày</th><th>Giờ</th><th>Ghi chú</th></tr></thead><tbody>' + makeupSessions.map(function(item) { return '<tr><td><strong>Học bù ' + escapeHtml(displayDate(item.sessionDate)) + '</strong></td><td>' + escapeHtml(item.startTime) + ' - ' + escapeHtml(item.endTime) + '</td><td>' + escapeHtml(item.note || "Không có ghi chú") + '</td></tr>'; }).join("") + '</tbody></table>' : '<p class="empty">Không có buổi học bù trong khoảng báo cáo.</p>') + '</section>';
  const headerQr = paymentQr?.configured ? '<aside class="pdf-head-qr"><img src="' + escapeHtml(paymentQr.imageUrl) + '" alt="QR ngân hàng"><small>QR thanh toán</small></aside>' : '';
  const body = (options.overview ? '<section class="report-summary"><div><small>Điểm TB học tập</small><strong>' + (grades.length ? (grades.reduce(function (sum, item) { return sum + item.score / item.maxScore * 10; }, 0) / grades.length).toFixed(1) : '—') + '</strong></div><div><small>Số buổi học</small><strong>' + (totalSessions ? attendedSessions + ' / ' + totalSessions : '—') + '</strong></div><div><small>Cộng / trừ hiện tại</small><strong>' + (detail.pointBalance > 0 ? '+' : '') + detail.pointBalance + '</strong></div></section>' : '') +
    (options.grades ? '<section class="report-section"><h2>Điểm học tập</h2>' + (grades.length ? '<table><thead><tr><th>Ngày</th><th>Nội dung</th><th>Loại bài</th><th>Điểm</th></tr></thead><tbody>' + grades.map(function (item) { return '<tr><td>' + escapeHtml(displayDate(item.date)) + '</td><td>' + escapeHtml(item.title) + '</td><td>' + escapeHtml(item.category) + '</td><td><strong>' + item.score + ' / ' + item.maxScore + '</strong></td></tr>'; }).join("") + '</tbody></table>' : '<p class="empty">Chưa có dữ liệu điểm học tập</p>') + '</section>' : '') +
    (options.attendance ? months.map(calendarHtml).join("") : '') +
    makeupSection +
    (options.points ? '<section class="report-section"><h2>Lịch sử cộng / trừ điểm</h2>' + (points.length ? '<table><thead><tr><th>Ngày</th><th>Thay đổi</th><th>Quy tắc / Lý do</th><th>Người thực hiện</th></tr></thead><tbody>' + points.map(function (item) { return '<tr><td>' + escapeHtml(displayDateTime(item.createdAt)) + '</td><td><strong class="' + (item.delta >= 0 ? 'plus' : 'minus') + '">' + (item.delta > 0 ? '+' : '') + item.delta + '</strong></td><td>' + escapeHtml(item.reason) + '</td><td>' + escapeHtml(item.actor) + '</td></tr>'; }).join("") + '</tbody></table>' : '<p class="empty">Chưa có lịch sử cộng/trừ điểm</p>') + '</section>' : '') +
    (options.comments ? '<section class="report-section"><h2>Nhận xét giáo viên</h2>' + (comments.length ? '<div class="pdf-comments">' + comments.map(function (item) { return '<article><strong>' + escapeHtml(displayDate(item.date)) + '</strong><p>' + escapeHtml(item.content) + '</p><small>' + escapeHtml(item.creator) + ' - ' + escapeHtml(item.type) + '</small></article>'; }).join("") + '</div>' : '<p class="empty">Chưa có nhận xét</p>') + '</section>' : '');
  popup.document.open();
  popup.document.write('<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>PHMT MATH - Báo cáo ' + escapeHtml(detail.student.name) + '</title>' + stylesheetLinks + '<style>@page{size:A4 portrait;margin:13mm}*{box-sizing:border-box}body{font-family:"Be Vietnam Pro",Arial,sans-serif;color:#18213a;font-size:10px;line-height:1.5;margin:0}header.pdf-head{position:relative;border-bottom:3px solid #5b5ce2;padding:0 0 12px;margin-bottom:15px;min-height:104px}header.pdf-head.has-qr{padding-right:112px}header.pdf-head>strong{color:#5b5ce2;font-size:14px}h1{font-size:20px;margin:4px 0 10px}h2{font-size:13px;margin:0 0 9px;color:#30365d}.student-meta{display:grid;grid-template-columns:1fr 1fr;gap:3px 20px}.student-meta p{margin:0}.pdf-head-qr{position:absolute;top:0;right:0;width:96px;text-align:center}.pdf-head-qr img{display:block;width:90px;height:90px;margin-left:auto;object-fit:contain;border:1px solid #dfe2ef;border-radius:8px;background:#fff;padding:3px}.pdf-head-qr small{display:block;margin-top:3px;color:#667085;font-size:7px}.report-summary{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;margin:14px 0}.report-summary div{border:1px solid #dfe2ef;border-radius:8px;padding:9px}.report-summary small{display:block;color:#667085}.report-summary strong{font-size:18px}.report-section{margin:16px 0;break-inside:avoid}.report-makeup{margin-top:10px}.report-section table{width:100%;border-collapse:collapse}.report-section th,.report-section td{border:1px solid #dfe2ef;padding:6px;text-align:left;vertical-align:top}.report-section th{background:#f1f2ff;color:#41466f}.plus{color:#16845a}.minus{color:#cf4050}.pdf-calendar{border:1px solid #dfe2ef;border-radius:8px;overflow:hidden}.pdf-week,.pdf-days{display:grid;grid-template-columns:repeat(7,1fr)}.pdf-week b{padding:5px;text-align:center;background:#f1f2ff;border-right:1px solid #dfe2ef}.pdf-days>span{min-height:53px;padding:5px;border-top:1px solid #dfe2ef;border-right:1px solid #dfe2ef;display:grid;grid-template-columns:1fr auto;align-content:start;gap:2px}.pdf-days i{font-style:normal}.pdf-days strong{font-size:14px}.pdf-days small{grid-column:1/-1;font-size:7px}.pdf-days .present{background:#e9f8f1;color:#126e4c}.pdf-days .late{background:#fff3df;color:#925b08}.pdf-days .allowed{background:#eaf3ff;color:#2e65a5}.pdf-days .absent{background:#ffedef;color:#ad2f3e}.pdf-days .none{background:#f4f5f8;color:#73788a}.pdf-days .unmarked{background:#f5f2ff;color:#6757a8}.pdf-legend{display:flex;flex-wrap:wrap;gap:7px 13px;margin-top:6px;font-size:8px}.pdf-comments article{border-left:3px solid #5b5ce2;padding:4px 9px;margin:8px 0}.pdf-comments p{margin:3px 0}.pdf-comments small,.empty{color:#667085}footer.pdf-footer{margin-top:18px;border-top:1px solid #dfe2ef;padding-top:7px;color:#667085;font-size:8px}@media print{.report-section{break-inside:avoid}.report-calendar{break-before:auto}}</style></head><body><header class="pdf-head' + (paymentQr?.configured ? ' has-qr' : '') + '"><strong>PHMT MATH</strong><h1>BÁO CÁO HỌC TẬP HỌC SINH</h1><div class="student-meta"><p><b>Học sinh:</b> ' + escapeHtml(detail.student.name) + '</p><p><b>Lớp / môn:</b> ' + escapeHtml(detail.classInfo.name) + '</p><p><b>Giáo viên:</b> ' + escapeHtml(detail.classInfo.teacher) + '</p><p><b>Thời gian:</b> ' + escapeHtml(displayDate(range.from)) + ' - ' + escapeHtml(displayDate(range.to)) + '</p></div>' + headerQr + '</header>' + body + '<footer class="pdf-footer">Ngày xuất báo cáo: ' + escapeHtml(new Date().toLocaleString("vi-VN", { timeZone: APP_TIME_ZONE })) + '</footer><script>window.onload=function(){setTimeout(function(){window.print()},500)}<\/script></body></html>');
  popup.document.close();
  notify("Đã mở bản in — chọn “Lưu dưới dạng PDF”");
}

function ReportModal(props: { student: ClassHubStudent; detail: StudentDetail; close: () => void; notify: (text: string) => void }) {
  const [filter, setFilter] = useState<TimeFilter>({ preset: "month", from: "", to: "" });
  const [options, setOptions] = useState<ReportOptions>({ overview: true, grades: true, attendance: true, points: true, comments: true });
  const labels: Array<[keyof ReportOptions, string]> = [["overview", "Tổng quan học sinh"], ["grades", "Bảng điểm"], ["attendance", "Điểm danh dạng lịch"], ["points", "Lịch sử cộng/trừ điểm"], ["comments", "Nhận xét giáo viên"]];
  const close = props.close;
  useEffect(function () {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    function closeOnEscape(event: KeyboardEvent) {
      if (event.key === "Escape") close();
    }
    document.addEventListener("keydown", closeOnEscape);
    return function () {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [close]);

  return createPortal(
    <div className="modal report-modal-overlay" onMouseDown={props.close}>
      <section className="form-modal student-report-modal" role="dialog" aria-modal="true" aria-labelledby="student-report-title" onMouseDown={function (event) { event.stopPropagation(); }}>
        <div className="modal-head"><div><h2 id="student-report-title">Xuất báo cáo — {props.student.name}</h2><p>Chọn thời gian và nội dung trước khi tạo bản PDF.</p></div><button className="modal-close" aria-label="Đóng cửa sổ xuất báo cáo" onClick={props.close}><X size={19} /></button></div>
        <div className="report-modal-body">
          <div className="report-modal-section"><strong>Khoảng thời gian</strong><TimeFilterBar value={filter} onChange={setFilter} /></div>
          <div className="report-modal-section"><strong>Nội dung báo cáo</strong><div className="report-option-grid">{labels.map(function (item) { return <label key={item[0]}><input type="checkbox" checked={options[item[0]]} onChange={function (event) { setOptions({ ...options, [item[0]]: event.target.checked }); }} /><span><Check size={15} /></span>{item[1]}</label>; })}</div></div>
          <div className="report-note"><FileText size={18} /><p>Điểm danh sẽ được trình bày thành lịch riêng cho từng tháng, kết hợp màu và ký hiệu để vẫn đọc rõ khi in đen trắng.</p></div>
        </div>
        <div className="modal-footer"><button className="button ghost" onClick={props.close}>Hủy</button><button className="button primary" disabled={!Object.values(options).some(Boolean)} onClick={function () { void printStudentReport(props.detail, filter, options, props.notify); }}><FileText size={16} />Tạo bản PDF</button></div>
      </section>
    </div>,
    document.body,
  );
}

export function ClassHubView(props: {
  records: ClassHubClass[];
  students: ClassHubStudent[];
  rewardStudents: Array<{ id: number; points: number }>;
  navigationTarget?: { classId: string; studentId: number; requestId: number } | null;
  admin: boolean;
  onAdd: () => void;
  onEdit: (item: ClassHubClass) => void;
  onEditStudent: (student: ClassHubStudent) => void;
  onCreateStudent: (course: ClassHubClass) => void;
  onDelete: (item: ClassHubClass) => void;
  onRefresh: () => Promise<void>;
  notify: (text: string) => void;
}) {
  const navigationClass = props.navigationTarget
    ? props.records.find(function (item) {
        return classIdentity(item) === props.navigationTarget?.classId;
      })
    : null;
  const navigationStudent = navigationClass
    ? props.students.find(function (student) {
        return (
          student.id === props.navigationTarget?.studentId &&
          studentInCourse(student, navigationClass)
        );
      })
    : null;
  const [selectedClassIdentity, setSelectedClassIdentity] = useState(
    navigationClass ? classIdentity(navigationClass) : "",
  );
  const [summary, setSummary] = useState<ClassSummary>({ points: {}, latestComments: {} });
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [summaryError, setSummaryError] = useState("");
  const [selectedStudent, setSelectedStudent] = useState<ClassHubStudent | null>(navigationStudent || null);
  const [detail, setDetail] = useState<StudentDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(Boolean(navigationStudent));
  const [detailError, setDetailError] = useState("");
  const [detailTab, setDetailTab] = useState<DetailTab>("overview");
  const [reportOpen, setReportOpen] = useState(false);
  const [enrollmentOpen, setEnrollmentOpen] = useState(false);
  const activeClass = props.records.find(function (item) { return classIdentity(item) === selectedClassIdentity; }) || null;
  const classStudents = activeClass ? props.students.filter(function (student) { return studentInCourse(student, activeClass); }) : [];
  async function loadSummary(item: ClassHubClass) {
    setSummaryLoading(true); setSummaryError("");
    try {
      const response = await fetch("/api/class-dashboard?className=" + encodeURIComponent(item.name) + "&classKey=" + encodeURIComponent(item.key || ""), { cache: "no-store" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Không thể tải dữ liệu lớp.");
      setSummary(payload as ClassSummary);
    } catch (error) { setSummaryError(error instanceof Error ? error.message : "Không thể tải dữ liệu. Vui lòng thử lại."); }
    finally { setSummaryLoading(false); }
  }
  async function loadDetail(student: ClassHubStudent, force = false) {
    if (!student.id) { setDetailError("Học sinh chưa có ID hợp lệ."); return; }
    if (!force && detail?.student.id === student.id) return;
    setDetailLoading(true); setDetailError(""); setDetail(null);
    try {
      const response = await fetch("/api/student-records/" + student.id + "?courseId=" + encodeURIComponent(activeClass?.key || ""), { cache: "no-store" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Không thể tải dữ liệu. Vui lòng thử lại.");
      setDetail(payload as StudentDetail);
    } catch (error) { setDetailError(error instanceof Error ? error.message : "Không thể tải dữ liệu. Vui lòng thử lại."); }
    finally { setDetailLoading(false); }
  }
  function openClass(item: ClassHubClass) {
    setSelectedClassIdentity(classIdentity(item)); setSelectedStudent(null); setDetail(null); setReportOpen(false); setSummary({ points: {}, latestComments: {} });
    void loadSummary(item); window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function openStudent(student: ClassHubStudent, tab: DetailTab) {
    setSelectedStudent(student); setDetailTab(tab); setReportOpen(false); void loadDetail(student); window.scrollTo({ top: 0, behavior: "smooth" });
  }
  async function openReport(student: ClassHubStudent) {
    setSelectedStudent(student); setReportOpen(true); await loadDetail(student); window.scrollTo({ top: 0, behavior: "smooth" });
  }
  async function removeFromClass(student: ClassHubStudent) {
    if (!student.id || !activeClass?.key || !window.confirm("Xóa " + student.name + " khỏi lớp " + activeClass.name + "? Tài khoản học sinh vẫn được giữ nguyên.")) return;
    const response = await fetch("/api/enrollments", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ studentId: student.id, classKey: activeClass.key }) });
    const payload = await response.json();
    if (!response.ok) { props.notify(payload.error || "Không thể xóa học sinh khỏi lớp."); return; }
    await props.onRefresh();
    props.notify("Đã xóa học sinh khỏi lớp, tài khoản vẫn còn hoạt động");
  }
  useEffect(function () {
    if (!navigationClass || !navigationStudent) return;
    const timer = window.setTimeout(function () {
      void loadSummary(navigationClass);
      void loadDetail(navigationStudent, true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 0);
    return function () {
      window.clearTimeout(timer);
    };
    // Search targets are immutable for this mount; the parent changes the key per request.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (!activeClass) return (
    <>
      <div className="page-title"><div><h1>Lớp học</h1><p>Trung tâm quản lý thông tin lớp và hồ sơ chi tiết từng học sinh.</p></div><div className="page-actions"><button className="button primary" onClick={props.onAdd}><Plus size={17} />Tạo lớp mới</button></div></div>
      <div className={props.admin ? "admin-strip active" : "admin-strip"}><Users size={17} /><span>{props.admin ? "Chọn một lớp để xem danh sách và hồ sơ học sinh." : "Đăng nhập Admin để quản lý lớp học."}</span></div>
      <div className="class-grid class-hub-grid">{props.records.map(function (item) { return <article className="card class-card class-hub-card" key={item.id || item.key || item.name}><button className="class-card-open" onClick={function () { openClass(item); }}><div className={"class-cover " + item.tone}>{item.logoUrl ? <img src={item.logoUrl} alt={"Logo " + item.name} /> : <BookOpen size={25} />}<b>{classLabel(item)}</b></div><div className="class-body"><h2>{item.name}</h2><p><Users size={15} />{item.studentCount} học sinh · GV {item.teacher}</p><p><CalendarDays size={15} />{classScheduleSummary(item)}</p><p><GraduationCap size={15} />{item.room || "Chưa xếp phòng"}</p><span className="class-open-hint">Mở chi tiết lớp <ChevronRight size={15} /></span></div></button><footer className="card-admin-actions"><button className="button soft" onClick={function () { props.onEdit(item); }}><Pencil size={15} />Chỉnh sửa</button>{props.admin ? <button className="icon-button delete" title="Xóa lớp" onClick={function () { props.onDelete(item); }}><Trash2 size={16} /></button> : null}</footer></article>; })}</div>
      {!props.records.length ? <div className="card empty-state"><Users size={28} /><h2>Chưa có lớp học</h2><p>Chọn “Tạo lớp mới” để bắt đầu.</p></div> : null}
    </>
  );
  if (selectedStudent) {
    if (detailLoading) return <div className="class-detail-loading"><span className="class-loading-avatar" /><div><b>Đang tải hồ sơ {selectedStudent.name}...</b><small>Điểm, điểm danh, cộng/trừ và nhận xét đang được tải riêng.</small></div></div>;
    if (detailError || !detail) return <div className="card class-error-state"><AlertTriangle /><h2>Không thể tải dữ liệu</h2><p>{detailError || "Vui lòng thử lại."}</p><div><button className="button ghost" onClick={function () { setSelectedStudent(null); }}><ArrowLeft size={16} />Quay lại lớp</button><button className="button primary" onClick={function () { void loadDetail(selectedStudent, true); }}><RefreshCw size={16} />Thử lại</button></div></div>;
    return <><StudentProfile student={selectedStudent} detail={detail} tab={detailTab} setTab={setDetailTab} back={function () { setSelectedStudent(null); setReportOpen(false); }} editStudent={function () { props.onEditStudent(selectedStudent); }} openReport={function () { setReportOpen(true); }} reload={async function () { await loadDetail(selectedStudent, true); await loadSummary(activeClass); }} notify={props.notify} />{reportOpen ? <ReportModal student={selectedStudent} detail={detail} close={function () { setReportOpen(false); }} notify={props.notify} /> : null}</>;
  }
  return (
    <div className="class-detail-page">
      <div className="class-detail-breadcrumb"><button onClick={function () { setSelectedClassIdentity(""); }}><ArrowLeft size={16} />Danh sách lớp</button><span>/</span><strong>{activeClass.name}</strong></div>
      <header className="card class-detail-head"><div className={"class-detail-logo " + activeClass.tone}>{activeClass.logoUrl ? <img src={activeClass.logoUrl} alt={"Logo " + activeClass.name} /> : <BookOpen />}</div><div className="class-detail-title"><span className="class-label-pill">{classLabel(activeClass)}</span><h1>{activeClass.name}</h1><p>GV {activeClass.teacher} · {activeClass.room || "Chưa xếp phòng"} · {classScheduleSummary(activeClass)}</p><strong><Users size={16} />{classStudents.length} học sinh</strong></div><div className="class-detail-actions"><button className="button primary" onClick={function() { setEnrollmentOpen(true); }}><Plus size={16} />Thêm học sinh</button><button className="button ghost" onClick={function () { props.onEdit(activeClass); }}><Pencil size={16} />Chỉnh sửa lớp</button></div></header>
      {summaryError ? <div className="class-inline-error"><AlertTriangle size={17} /><span>{summaryError}</span><button onClick={function () { void loadSummary(activeClass); }}>Thử lại</button></div> : null}
      <section className="card class-roster-card"><header><div><h2>Danh sách học sinh</h2><p>Click vào tên hoặc từng chỉ số để mở đúng phần chi tiết.</p></div><span>{classStudents.length} học sinh</span></header>{classStudents.length ? <div className="table-scroll"><table className="class-student-table"><thead><tr><th>STT</th><th>Học sinh</th><th>Điểm TB</th><th>Chuyên cần</th><th>Cộng / trừ điểm</th><th>Nhận xét mới nhất</th><th>Báo cáo</th><th>Thao tác</th></tr></thead><tbody>{classStudents.map(function (student, index) { const rewardPoint = props.rewardStudents.find(function (item) { return item.id === student.id; })?.points; const points = student.id ? summary.points[String(student.id)] ?? rewardPoint ?? 0 : 0; const comment = student.id ? summary.latestComments[String(student.id)] : undefined; return <tr key={student.code}><td data-label="STT">{index + 1}</td><td data-label="Học sinh"><button className="student-cell-button" onClick={function () { openStudent(student, "overview"); }}><span className={"mini-avatar avatar-" + student.tone}>{student.initials}</span><span><strong>{student.name}</strong><small>{student.code}</small></span><ChevronRight size={15} /></button></td><td data-label="Điểm TB"><button className="metric-link academic" onClick={function () { openStudent(student, "grades"); }}>{student.hasGrades ? student.avg.toFixed(1) : "—"}<ChevronRight size={14} /></button></td><td data-label="Chuyên cần"><button className="metric-link attendance" onClick={function () { openStudent(student, "attendance"); }}>{student.hasAttendance ? student.attendance + "%" : "—"}<ChevronRight size={14} /></button></td><td data-label="Cộng / trừ"><button className={"metric-link points " + (points < 0 ? "negative" : "")} onClick={function () { openStudent(student, "points"); }}>{points > 0 ? "+" : ""}{points}<ChevronRight size={14} /></button></td><td data-label="Nhận xét"><button className="latest-comment-link" onClick={function () { openStudent(student, "comments"); }}>{summaryLoading ? <span className="comment-loading" /> : comment ? <><strong>{comment.content}</strong><small>{displayDate(comment.date)}</small></> : <em>Chưa có nhận xét</em>}<ChevronRight size={14} /></button></td><td data-label="Báo cáo"><button className="button soft report-row-button" onClick={function () { void openReport(student); }}><FileText size={15} />Xuất báo cáo</button></td><td data-label="Thao tác"><button className="icon-button delete" title="Xóa khỏi lớp" onClick={function() { void removeFromClass(student); }}><Trash2 size={15} /></button></td></tr>; })}</tbody></table></div> : <div className="class-empty-inline"><UserRound size={26} /><h3>Lớp này chưa có học sinh</h3><p>Chọn “Thêm học sinh” để xếp tài khoản có sẵn vào lớp.</p></div>}</section>
      {enrollmentOpen ? <EnrollmentModal course={activeClass} students={props.students} close={function() { setEnrollmentOpen(false); }} refresh={props.onRefresh} createStudent={function() { setEnrollmentOpen(false); props.onCreateStudent(activeClass); }} notify={props.notify} /> : null}
    </div>
  );
}
