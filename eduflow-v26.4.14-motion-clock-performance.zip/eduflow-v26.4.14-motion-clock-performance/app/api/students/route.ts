import { and, desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { appState, studentEnrollments, students } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";
import { fallbackClassKey, resolveCourse } from "../../../lib/course-access";

function isUnassignedClassName(value: unknown): boolean {
  const name = String(value || "").trim().toLocaleLowerCase("vi");
  return !name || name === "chưa xếp lớp" || name === "chua xep lop";
}


async function resolveRequestedEnrollments(
  db: Awaited<ReturnType<typeof getDb>>,
  payload: Record<string, unknown>,
): Promise<{ classKey: string; className: string }[]> {
  const requested = Array.isArray(payload.classEnrollments)
    ? payload.classEnrollments
        .map(function(item) {
          const row = item && typeof item === "object" ? item as Record<string, unknown> : {};
          return { classKey: String(row.classKey || "").trim(), className: String(row.className || "").trim() };
        })
        .filter(function(item) { return item.classKey || item.className; })
    : Array.isArray(payload.classKeys)
      ? payload.classKeys.map(function(classKey) { return { classKey: String(classKey || "").trim(), className: "" }; }).filter(function(item) { return item.classKey; })
      : [];
  if (!requested.length) {
    const className = String(payload.className || "").trim();
    const classKey = String(payload.classKey || "").trim();
    if (!isUnassignedClassName(className) || classKey) requested.push({ classKey, className });
  }
  const resolved: { classKey: string; className: string }[] = [];
  for (const item of requested) {
    const course = await resolveCourse(db, { classKey: item.classKey, className: item.className });
    if (!course) continue;
    if (resolved.some(function(existing) { return existing.classKey === course.key; })) continue;
    resolved.push({ classKey: course.key, className: course.name });
  }
  return resolved;
}

const sampleStudents = [
  ["HS24001", "Nguyễn Minh Anh", "Toán 12A1", 8.7, 96, "Đang học"],
  ["HS24002", "Trần Gia Huy", "Toán 12A1", 9.1, 98, "Đang học"],
  ["HS24003", "Lê Khánh Linh", "Toán 11A2", 7.6, 91, "Đang học"],
  ["HS24004", "Phạm Hoàng Nam", "Toán 12A1", 5.4, 76, "Cần chú ý"],
  ["HS24005", "Võ Ngọc Anh", "Toán 10A3", 8.2, 94, "Đang học"],
  ["HS24006", "Đỗ Thu Hà", "Toán 11A2", 6.8, 88, "Đang học"]
] as const;

async function seedOnce() {
  const db = await getDb();
  const seeded = await db.select({ key: appState.key }).from(appState).where(eq(appState.key, "initial_students_seeded")).limit(1);
  if (seeded.length) return;
  const existing = await db.select({ id: students.id }).from(students).limit(1);
  if (!existing.length) {
    const now = new Date().toISOString();
    await db.insert(students).values(sampleStudents.map(function(row) {
      return {
        code: row[0], name: row[1], className: row[2], averageScore: row[3],
        attendanceRate: row[4], status: row[5], createdAt: now
      };
    })).onConflictDoNothing();
  }
  const rows = await db.select().from(students);
  for (const student of rows) {
    if (isUnassignedClassName(student.className)) continue;
    const course = await resolveCourse(db, { className: student.className });
    const now = new Date().toISOString();
    await db.insert(studentEnrollments).values({
      studentId: student.id,
      classKey: course?.key || fallbackClassKey(student.className),
      className: student.className,
      status: "active",
      enrolledAt: student.createdAt || now,
      createdAt: student.createdAt || now,
      updatedAt: now,
    }).onConflictDoNothing();
  }
  await db.insert(appState).values({ key: "initial_students_seeded", value: new Date().toISOString() }).onConflictDoNothing();
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    await seedOnce();
    const db = await getDb();
    const [rows, enrollmentRows] = await Promise.all([
      db.select().from(students).orderBy(desc(students.id)),
      db.select().from(studentEnrollments).where(eq(studentEnrollments.status, "active")),
    ]);
    const byStudent = new Map<number, typeof enrollmentRows>();
    enrollmentRows.forEach(function(enrollment) {
      const list = byStudent.get(enrollment.studentId) || [];
      list.push(enrollment);
      byStudent.set(enrollment.studentId, list);
    });
    return Response.json({ students: rows.map(function(student) {
      const enrollments = (byStudent.get(student.id) || []).filter(function(item) { return !isUnassignedClassName(item.className); });
      return {
        ...student,
        enrollments: enrollments.map(function(item) { return { id: item.id, classKey: item.classKey, className: item.className, status: item.status }; }),
        classKeys: enrollments.map(function(item) { return item.classKey; }),
        classNames: enrollments.map(function(item) { return item.className; }),
      };
    }) }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Không thể tải danh sách học sinh." }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as { students?: Record<string, unknown>[] };
  if (!Array.isArray(payload.students) || !payload.students.length) {
    return Response.json({ error: "Tệp Excel không có dữ liệu học sinh hợp lệ." }, { status: 400 });
  }
  if (payload.students.length > 1000) {
    return Response.json({ error: "Mỗi lần chỉ nhập tối đa 1.000 học sinh." }, { status: 400 });
  }
  try {
    const db = await getDb();
    let imported = 0;
    for (const row of payload.students) {
      const code = String(row.code || "").trim().toUpperCase();
      const name = String(row.name || "").trim();
      const className = String(row.className || "").trim();
      if (!code || !name) continue;
      const values = {
        code, name, className: className || "Chưa xếp lớp",
        averageScore: 0,
        attendanceRate: 0,
        status: String(row.status || "Đang học"),
        phone: String(row.phone || ""),
        email: String(row.email || ""),
        createdAt: new Date().toISOString()
      };
      await db.insert(students).values(values).onConflictDoUpdate({
        target: students.code,
        set: {
          name: values.name, className: values.className, averageScore: values.averageScore,
          attendanceRate: values.attendanceRate, status: values.status,
          phone: values.phone, email: values.email
        }
      });
      if (!isUnassignedClassName(className)) {
        const stored = await db.select({ id: students.id }).from(students).where(eq(students.code, code)).limit(1);
        const course = await resolveCourse(db, { className });
        if (stored[0]) await db.insert(studentEnrollments).values({
          studentId: stored[0].id,
          classKey: course?.key || fallbackClassKey(className),
          className,
          status: "active",
          enrolledAt: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }).onConflictDoUpdate({
          target: [studentEnrollments.studentId, studentEnrollments.classKey],
          set: { className, status: "active", updatedAt: new Date().toISOString() },
        });
      }
      imported += 1;
    }
    if (!imported) return Response.json({ error: "Không tìm thấy dòng hợp lệ. Cần có Mã học sinh, Họ tên và Lớp." }, { status: 400 });
    return Response.json({ success: true, imported });
  } catch {
    return Response.json({ error: "Không thể nhập dữ liệu Excel." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as Record<string, unknown>;
  const name = String(payload.name || "").trim();
  const code = String(payload.code || "").trim().toUpperCase();
  if (!name || !code) {
    return Response.json({ error: "Vui lòng nhập họ tên và mã học sinh." }, { status: 400 });
  }
  try {
    const db = await getDb();
    const enrollments = await resolveRequestedEnrollments(db, payload);
    const primaryClassName = enrollments[0]?.className || "Chưa xếp lớp";
    const now = new Date().toISOString();
    const result = await db.insert(students).values({
      name, code, className: primaryClassName,
      averageScore: Number(payload.averageScore) || 0,
      attendanceRate: Number(payload.attendanceRate) || 0,
      status: String(payload.status || "Đang học"),
      phone: String(payload.phone || ""),
      email: String(payload.email || ""),
      createdAt: now
    }).returning();
    for (const enrollment of enrollments) {
      await db.insert(studentEnrollments).values({
        studentId: result[0].id,
        classKey: enrollment.classKey,
        className: enrollment.className,
        status: "active",
        enrolledAt: now,
        createdAt: now,
        updatedAt: now,
      }).onConflictDoUpdate({
        target: [studentEnrollments.studentId, studentEnrollments.classKey],
        set: { className: enrollment.className, status: "active", updatedAt: now },
      });
    }
    return Response.json({ student: result[0], enrollments }, { status: 201 });
  } catch {
    return Response.json({ error: "Mã học sinh đã tồn tại hoặc dữ liệu chưa hợp lệ." }, { status: 409 });
  }
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as Record<string, unknown>;
  const id = Number(payload.id);
  if (!id) return Response.json({ error: "Thiếu học sinh cần sửa." }, { status: 400 });
  try {
    const db = await getDb();
    const desiredEnrollments = await resolveRequestedEnrollments(db, payload);
    const primaryClassName = desiredEnrollments[0]?.className || "Chưa xếp lớp";
    const result = await db.update(students).set({
      name: String(payload.name || "").trim(),
      code: String(payload.code || "").trim().toUpperCase(),
      className: primaryClassName,
      averageScore: Number(payload.averageScore) || 0,
      attendanceRate: Number(payload.attendanceRate) || 0,
      status: String(payload.status || "Đang học"),
      phone: String(payload.phone || ""),
      email: String(payload.email || "")
    }).where(eq(students.id, id)).returning();
    if (!result.length) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });

    const currentRows = await db.select().from(studentEnrollments).where(eq(studentEnrollments.studentId, id));
    const desiredByKey = new Map(desiredEnrollments.map(function(item) { return [item.classKey, item]; }));
    const currentActiveByKey = new Map(currentRows.filter(function(item) { return item.status === "active"; }).map(function(item) { return [item.classKey, item]; }));
    for (const current of currentRows) {
      if (isUnassignedClassName(current.className) || (current.status === "active" && !desiredByKey.has(current.classKey))) {
        await db.delete(studentEnrollments).where(eq(studentEnrollments.id, current.id));
      }
    }
    const now = new Date().toISOString();
    for (const enrollment of desiredEnrollments) {
      const existing = currentActiveByKey.get(enrollment.classKey);
      if (existing && existing.className === enrollment.className) continue;
      await db.insert(studentEnrollments).values({
        studentId: id,
        classKey: enrollment.classKey,
        className: enrollment.className,
        status: "active",
        enrolledAt: existing?.enrolledAt || now,
        createdAt: existing?.createdAt || now,
        updatedAt: now,
      }).onConflictDoUpdate({
        target: [studentEnrollments.studentId, studentEnrollments.classKey],
        set: { className: enrollment.className, status: "active", updatedAt: now },
      });
    }
    return Response.json({ student: result[0], enrollments: desiredEnrollments });
  } catch {
    return Response.json({ error: "Không thể cập nhật học sinh. Vui lòng kiểm tra mã học sinh và lớp học." }, { status: 409 });
  }
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as { id?: number; all?: boolean };
  const db = await getDb();
  if (payload.all) {
    await db.delete(students);
    return Response.json({ success: true });
  }
  if (!payload.id) return Response.json({ error: "Thiếu học sinh cần xóa." }, { status: 400 });
  await db.delete(students).where(eq(students.id, payload.id));
  return Response.json({ success: true });
}
