import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems } from "../../../../db/schema";
import { requireAdmin } from "../../../../lib/admin-auth";

const SETTINGS_KEY = "payment-qr";
type StoredObject = { body: BodyInit; httpMetadata?: { contentType?: string } };
type FileBucket = {
  get(key: string): Promise<StoredObject | null>;
  put(key: string, value: ArrayBuffer, options?: { httpMetadata?: { contentType?: string } }): Promise<unknown>;
  delete(key: string): Promise<void>;
};

async function bucket(): Promise<FileBucket> {
  const { env } = await import("cloudflare:workers");
  const value = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!value) throw new Error("Kho ảnh chưa được cấu hình.");
  return value;
}

function decode(value: string): Record<string, unknown> {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.kind, "settings"), eq(adminItems.itemKey, SETTINGS_KEY))).limit(1);
  const data = rows[0] ? decode(rows[0].data) : {};
  if (new URL(request.url).searchParams.get("meta") === "1") {
    return Response.json({ configured: Boolean(data.objectKey), bankName: String(data.bankName || ""), accountName: String(data.accountName || ""), accountNumber: String(data.accountNumber || ""), imageUrl: data.objectKey ? "/api/settings/payment-qr" : "" }, { headers: { "Cache-Control": "no-store" } });
  }
  if (!data.objectKey) return new Response("Chưa cấu hình QR.", { status: 404 });
  const object = await (await bucket()).get(String(data.objectKey));
  if (!object) return new Response("Ảnh QR đã bị xóa.", { status: 404 });
  return new Response(object.body, { headers: { "Content-Type": String(data.contentType || object.httpMetadata?.contentType || "image/png"), "Cache-Control": "private, max-age=60" } });
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File) || !file.size) return Response.json({ error: "Vui lòng chọn ảnh QR." }, { status: 400 });
  if (!["image/png", "image/jpeg", "image/webp"].includes(file.type) || file.size > 3 * 1024 * 1024) return Response.json({ error: file.size > 3 * 1024 * 1024 ? "Ảnh QR tối đa 3 MB." : "QR phải là ảnh PNG, JPG hoặc WEBP." }, { status: 400 });
  const db = await getDb();
  const existing = await db.select().from(adminItems).where(and(eq(adminItems.kind, "settings"), eq(adminItems.itemKey, SETTINGS_KEY))).limit(1);
  const previous = existing[0] ? decode(existing[0].data) : {};
  const storage = await bucket();
  const objectKey = "settings/payment-qr/" + crypto.randomUUID();
  await storage.put(objectKey, await file.arrayBuffer(), { httpMetadata: { contentType: file.type } });
  if (previous.objectKey) {
    try { await storage.delete(String(previous.objectKey)); } catch {}
  }
  const now = new Date().toISOString();
  const data = {
    objectKey,
    contentType: file.type,
    bankName: String(form.get("bankName") || "").trim().slice(0, 120),
    accountName: String(form.get("accountName") || "").trim().slice(0, 120),
    accountNumber: String(form.get("accountNumber") || "").trim().slice(0, 80),
  };
  await db.insert(adminItems).values({ kind: "settings", itemKey: SETTINGS_KEY, title: "QR ngân hàng", data: JSON.stringify(data), createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: [adminItems.kind, adminItems.itemKey], set: { data: JSON.stringify(data), updatedAt: now } });
  return Response.json({ success: true, configured: true, imageUrl: "/api/settings/payment-qr" });
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.kind, "settings"), eq(adminItems.itemKey, SETTINGS_KEY))).limit(1);
  if (rows[0]) {
    const data = decode(rows[0].data);
    if (data.objectKey) {
      try { await (await bucket()).delete(String(data.objectKey)); } catch {}
    }
    await db.delete(adminItems).where(eq(adminItems.id, rows[0].id));
  }
  return Response.json({ success: true });
}
