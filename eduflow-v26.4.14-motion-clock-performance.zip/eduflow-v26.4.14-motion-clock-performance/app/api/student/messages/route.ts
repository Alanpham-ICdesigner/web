import { asc, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems, studentEnrollments, students } from "../../../../db/schema";
import { getStudentSessionId } from "../../../../lib/student-auth";

function decode(value: string): Record<string, unknown> {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

function cleanBody(value: unknown): string {
  return String(value || "").replace(/\r\n/g, "\n").trim().slice(0, 4000);
}

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "messages")).orderBy(asc(adminItems.id));
  const messages = rows.map(function(row) {
    const data = decode(row.data);
    if (Number(data.studentId) !== studentId) return null;
    const direction = String(data.direction || "student") === "teacher" ? "teacher" : "student";
    return {
      id: row.id,
      classKey: String(data.classKey || ""),
      className: String(data.className || ""),
      teacher: String(data.teacher || "Giáo viên"),
      direction,
      body: String(data.body || ""),
      createdAt: row.createdAt,
      read: direction === "teacher" ? Boolean(data.studentReadAt) : true,
    };
  }).filter(Boolean);
  return Response.json({ messages }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as { body?: string };
  const body = cleanBody(payload.body);
  if (!body) return Response.json({ error: "Vui lòng nhập nội dung tin nhắn." }, { status: 400 });

  const db = await getDb();
  const enrollments = await db.select().from(studentEnrollments).where(eq(studentEnrollments.studentId, studentId));
  const enrollment = enrollments.find(function(row) { return row.status === "active"; });
  if (!enrollment) return Response.json({ error: "Bạn chưa tham gia lớp học đang hoạt động." }, { status: 403 });
  const studentRows = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!studentRows.length) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });
  const classRows = await db.select().from(adminItems).where(eq(adminItems.kind, "classes"));
  const classRow = classRows.find(function(row) { return row.itemKey === enrollment.classKey; });
  const classData = classRow ? decode(classRow.data) : {};
  const teacher = String(classData.teacher || "Giáo viên");
  const now = new Date().toISOString();
  const inserted = await db.insert(adminItems).values({
    kind: "messages",
    itemKey: "message-" + crypto.randomUUID(),
    title: studentRows[0].name,
    data: JSON.stringify({
      studentId,
      studentCode: studentRows[0].code,
      studentName: studentRows[0].name,
      classKey: enrollment.classKey,
      className: enrollment.className,
      teacher,
      direction: "student",
      body,
      adminReadAt: null,
      studentReadAt: now,
    }),
    createdAt: now,
    updatedAt: now,
  }).returning();
  return Response.json({ id: inserted[0]?.id || 0, success: true }, { status: 201 });
}

export async function PATCH(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "messages"));
  const now = new Date().toISOString();
  for (const row of rows) {
    const data = decode(row.data);
    if (Number(data.studentId) !== studentId || String(data.direction || "") !== "teacher") continue;
    if (data.studentReadAt) continue;
    data.studentReadAt = now;
    await db.update(adminItems).set({ data: JSON.stringify(data), updatedAt: now }).where(eq(adminItems.id, row.id));
  }
  return Response.json({ success: true });
}
