import { getStudentSessionId } from "../../../../../lib/student-auth";

async function database() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("D1 binding DB is unavailable");
  return env.DB as D1Database;
}

type FocusTaskRow = {
  id: number;
  title: string;
  is_done: number;
  sort_order: number;
  target_pomodoros: number;
  completed_pomodoros: number;
  completed_at: string;
  created_at: string;
  updated_at: string;
};

function taskView(row: FocusTaskRow) {
  return {
    id: Number(row.id),
    title: String(row.title || ""),
    done: Boolean(row.is_done),
    sortOrder: Number(row.sort_order || 0),
    targetPomodoros: Math.max(1, Math.min(24, Number(row.target_pomodoros) || 1)),
    completedPomodoros: Math.max(0, Number(row.completed_pomodoros) || 0),
    completedAt: String(row.completed_at || ""),
    createdAt: String(row.created_at || ""),
    updatedAt: String(row.updated_at || ""),
  };
}

async function listTasks(db: D1Database, studentId: number) {
  const rows = await db.prepare(`
    SELECT id, title, is_done, sort_order, target_pomodoros, completed_pomodoros,
           completed_at, created_at, updated_at
    FROM student_focus_tasks
    WHERE student_id = ?
    ORDER BY is_done ASC, sort_order ASC, id ASC
  `).bind(studentId).all() as { results?: FocusTaskRow[] };

  const active = await db.prepare(`
    SELECT l.task_id
    FROM student_focus_timer_state t
    JOIN student_focus_task_sessions l
      ON l.student_id = t.student_id AND l.session_key = t.session_key
    JOIN student_focus_tasks f
      ON f.id = l.task_id AND f.student_id = t.student_id
    WHERE t.student_id = ?
      AND t.mode = 'focus'
      AND t.session_key <> ''
      AND l.completed_at = ''
      AND f.is_done = 0
    LIMIT 1
  `).bind(studentId).first() as { task_id?: number } | null;

  return {
    tasks: (rows.results || []).map(taskView),
    activeTaskId: Math.max(0, Number(active?.task_id) || 0) || null,
  };
}

function cleanTitle(value: unknown): string {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 180);
}

function targetPomodoros(value: unknown): number {
  const parsed = Math.round(Number(value));
  if (!Number.isFinite(parsed)) return 1;
  return Math.max(1, Math.min(24, parsed));
}

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const db = await database();
  return Response.json(await listTasks(db, studentId), { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as Record<string, unknown>;
  const action = String(payload.action || "create");
  const db = await database();
  const now = new Date().toISOString();

  if (action === "create") {
    const title = cleanTitle(payload.title);
    if (!title) return Response.json({ error: "Nhập nội dung việc cần làm." }, { status: 400 });
    const max = await db.prepare(`SELECT COALESCE(MAX(sort_order), -1) AS max_sort FROM student_focus_tasks WHERE student_id = ? AND is_done = 0`).bind(studentId).first() as { max_sort?: number } | null;
    await db.prepare(`
      INSERT INTO student_focus_tasks
        (student_id, title, is_done, sort_order, target_pomodoros, completed_pomodoros, completed_at, created_at, updated_at)
      VALUES (?, ?, 0, ?, ?, 0, '', ?, ?)
    `).bind(studentId, title, Math.max(0, Number(max?.max_sort) + 1 || 0), targetPomodoros(payload.targetPomodoros), now, now).run();
    return Response.json(await listTasks(db, studentId), { headers: { "Cache-Control": "no-store" } });
  }

  if (action === "link-session") {
    const taskId = Math.max(0, Math.floor(Number(payload.taskId) || 0));
    const sessionKey = String(payload.sessionKey || "").trim().slice(0, 100);
    if (!taskId || !/^focus_[A-Za-z0-9_-]{8,90}$/.test(sessionKey)) {
      return Response.json({ error: "Không thể liên kết task với phiên Focus này." }, { status: 400 });
    }
    const task = await db.prepare(`SELECT id FROM student_focus_tasks WHERE id = ? AND student_id = ? AND is_done = 0 LIMIT 1`).bind(taskId, studentId).first();
    if (!task) return Response.json({ error: "Task không còn tồn tại hoặc đã hoàn thành." }, { status: 404 });
    await db.prepare(`
      INSERT INTO student_focus_task_sessions
        (student_id, task_id, session_key, completed_at, created_at, updated_at)
      VALUES (?, ?, ?, '', ?, ?)
      ON CONFLICT(student_id, session_key) DO UPDATE SET
        task_id = CASE WHEN student_focus_task_sessions.completed_at = '' THEN excluded.task_id ELSE student_focus_task_sessions.task_id END,
        updated_at = CASE WHEN student_focus_task_sessions.completed_at = '' THEN excluded.updated_at ELSE student_focus_task_sessions.updated_at END
    `).bind(studentId, taskId, sessionKey, now, now).run();
    return Response.json({ linked: true, taskId, sessionKey }, { headers: { "Cache-Control": "no-store" } });
  }

  if (action === "unlink-session") {
    const sessionKey = String(payload.sessionKey || "").trim().slice(0, 100);
    if (!/^focus_[A-Za-z0-9_-]{8,90}$/.test(sessionKey)) {
      return Response.json({ error: "Phiên Focus không hợp lệ." }, { status: 400 });
    }
    await db.prepare(`
      DELETE FROM student_focus_task_sessions
      WHERE student_id = ? AND session_key = ? AND completed_at = ''
    `).bind(studentId, sessionKey).run();
    return Response.json({ linked: false, taskId: null, sessionKey }, { headers: { "Cache-Control": "no-store" } });
  }

  if (action === "reorder") {
    const ids = Array.isArray(payload.ids) ? payload.ids.map(function(value) { return Math.max(0, Math.floor(Number(value) || 0)); }).filter(Boolean).slice(0, 100) : [];
    const unique = Array.from(new Set(ids));
    if (!unique.length) return Response.json(await listTasks(db, studentId), { headers: { "Cache-Control": "no-store" } });
    const statements = unique.map(function(id, index) {
      return db.prepare(`UPDATE student_focus_tasks SET sort_order = ?, updated_at = ? WHERE id = ? AND student_id = ? AND is_done = 0`).bind(index, now, id, studentId);
    });
    await db.batch(statements);
    return Response.json(await listTasks(db, studentId), { headers: { "Cache-Control": "no-store" } });
  }

  return Response.json({ error: "Thao tác task không hợp lệ." }, { status: 400 });
}

export async function PATCH(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as Record<string, unknown>;
  const id = Math.max(0, Math.floor(Number(payload.id) || 0));
  if (!id) return Response.json({ error: "Task không hợp lệ." }, { status: 400 });
  const db = await database();
  const existing = await db.prepare(`SELECT * FROM student_focus_tasks WHERE id = ? AND student_id = ? LIMIT 1`).bind(id, studentId).first() as (FocusTaskRow & { student_id: number }) | null;
  if (!existing) return Response.json({ error: "Không tìm thấy task." }, { status: 404 });

  const title = payload.title === undefined ? existing.title : cleanTitle(payload.title);
  if (!title) return Response.json({ error: "Tên task không được để trống." }, { status: 400 });
  const done = payload.done === undefined ? Boolean(existing.is_done) : Boolean(payload.done);
  const target = payload.targetPomodoros === undefined ? targetPomodoros(existing.target_pomodoros) : targetPomodoros(payload.targetPomodoros);
  const now = new Date().toISOString();
  const completedAt = done ? (existing.completed_at || now) : "";
  let sortOrder = Number(existing.sort_order) || 0;
  if (!done && Boolean(existing.is_done)) {
    const max = await db.prepare(`SELECT COALESCE(MAX(sort_order), -1) AS max_sort FROM student_focus_tasks WHERE student_id = ? AND is_done = 0`).bind(studentId).first() as { max_sort?: number } | null;
    const currentMax = Number(max?.max_sort);
    sortOrder = Math.max(0, (Number.isFinite(currentMax) ? currentMax : -1) + 1);
  }

  await db.prepare(`
    UPDATE student_focus_tasks
    SET title = ?, is_done = ?, sort_order = ?, target_pomodoros = ?, completed_at = ?, updated_at = ?
    WHERE id = ? AND student_id = ?
  `).bind(title, done ? 1 : 0, sortOrder, target, completedAt, now, id, studentId).run();
  return Response.json(await listTasks(db, studentId), { headers: { "Cache-Control": "no-store" } });
}

export async function DELETE(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const url = new URL(request.url);
  const id = Math.max(0, Math.floor(Number(url.searchParams.get("id")) || 0));
  if (!id) return Response.json({ error: "Task không hợp lệ." }, { status: 400 });
  const db = await database();
  await db.prepare(`DELETE FROM student_focus_tasks WHERE id = ? AND student_id = ?`).bind(id, studentId).run();
  return Response.json(await listTasks(db, studentId), { headers: { "Cache-Control": "no-store" } });
}
