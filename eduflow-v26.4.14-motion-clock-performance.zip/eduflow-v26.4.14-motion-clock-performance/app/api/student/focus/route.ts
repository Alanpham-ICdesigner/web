import { getStudentSessionId } from "../../../../lib/student-auth";
import { FocusTimerConflictError, getFocusTimer, mutateFocusTimer, type FocusTimerMutation } from "../../../../lib/focus-timer";
import { clampFocusMinutes, mondayDateKey, vietnamDateKey } from "../../../../lib/student-companion";

async function database() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("D1 binding DB is unavailable");
  return env.DB as D1Database;
}

function focusSessionDateKey(startedAt: Date, completedAt: Date): string {
  return vietnamDateKey(Number.isNaN(startedAt.getTime()) ? completedAt : startedAt);
}

async function focusStats(db: D1Database, studentId: number, today: string) {
  const weekStart = mondayDateKey(today);
  const row = await db.prepare(`
    WITH tracked AS (
      SELECT
        COALESCE(SUM(CASE WHEN date_key = ? THEN focus_minutes ELSE 0 END), 0) AS today_tracked_minutes,
        COALESCE(SUM(CASE WHEN date_key = ? THEN 1 ELSE 0 END), 0) AS today_sessions,
        COALESCE(SUM(focus_minutes), 0) AS week_tracked_minutes,
        COUNT(*) AS week_sessions
      FROM student_focus_sessions
      WHERE student_id = ? AND date_key >= ? AND date_key <= ?
    ),
    manual AS (
      SELECT
        COALESCE(SUM(CASE WHEN date_key = ? THEN manual_minutes ELSE 0 END), 0) AS today_manual_minutes,
        COALESCE(SUM(manual_minutes), 0) AS week_manual_minutes
      FROM student_focus_adjustments
      WHERE student_id = ? AND date_key >= ? AND date_key <= ?
    )
    SELECT
      tracked.today_tracked_minutes,
      tracked.today_sessions,
      tracked.week_tracked_minutes,
      tracked.week_sessions,
      manual.today_manual_minutes,
      manual.week_manual_minutes
    FROM tracked CROSS JOIN manual
  `).bind(
    today,
    today,
    studentId,
    weekStart,
    today,
    today,
    studentId,
    weekStart,
    today,
  ).first() as {
    today_tracked_minutes: number;
    today_sessions: number;
    week_tracked_minutes: number;
    week_sessions: number;
    today_manual_minutes: number;
    week_manual_minutes: number;
  } | null;

  const todayTrackedMinutes = Math.max(0, Number(row?.today_tracked_minutes) || 0);
  const todayManualMinutes = Math.max(0, Number(row?.today_manual_minutes) || 0);
  const weekTrackedMinutes = Math.max(0, Number(row?.week_tracked_minutes) || 0);
  const weekManualMinutes = Math.max(0, Number(row?.week_manual_minutes) || 0);

  return {
    todayMinutes: todayTrackedMinutes + todayManualMinutes,
    todayTrackedMinutes,
    todayManualMinutes,
    todaySessions: Math.max(0, Number(row?.today_sessions) || 0),
    weekMinutes: weekTrackedMinutes + weekManualMinutes,
    weekTrackedMinutes,
    weekManualMinutes,
    weekSessions: Math.max(0, Number(row?.week_sessions) || 0),
    weekStart,
  };
}

async function responsePayload(db: D1Database, studentId: number, now: Date, timerOnly: boolean) {
  const timer = await getFocusTimer(db, studentId, now);
  if (timerOnly) return { timer, serverNow: now.toISOString() };
  return {
    timer,
    serverNow: now.toISOString(),
    stats: await focusStats(db, studentId, vietnamDateKey(now)),
  };
}

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const db = await database();
  const now = new Date();
  const timerOnly = new URL(request.url).searchParams.get("timerOnly") === "1";
  return Response.json(await responsePayload(db, studentId, now, timerOnly), { headers: { "Cache-Control": "no-store" } });
}

async function legacyCompletion(db: D1Database, studentId: number, payload: Record<string, unknown>) {
  const sessionKey = String(payload.sessionKey || "").trim();
  if (!/^[A-Za-z0-9_-]{8,80}$/.test(sessionKey)) return Response.json({ error: "Phiên tập trung không hợp lệ." }, { status: 400 });

  const focusMinutes = clampFocusMinutes(payload.focusMinutes);
  const startedAtRaw = String(payload.startedAt || "");
  const startedAtDate = new Date(startedAtRaw);
  if (!startedAtRaw || Number.isNaN(startedAtDate.getTime())) return Response.json({ error: "Thời gian bắt đầu không hợp lệ." }, { status: 400 });

  const serverNow = new Date();
  if (startedAtDate.getTime() > serverNow.getTime() + 5000) return Response.json({ error: "Thời gian bắt đầu không hợp lệ." }, { status: 400 });

  const completedAtRaw = String(payload.completedAt || "");
  const requestedCompletedAt = new Date(completedAtRaw);
  const completedAt = completedAtRaw && !Number.isNaN(requestedCompletedAt.getTime()) && requestedCompletedAt.getTime() >= startedAtDate.getTime() && requestedCompletedAt.getTime() <= serverNow.getTime()
    ? requestedCompletedAt
    : serverNow;

  const minimumElapsedMs = Math.max(0, focusMinutes * 60_000 - 5000);
  if (completedAt.getTime() - startedAtDate.getTime() < minimumElapsedMs) {
    return Response.json({ error: "Phiên tập trung chưa đủ thời gian để ghi nhận." }, { status: 409 });
  }

  const result = await db.prepare(`
    INSERT OR IGNORE INTO student_focus_sessions
      (student_id, session_key, focus_minutes, started_at, completed_at, date_key)
    VALUES (?, ?, ?, ?, ?, ?)
  `).bind(studentId, sessionKey, focusMinutes, startedAtDate.toISOString(), completedAt.toISOString(), focusSessionDateKey(startedAtDate, completedAt)).run();

  return Response.json({
    recorded: Boolean(result.meta?.changes),
    stats: await focusStats(db, studentId, vietnamDateKey(serverNow)),
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as Record<string, unknown>;
  const db = await database();

  // Backward compatibility for a cached V8.2.5 client during a rolling deploy.
  // New clients always send an explicit server-authoritative timer action.
  if (!payload.action) return legacyCompletion(db, studentId, payload);

  const action = String(payload.action || "") as FocusTimerMutation["action"];
  if (!["configure", "start", "start-break", "pause", "resume-break", "stop", "skip-break"].includes(action)) {
    return Response.json({ error: "Thao tác Pomodoro không hợp lệ." }, { status: 400 });
  }

  const revision = Number(payload.revision);
  if (!Number.isInteger(revision) || revision < 0) return Response.json({ error: "Phiên đồng bộ Pomodoro không hợp lệ." }, { status: 400 });

  const now = new Date();
  try {
    const timer = await mutateFocusTimer(db, studentId, {
      action,
      revision,
      focusMinutes: payload.focusMinutes,
      breakMinutes: payload.breakMinutes,
    }, now);
    return Response.json({ timer, serverNow: now.toISOString() }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof FocusTimerConflictError) {
      return Response.json({ error: error.message, timer: error.timer, serverNow: now.toISOString() }, { status: 409, headers: { "Cache-Control": "no-store" } });
    }
    return Response.json({ error: error instanceof Error ? error.message : "Không thể đồng bộ Pomodoro." }, { status: 500, headers: { "Cache-Control": "no-store" } });
  }
}
