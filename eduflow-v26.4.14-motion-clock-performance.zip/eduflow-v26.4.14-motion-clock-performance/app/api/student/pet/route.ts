import { getStudentSessionId } from "../../../../lib/student-auth";
import {
  PETDEX_PUNCH_SLUG,
  freezeCooldownState,
  missedCheckinDays,
  nextTenDayMilestone,
  shiftDateKey,
  vietnamDateKey,
} from "../../../../lib/student-companion";
import { clientPetdexPet, findPetdexPet, localPunchPet, type PetdexCatalogPet } from "../../../../lib/petdex-catalog";
import { hasFreezeProtection, reconcileAutomaticStreakFreeze } from "../../../../lib/streak-freeze";

type PetProfileRow = {
  student_id: number;
  pet_slug: string;
  pet_name: string;
  current_streak: number;
  longest_streak: number;
  total_checkins: number;
  last_checkin_date: string;
  freeze_used_month: string;
  freeze_last_used_date: string;
  created_at: string;
  updated_at: string;
};

type PetAsset = PetdexCatalogPet & { name: string };

async function database() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("D1 binding DB is unavailable");
  return env.DB as D1Database;
}

async function petAsset(profile: PetProfileRow): Promise<PetAsset> {
  const selected = await findPetdexPet(profile.pet_slug || PETDEX_PUNCH_SLUG);
  const fallback = localPunchPet();
  const asset = selected || fallback;
  const clientAsset = clientPetdexPet({
    ...asset,
    slug: String(profile.pet_slug || asset.slug || PETDEX_PUNCH_SLUG),
    available: Boolean(selected),
  });
  return {
    ...clientAsset,
    name: String(profile.pet_name || asset.displayName || "Punch").trim() || "Punch",
  };
}

async function responseState(db: D1Database, profile: PetProfileRow, today: string) {
  const current = Math.max(0, Number(profile.current_streak) || 0);
  const nextMilestone = nextTenDayMilestone(current);
  const freeze = freezeCooldownState(profile.freeze_last_used_date || "", today);
  const yesterday = shiftDateKey(today, -1);
  const freezeProtectedYesterday = await hasFreezeProtection(db, profile.student_id, yesterday);
  const rawMissedDays = profile.last_checkin_date === today ? 0 : missedCheckinDays(profile.last_checkin_date || "", today);
  const missedDays = freezeProtectedYesterday && rawMissedDays === 1 ? 0 : rawMissedDays;
  return {
    pet: await petAsset(profile),
    streak: {
      current,
      longest: Math.max(0, Number(profile.longest_streak) || 0),
      totalCheckins: Math.max(0, Number(profile.total_checkins) || 0),
      checkedInToday: profile.last_checkin_date === today,
      lastCheckinDate: profile.last_checkin_date || "",
      nextMilestone,
      milestoneProgress: current % 10,
      freezeAvailable: freeze.available,
      freezeLastUsedDate: profile.freeze_last_used_date || "",
      freezeNextAvailableDate: freeze.nextAvailableDate,
      freezeDaysRemaining: freeze.daysRemaining,
      freezeProtectedYesterday,
      missedCheckin: missedDays > 0,
      missedDays,
    },
  };
}

async function ensureProfile(db: D1Database, studentId: number, nowIso: string) {
  await db.prepare(`
    INSERT OR IGNORE INTO student_pet_profiles
      (student_id, pet_slug, pet_name, current_streak, longest_streak, total_checkins, last_checkin_date, freeze_used_month, freeze_last_used_date, created_at, updated_at)
    VALUES (?, ?, 'Punch', 0, 0, 0, '', '', '', ?, ?)
  `).bind(studentId, PETDEX_PUNCH_SLUG, nowIso, nowIso).run();

  // One-time legacy migration only. Never overwrite a student's later Petdex choice.
  await db.prepare(`
    UPDATE student_pet_profiles
    SET
      pet_name = CASE WHEN pet_name = 'Shinchan' THEN 'Punch' ELSE pet_name END,
      pet_slug = ?,
      updated_at = ?
    WHERE student_id = ? AND pet_slug = 'shinchan'
  `).bind(PETDEX_PUNCH_SLUG, nowIso, studentId).run();
}

async function getProfile(db: D1Database, studentId: number): Promise<PetProfileRow> {
  const row = await db.prepare(`
    SELECT student_id, pet_slug, pet_name, current_streak, longest_streak, total_checkins,
           last_checkin_date, freeze_used_month, freeze_last_used_date, created_at, updated_at
    FROM student_pet_profiles WHERE student_id = ? LIMIT 1
  `).bind(studentId).first() as PetProfileRow | null;
  if (!row) throw new Error("Pet profile is unavailable");
  return row;
}

function normalizePetName(value: unknown): string {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const db = await database();
  const now = new Date();
  const nowIso = now.toISOString();
  const today = vietnamDateKey(now);
  await ensureProfile(db, studentId, nowIso);
  await reconcileAutomaticStreakFreeze(db, studentId, now);
  const profile = await getProfile(db, studentId);
  return Response.json(await responseState(db, profile, today), { headers: { "Cache-Control": "no-store" } });
}

export async function PATCH(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });

  let body: { petName?: unknown; petSlug?: unknown } = {};
  try {
    body = await request.json() as { petName?: unknown; petSlug?: unknown };
  } catch {
    return Response.json({ error: "Dữ liệu pet không hợp lệ." }, { status: 400 });
  }

  const hasName = Object.prototype.hasOwnProperty.call(body, "petName");
  const hasSlug = Object.prototype.hasOwnProperty.call(body, "petSlug");
  if (!hasName && !hasSlug) return Response.json({ error: "Không có thay đổi pet." }, { status: 400 });

  let petName = "";
  if (hasName) {
    petName = normalizePetName(body.petName);
    const characterCount = Array.from(petName).length;
    if (characterCount < 1 || characterCount > 24) {
      return Response.json({ error: "Tên pet cần từ 1 đến 24 ký tự." }, { status: 400 });
    }
  }

  let petSlug = "";
  if (hasSlug) {
    petSlug = String(body.petSlug ?? "").trim().toLowerCase();
    if (!/^[a-z0-9][a-z0-9_-]{0,79}$/.test(petSlug)) {
      return Response.json({ error: "Pet đã chọn không hợp lệ." }, { status: 400 });
    }
    const selected = await findPetdexPet(petSlug);
    if (!selected) return Response.json({ error: "Pet này hiện không còn trong Petdex." }, { status: 404 });
  }

  const db = await database();
  const now = new Date();
  const nowIso = now.toISOString();
  const today = vietnamDateKey(now);
  await ensureProfile(db, studentId, nowIso);
  await reconcileAutomaticStreakFreeze(db, studentId, now);

  if (hasName && hasSlug) {
    await db.prepare(`UPDATE student_pet_profiles SET pet_name = ?, pet_slug = ?, updated_at = ? WHERE student_id = ?`)
      .bind(petName, petSlug, nowIso, studentId).run();
  } else if (hasName) {
    await db.prepare(`UPDATE student_pet_profiles SET pet_name = ?, updated_at = ? WHERE student_id = ?`)
      .bind(petName, nowIso, studentId).run();
  } else {
    await db.prepare(`UPDATE student_pet_profiles SET pet_slug = ?, updated_at = ? WHERE student_id = ?`)
      .bind(petSlug, nowIso, studentId).run();
  }

  const profile = await getProfile(db, studentId);
  return Response.json(await responseState(db, profile, today), { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });

  const db = await database();
  const now = new Date();
  const nowIso = now.toISOString();
  const today = vietnamDateKey(now);
  const yesterday = shiftDateKey(today, -1);
  const twoDaysAgo = shiftDateKey(today, -2);

  await ensureProfile(db, studentId, nowIso);
  const reconciliation = await reconcileAutomaticStreakFreeze(db, studentId, now);
  const before = await getProfile(db, studentId);
  const protectedYesterday = await hasFreezeProtection(db, studentId, yesterday);
  const continuesStreak = before.last_checkin_date === yesterday || (before.last_checkin_date === twoDaysAgo && protectedYesterday);

  const batchResults = await db.batch([
    db.prepare(`
      INSERT OR IGNORE INTO student_daily_checkins (student_id, checkin_date, checked_at, used_freeze)
      VALUES (?, ?, ?, 0)
    `).bind(studentId, today, nowIso),
    db.prepare(`
      UPDATE student_pet_profiles
      SET
        current_streak = CASE
          WHEN last_checkin_date = ? THEN current_streak
          WHEN ? = 1 THEN current_streak + 1
          ELSE 1
        END,
        longest_streak = MAX(longest_streak, CASE
          WHEN last_checkin_date = ? THEN current_streak
          WHEN ? = 1 THEN current_streak + 1
          ELSE 1
        END),
        total_checkins = total_checkins + CASE WHEN last_checkin_date = ? THEN 0 ELSE 1 END,
        last_checkin_date = CASE WHEN last_checkin_date = ? THEN last_checkin_date ELSE ? END,
        updated_at = ?
      WHERE student_id = ?
    `).bind(
      today, continuesStreak ? 1 : 0,
      today, continuesStreak ? 1 : 0,
      today,
      today, today,
      nowIso,
      studentId,
    ),
  ]);

  const profile = await getProfile(db, studentId);
  const changed = Boolean(batchResults[0]?.meta?.changes);
  const usedFreeze = Boolean(reconciliation.usedFreeze);
  const milestone = changed && profile.current_streak > 0 && profile.current_streak % 10 === 0;
  const majorMilestone = milestone && profile.current_streak % 100 === 0;

  return Response.json({
    ...(await responseState(db, profile, today)),
    result: {
      changed,
      usedFreeze,
      milestone,
      majorMilestone,
      message: !changed
        ? "Hôm nay bạn đã điểm danh rồi."
        : usedFreeze
          ? "Streak Freeze đã tự động bảo vệ ngày hôm qua. Điểm danh hôm nay đã tiếp tục chuỗi."
          : milestone
            ? "Bạn vừa đạt mốc " + profile.current_streak + " ngày."
            : "Điểm danh hôm nay thành công.",
    },
  }, { headers: { "Cache-Control": "no-store" } });
}
