import { and, countDistinct, eq, inArray } from "drizzle-orm";
import { getDb } from "../../../../db";
import { assignmentSubmissionFiles, assignmentSubmissions, assignmentTeacherCompletions, assignments } from "../../../../db/schema";
import { getStudentSessionId } from "../../../../lib/student-auth";
import { getAssignmentStatus } from "../../../../lib/assignment-status";
import { studentCanAccessCourse } from "../../../../lib/course-access";
import { COMPLETED_SUBMISSION_STATUSES, isStudentSubmittedStatus } from "../../../../lib/assignment-submission";

const MAX_SUBMISSION_TOTAL_SIZE = 10 * 1024 * 1024;
const ALLOWED_TYPES = new Set(["application/pdf", "image/jpeg", "image/png", "image/webp"]);
type R2HeadObject = { size: number; httpMetadata?: { contentType?: string } };
type FileBucket = {
  put(key: string, value: ArrayBuffer, options?: { httpMetadata?: { contentType?: string } }): Promise<unknown>;
  head(key: string): Promise<R2HeadObject | null>;
  delete(key: string): Promise<void>;
};
type D1PreparedStatement = { bind(...values: unknown[]): D1PreparedStatement };
type D1Result = { meta?: { changes?: number } };
type RawD1 = {
  prepare(sql: string): D1PreparedStatement;
  batch(statements: D1PreparedStatement[]): Promise<D1Result[]>;
};
type StoredFile = {
  id: number;
  objectKey: string;
  fileName: string;
  fileSize: number;
  contentType: string;
  createdAt: string;
};
type DirectUploadedFile = {
  objectKey: string;
  fileName: string;
  fileSize: number;
  contentType: string;
};

class SubmissionConflictError extends Error {}

async function getBucket(): Promise<FileBucket> {
  const { env } = await import("cloudflare:workers");
  const bucket = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!bucket) throw new Error("Kho tệp chưa được cấu hình.");
  return bucket;
}

async function getRawD1(): Promise<RawD1> {
  const { env } = await import("cloudflare:workers");
  const database = (env as unknown as { DB?: RawD1 }).DB;
  if (!database) throw new Error("Cơ sở dữ liệu chưa được cấu hình.");
  return database;
}

async function deleteUnreferencedObjects(bucket: FileBucket, keys: string[]): Promise<void> {
  if (!keys.length) return;
  const raw = await getRawD1();
  await Promise.all(Array.from(new Set(keys)).map(async function(key) {
    try {
      const references = await raw.batch([
        raw.prepare("SELECT 1 FROM assignment_submission_files WHERE object_key = ? LIMIT 1").bind(key),
        raw.prepare("SELECT 1 FROM assignment_submissions WHERE object_key = ? LIMIT 1").bind(key),
      ]);
      const referenced = references.some(function(result) {
        return Boolean((result as D1Result & { results?: unknown[] }).results?.length);
      });
      if (!referenced) await bucket.delete(key);
    } catch {}
  }));
}

function safeFileName(name: string): string {
  return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9._-]+/g, "-").slice(-100) || "submission";
}

function isAllowedFile(file: File): boolean {
  const hasAllowedExtension = /\.(?:pdf|jpe?g|png|webp)$/i.test(file.name);
  const type = String(file.type || "").toLowerCase();
  return hasAllowedExtension && (!type || type === "application/octet-stream" || ALLOWED_TYPES.has(type));
}

function normalizedContentType(file: File): string {
  const type = String(file.type || "").toLowerCase();
  if (ALLOWED_TYPES.has(type)) return type;
  if (/\.pdf$/i.test(file.name)) return "application/pdf";
  if (/\.png$/i.test(file.name)) return "image/png";
  if (/\.webp$/i.test(file.name)) return "image/webp";
  return "image/jpeg";
}

function isAllowedStoredFile(name: string, contentType: string): boolean {
  const type = String(contentType || "").toLowerCase();
  return /\.(?:pdf|jpe?g|png|webp)$/i.test(name) && (!type || type === "application/octet-stream" || ALLOWED_TYPES.has(type));
}

function normalizedStoredContentType(name: string, contentType: string): string {
  const type = String(contentType || "").toLowerCase();
  if (ALLOWED_TYPES.has(type)) return type;
  if (/\.pdf$/i.test(name)) return "application/pdf";
  if (/\.png$/i.test(name)) return "image/png";
  if (/\.webp$/i.test(name)) return "image/webp";
  return "image/jpeg";
}

function syntheticLegacyFile(existing: typeof assignmentSubmissions.$inferSelect): StoredFile[] {
  if (!existing.objectKey) return [];
  return [{
    id: 0,
    objectKey: existing.objectKey,
    fileName: existing.fileName || "Bài nộp",
    fileSize: existing.fileSize || 0,
    contentType: existing.contentType || "application/octet-stream",
    createdAt: existing.submittedAt,
  }];
}

async function updateSubmittedCount(db: Awaited<ReturnType<typeof getDb>>, assignmentId: number): Promise<number> {
  const rows = await db.select({ count: countDistinct(assignmentSubmissions.studentId) })
    .from(assignmentSubmissions)
    .where(and(eq(assignmentSubmissions.assignmentId, assignmentId), inArray(assignmentSubmissions.status, [...COMPLETED_SUBMISSION_STATUSES])));
  const submittedCount = Number(rows[0]?.count || 0);
  await db.update(assignments).set({ submittedCount }).where(eq(assignments.id, assignmentId));
  return submittedCount;
}

async function loadAssignmentForStudent(request: Request, assignmentId: number) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return { response: Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 }) } as const;
  if (!assignmentId) return { response: Response.json({ error: "Bài tập không hợp lệ." }, { status: 400 }) } as const;
  const db = await getDb();
  const assignmentRows = await db.select().from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
  const assignment = assignmentRows[0];
  if (!assignment || !await studentCanAccessCourse(db, studentId, assignment.classKey)) {
    return { response: Response.json({ error: "Bạn không có quyền nộp bài tập này." }, { status: 403 }) } as const;
  }
  return { db, studentId, assignment } as const;
}

export async function PATCH(request: Request) {
  const payload = await request.json().catch(function() { return {}; }) as { assignmentId?: number; action?: string };
  const assignmentId = Number(payload.assignmentId || 0);
  if (payload.action !== "unsubmit") return Response.json({ error: "Thao tác bài nộp không hợp lệ." }, { status: 400 });
  const context = await loadAssignmentForStudent(request, assignmentId);
  if ("response" in context) return context.response;
  const { db, studentId, assignment } = context;
  if (getAssignmentStatus(assignment.dueDate) === "Đã kết thúc") {
    return Response.json({ error: "Bài tập đã hết hạn nên không thể thu hồi bài nộp." }, { status: 400 });
  }
  const rows = await db.select().from(assignmentSubmissions).where(and(eq(assignmentSubmissions.assignmentId, assignmentId), eq(assignmentSubmissions.studentId, studentId))).limit(1);
  const existing = rows[0];
  if (!existing || !isStudentSubmittedStatus(existing.status)) {
    return Response.json({ error: "Bài này hiện không ở trạng thái đã nộp." }, { status: 409 });
  }
  const now = new Date().toISOString();
  const updated = await db.update(assignmentSubmissions).set({
    status: "draft",
    score: null,
    feedback: "",
    gradedAt: null,
    updatedAt: now,
  }).where(and(
    eq(assignmentSubmissions.id, existing.id),
    eq(assignmentSubmissions.status, existing.status),
    eq(assignmentSubmissions.updatedAt, existing.updatedAt),
  )).returning({ id: assignmentSubmissions.id });
  if (!updated.length) return Response.json({ error: "Bài nộp vừa được cập nhật ở thiết bị khác. Vui lòng tải lại." }, { status: 409 });
  await updateSubmittedCount(db, assignmentId);
  return Response.json({
    success: true,
    submission: {
      id: existing.id,
      status: "draft",
      submittedAt: existing.submittedAt,
      score: null,
      feedback: "",
      gradedAt: null,
    },
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });

  try {
    const requestType = request.headers.get("content-type") || "";
    let assignmentId = 0;
    let responseText = "";
    let files: File[] = [];
    let removeFileIds: number[] = [];
    let removeLegacyFile = false;
    let expectedUpdatedAt: string | null = null;
    let directUploads: DirectUploadedFile[] = [];
    if (requestType.includes("multipart/form-data")) {
      const form = await request.formData();
      assignmentId = Number(form.get("assignmentId"));
      responseText = String(form.get("responseText") || "").trim().slice(0, 10_000);
      files = form.getAll("files").filter(function(candidate): candidate is File { return candidate instanceof File && candidate.size > 0; });
      if (!files.length) {
        const legacyFile = form.get("file");
        if (legacyFile instanceof File && legacyFile.size > 0) files = [legacyFile];
      }
      removeFileIds = form.getAll("removeFileIds").map(Number).filter(function(id) { return Number.isInteger(id) && id > 0; });
      removeLegacyFile = String(form.get("removeLegacyFile") || "") === "1";
      expectedUpdatedAt = form.has("expectedUpdatedAt") ? String(form.get("expectedUpdatedAt") || "") : null;
    } else {
      const payload = await request.json().catch(function() { return {}; }) as {
        assignmentId?: number;
        responseText?: string;
        expectedUpdatedAt?: string;
        removeFileIds?: unknown[];
        removeLegacyFile?: boolean;
        uploadedFiles?: Array<{ objectKey?: unknown; fileName?: unknown; fileSize?: unknown; contentType?: unknown }>;
      };
      assignmentId = Number(payload.assignmentId);
      responseText = String(payload.responseText || "").trim().slice(0, 10_000);
      expectedUpdatedAt = Object.prototype.hasOwnProperty.call(payload, "expectedUpdatedAt") ? String(payload.expectedUpdatedAt || "") : null;
      removeFileIds = (Array.isArray(payload.removeFileIds) ? payload.removeFileIds : []).map(Number).filter(function(id) { return Number.isInteger(id) && id > 0; });
      removeLegacyFile = Boolean(payload.removeLegacyFile);
      directUploads = (Array.isArray(payload.uploadedFiles) ? payload.uploadedFiles : []).slice(0, 20).map(function(file) {
        return {
          objectKey: String(file.objectKey || ""),
          fileName: String(file.fileName || "").slice(0, 180),
          fileSize: Number(file.fileSize || 0),
          contentType: String(file.contentType || "").toLowerCase(),
        };
      });
    }
    if (!assignmentId) return Response.json({ error: "Bài tập không hợp lệ." }, { status: 400 });

    const multipartTotalFileSize = files.reduce(function(total, file) { return total + file.size; }, 0);
    if (files.some(function(file) { return !isAllowedFile(file); }) || directUploads.some(function(file) { return !file.objectKey || !isAllowedStoredFile(file.fileName, file.contentType) || !Number.isFinite(file.fileSize) || file.fileSize <= 0; })) {
      return Response.json({ error: "Chỉ hỗ trợ ảnh JPG, PNG, WEBP hoặc PDF." }, { status: 400 });
    }
    if (multipartTotalFileSize > MAX_SUBMISSION_TOTAL_SIZE || directUploads.reduce(function(total, file) { return total + file.fileSize; }, 0) > MAX_SUBMISSION_TOTAL_SIZE) {
      return Response.json({ error: "Tổng dung lượng tất cả tệp tối đa 10 MB." }, { status: 400 });
    }

    const db = await getDb();
    const assignmentRows = await db.select().from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
    const assignment = assignmentRows[0];
    if (!assignment || !await studentCanAccessCourse(db, studentId, assignment.classKey)) {
      return Response.json({ error: "Bạn không có quyền nộp bài tập này." }, { status: 403 });
    }
    if (getAssignmentStatus(assignment.dueDate) === "Đã kết thúc") return Response.json({ error: "Bài tập đã hết hạn. Vui lòng liên hệ giáo viên nếu cần mở lại." }, { status: 400 });

    let storageBucket: FileBucket | null = null;
    const verifiedDirectUploads: DirectUploadedFile[] = [];
    if (directUploads.length) {
      const prefix = "submissions/" + assignmentId + "/" + studentId + "/";
      const uniqueKeys = new Set<string>();
      storageBucket = await getBucket();
      for (const file of directUploads) {
        if (!file.objectKey.startsWith(prefix) || uniqueKeys.has(file.objectKey) || file.fileSize > MAX_SUBMISSION_TOTAL_SIZE) {
          return Response.json({ error: "Tệp bài nộp tải lên không hợp lệ. Vui lòng chọn lại tệp." }, { status: 400 });
        }
        uniqueKeys.add(file.objectKey);
        const stored = await storageBucket.head(file.objectKey);
        if (!stored || stored.size <= 0 || stored.size > MAX_SUBMISSION_TOTAL_SIZE || stored.size !== file.fileSize) {
          return Response.json({ error: "Không xác minh được tệp bài nộp trên kho lưu trữ. Vui lòng tải lại tệp." }, { status: 400 });
        }
        verifiedDirectUploads.push({
          objectKey: file.objectKey,
          fileName: file.fileName,
          fileSize: stored.size,
          contentType: normalizedStoredContentType(file.fileName, stored.httpMetadata?.contentType || file.contentType),
        });
      }
    }

    const existingRows = await db.select().from(assignmentSubmissions).where(and(eq(assignmentSubmissions.assignmentId, assignmentId), eq(assignmentSubmissions.studentId, studentId))).limit(1);
    const existing = existingRows[0];
    if (existing && existing.status !== "teacher_completed" && (expectedUpdatedAt === null || expectedUpdatedAt !== existing.updatedAt)) {
      return Response.json({ error: "Bài nộp đã thay đổi ở thiết bị khác. Vui lòng tải lại trước khi nộp." }, { status: 409, headers: { "Cache-Control": "no-store" } });
    }

    const storedRows = existing
      ? await db.select().from(assignmentSubmissionFiles).where(eq(assignmentSubmissionFiles.submissionId, existing.id))
      : [];
    const existingFiles: StoredFile[] = storedRows.length ? storedRows : existing ? syntheticLegacyFile(existing) : [];
    const removeSet = new Set(removeFileIds);
    const remainingExistingFiles = existingFiles.filter(function(file) { return file.id ? !removeSet.has(file.id) : !removeLegacyFile; });
    const directTotalFileSize = verifiedDirectUploads.reduce(function(total, file) { return total + file.fileSize; }, 0);
    const finalTotalSize = remainingExistingFiles.reduce(function(total, file) { return total + Number(file.fileSize || 0); }, 0) + multipartTotalFileSize + directTotalFileSize;
    if (finalTotalSize > MAX_SUBMISSION_TOTAL_SIZE) {
      return Response.json({ error: "Tổng dung lượng bài nộp sau khi cập nhật tối đa 10 MB." }, { status: 400 });
    }
    if (!files.length && !verifiedDirectUploads.length && !responseText && !remainingExistingFiles.length) {
      return Response.json({ error: "Vui lòng giữ lại hoặc chọn ít nhất một tệp, hoặc nhập câu trả lời." }, { status: 400 });
    }

    const now = new Date().toISOString();
    const pendingUploads = files.map(function(file) {
      return {
        objectKey: "submissions/" + assignmentId + "/" + studentId + "/" + crypto.randomUUID() + "-" + safeFileName(file.name),
        file,
        fileName: file.name,
        fileSize: file.size,
        contentType: normalizedContentType(file),
      };
    });
    const uploaded: Array<{ objectKey: string; fileName: string; fileSize: number; contentType: string }> = [];
    if (pendingUploads.length) {
      const bucket = storageBucket || await getBucket();
      storageBucket = bucket;
      const results = await Promise.allSettled(pendingUploads.map(async function(entry) {
        const body = await entry.file.arrayBuffer();
        await bucket.put(entry.objectKey, body, { httpMetadata: { contentType: entry.contentType } });
        return { objectKey: entry.objectKey, fileName: entry.fileName, fileSize: entry.fileSize, contentType: entry.contentType };
      }));
      results.forEach(function(result) { if (result.status === "fulfilled") uploaded.push(result.value); });
      const failed = results.find(function(result) { return result.status === "rejected"; });
      if (failed) {
        await Promise.all(uploaded.map(async function(file) { try { await storageBucket?.delete(file.objectKey); } catch {} }));
        throw failed.reason;
      }
    }

    const finalFiles: Array<{ objectKey: string; fileName: string; fileSize: number; contentType: string }> = remainingExistingFiles
      .map(function(file) { return { objectKey: file.objectKey, fileName: file.fileName, fileSize: file.fileSize, contentType: file.contentType }; })
      .concat(verifiedDirectUploads, uploaded);
    const firstFile = finalFiles[0];
    let submissionId = existing?.id || 0;
    try {
      const raw = await getRawD1();
      let results: D1Result[];
      if (existing) {
        const guardSql = "EXISTS (SELECT 1 FROM assignment_submissions WHERE id = ? AND assignment_id = ? AND student_id = ? AND updated_at = ?)";
        const statements: D1PreparedStatement[] = [
          raw.prepare("UPDATE assignment_submissions SET submitted_at = ?, response_text = ?, object_key = ?, file_name = ?, file_size = ?, content_type = ?, status = 'submitted', score = NULL, feedback = '', graded_at = NULL, updated_at = ? WHERE id = ? AND assignment_id = ? AND student_id = ? AND updated_at = ?")
            .bind(now, responseText, firstFile?.objectKey || "", firstFile?.fileName || "", firstFile?.fileSize || 0, firstFile?.contentType || "", now, existing.id, assignmentId, studentId, existing.updatedAt),
          raw.prepare("DELETE FROM assignment_submission_files WHERE submission_id = ? AND " + guardSql)
            .bind(existing.id, existing.id, assignmentId, studentId, now),
          raw.prepare("DELETE FROM assignment_teacher_completions WHERE assignment_id = ? AND student_id = ? AND " + guardSql)
            .bind(assignmentId, studentId, existing.id, assignmentId, studentId, now),
        ];
        finalFiles.forEach(function(file) {
          statements.push(raw.prepare("INSERT INTO assignment_submission_files (submission_id, object_key, file_name, file_size, content_type, created_at) SELECT ?, ?, ?, ?, ?, ? WHERE " + guardSql)
            .bind(existing.id, file.objectKey, file.fileName, file.fileSize, file.contentType, now, existing.id, assignmentId, studentId, now));
        });
        results = await raw.batch(statements);
        if (!Number(results[0]?.meta?.changes || 0)) throw new SubmissionConflictError("Bài nộp vừa được cập nhật ở thiết bị khác. Vui lòng tải lại rồi nộp lại.");
      } else {
        const statements: D1PreparedStatement[] = [
          raw.prepare("INSERT INTO assignment_submissions (assignment_id, student_id, submitted_at, response_text, object_key, file_name, file_size, content_type, status, score, feedback, graded_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'submitted', NULL, '', NULL, ?)")
            .bind(assignmentId, studentId, now, responseText, firstFile?.objectKey || "", firstFile?.fileName || "", firstFile?.fileSize || 0, firstFile?.contentType || "", now),
          raw.prepare("DELETE FROM assignment_teacher_completions WHERE assignment_id = ? AND student_id = ? AND EXISTS (SELECT 1 FROM assignment_submissions WHERE assignment_id = ? AND student_id = ? AND updated_at = ?)")
            .bind(assignmentId, studentId, assignmentId, studentId, now),
        ];
        finalFiles.forEach(function(file) {
          statements.push(raw.prepare("INSERT INTO assignment_submission_files (submission_id, object_key, file_name, file_size, content_type, created_at) SELECT id, ?, ?, ?, ?, ? FROM assignment_submissions WHERE assignment_id = ? AND student_id = ? AND updated_at = ?")
            .bind(file.objectKey, file.fileName, file.fileSize, file.contentType, now, assignmentId, studentId, now));
        });
        results = await raw.batch(statements);
        if (!Number(results[0]?.meta?.changes || 0)) throw new SubmissionConflictError("Bài nộp đã được tạo ở thiết bị khác. Vui lòng tải lại.");
        const insertedRows = await db.select({ id: assignmentSubmissions.id }).from(assignmentSubmissions).where(and(eq(assignmentSubmissions.assignmentId, assignmentId), eq(assignmentSubmissions.studentId, studentId))).limit(1);
        submissionId = insertedRows[0]?.id || 0;
      }
    } catch (reason) {
      if (storageBucket) await deleteUnreferencedObjects(storageBucket, verifiedDirectUploads.concat(uploaded).map(function(file) { return file.objectKey; }));
      if (String(reason).includes("UNIQUE constraint failed: assignment_submissions")) {
        throw new SubmissionConflictError("Bài nộp đã được tạo ở thiết bị khác. Vui lòng tải lại.");
      }
      throw reason;
    }

    if (existingFiles.length) {
      const finalKeys = new Set(finalFiles.map(function(file) { return file.objectKey; }));
      const obsoleteKeys = Array.from(new Set(existingFiles.filter(function(file) { return !finalKeys.has(file.objectKey); }).map(function(file) { return file.objectKey; })));
      if (obsoleteKeys.length) await deleteUnreferencedObjects(storageBucket || await getBucket(), obsoleteKeys);
    }

    await updateSubmittedCount(db, assignmentId);
    const [completedSubmissionRows, completedTeacherRows] = await Promise.all([
      db.select({ assignmentId: assignmentSubmissions.assignmentId }).from(assignmentSubmissions)
        .where(and(eq(assignmentSubmissions.studentId, studentId), inArray(assignmentSubmissions.status, [...COMPLETED_SUBMISSION_STATUSES]))),
      db.select({ assignmentId: assignmentTeacherCompletions.assignmentId }).from(assignmentTeacherCompletions)
        .where(eq(assignmentTeacherCompletions.studentId, studentId)),
    ]);
    const completedCount = new Set(completedSubmissionRows.concat(completedTeacherRows).map(function(row) { return row.assignmentId; })).size;

    // V7.2: nộp bài chỉ cập nhật tiến độ học tập. Điểm thi đua chỉ do giáo viên cộng/trừ thủ công.
    return Response.json({ success: true, awarded: 0, completed: completedCount, submissionId, submittedAt: now, updatedAt: now, fileCount: finalFiles.length });
  } catch (reason) {
    if (reason instanceof SubmissionConflictError) {
      return Response.json({ error: reason.message }, { status: 409, headers: { "Cache-Control": "no-store" } });
    }
    console.error("student submission failed", reason);
    return Response.json({ error: "Không thể lưu bài nộp. Vui lòng thử lại." }, { status: 500 });
  }
}
