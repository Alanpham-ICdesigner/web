import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { assignments } from "../../../../../db/schema";
import { getAssignmentStatus } from "../../../../../lib/assignment-status";
import { studentCanAccessCourse } from "../../../../../lib/course-access";
import { getStudentSessionId } from "../../../../../lib/student-auth";

const MAX_SUBMISSION_TOTAL_SIZE = 10 * 1024 * 1024;
const ALLOWED_TYPES = new Set(["application/pdf", "image/jpeg", "image/png", "image/webp"]);

type R2HeadObject = { size: number; httpMetadata?: { contentType?: string } };
type FileBucket = {
  put(key: string, value: ReadableStream<Uint8Array>, options?: { httpMetadata?: { contentType?: string } }): Promise<unknown>;
  head(key: string): Promise<R2HeadObject | null>;
  delete(key: string): Promise<void>;
};
type D1PreparedStatement = { bind(...values: unknown[]): D1PreparedStatement };
type D1Result = { results?: unknown[] };
type RawD1 = {
  prepare(sql: string): D1PreparedStatement;
  batch(statements: D1PreparedStatement[]): Promise<D1Result[]>;
};

async function getBucket(): Promise<FileBucket> {
  const { env } = await import("cloudflare:workers");
  const bucket = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!bucket) throw new Error("Kho tệp chưa được cấu hình.");
  return bucket;
}

async function getRawD1(): Promise<RawD1> {
  const { env } = await import("cloudflare:workers");
  const database = (env as unknown as { DB?: RawD1 }).DB;
  if (!database) throw new Error("Cơ sở dữ liệu chưa được cấu hình.");
  return database;
}

function safeFileName(name: string): string {
  return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9._-]+/g, "-").slice(-100) || "submission";
}

function allowedFile(name: string, contentType: string): boolean {
  const type = String(contentType || "").toLowerCase();
  return /\.(?:pdf|jpe?g|png|webp)$/i.test(name) && (!type || type === "application/octet-stream" || ALLOWED_TYPES.has(type));
}

function normalizedContentType(name: string, contentType: string): string {
  const type = String(contentType || "").toLowerCase();
  if (ALLOWED_TYPES.has(type)) return type;
  if (/\.pdf$/i.test(name)) return "application/pdf";
  if (/\.png$/i.test(name)) return "image/png";
  if (/\.webp$/i.test(name)) return "image/webp";
  return "image/jpeg";
}

async function loadContext(request: Request, assignmentId: number) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return { response: Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 }) } as const;
  if (!assignmentId) return { response: Response.json({ error: "Bài tập không hợp lệ." }, { status: 400 }) } as const;
  const db = await getDb();
  const rows = await db.select().from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
  const assignment = rows[0];
  if (!assignment || !await studentCanAccessCourse(db, studentId, assignment.classKey)) {
    return { response: Response.json({ error: "Bạn không có quyền nộp bài tập này." }, { status: 403 }) } as const;
  }
  if (getAssignmentStatus(assignment.dueDate) === "Đã kết thúc") {
    return { response: Response.json({ error: "Bài tập đã hết hạn. Vui lòng liên hệ giáo viên nếu cần mở lại." }, { status: 400 }) } as const;
  }
  return { studentId } as const;
}

export async function PUT(request: Request) {
  let objectKey = "";
  let bucket: FileBucket | null = null;
  try {
    const url = new URL(request.url);
    const assignmentId = Number(url.searchParams.get("assignmentId") || 0);
    const fileName = String(url.searchParams.get("name") || "").trim().slice(0, 180);
    const claimedSize = Number(url.searchParams.get("size") || 0);
    const requestedType = String(url.searchParams.get("contentType") || request.headers.get("content-type") || "").toLowerCase();
    const context = await loadContext(request, assignmentId);
    if ("response" in context) return context.response;
    if (!fileName || !allowedFile(fileName, requestedType)) {
      return Response.json({ error: "Chỉ hỗ trợ ảnh JPG, PNG, WEBP hoặc PDF." }, { status: 400 });
    }
    if (!Number.isFinite(claimedSize) || claimedSize <= 0 || claimedSize > MAX_SUBMISSION_TOTAL_SIZE) {
      return Response.json({ error: "Mỗi lượt nộp có tổng dung lượng tối đa 10 MB." }, { status: 400 });
    }
    if (!request.body) return Response.json({ error: "Tệp tải lên không có dữ liệu." }, { status: 400 });

    const contentType = normalizedContentType(fileName, requestedType);
    objectKey = "submissions/" + assignmentId + "/" + context.studentId + "/" + crypto.randomUUID() + "-" + safeFileName(fileName);
    bucket = await getBucket();
    // Stream the raw file body straight to R2. Do not parse multipart or buffer the whole file in the Worker.
    await bucket.put(objectKey, request.body, { httpMetadata: { contentType } });
    const stored = await bucket.head(objectKey);
    if (!stored || stored.size <= 0 || stored.size > MAX_SUBMISSION_TOTAL_SIZE || stored.size !== claimedSize) {
      try { await bucket.delete(objectKey); } catch {}
      return Response.json({ error: "Tệp tải lên không đầy đủ hoặc vượt quá giới hạn 10 MB. Vui lòng thử lại." }, { status: 400 });
    }

    return Response.json({
      success: true,
      file: { objectKey, fileName, fileSize: stored.size, contentType },
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (reason) {
    if (bucket && objectKey) { try { await bucket.delete(objectKey); } catch {} }
    console.error("student submission raw upload failed", reason);
    return Response.json({ error: "Không thể tải tệp bài nộp lên kho lưu trữ. Vui lòng thử lại." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  try {
    const payload = await request.json().catch(function() { return {}; }) as { assignmentId?: number; objectKeys?: string[] };
    const assignmentId = Number(payload.assignmentId || 0);
    if (!assignmentId) return Response.json({ error: "Bài tập không hợp lệ." }, { status: 400 });
    const prefix = "submissions/" + assignmentId + "/" + studentId + "/";
    const keys = Array.from(new Set((Array.isArray(payload.objectKeys) ? payload.objectKeys : [])
      .map(function(value) { return String(value || ""); })
      .filter(function(key) { return key.startsWith(prefix); })
      .slice(0, 20)));
    if (!keys.length) return Response.json({ success: true, deleted: 0 });

    const [bucket, raw] = await Promise.all([getBucket(), getRawD1()]);
    let deleted = 0;
    await Promise.all(keys.map(async function(key) {
      try {
        const references = await raw.batch([
          raw.prepare("SELECT 1 FROM assignment_submission_files WHERE object_key = ? LIMIT 1").bind(key),
          raw.prepare("SELECT 1 FROM assignment_submissions WHERE object_key = ? LIMIT 1").bind(key),
        ]);
        if (!references.some(function(result) { return Boolean(result.results?.length); })) {
          await bucket.delete(key);
          deleted += 1;
        }
      } catch {}
    }));
    return Response.json({ success: true, deleted }, { headers: { "Cache-Control": "no-store" } });
  } catch (reason) {
    console.error("student submission upload cleanup failed", reason);
    return Response.json({ error: "Không thể dọn tệp tải lên tạm thời." }, { status: 500 });
  }
}
