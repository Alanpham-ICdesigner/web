import { getStudentSessionId } from "../../../../lib/student-auth";
import { getVapidPublicKey } from "../../../../lib/web-push";

function cleanKey(value: unknown): string {
  const key = String(value || "").trim();
  return /^[A-Za-z0-9_-]{16,512}$/.test(key) ? key : "";
}

function cleanEndpoint(value: unknown): string {
  const endpoint = String(value || "").trim();
  if (endpoint.length > 4096) return "";
  try {
    const url = new URL(endpoint);
    return url.protocol === "https:" ? endpoint : "";
  } catch {
    return "";
  }
}

async function database(): Promise<D1Database> {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("D1 binding DB is unavailable");
  return env.DB as D1Database;
}

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Bạn cần đăng nhập học sinh." }, { status: 401 });
  const publicKey = await getVapidPublicKey();
  const db = await database();
  const rows = await db.prepare("SELECT endpoint, enabled, updated_at FROM push_subscriptions WHERE student_id = ? AND enabled = 1 ORDER BY updated_at DESC").bind(studentId).all() as { results?: Array<{ endpoint: string; enabled: number; updated_at: string }> };
  return Response.json({
    publicKey,
    configured: Boolean(publicKey),
    subscriptions: (rows.results || []).map(function(row) { return { endpoint: row.endpoint, enabled: Boolean(row.enabled), updatedAt: row.updated_at }; }),
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Bạn cần đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as {
    endpoint?: string;
    keys?: { p256dh?: string; auth?: string };
    userAgent?: string;
    platform?: string;
  };
  const endpoint = cleanEndpoint(payload.endpoint);
  const p256dh = cleanKey(payload.keys?.p256dh);
  const auth = cleanKey(payload.keys?.auth);
  if (!endpoint || !p256dh || !auth) return Response.json({ error: "Push subscription không hợp lệ." }, { status: 400 });
  if (!await getVapidPublicKey()) return Response.json({ error: "Web Push chưa được cấu hình VAPID trên Cloudflare." }, { status: 503 });

  const db = await database();
  const now = new Date().toISOString();
  const userAgent = String(payload.userAgent || request.headers.get("user-agent") || "").slice(0, 800);
  const platform = String(payload.platform || "").slice(0, 160);
  await db.prepare(`
    INSERT INTO push_subscriptions
      (student_id, endpoint, p256dh, auth, user_agent, platform, enabled, last_success_at, failure_count, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, 1, '', 0, ?, ?)
    ON CONFLICT(endpoint) DO UPDATE SET
      student_id = excluded.student_id,
      p256dh = excluded.p256dh,
      auth = excluded.auth,
      user_agent = excluded.user_agent,
      platform = excluded.platform,
      enabled = 1,
      failure_count = 0,
      updated_at = excluded.updated_at
  `).bind(studentId, endpoint, p256dh, auth, userAgent, platform, now, now).run();
  return Response.json({ success: true, status: "enabled" }, { headers: { "Cache-Control": "no-store" } });
}

export async function DELETE(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Bạn cần đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as { endpoint?: string };
  const endpoint = cleanEndpoint(payload.endpoint);
  if (!endpoint) return Response.json({ error: "Thiếu Push subscription cần tắt." }, { status: 400 });
  const db = await database();
  const now = new Date().toISOString();
  await db.prepare("UPDATE push_subscriptions SET enabled = 0, updated_at = ? WHERE student_id = ? AND endpoint = ?").bind(now, studentId, endpoint).run();
  return Response.json({ success: true, status: "disabled" }, { headers: { "Cache-Control": "no-store" } });
}
