import { eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems, studentEnrollments } from "../../../../db/schema";
import { decodeNotification } from "../../../../lib/notifications";
import { getStudentSessionId } from "../../../../lib/student-auth";

export async function PATCH(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as { id?: number; all?: boolean; courseId?: string };
  const db = await getDb();
  const enrollmentRows = await db.select().from(studentEnrollments).where(eq(studentEnrollments.studentId, studentId));
  const classKeys = new Set(enrollmentRows.filter(function(item) { return item.status === "active"; }).map(function(item) { return item.classKey; }));
  const classNames = new Set(enrollmentRows.filter(function(item) { return item.status === "active"; }).map(function(item) { return item.className; }));
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "notifications"));
  const now = new Date().toISOString();
  for (const row of rows) {
    if (!payload.all && row.id !== Number(payload.id)) continue;
    const data = decodeNotification(row.data);
    if (payload.courseId && data.classKey && String(data.classKey) !== String(payload.courseId)) continue;
    if (payload.courseId && !data.classKey) {
      const selected = enrollmentRows.find(function(item) { return item.classKey === payload.courseId; });
      if (data.className && String(data.className) !== selected?.className) continue;
    }
    const audience = String(data.audience || "");
    const courseAllowed = (!data.classKey && !data.className) || classKeys.has(String(data.classKey || "")) || classNames.has(String(data.className || ""));
    const allowed = (!audience || audience === "all_students") && courseAllowed || (audience === "student" && Number(data.studentId) === studentId && courseAllowed);
    if (!allowed) continue;
    if (audience === "student") data.studentReadAt = now;
    else {
      const readIds = Array.isArray(data.readByStudentIds) ? data.readByStudentIds.map(Number) : [];
      if (!readIds.includes(studentId)) readIds.push(studentId);
      data.readByStudentIds = readIds;
    }
    await db.update(adminItems).set({ data: JSON.stringify(data), updatedAt: now }).where(eq(adminItems.id, row.id));
  }
  return Response.json({ success: true });
}
