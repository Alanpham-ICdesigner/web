import { eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { studentAccounts, students } from "../../../../db/schema";
import { clearStudentSessionCookie, getStudentSessionId, studentSessionCookie, verifyStudentPin } from "../../../../lib/student-auth";
import { checkLoginAllowed, LOGIN_LOCK_MINUTES, recordFailedLogin, resetFailedLogins } from "../../../../lib/login-security";

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ authenticated: false });
  const db = await getDb();
  const rows = await db.select({ id: students.id, code: students.code, name: students.name, className: students.className }).from(students).where(eq(students.id, studentId)).limit(1);
  if (!rows.length) return Response.json({ authenticated: false }, { headers: { "Set-Cookie": clearStudentSessionCookie() } });
  return Response.json({ authenticated: true, student: rows[0] }, { headers: { "Cache-Control": "no-store", "Set-Cookie": await studentSessionCookie(studentId) } });
}

export async function POST(request: Request) {
  const payload = await request.json().catch(function() { return {}; }) as { code?: string; pin?: string };
  const code = String(payload.code || "").trim().toUpperCase().slice(0, 64);
  const pin = String(payload.pin || "").trim();
  if (!code) return Response.json({ error: "Tên tài khoản hoặc PIN không đúng.", reason: "INVALID_PASSWORD" }, { status: 401 });
  const allowed = await checkLoginAllowed("student", code);
  if (allowed.locked) {
    return Response.json({ error: "Bạn đã nhập sai mật khẩu quá nhiều lần. Vui lòng thử lại sau " + Math.ceil(allowed.retryAfter / 60) + " phút.", reason: "TEMPORARILY_LOCKED", retryAfter: allowed.retryAfter }, { status: 429 });
  }
  const db = await getDb();
  const studentRows = await db.select().from(students).where(eq(students.code, code)).limit(1);
  const accountRows = studentRows.length ? await db.select().from(studentAccounts).where(eq(studentAccounts.studentId, studentRows[0].id)).limit(1) : [];
  const valid = /^\d{6}$/.test(pin) && accountRows.length > 0 && await verifyStudentPin(pin, accountRows[0].pinHash, accountRows[0].pinSalt);
  if (!studentRows.length || !valid) {
    const failed = await recordFailedLogin("student", code);
    if (failed.locked) {
      return Response.json({ error: "Bạn đã nhập sai quá số lần cho phép. Tài khoản tạm thời bị khóa trong " + LOGIN_LOCK_MINUTES + " phút.", reason: "TEMPORARILY_LOCKED", retryAfter: failed.retryAfter }, { status: 429 });
    }
    const warning = failed.remainingAttempts <= 2 ? " Bạn còn " + failed.remainingAttempts + " lần thử." : "";
    return Response.json({ error: "Tên tài khoản hoặc PIN không đúng." + warning, reason: "INVALID_PASSWORD", remainingAttempts: failed.remainingAttempts }, { status: 401 });
  }
  await resetFailedLogins("student", code);
  return Response.json({ authenticated: true, student: { id: studentRows[0].id, code: studentRows[0].code, name: studentRows[0].name, className: studentRows[0].className } }, { headers: { "Set-Cookie": await studentSessionCookie(studentRows[0].id) } });
}

export async function DELETE() {
  return Response.json({ authenticated: false }, { headers: { "Set-Cookie": clearStudentSessionCookie() } });
}
