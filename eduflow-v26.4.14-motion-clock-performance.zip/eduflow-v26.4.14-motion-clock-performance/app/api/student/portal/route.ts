import { asc, desc, eq, inArray } from "drizzle-orm";
import { getDb } from "../../../../db";
import {
  adminItems,
  assignmentSubmissionFiles,
  assignmentSubmissions,
  assignmentTeacherCompletions,
  assignments,
  courseSchedules,
  courseSessions,
  pointTransactions,
  rewardItems,
  rewardRedemptions,
  studentEnrollments,
  students,
} from "../../../../db/schema";
import { getStudentSessionId } from "../../../../lib/student-auth";
import { getAssignmentStatus } from "../../../../lib/assignment-status";
import { activeEnrollments, fallbackClassKey, findCourseByName, studentCanAccessCourse } from "../../../../lib/course-access";
import { isAssignmentCompletedStatus } from "../../../../lib/assignment-submission";

function decode(value: string): Record<string, unknown> {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

function normalized(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s*-\s*\d{4}\s*-\s*\d{4}\s*$/, "").replace(/\s+/g, " ").trim();
}

function legacyWeekdays(value: string): number[] {
  const lookup: Array<[RegExp, number]> = [
    [/thứ\s*2|\bt2\b/gi, 1], [/thứ\s*3|\bt3\b/gi, 2], [/thứ\s*4|\bt4\b/gi, 3],
    [/thứ\s*5|\bt5\b/gi, 4], [/thứ\s*6|\bt6\b/gi, 5], [/thứ\s*7|\bt7\b/gi, 6], [/chủ\s*nhật|\bcn\b/gi, 7],
  ];
  return lookup.filter(function(item) { return item[0].test(value); }).map(function(item) { return item[1]; });
}

function courseData(row: typeof adminItems.$inferSelect) {
  const data = decode(row.data);
  return {
    id: row.id,
    key: row.itemKey,
    name: row.title,
    label: String(data.label || ""),
    teacher: String(data.teacher || "Giáo viên"),
    room: String(data.room || ""),
    tone: String(data.tone || "indigo"),
    logoUrl: String(data.logoUrl || ""),
    legacySchedule: String(data.schedule || ""),
    legacyStartTime: String(data.startTime || ""),
    legacyEndTime: String(data.endTime || ""),
  };
}

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const db = await getDb();
  const studentRows = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!studentRows.length) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });
  const student = studentRows[0];

  let enrollmentRows = (await activeEnrollments(db, studentId)).filter(function(item) {
    const name = String(item.className || "").trim().toLocaleLowerCase("vi");
    return name && name !== "chưa xếp lớp" && name !== "chua xep lop";
  });
  if (!enrollmentRows.length && student.className && student.className !== "Chưa xếp lớp") {
    const legacyCourse = await findCourseByName(db, student.className);
    const now = new Date().toISOString();
    await db.insert(studentEnrollments).values({ studentId, classKey: legacyCourse?.key || fallbackClassKey(student.className), className: student.className, status: "active", enrolledAt: student.createdAt, createdAt: student.createdAt, updatedAt: now }).onConflictDoNothing();
    enrollmentRows = (await activeEnrollments(db, studentId)).filter(function(item) {
      const name = String(item.className || "").trim().toLocaleLowerCase("vi");
      return name && name !== "chưa xếp lớp" && name !== "chua xep lop";
    });
  }

  const [classRows, scheduleRows, sessionRows, assignmentRows, submissionRows, teacherCompletionRows, itemRows, transactionRows, rewards, redemptionRows] = await Promise.all([
    db.select().from(adminItems).where(eq(adminItems.kind, "classes")).orderBy(asc(adminItems.id)),
    db.select().from(courseSchedules).orderBy(asc(courseSchedules.sortOrder)),
    db.select().from(courseSessions).orderBy(asc(courseSessions.sessionDate), asc(courseSessions.startTime)),
    db.select().from(assignments).orderBy(desc(assignments.id)),
    db.select().from(assignmentSubmissions).where(eq(assignmentSubmissions.studentId, studentId)),
    db.select().from(assignmentTeacherCompletions).where(eq(assignmentTeacherCompletions.studentId, studentId)),
    db.select().from(adminItems).orderBy(desc(adminItems.id)),
    db.select().from(pointTransactions).where(eq(pointTransactions.studentId, studentId)).orderBy(desc(pointTransactions.id)),
    db.select().from(rewardItems).where(eq(rewardItems.active, true)).orderBy(desc(rewardItems.id)),
    db.select().from(rewardRedemptions).where(eq(rewardRedemptions.studentId, studentId)).orderBy(desc(rewardRedemptions.id)),
  ]);

  const classMap = new Map(classRows.map(function(row) { return [row.itemKey, courseData(row)]; }));
  const enrollmentKeys = new Set(enrollmentRows.map(function(item) { return item.classKey; }));
  const submissionMap = new Map(submissionRows.filter(function(row) { return row.status !== "teacher_completed"; }).map(function(row) { return [row.assignmentId, row]; }));
  const teacherCompletionMap = new Map(teacherCompletionRows.map(function(row) { return [row.assignmentId, row]; }));
  const submissionIds = submissionRows.filter(function(row) { return row.status !== "teacher_completed"; }).map(function(row) { return row.id; });
  const submissionFileRows = submissionIds.length
    ? await db.select().from(assignmentSubmissionFiles).where(inArray(assignmentSubmissionFiles.submissionId, submissionIds)).orderBy(asc(assignmentSubmissionFiles.id))
    : [];
  const filesBySubmission = new Map<number, typeof assignmentSubmissionFiles.$inferSelect[]>();
  submissionFileRows.forEach(function(file) {
    const current = filesBySubmission.get(file.submissionId) || [];
    current.push(file);
    filesBySubmission.set(file.submissionId, current);
  });
  const attendedMakeupSessionIds = new Set(itemRows.filter(function(item) { return item.kind === "attendance"; }).flatMap(function(item) {
    const data = decode(item.data);
    const sessionId = Number(data.sessionId || 0);
    const states = (data.states || {}) as Record<string, string>;
    return sessionId > 0 && Boolean(states[student.code]) ? [sessionId] : [];
  }));
  const allCourses = enrollmentRows.map(function(enrollment, index) {
    const stored = classMap.get(enrollment.classKey);
    const course = stored || { id: 0, key: enrollment.classKey, name: enrollment.className, label: "", teacher: "Giáo viên", room: "", tone: ["indigo", "green", "orange"][index % 3], logoUrl: "", legacySchedule: "", legacyStartTime: "", legacyEndTime: "" };
    let schedules = scheduleRows.filter(function(item) { return item.classKey === enrollment.classKey; });
    if (!schedules.length) schedules = legacyWeekdays(course.legacySchedule).map(function(weekday, order) { return { id: -(order + 1), classKey: course.key, weekday, startTime: course.legacyStartTime || "08:00", endTime: course.legacyEndTime || "09:30", room: course.room, sortOrder: order, createdAt: "", updatedAt: "" }; });
    const courseAssignments = assignmentRows.filter(function(item) { return item.classKey === course.key || (!item.classKey && item.className === course.name); });
    const unread = itemRows.filter(function(item) {
      if (item.kind !== "notifications") return false;
      const data = decode(item.data);
      const audience = String(data.audience || "");
      const allowed = (!data.classKey && !data.className) || String(data.classKey || "") === course.key || String(data.className || "") === course.name;
      const targeted = audience === "student" ? Number(data.studentId) === studentId : audience === "all_students" || !audience;
      const readIds = Array.isArray(data.readByStudentIds) ? data.readByStudentIds.map(Number) : [];
      return allowed && targeted && !readIds.includes(studentId) && !data.studentReadAt;
    }).length;
    const courseSessionsForCard = sessionRows.filter(function(item) { return item.classKey === course.key && item.status !== "cancelled"; });
    const pendingMakeupSessions = courseSessionsForCard.filter(function(item) { return item.sessionType === "makeup" && !attendedMakeupSessionIds.has(item.id); }).length;
    return { ...course, schedules, upcomingSessions: courseSessionsForCard.slice(0, 3), pendingMakeupSessions, pendingAssignments: courseAssignments.filter(function(item) { const submission = submissionMap.get(item.id); return !isAssignmentCompletedStatus(submission?.status) && !teacherCompletionMap.has(item.id) && getAssignmentStatus(item.dueDate) !== "Đã kết thúc"; }).length, unreadNotifications: unread };
  });

  const enrollmentNames = new Set(enrollmentRows.map(function(item) { return item.className; }));
  const globalNotifications = itemRows.filter(function(item) {
    if (item.kind !== "notifications") return false;
    const data = decode(item.data);
    const audience = String(data.audience || "");
    const classKey = String(data.classKey || "");
    const className = String(data.className || "");
    const courseAllowed = (!classKey && !className) || enrollmentKeys.has(classKey) || enrollmentNames.has(className);
    if (audience === "student") return Number(data.studentId) === studentId && courseAllowed;
    if (audience === "all_students") return courseAllowed;
    const target = String(data.target || "");
    if (!audience && target === "Toàn bộ học sinh") return true;
    if (!audience && (target === "Một lớp" || target === "")) return courseAllowed;
    return false;
  }).map(function(item) {
    const data = decode(item.data);
    const readIds = Array.isArray(data.readByStudentIds) ? data.readByStudentIds.map(Number) : [];
    const audience = String(data.audience || "");
    const classKey = String(data.classKey || "");
    const className = String(data.className || "");
    const matchedEnrollment = classKey
      ? enrollmentRows.find(function(row) { return row.classKey === classKey; })
      : enrollmentRows.find(function(row) { return className && row.className === className; });
    return {
      id: item.id,
      title: item.title,
      body: String(data.body || ""),
      createdAt: item.createdAt,
      read: audience === "student" ? Boolean(data.studentReadAt) : readIds.includes(studentId),
      actionView: String(data.actionView || "overview"),
      courseKey: matchedEnrollment?.classKey || "",
      courseName: matchedEnrollment?.className || className || "Thông báo chung",
    };
  }).sort(function(a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });

  const profileRow = itemRows.find(function(item) { return item.kind === "settings" && item.itemKey === "profile"; });
  const siteProfile = profileRow ? decode(profileRow.data) : {};
  const rewardMap = new Map(rewards.map(function(reward) { return [reward.id, reward]; }));
  const balance = transactionRows.reduce(function(total, row) { return total + row.delta; }, 0);
  const common = {
    student: { id: student.id, code: student.code, name: student.name, className: student.className, status: student.status },
    site: { siteName: String(siteProfile.siteName || "EduFlow"), logoUrl: String(siteProfile.logoUrl || ""), schoolName: String(siteProfile.schoolName || "") },
    courses: allCourses,
    sessions: sessionRows.filter(function(item) { return enrollmentKeys.has(item.classKey) && item.status !== "cancelled"; }),
    notifications: globalNotifications,
    points: balance,
    transactions: transactionRows,
    rewards,
    redemptions: redemptionRows.map(function(row) { return { ...row, rewardTitle: rewardMap.get(row.rewardId)?.title || "Quà đã ngừng" }; }),
  };

  const requestedCourseKey = String(new URL(request.url).searchParams.get("courseId") || "");
  if (!requestedCourseKey) return Response.json(common, { headers: { "Cache-Control": "no-store" } });
  if (!enrollmentKeys.has(requestedCourseKey) || !await studentCanAccessCourse(db, studentId, requestedCourseKey)) return Response.json({ error: "Bạn chưa tham gia môn học này." }, { status: 403 });
  const selectedCourse = allCourses.find(function(item) { return item.key === requestedCourseKey; });
  if (!selectedCourse) return Response.json({ error: "Không tìm thấy môn học." }, { status: 404 });

  const selectedAssignments = assignmentRows.filter(function(item) { return item.classKey === requestedCourseKey || (!item.classKey && item.className === selectedCourse.name); }).map(function(row) {
    const submission = submissionMap.get(row.id);
    const teacherCompletion = teacherCompletionMap.get(row.id);
    return {
      ...row,
      status: getAssignmentStatus(row.dueDate),
      teacherCompletedAt: teacherCompletion?.completedAt || null,
      submission: submission ? {
        id: submission.id,
        submittedAt: submission.submittedAt,
        responseText: submission.responseText,
        fileName: submission.fileName,
        fileSize: submission.fileSize,
        contentType: submission.contentType,
        files: (filesBySubmission.get(submission.id) || []).map(function(file) { return { id: file.id, fileName: file.fileName, fileSize: file.fileSize, contentType: file.contentType }; }),
        status: submission.status,
        score: submission.score,
        feedback: submission.feedback,
        gradedAt: submission.gradedAt,
        updatedAt: submission.updatedAt,
      } : null,
    };
  });

  let gradeSum = 0, gradeWeight = 0;
  const gradebooks: { title: string; term: string; assessments: { id: string; title: string; maxScore: number; weight: number; date: string; score: number | null }[] }[] = [];
  const applicableGradeRows = itemRows.filter(function(item) {
    if (item.kind !== "grades") return false;
    const data = decode(item.data);
    return String(data.classKey || "") === requestedCourseKey || (!data.classKey && (String(data.className || student.className) === selectedCourse.name || String(data.className || "") === "Tất cả lớp"));
  });
  const hasModernGradebook = applicableGradeRows.some(function(item) { return Array.isArray(decode(item.data).assessments); });
  const seenAssessments = new Set<string>();
  applicableGradeRows.forEach(function(item) {
    const data = decode(item.data);
    const modern = Array.isArray(data.assessments);
    if (!modern && hasModernGradebook) return;
    const term = String(data.term || item.title || "Sổ điểm");
    const assessments: { id: string; title: string; maxScore: number; weight: number; date: string; score: number | null }[] = [];
    if (modern) {
      const scores = (data.scores || {}) as Record<string, Record<string, number | null>>;
      (data.assessments as Record<string, unknown>[]).forEach(function(raw, index) {
        const id = String(raw.id || "assessment-" + index);
        const title = String(raw.title || "Bài kiểm tra " + (index + 1));
        const signature = normalized(term) + "|" + normalized(title);
        if (seenAssessments.has(signature)) return;
        seenAssessments.add(signature);
        const maxScore = Math.max(.1, Number(raw.maxScore) || 10);
        const weight = Math.max(0, Number(raw.weight) || 0);
        const score = scores[student.code]?.[id];
        const parsed = score === null || score === undefined ? null : Number(score);
        assessments.push({ id, title, maxScore, weight, date: String(raw.date || ""), score: parsed });
        if (parsed !== null && weight > 0) { gradeSum += (parsed / maxScore) * 10 * weight; gradeWeight += weight; }
      });
    } else {
      const labels = ["Bài 1", "Bài 2", "Giữa kỳ", "Cuối kỳ"];
      const weights = Array.isArray(data.weights) ? data.weights.map(Number) : [20, 30, 20, 30];
      const legacyScores = (data.scores || {}) as Record<string, number[]>;
      const row = Array.isArray(legacyScores[student.code]) ? legacyScores[student.code] : [];
      labels.forEach(function(title, index) { const signature = normalized(term) + "|" + normalized(title); if (seenAssessments.has(signature)) return; seenAssessments.add(signature); const score = Number.isFinite(Number(row[index])) ? Number(row[index]) : null; const weight = Number(weights[index]) || 0; assessments.push({ id: "legacy-" + index, title, maxScore: 10, weight, date: "", score }); if (score !== null && weight > 0) { gradeSum += score * weight; gradeWeight += weight; } });
    }
    if (assessments.length) gradebooks.push({ title: item.title, term, assessments });
  });

  const attendance = itemRows.filter(function(item) { return item.kind === "attendance"; }).map(function(item) {
    const data = decode(item.data);
    const savedClassKey = String(data.classKey || data.classId || "");
    const correctCourse = savedClassKey === requestedCourseKey || (!savedClassKey && String(data.className || "") === selectedCourse.name);
    if (!correctCourse) return null;
    const states = (data.states || {}) as Record<string, string>;
    const status = states[student.code];
    if (!status) return null;
    return { id: item.id, title: item.title, classKey: requestedCourseKey, className: selectedCourse.name, date: String(data.date || ""), startTime: String(data.startTime || ""), endTime: String(data.endTime || ""), status, sessionType: String(data.sessionType || "regular"), sessionId: Number(data.sessionId || 0), note: String(((data.notes || {}) as Record<string, unknown>)[student.code] || "") };
  }).filter(function(item): item is NonNullable<typeof item> { return item !== null; }).sort(function(a, b) { return (b.date + b.startTime).localeCompare(a.date + a.startTime); });
  const present = attendance.filter(function(item) { return item.status === "present" || item.status === "late"; }).length;

  const documents = itemRows.filter(function(item) {
    if (item.kind !== "documents") return false;
    const data = decode(item.data);
    const folder = String(data.folder || "Tài liệu chung");
    const legacyFolderAllowed = folder === "Tài liệu chung" || folder === student.className;
    return folder === "Tài liệu chung" || folder === selectedCourse.name || (!selectedCourse && legacyFolderAllowed);
  }).map(function(item) { const data = decode(item.data); return { id: item.id, name: item.title, folder: String(data.folder || "Tài liệu chung"), size: Number(data.size) || 0, contentType: String(data.contentType || ""), createdAt: item.createdAt }; }).sort(function(a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });

  const calendar = itemRows.filter(function(item) {
    if (item.kind !== "calendar") return false;
    const data = decode(item.data);
    return String(data.classKey || "") === requestedCourseKey || (!data.classKey && (!data.className || String(data.className) === selectedCourse.name));
  }).map(function(item) { const data = decode(item.data); const fallbackDay = String(Math.max(1, Math.min(31, Number(data.day) || 1))).padStart(2, "0"); const date = String(data.date || "2026-08-" + fallbackDay); const time = String(data.time || ""); return { id: item.id, title: item.title, date: time && !date.includes("T") ? date + "T" + time : date, type: String(data.type || "Kiểm tra"), details: String(data.details || data.body || "") }; });

  const comments = itemRows.filter(function(item) {
    if (item.kind !== "comments") return false;
    const data = decode(item.data);
    return (Number(data.studentId) === studentId || String(data.studentCode || "") === student.code) && (String(data.classKey || "") === requestedCourseKey || (!data.classKey && String(data.className || student.className) === selectedCourse.name));
  }).map(function(item) { const data = decode(item.data); return { id: item.id, content: String(data.content || ""), date: String(data.commentDate || item.createdAt.slice(0, 10)), type: String(data.commentType || "Theo ngày"), creator: String(data.creator || selectedCourse.teacher), createdAt: item.createdAt }; }).sort(function(a, b) {
    const byDate = String(b.date).localeCompare(String(a.date));
    return byDate || String(b.createdAt).localeCompare(String(a.createdAt));
  });

  return Response.json({
    ...common,
    course: selectedCourse,
    average: gradeWeight ? Number((gradeSum / gradeWeight).toFixed(1)) : null,
    attendanceRate: attendance.length ? Math.round(present / attendance.length * 100) : null,
    attendance,
    gradebooks,
    assignments: selectedAssignments,
    submissions: Array.from(new Set(
      submissionRows.filter(function(row) { return isAssignmentCompletedStatus(row.status) && row.status !== "teacher_completed" && selectedAssignments.some(function(item) { return item.id === row.assignmentId; }); }).map(function(row) { return row.assignmentId; })
        .concat(teacherCompletionRows.filter(function(row) { return selectedAssignments.some(function(item) { return item.id === row.assignmentId; }); }).map(function(row) { return row.assignmentId; }))
    )),
    calendar,
    documents,
    comments,
    sessions: sessionRows.filter(function(item) { return item.classKey === requestedCourseKey && item.status !== "cancelled"; }),
  }, { headers: { "Cache-Control": "no-store" } });
}
