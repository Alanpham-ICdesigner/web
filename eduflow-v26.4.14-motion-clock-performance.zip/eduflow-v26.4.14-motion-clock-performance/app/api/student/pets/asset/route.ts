import { getStudentSessionId } from "../../../../../lib/student-auth";
import { isAllowedPetdexAsset } from "../../../../../lib/petdex-catalog";

function imageContentType(source: string, upstream: Response): string {
  const upstreamType = String(upstream.headers.get("content-type") || "").split(";", 1)[0].trim().toLowerCase();
  if (upstreamType === "image/webp" || upstreamType === "image/png") return upstreamType;
  return source.toLowerCase().endsWith(".png") ? "image/png" : "image/webp";
}

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });

  const url = new URL(request.url);
  const petId = String(url.searchParams.get("pet") || "unknown").slice(0, 80);
  const source = String(url.searchParams.get("src") || "");
  if (!isAllowedPetdexAsset(source)) {
    console.warn("[EDUFLOW Petdex] Rejected asset URL", { petId });
    return Response.json({ error: "Đường dẫn hình pet không hợp lệ." }, { status: 400 });
  }

  try {
    // Fetch on the Worker and stream the public Petdex image back from the
    // EDUFLOW origin. This deliberately does NOT redirect the browser to R2:
    // direct cross-origin image requests were the reason remote cards rendered
    // as broken <img> elements while Punch (local) still worked.
    const upstream = await fetch(source, {
      headers: { Accept: "image/avif,image/webp,image/png,image/*,*/*;q=0.8" },
      redirect: "follow",
      signal: AbortSignal.timeout(15_000),
    });
    if (!upstream.ok || !upstream.body) {
      console.warn("[EDUFLOW Petdex] Upstream asset failed", { petId, status: upstream.status });
      return new Response("Không tải được hình pet.", { status: upstream.status === 404 ? 404 : 502 });
    }

    // Keep transport headers such as Content-Encoding so the upstream byte
    // stream remains valid, but strip headers that should not be reflected.
    const headers = new Headers(upstream.headers);
    headers.delete("Set-Cookie");
    headers.delete("Content-Disposition");
    headers.set("Content-Type", imageContentType(source, upstream));
    headers.set("Cache-Control", "public, max-age=86400, s-maxage=604800, stale-while-revalidate=86400");
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Cross-Origin-Resource-Policy", "same-origin");

    return new Response(upstream.body, { status: 200, headers });
  } catch (error) {
    console.warn("[EDUFLOW Petdex] Asset proxy error", { petId, error });
    return new Response("Không tải được hình pet.", { status: 502 });
  }
}
