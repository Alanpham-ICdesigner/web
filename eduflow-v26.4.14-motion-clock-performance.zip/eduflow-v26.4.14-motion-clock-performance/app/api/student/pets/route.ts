import { getStudentSessionId } from "../../../../lib/student-auth";
import { clientPetdexPet, petdexCatalogSnapshot } from "../../../../lib/petdex-catalog";

export async function GET(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const url = new URL(request.url);
  const query = String(url.searchParams.get("q") || "").trim().toLowerCase();
  const kind = String(url.searchParams.get("kind") || "").trim().toLowerCase();
  const tag = String(url.searchParams.get("tag") || "").trim().toLowerCase();
  const version = String(url.searchParams.get("version") || "").trim().toLowerCase();
  const force = url.searchParams.get("refresh") === "1";
  const limit = Math.min(48, Math.max(8, Number(url.searchParams.get("limit")) || 24));
  const offset = Math.max(0, Math.floor(Number(url.searchParams.get("offset")) || 0));
  const snapshot = await petdexCatalogSnapshot(force);
  const searched = query
    ? snapshot.pets.filter(function(pet) {
        return pet.slug.includes(query) || pet.displayName.toLowerCase().includes(query) || pet.tags.some(function(item) { return item.toLowerCase().includes(query); });
      })
    : snapshot.pets;
  const filtered = searched
    .filter(function(pet) { return !kind || pet.kind === kind; })
    .filter(function(pet) { return !tag || pet.tags.some(function(item) { return item.toLowerCase() === tag; }); })
    .filter(function(pet) { return !version || pet.version === version; });
  const kinds = Array.from(new Set(searched.map(function(pet) { return pet.kind; }).filter(Boolean))).sort();
  const versions = Array.from(new Set(searched.map(function(pet) { return pet.version; }).filter(Boolean))).sort();
  const tagCounts = new Map<string, number>();
  for (const pet of searched) for (const item of pet.tags) tagCounts.set(item, (tagCounts.get(item) || 0) + 1);
  const tags = Array.from(tagCounts.entries())
    .sort(function(a, b) { return b[1] - a[1] || a[0].localeCompare(b[0]); })
    .slice(0, 30)
    .map(function(item) { return item[0]; });
  return Response.json({
    pets: filtered.slice(offset, offset + limit).map(clientPetdexPet),
    total: filtered.length,
    offset,
    nextOffset: offset + limit < filtered.length ? offset + limit : null,
    facets: { kinds, tags, versions },
    warning: snapshot.warning,
  }, {
    headers: { "Cache-Control": "private, no-store" },
  });
}
