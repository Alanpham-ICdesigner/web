import { eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { pointTransactions, rewardItems, rewardRedemptions, students } from "../../../../db/schema";
import { getStudentSessionId } from "../../../../lib/student-auth";
import { createAutomaticNotification, createPointNotification } from "../../../../lib/notifications";

export async function POST(request: Request) {
  const studentId = await getStudentSessionId(request);
  if (!studentId) return Response.json({ error: "Vui lòng đăng nhập học sinh." }, { status: 401 });
  const payload = await request.json().catch(function() { return {}; }) as { rewardId?: number };
  const rewardId = Number(payload.rewardId);
  if (!rewardId) return Response.json({ error: "Vui lòng chọn quà cần đổi." }, { status: 400 });
  const db = await getDb();
  const rewards = await db.select().from(rewardItems).where(eq(rewardItems.id, rewardId)).limit(1);
  const reward = rewards[0];
  if (!reward || !reward.active) return Response.json({ error: "Quà này hiện không còn mở đổi." }, { status: 404 });
  if (reward.stock < 1) return Response.json({ error: "Quà đã hết số lượng." }, { status: 409 });
  const transactions = await db.select({ delta: pointTransactions.delta }).from(pointTransactions).where(eq(pointTransactions.studentId, studentId));
  const balance = transactions.reduce(function(total, row) { return total + row.delta; }, 0);
  if (balance < reward.cost) return Response.json({ error: "Bạn chưa đủ điểm để đổi món quà này." }, { status: 400 });
  const now = new Date().toISOString();
  await db.insert(rewardRedemptions).values({ studentId, rewardId, cost: reward.cost, status: "pending", createdAt: now });
  await db.insert(pointTransactions).values({ studentId, delta: -reward.cost, reason: "Đổi quà: " + reward.title, source: "redemption", createdAt: now });
  await db.update(rewardItems).set({ stock: reward.stock - 1, updatedAt: now }).where(eq(rewardItems.id, rewardId));
  const studentRows = await db.select({ name: students.name, code: students.code }).from(students).where(eq(students.id, studentId)).limit(1);
  const student = studentRows[0];
  await createAutomaticNotification({ audience: "admin", title: "Yêu cầu đổi quà mới", body: (student?.name || "Một học sinh") + " (" + (student?.code || "") + ") muốn đổi “" + reward.title + "” với " + reward.cost + " điểm.", actionView: "rewardstore", category: "redemption" });
  await createPointNotification(studentId, -reward.cost, "Đã giữ điểm cho yêu cầu đổi quà: " + reward.title);
  return Response.json({ success: true, points: balance - reward.cost });
}
