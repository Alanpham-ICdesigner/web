import { desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { adminItems } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";
import { decodeNotification } from "../../../lib/notifications";

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "notifications")).orderBy(desc(adminItems.id));
  return Response.json({ notifications: rows.map(function(row) {
    const data = decodeNotification(row.data);
    if (data.audience !== "admin") return null;
    return { id: row.id, title: row.title, body: String(data.body || ""), createdAt: row.createdAt, read: Boolean(data.adminReadAt), actionView: String(data.actionView || "dashboard") };
  }).filter(Boolean) }, { headers: { "Cache-Control": "no-store" } });
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { id?: number; all?: boolean };
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "notifications"));
  const now = new Date().toISOString();
  for (const row of rows) {
    const data = decodeNotification(row.data);
    if (data.audience !== "admin" || (!payload.all && row.id !== Number(payload.id))) continue;
    data.adminReadAt = now;
    await db.update(adminItems).set({ data: JSON.stringify(data), updatedAt: now }).where(eq(adminItems.id, row.id));
  }
  return Response.json({ success: true });
}
