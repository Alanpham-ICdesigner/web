import { and, asc, eq, gte, lte } from "drizzle-orm";
import { getDb } from "../../../db";
import { courseSessions } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";
import { resolveCourse } from "../../../lib/course-access";

function dateOnly(value: unknown): string {
  const text = String(value || "");
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : "";
}

function timeOnly(value: unknown): string {
  const text = String(value || "");
  return /^\d{2}:\d{2}$/.test(text) ? text : "";
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const url = new URL(request.url);
  const classKey = String(url.searchParams.get("classKey") || "");
  const from = dateOnly(url.searchParams.get("from"));
  const to = dateOnly(url.searchParams.get("to"));
  const conditions = [];
  if (classKey) conditions.push(eq(courseSessions.classKey, classKey));
  if (from) conditions.push(gte(courseSessions.sessionDate, from));
  if (to) conditions.push(lte(courseSessions.sessionDate, to));
  const db = await getDb();
  const rows = conditions.length
    ? await db.select().from(courseSessions).where(and(...conditions)).orderBy(asc(courseSessions.sessionDate), asc(courseSessions.startTime))
    : await db.select().from(courseSessions).orderBy(asc(courseSessions.sessionDate), asc(courseSessions.startTime));
  return Response.json({ sessions: rows }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as Record<string, unknown>;
  const db = await getDb();
  const course = await resolveCourse(db, { classKey: String(payload.classKey || ""), className: String(payload.className || "") });
  const sessionDate = dateOnly(payload.sessionDate);
  const startTime = timeOnly(payload.startTime);
  const endTime = timeOnly(payload.endTime);
  const sessionType = String(payload.sessionType || "makeup") === "regular" ? "regular" : "makeup";
  if (!course || !sessionDate || !startTime || !endTime || startTime >= endTime) return Response.json({ error: "Vui lòng nhập đầy đủ lớp, ngày và giờ hợp lệ." }, { status: 400 });
  const now = new Date().toISOString();
  const rows = await db.insert(courseSessions).values({
    classKey: course.key,
    className: course.name,
    sessionType,
    sessionDate,
    startTime,
    endTime,
    note: String(payload.note || "").trim().slice(0, 1000),
    status: "scheduled",
    createdAt: now,
    updatedAt: now,
  }).returning();
  return Response.json({ session: rows[0] }, { status: 201 });
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as Record<string, unknown>;
  const id = Number(payload.id);
  const db = await getDb();
  const course = await resolveCourse(db, { classKey: String(payload.classKey || ""), className: String(payload.className || "") });
  const sessionDate = dateOnly(payload.sessionDate);
  const startTime = timeOnly(payload.startTime);
  const endTime = timeOnly(payload.endTime);
  if (!id || !course || !sessionDate || !startTime || !endTime || startTime >= endTime) return Response.json({ error: "Dữ liệu buổi học không hợp lệ." }, { status: 400 });
  const rows = await db.update(courseSessions).set({
    classKey: course.key,
    className: course.name,
    sessionType: String(payload.sessionType || "makeup") === "regular" ? "regular" : "makeup",
    sessionDate,
    startTime,
    endTime,
    note: String(payload.note || "").trim().slice(0, 1000),
    status: String(payload.status || "scheduled"),
    updatedAt: new Date().toISOString(),
  }).where(eq(courseSessions.id, id)).returning();
  return rows[0] ? Response.json({ session: rows[0] }) : Response.json({ error: "Không tìm thấy buổi học." }, { status: 404 });
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { id?: number };
  const id = Number(payload.id);
  if (!id) return Response.json({ error: "Thiếu buổi học cần xóa." }, { status: 400 });
  await (await getDb()).delete(courseSessions).where(eq(courseSessions.id, id));
  return Response.json({ success: true });
}
