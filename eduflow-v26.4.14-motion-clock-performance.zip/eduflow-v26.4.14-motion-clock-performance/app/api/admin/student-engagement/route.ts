import { requireAdmin } from "../../../../lib/admin-auth";
import { reconcileAllExpiredFocusTimers } from "../../../../lib/focus-timer";
import { mondayDateKey, shiftDateKey, vietnamDateKey } from "../../../../lib/student-companion";
import { sendPushToStudent } from "../../../../lib/web-push";

type PeriodMode = "day" | "week" | "month";

type EngagementRow = {
  student_id: number;
  student_code: string;
  student_name: string;
  legacy_class_name: string;
  class_keys: string | null;
  class_names: string | null;
  current_streak: number | null;
  longest_streak: number | null;
  total_checkins: number | null;
  last_checkin_date: string | null;
  period_checkins: number | null;
  latest_period_checkin: string | null;
  earliest_period_checkin_at: string | null;
  tracked_focus_minutes: number | null;
  manual_focus_minutes: number | null;
  focus_sessions: number | null;
  day_manual_focus_minutes: number | null;
  day_manual_focus_note: string | null;
  focus_timer_mode: string | null;
  focus_timer_status: string | null;
  focus_timer_remaining_ms: number | null;
  focus_timer_ends_at: string | null;
};

type AdjustmentHistoryRow = {
  id: number;
  student_id: number;
  student_code: string;
  student_name: string;
  legacy_class_name: string;
  class_keys: string | null;
  class_names: string | null;
  date_key: string;
  previous_manual_minutes: number;
  manual_minutes: number;
  delta_minutes: number;
  tracked_focus_minutes_snapshot: number;
  focus_minutes_after: number;
  note: string;
  created_at: string;
};

async function database() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("D1 binding DB is unavailable");
  return env.DB as D1Database;
}

function validDateKey(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parts = value.split("-").map(Number);
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
  return date.toISOString().slice(0, 10) === value;
}

function splitGroup(value: string | null, fallback = ""): string[] {
  const parts = String(value || "")
    .split("||")
    .map(function(item) { return item.trim(); })
    .filter(Boolean);
  if (parts.length) return Array.from(new Set(parts));
  return fallback ? [fallback] : [];
}

function monthStartDateKey(dateKey: string): string {
  return dateKey.slice(0, 7) + "-01";
}

function monthEndDateKey(dateKey: string): string {
  const parts = dateKey.split("-").map(Number);
  return new Date(Date.UTC(parts[0], parts[1], 0)).toISOString().slice(0, 10);
}

function requestedPeriod(value: string | null): PeriodMode {
  if (value === "week") return "week";
  if (value === "month") return "month";
  return "day";
}

function formatDateKey(dateKey: string): string {
  const parts = dateKey.split("-");
  return parts.length === 3 ? parts[2] + "/" + parts[1] + "/" + parts[0] : dateKey;
}

function formatMinutes(totalMinutes: number): string {
  const minutes = Math.max(0, Math.round(totalMinutes));
  const hours = Math.floor(minutes / 60);
  const remain = minutes % 60;
  if (!hours) return remain + " phút";
  if (!remain) return hours + " giờ";
  return hours + " giờ " + remain + " phút";
}

async function adjustmentHistory(db: D1Database, limit: number) {
  const result = await db.prepare(`
    WITH active_enrollments AS (
      SELECT
        student_id,
        GROUP_CONCAT(class_key, '||') AS class_keys,
        GROUP_CONCAT(class_name, '||') AS class_names
      FROM (
        SELECT student_id, class_key, class_name
        FROM student_enrollments
        WHERE status = 'active'
        ORDER BY class_name COLLATE NOCASE, class_key
      )
      GROUP BY student_id
    )
    SELECT
      h.id,
      h.student_id,
      s.code AS student_code,
      s.name AS student_name,
      s.class_name AS legacy_class_name,
      e.class_keys,
      e.class_names,
      h.date_key,
      h.previous_manual_minutes,
      h.manual_minutes,
      h.delta_minutes,
      h.tracked_focus_minutes_snapshot,
      h.focus_minutes_after,
      h.note,
      h.created_at
    FROM student_focus_adjustment_history h
    INNER JOIN students s ON s.id = h.student_id
    LEFT JOIN active_enrollments e ON e.student_id = s.id
    ORDER BY h.created_at DESC, h.id DESC
    LIMIT ?
  `).bind(limit).all() as { results?: AdjustmentHistoryRow[] };

  return (result.results || []).map(function(row) {
    return {
      id: Number(row.id),
      studentId: Number(row.student_id),
      code: String(row.student_code || ""),
      name: String(row.student_name || ""),
      classKeys: splitGroup(row.class_keys),
      classNames: splitGroup(row.class_names, row.legacy_class_name || ""),
      date: String(row.date_key || ""),
      previousManualMinutes: Math.max(0, Number(row.previous_manual_minutes) || 0),
      manualMinutes: Math.max(0, Number(row.manual_minutes) || 0),
      deltaMinutes: Number(row.delta_minutes) || 0,
      trackedFocusMinutes: Math.max(0, Number(row.tracked_focus_minutes_snapshot) || 0),
      focusMinutesAfter: Math.max(0, Number(row.focus_minutes_after) || 0),
      note: String(row.note || ""),
      createdAt: String(row.created_at || ""),
    };
  });
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;

  const url = new URL(request.url);
  if (url.searchParams.get("view") === "adjustment-history") {
    try {
      const db = await database();
      const requestedLimit = Number(url.searchParams.get("limit") || 60);
      const limit = Number.isInteger(requestedLimit) ? Math.min(100, Math.max(1, requestedLimit)) : 60;
      const history = await adjustmentHistory(db, limit);
      return Response.json({ history }, { headers: { "Cache-Control": "no-store" } });
    } catch (error) {
      return Response.json({
        error: error instanceof Error ? error.message : "Không thể tải lịch sử bổ sung Pomodoro.",
      }, { status: 500, headers: { "Cache-Control": "no-store" } });
    }
  }
  const mode = requestedPeriod(url.searchParams.get("period"));
  const today = vietnamDateKey();
  const requestedDate = String(url.searchParams.get("date") || "").trim();
  const anchorDate = validDateKey(requestedDate) && requestedDate <= today ? requestedDate : today;
  const periodStart = mode === "week" ? mondayDateKey(anchorDate) : mode === "month" ? monthStartDateKey(anchorDate) : anchorDate;
  const naturalPeriodEnd = mode === "week" ? shiftDateKey(periodStart, 6) : mode === "month" ? monthEndDateKey(anchorDate) : anchorDate;
  const periodEnd = naturalPeriodEnd > today ? today : naturalPeriodEnd;
  const periodDayCount = Math.max(1, Math.round((Date.parse(periodEnd + "T00:00:00Z") - Date.parse(periodStart + "T00:00:00Z")) / 86_400_000) + 1);

  try {
    const db = await database();
    const serverNow = new Date();
    // Keep teacher statistics accurate even when a student closed every tab before
    // the Focus boundary. Reconciliation records only already-expired sessions and
    // pauses the next phase; it never advances a second phase in the background.
    await reconcileAllExpiredFocusTimers(db, new Date());
    const result = await db.prepare(`
      WITH active_enrollments AS (
        SELECT
          student_id,
          GROUP_CONCAT(class_key, '||') AS class_keys,
          GROUP_CONCAT(class_name, '||') AS class_names
        FROM (
          SELECT student_id, class_key, class_name
          FROM student_enrollments
          WHERE status = 'active'
          ORDER BY class_name COLLATE NOCASE, class_key
        )
        GROUP BY student_id
      ),
      period_checkins AS (
        SELECT
          student_id,
          COUNT(*) AS period_checkins,
          MAX(checkin_date) AS latest_period_checkin,
          MIN(checked_at) AS earliest_period_checkin_at
        FROM student_daily_checkins
        WHERE checkin_date >= ? AND checkin_date <= ?
        GROUP BY student_id
      ),
      period_focus AS (
        SELECT
          student_id,
          COALESCE(SUM(focus_minutes), 0) AS focus_minutes,
          COUNT(*) AS focus_sessions
        FROM student_focus_sessions
        WHERE date_key >= ? AND date_key <= ?
        GROUP BY student_id
      ),
      period_manual AS (
        SELECT
          student_id,
          COALESCE(SUM(manual_minutes), 0) AS manual_focus_minutes
        FROM student_focus_adjustments
        WHERE date_key >= ? AND date_key <= ?
        GROUP BY student_id
      ),
      day_manual AS (
        SELECT student_id, manual_minutes, note
        FROM student_focus_adjustments
        WHERE date_key = ?
      )
      SELECT
        s.id AS student_id,
        s.code AS student_code,
        s.name AS student_name,
        s.class_name AS legacy_class_name,
        e.class_keys,
        e.class_names,
        COALESCE(p.current_streak, 0) AS current_streak,
        COALESCE(p.longest_streak, 0) AS longest_streak,
        COALESCE(p.total_checkins, 0) AS total_checkins,
        COALESCE(p.last_checkin_date, '') AS last_checkin_date,
        COALESCE(c.period_checkins, 0) AS period_checkins,
        COALESCE(c.latest_period_checkin, '') AS latest_period_checkin,
        COALESCE(c.earliest_period_checkin_at, '') AS earliest_period_checkin_at,
        COALESCE(f.focus_minutes, 0) AS tracked_focus_minutes,
        COALESCE(m.manual_focus_minutes, 0) AS manual_focus_minutes,
        COALESCE(f.focus_sessions, 0) AS focus_sessions,
        COALESCE(dm.manual_minutes, 0) AS day_manual_focus_minutes,
        COALESCE(dm.note, '') AS day_manual_focus_note,
        COALESCE(t.mode, 'focus') AS focus_timer_mode,
        COALESCE(t.status, 'idle') AS focus_timer_status,
        COALESCE(t.remaining_ms, 0) AS focus_timer_remaining_ms,
        COALESCE(t.ends_at, '') AS focus_timer_ends_at
      FROM students s
      LEFT JOIN active_enrollments e ON e.student_id = s.id
      LEFT JOIN student_pet_profiles p ON p.student_id = s.id
      LEFT JOIN period_checkins c ON c.student_id = s.id
      LEFT JOIN period_focus f ON f.student_id = s.id
      LEFT JOIN period_manual m ON m.student_id = s.id
      LEFT JOIN day_manual dm ON dm.student_id = s.id
      LEFT JOIN student_focus_timer_state t ON t.student_id = s.id
      ORDER BY s.name COLLATE NOCASE, s.id
    `).bind(periodStart, periodEnd, periodStart, periodEnd, periodStart, periodEnd, anchorDate).all() as { results?: EngagementRow[] };

    const rows = (result.results || []).map(function(row) {
      const classNames = splitGroup(row.class_names, row.legacy_class_name || "");
      const classKeys = splitGroup(row.class_keys);
      const showLiveTimer = mode === "day" && anchorDate === today;
      const trackedFocusMinutes = Math.max(0, Number(row.tracked_focus_minutes) || 0);
      const manualFocusMinutes = Math.max(0, Number(row.manual_focus_minutes) || 0);
      return {
        studentId: Number(row.student_id),
        code: String(row.student_code || ""),
        name: String(row.student_name || ""),
        classKeys,
        classNames,
        currentStreak: Math.max(0, Number(row.current_streak) || 0),
        longestStreak: Math.max(0, Number(row.longest_streak) || 0),
        totalCheckins: Math.max(0, Number(row.total_checkins) || 0),
        lastCheckinDate: String(row.last_checkin_date || ""),
        periodCheckins: Math.max(0, Number(row.period_checkins) || 0),
        latestPeriodCheckin: String(row.latest_period_checkin || ""),
        earliestPeriodCheckinAt: String(row.earliest_period_checkin_at || ""),
        trackedFocusMinutes,
        manualFocusMinutes,
        manualFocusNote: mode === "day" ? String(row.day_manual_focus_note || "") : "",
        focusMinutes: trackedFocusMinutes + manualFocusMinutes,
        focusSessions: Math.max(0, Number(row.focus_sessions) || 0),
        focusTimerMode: showLiveTimer && row.focus_timer_mode === "break" ? "break" : "focus",
        focusTimerStatus: showLiveTimer && (row.focus_timer_status === "running" || row.focus_timer_status === "paused") ? row.focus_timer_status : "idle",
        focusTimerRemainingMs: showLiveTimer ? Math.max(0, Number(row.focus_timer_remaining_ms) || 0) : 0,
        focusTimerEndsAt: showLiveTimer ? String(row.focus_timer_ends_at || "") : "",
      };
    });

    return Response.json({
      period: mode,
      anchorDate,
      periodStart,
      periodEnd,
      periodDayCount,
      serverNow: serverNow.toISOString(),
      rows,
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return Response.json({
      error: error instanceof Error ? error.message : "Không thể tải thống kê streak và Pomodoro.",
    }, { status: 500, headers: { "Cache-Control": "no-store" } });
  }
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;

  const payload = await request.json().catch(function() { return {}; }) as {
    studentId?: number;
    date?: string;
    manualMinutes?: number;
    note?: string;
  };
  const studentId = Number(payload.studentId || 0);
  const dateKey = String(payload.date || "").trim();
  const manualMinutes = Number(payload.manualMinutes);
  const note = String(payload.note || "").trim().slice(0, 240);
  const today = vietnamDateKey();

  if (!Number.isInteger(studentId) || studentId <= 0) return Response.json({ error: "Học sinh không hợp lệ." }, { status: 400 });
  if (!validDateKey(dateKey) || dateKey > today) return Response.json({ error: "Ngày điều chỉnh không hợp lệ." }, { status: 400 });
  if (!Number.isInteger(manualMinutes) || manualMinutes < 0 || manualMinutes > 1440) {
    return Response.json({ error: "Thời gian bổ sung phải từ 0 đến 1.440 phút." }, { status: 400 });
  }

  try {
    const db = await database();
    const studentResult = await db.prepare("SELECT id, name, code FROM students WHERE id = ? LIMIT 1").bind(studentId).all() as { results?: Array<{ id: number; name: string; code: string }> };
    const student = studentResult.results?.[0];
    if (!student) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });

    const currentResult = await db.prepare("SELECT manual_minutes, note FROM student_focus_adjustments WHERE student_id = ? AND date_key = ? LIMIT 1").bind(studentId, dateKey).all() as { results?: Array<{ manual_minutes: number; note: string }> };
    const previousManualMinutes = Math.max(0, Number(currentResult.results?.[0]?.manual_minutes) || 0);
    const previousNote = String(currentResult.results?.[0]?.note || "");

    const trackedResult = await db.prepare("SELECT COALESCE(SUM(focus_minutes), 0) AS tracked_minutes, COUNT(*) AS focus_sessions FROM student_focus_sessions WHERE student_id = ? AND date_key = ?").bind(studentId, dateKey).all() as { results?: Array<{ tracked_minutes: number; focus_sessions: number }> };
    const trackedFocusMinutes = Math.max(0, Number(trackedResult.results?.[0]?.tracked_minutes) || 0);
    const focusSessions = Math.max(0, Number(trackedResult.results?.[0]?.focus_sessions) || 0);
    if (trackedFocusMinutes + manualMinutes > 1440) {
      return Response.json({ error: "Tổng Pomodoro trong một ngày không thể vượt quá 24 giờ." }, { status: 400 });
    }
    const changed = previousManualMinutes !== manualMinutes || previousNote !== note;
    const minutesChanged = previousManualMinutes !== manualMinutes;
    const now = new Date().toISOString();
    const focusMinutes = trackedFocusMinutes + manualMinutes;
    let notificationCreated = false;
    let notificationTitle = "";
    let notificationBody = "";

    if (minutesChanged) {
      const readableDate = formatDateKey(dateKey);
      const noteSuffix = note ? " Ghi chú: " + note + "." : "";
      notificationTitle = "Điều chỉnh thời gian Pomodoro";
      if (previousManualMinutes === 0 && manualMinutes > 0) {
        notificationTitle = "Bổ sung thời gian Pomodoro";
        notificationBody = "Giáo viên đã bổ sung " + formatMinutes(manualMinutes) + " học ngoài EDUFLOW cho ngày " + readableDate + ". Tổng thời gian Pomodoro trong ngày: " + formatMinutes(focusMinutes) + "." + noteSuffix;
      } else if (manualMinutes === 0) {
        notificationBody = "Giáo viên đã gỡ phần thời gian học ngoài EDUFLOW của ngày " + readableDate + ". Tổng thời gian Pomodoro trong ngày hiện là " + formatMinutes(focusMinutes) + "." + noteSuffix;
      } else {
        const direction = manualMinutes > previousManualMinutes ? "lên" : "xuống";
        notificationBody = "Thời gian học ngoài EDUFLOW ngày " + readableDate + " đã được điều chỉnh từ " + formatMinutes(previousManualMinutes) + " " + direction + " " + formatMinutes(manualMinutes) + ". Tổng thời gian Pomodoro mới: " + formatMinutes(focusMinutes) + "." + noteSuffix;
      }
    }

    if (changed) {
      const adjustmentStatement = db.prepare(`
        INSERT INTO student_focus_adjustments (student_id, date_key, manual_minutes, note, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(student_id, date_key) DO UPDATE SET
          manual_minutes = excluded.manual_minutes,
          note = excluded.note,
          updated_at = excluded.updated_at
      `).bind(studentId, dateKey, manualMinutes, note, now, now);
      const historyStatement = db.prepare(`
        INSERT INTO student_focus_adjustment_history
          (student_id, date_key, previous_manual_minutes, manual_minutes, delta_minutes, tracked_focus_minutes_snapshot, focus_minutes_after, note, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        studentId,
        dateKey,
        previousManualMinutes,
        manualMinutes,
        manualMinutes - previousManualMinutes,
        trackedFocusMinutes,
        focusMinutes,
        note,
        now,
      );

      if (minutesChanged) {
        const notificationKey = "focus-adjustment-" + studentId + "-" + dateKey + "-" + crypto.randomUUID();
        const notificationData = JSON.stringify({
          body: notificationBody,
          audience: "student",
          studentId,
          actionView: "overview",
          category: "pomodoro_adjustment",
          automatic: true,
          adminReadAt: null,
          studentReadAt: null,
          readByStudentIds: [],
        });
        const notificationStatement = db.prepare(`
          INSERT INTO admin_items (kind, item_key, title, data, created_at, updated_at)
          VALUES ('notifications', ?, ?, ?, ?, ?)
        `).bind(notificationKey, notificationTitle, notificationData, now, now);
        // D1 batch is atomic: the manual adjustment and its in-app notification
        // either both commit or both roll back. A retry can never save the time
        // silently while losing the required student notification.
        await db.batch([adjustmentStatement, historyStatement, notificationStatement]);
        notificationCreated = true;
      } else {
        await db.batch([adjustmentStatement, historyStatement]);
      }
    }

    if (minutesChanged && notificationCreated) {
      await sendPushToStudent(studentId, {
        title: notificationTitle,
        body: notificationBody,
        url: "/student?view=pomodoro",
        tag: "pomodoro-adjustment-" + studentId + "-" + dateKey,
        category: "pomodoro",
        relatedId: dateKey,
      }, "pomodoro-adjustment:" + studentId + ":" + dateKey + ":" + now).catch(function(error) {
        console.error("[V26.2.2] Pomodoro adjustment push", error);
      });
    }

    return Response.json({
      success: true,
      changed,
      notificationCreated,
      historyRecorded: changed,
      studentId,
      date: dateKey,
      trackedFocusMinutes,
      manualFocusMinutes: manualMinutes,
      manualFocusNote: note,
      focusMinutes,
      focusSessions,
      updatedAt: now,
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Không thể lưu thời gian Pomodoro bổ sung." }, { status: 500, headers: { "Cache-Control": "no-store" } });
  }
}
