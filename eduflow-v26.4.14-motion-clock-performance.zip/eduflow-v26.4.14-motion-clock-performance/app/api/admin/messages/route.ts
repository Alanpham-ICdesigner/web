import { asc, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems, studentEnrollments, students } from "../../../../db/schema";
import { requireAdmin } from "../../../../lib/admin-auth";
import { sendPushToStudent } from "../../../../lib/web-push";

function decode(value: string): Record<string, unknown> {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

function cleanBody(value: unknown): string {
  return String(value || "").replace(/\r\n/g, "\n").trim().slice(0, 4000);
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "messages")).orderBy(asc(adminItems.id));
  const messages = rows.map(function(row) {
    const data = decode(row.data);
    const direction = String(data.direction || "student") === "teacher" ? "teacher" : "student";
    return {
      id: row.id,
      studentId: Number(data.studentId || 0),
      studentCode: String(data.studentCode || ""),
      studentName: String(data.studentName || row.title || "Học sinh"),
      classKey: String(data.classKey || ""),
      className: String(data.className || ""),
      teacher: String(data.teacher || "Giáo viên"),
      direction,
      body: String(data.body || ""),
      createdAt: row.createdAt,
      read: direction === "student" ? Boolean(data.adminReadAt) : true,
    };
  }).filter(function(item) { return item.studentId; });
  return Response.json({ messages }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { studentId?: number; body?: string };
  const studentId = Number(payload.studentId || 0);
  const body = cleanBody(payload.body);
  if (!studentId || !body) return Response.json({ error: "Thiếu học sinh hoặc nội dung tin nhắn." }, { status: 400 });

  const db = await getDb();
  const studentRows = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!studentRows.length) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });
  const enrollmentRows = await db.select().from(studentEnrollments).where(eq(studentEnrollments.studentId, studentId));
  const enrollment = enrollmentRows.find(function(row) { return row.status === "active"; });
  if (!enrollment) return Response.json({ error: "Học sinh chưa tham gia lớp học đang hoạt động." }, { status: 400 });
  const classRows = await db.select().from(adminItems).where(eq(adminItems.kind, "classes"));
  const classRow = classRows.find(function(row) { return row.itemKey === enrollment.classKey; });
  const classData = classRow ? decode(classRow.data) : {};
  const teacher = String(classData.teacher || "Giáo viên");
  const now = new Date().toISOString();
  const inserted = await db.insert(adminItems).values({
    kind: "messages",
    itemKey: "message-" + crypto.randomUUID(),
    title: studentRows[0].name,
    data: JSON.stringify({
      studentId,
      studentCode: studentRows[0].code,
      studentName: studentRows[0].name,
      classKey: enrollment.classKey,
      className: enrollment.className,
      teacher,
      direction: "teacher",
      body,
      adminReadAt: now,
      studentReadAt: null,
    }),
    createdAt: now,
    updatedAt: now,
  }).returning();
  const messageId = inserted[0]?.id || 0;
  await sendPushToStudent(studentId, {
    title: "Tin nhắn mới từ " + teacher,
    body: body.slice(0, 180),
    url: "/student?view=messages",
    tag: "message-" + messageId,
    category: "message",
    relatedId: messageId,
  }, "message:" + messageId).catch(function(error) { console.error("[V26 Web Push] message", error); });
  return Response.json({ id: messageId, success: true }, { status: 201 });
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { studentId?: number; all?: boolean };
  const studentId = Number(payload.studentId || 0);
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "messages"));
  const now = new Date().toISOString();
  for (const row of rows) {
    const data = decode(row.data);
    if (String(data.direction || "") !== "student") continue;
    if (!payload.all && Number(data.studentId) !== studentId) continue;
    if (data.adminReadAt) continue;
    data.adminReadAt = now;
    await db.update(adminItems).set({ data: JSON.stringify(data), updatedAt: now }).where(eq(adminItems.id, row.id));
  }
  return Response.json({ success: true });
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { studentId?: number };
  const studentId = Number(payload.studentId || 0);
  if (!studentId) return Response.json({ error: "Thiếu học sinh cần xóa cuộc hội thoại." }, { status: 400 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "messages"));
  let deleted = 0;
  for (const row of rows) {
    const data = decode(row.data);
    if (Number(data.studentId || 0) !== studentId) continue;
    await db.delete(adminItems).where(eq(adminItems.id, row.id));
    deleted += 1;
  }
  return Response.json({ success: true, deleted });
}
