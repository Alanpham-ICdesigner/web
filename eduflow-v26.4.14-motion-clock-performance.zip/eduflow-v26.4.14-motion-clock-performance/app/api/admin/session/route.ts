import { clearSessionCookie, isAdmin, sessionCookie, validPin } from "../../../../lib/admin-auth";
import { checkLoginAllowed, LOGIN_LOCK_MINUTES, recordFailedLogin, resetFailedLogins } from "../../../../lib/login-security";

export async function GET(request: Request) {
  return Response.json({ admin: await isAdmin(request) });
}

export async function POST(request: Request) {
  const payload = await request.json().catch(function() { return {}; }) as { pin?: string };
  const pin = (payload.pin || "").trim();
  const allowed = await checkLoginAllowed("admin", "admin");
  if (allowed.locked) {
    return Response.json({ error: "Bạn đã nhập sai mật khẩu quá nhiều lần. Vui lòng thử lại sau " + Math.ceil(allowed.retryAfter / 60) + " phút.", reason: "TEMPORARILY_LOCKED", retryAfter: allowed.retryAfter }, { status: 429 });
  }
  if (!(await validPin(pin))) {
    const failed = await recordFailedLogin("admin", "admin");
    if (failed.locked) {
      return Response.json({ error: "Bạn đã nhập sai quá số lần cho phép. Tài khoản tạm thời bị khóa trong " + LOGIN_LOCK_MINUTES + " phút.", reason: "TEMPORARILY_LOCKED", retryAfter: failed.retryAfter }, { status: 429 });
    }
    const warning = failed.remainingAttempts <= 2 ? " Bạn còn " + failed.remainingAttempts + " lần thử." : "";
    return Response.json({ error: "Mã PIN không đúng." + warning, reason: "INVALID_PASSWORD", remainingAttempts: failed.remainingAttempts }, { status: 401 });
  }
  await resetFailedLogins("admin", "admin");
  return Response.json(
    { admin: true },
    { headers: { "Set-Cookie": await sessionCookie() } }
  );
}

export async function DELETE() {
  return Response.json(
    { admin: false },
    { headers: { "Set-Cookie": clearSessionCookie() } }
  );
}
