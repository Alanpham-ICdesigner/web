import { asc, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems, students } from "../../../../db/schema";
import { isAdmin, requireAdmin } from "../../../../lib/admin-auth";
import { sendPushToAllStudents, sendPushToCourse, sendPushToStudent } from "../../../../lib/web-push";

const allowedKinds = new Set(["classes", "attendance", "grades", "calendar", "notifications", "notes", "settings", "folders", "comments"]);

function cleanKind(value: unknown): string {
  const kind = String(value || "").trim().toLowerCase();
  return allowedKinds.has(kind) ? kind : "";
}

function safeData(value: unknown): string {
  const data = value && typeof value === "object" ? value : {};
  const encoded = JSON.stringify(data);
  if (encoded.length > 200_000) throw new Error("Dữ liệu quá lớn.");
  return encoded;
}

function decode(row: typeof adminItems.$inferSelect) {
  let data: Record<string, unknown> = {};
  try { data = JSON.parse(row.data) as Record<string, unknown>; } catch {}
  return { id: row.id, kind: row.kind, key: row.itemKey, title: row.title, data, createdAt: row.createdAt, updatedAt: row.updatedAt };
}

function formatCalendarDate(value: unknown): string {
  const raw = String(value || "").slice(0, 10);
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
  return match ? match[3] + "/" + match[2] + "/" + match[1] : raw;
}

function testCalendarNotificationData(calendarId: number, data: Record<string, unknown>) {
  const date = formatCalendarDate(data.date);
  const time = String(data.time || "").trim();
  const details = String(data.details || data.body || "").trim();
  const className = String(data.className || "").trim();
  const pieces = [date, time, details].filter(Boolean);
  return {
    body: pieces.join(" · "),
    audience: "all_students",
    classKey: String(data.classKey || ""),
    className,
    actionView: "schedule",
    category: "test_calendar",
    relatedItemId: calendarId,
    automatic: true,
    adminReadAt: null,
    studentReadAt: null,
    readByStudentIds: [],
  };
}


function realScore(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function changedGradeStudentCodes(previous: Record<string, unknown>, next: Record<string, unknown>): string[] {
  const oldScores = previous.scores && typeof previous.scores === "object" ? previous.scores as Record<string, unknown> : {};
  const newScores = next.scores && typeof next.scores === "object" ? next.scores as Record<string, unknown> : {};
  const changed: string[] = [];
  Object.keys(newScores).forEach(function(code) {
    const before = oldScores[code];
    const after = newScores[code];
    let hasRealScore = false;
    let differs = false;
    if (Array.isArray(after)) {
      const oldArray = Array.isArray(before) ? before : [];
      after.forEach(function(value, index) {
        const nextScore = realScore(value);
        if (nextScore !== null) hasRealScore = true;
        if (nextScore !== realScore(oldArray[index])) differs = true;
      });
    } else if (after && typeof after === "object") {
      const oldMap = before && typeof before === "object" && !Array.isArray(before) ? before as Record<string, unknown> : {};
      Object.entries(after as Record<string, unknown>).forEach(function(entry) {
        const nextScore = realScore(entry[1]);
        if (nextScore !== null) hasRealScore = true;
        if (nextScore !== realScore(oldMap[entry[0]])) differs = true;
      });
    }
    if (hasRealScore && differs) changed.push(code);
  });
  return changed;
}

async function pushAnnouncement(data: Record<string, unknown>, id: number, title: string, bodyFallback: string) {
  const studentId = Number(data.studentId || 0);
  const classKey = String(data.classKey || "").trim();
  const className = String(data.className || "").trim();
  const payload = {
    title,
    body: String(data.body || bodyFallback || "Bạn có thông báo mới.").slice(0, 220),
    url: "/student?view=notifications&notificationId=" + id,
    tag: "announcement-" + id,
    category: "announcement",
    relatedId: id,
  };
  if (studentId) return sendPushToStudent(studentId, payload, "announcement:" + id);
  if (classKey || className) return sendPushToCourse(classKey, className, payload, "announcement:" + id);
  return sendPushToAllStudents(payload, "announcement:" + id);
}

export async function GET(request: Request) {
  const kind = cleanKind(new URL(request.url).searchParams.get("kind"));
  if (!kind) return Response.json({ error: "Loại dữ liệu không hợp lệ." }, { status: 400 });
  const admin = await isAdmin(request);
  if (!admin && kind !== "settings") return Response.json({ error: "Bạn cần đăng nhập Admin để xem dữ liệu này." }, { status: 401 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, kind)).orderBy(asc(adminItems.id));
  const visibleRows = admin ? rows : rows.filter(function (row) { return row.itemKey === "profile"; });
  return Response.json({ items: visibleRows.map(decode) }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    const payload = await request.json() as Record<string, unknown>;
    const kind = cleanKind(payload.kind);
    const title = String(payload.title || "").trim();
    if (!kind || !title) return Response.json({ error: "Thiếu loại hoặc tiêu đề dữ liệu." }, { status: 400 });
    const now = new Date().toISOString();
    const db = await getDb();
    const result = await db.insert(adminItems).values({
      kind, itemKey: String(payload.key || crypto.randomUUID()), title,
      data: safeData(payload.data), createdAt: now, updatedAt: now
    }).returning();

    if (kind === "calendar" && result[0]) {
      const calendarData = payload.data && typeof payload.data === "object"
        ? payload.data as Record<string, unknown>
        : {};
      const isTestCalendar = String(calendarData.type || "").toLocaleLowerCase("vi").includes("kiểm tra");
      const hasClassTarget = Boolean(String(calendarData.classKey || calendarData.className || "").trim());
      if (isTestCalendar && hasClassTarget) {
        const notificationKey = "test-calendar-" + result[0].id;
        await db.insert(adminItems).values({
          kind: "notifications",
          itemKey: notificationKey,
          title: "Lịch kiểm tra mới: " + title,
          data: JSON.stringify(testCalendarNotificationData(result[0].id, calendarData)),
          createdAt: now,
          updatedAt: now,
        }).onConflictDoUpdate({
          target: [adminItems.kind, adminItems.itemKey],
          set: {
            title: "Lịch kiểm tra mới: " + title,
            data: JSON.stringify(testCalendarNotificationData(result[0].id, calendarData)),
            updatedAt: now,
          },
        });
      }
      if (isTestCalendar && hasClassTarget) {
        await sendPushToCourse(String(calendarData.classKey || ""), String(calendarData.className || ""), {
          title: "Lịch kiểm tra mới: " + title,
          body: String(testCalendarNotificationData(result[0].id, calendarData).body || "Mở lịch kiểm tra để xem chi tiết.").slice(0, 220),
          url: "/student?courseId=" + encodeURIComponent(String(calendarData.classKey || "")) + "&courseName=" + encodeURIComponent(String(calendarData.className || "")) + "&tab=schedule",
          tag: "test-calendar-" + result[0].id,
          category: "test_calendar",
          relatedId: result[0].id,
        }, "test-calendar:" + result[0].id).catch(function(error) { console.error("[V26 Web Push] test calendar", error); });
      }
    }

    if (kind === "notifications" && result[0]) {
      const notificationData = payload.data && typeof payload.data === "object" ? payload.data as Record<string, unknown> : {};
      await pushAnnouncement(notificationData, result[0].id, title, "Bạn có thông báo mới.").catch(function(error) { console.error("[V26 Web Push] announcement", error); });
    }

    return Response.json({ item: decode(result[0]) }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Không thể lưu dữ liệu." }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    const payload = await request.json() as Record<string, unknown>;
    const kind = cleanKind(payload.kind);
    const key = String(payload.key || "").trim();
    const title = String(payload.title || key).trim();
    if (!kind || !key || !title) return Response.json({ error: "Thiếu khóa dữ liệu cần lưu." }, { status: 400 });
    const now = new Date().toISOString();
    const db = await getDb();
    const previousRows = kind === "grades" ? await db.select().from(adminItems).where(eq(adminItems.kind, "grades")) : [];
    const previousRow = previousRows.find(function(row) { return row.itemKey === key; });
    const previousData = previousRow ? decode(previousRow).data : {};
    const nextData = payload.data && typeof payload.data === "object" ? payload.data as Record<string, unknown> : {};
    const result = await db.insert(adminItems).values({ kind, itemKey: key, title, data: safeData(payload.data), createdAt: now, updatedAt: now }).onConflictDoUpdate({
      target: [adminItems.kind, adminItems.itemKey],
      set: { title, data: safeData(payload.data), updatedAt: now }
    }).returning();
    if (kind === "grades") {
      const changedCodes = changedGradeStudentCodes(previousData, nextData);
      if (changedCodes.length) {
        const studentRows = await db.select({ id: students.id, code: students.code }).from(students);
        const classKey = String(nextData.classKey || "");
        const className = String(nextData.className || "");
        for (const student of studentRows) {
          if (!changedCodes.includes(student.code)) continue;
          const notificationKey = "gradebook-" + key + "-" + student.id;
          await db.insert(adminItems).values({
            kind: "notifications", itemKey: notificationKey, title: "Có điểm mới",
            data: JSON.stringify({
              body: "Sổ điểm " + (className || title) + " vừa được giáo viên cập nhật.",
              audience: "student", studentId: student.id, classKey, className, actionView: "progress", category: "grade", studentReadAt: null, automatic: true,
            }),
            createdAt: now, updatedAt: now,
          }).onConflictDoUpdate({
            target: [adminItems.kind, adminItems.itemKey],
            set: {
              title: "Có điểm mới",
              data: JSON.stringify({
                body: "Sổ điểm " + (className || title) + " vừa được giáo viên cập nhật.",
                audience: "student", studentId: student.id, classKey, className, actionView: "progress", category: "grade", studentReadAt: null, automatic: true,
              }),
              updatedAt: now,
            },
          });
          await sendPushToStudent(student.id, {
            title: "Có điểm mới",
            body: "Sổ điểm " + (className || title) + " vừa được giáo viên cập nhật.",
            url: "/student?courseId=" + encodeURIComponent(classKey) + "&courseName=" + encodeURIComponent(className) + "&tab=progress",
            tag: "gradebook-" + key + "-" + student.id,
            category: "grade",
            relatedId: key,
          }, "gradebook:" + key + ":" + now + ":" + student.id).catch(function(error) { console.error("[V26 Web Push] gradebook", error); });
        }
      }
    }
    return Response.json({ item: decode(result[0]) });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Không thể lưu dữ liệu." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as Record<string, unknown>;
  const id = Number(payload.id);
  if (!id) return Response.json({ error: "Thiếu dữ liệu cần sửa." }, { status: 400 });
  const db = await getDb();
  const result = await db.update(adminItems).set({
    title: String(payload.title || "").trim(), data: safeData(payload.data), updatedAt: new Date().toISOString()
  }).where(eq(adminItems.id, id)).returning();
  return Response.json({ item: result[0] ? decode(result[0]) : null });
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as { id?: number };
  if (!payload.id) return Response.json({ error: "Thiếu dữ liệu cần xóa." }, { status: 400 });
  const db = await getDb();
  const existing = await db.select().from(adminItems).where(eq(adminItems.id, payload.id)).limit(1);
  let attendanceDeleted = 0;
  if (existing[0]?.kind === "classes") {
    let classData: Record<string, unknown> = {};
    try { classData = JSON.parse(existing[0].data) as Record<string, unknown>; } catch {}
    const classKey = String(existing[0].itemKey || "");
    const className = String(existing[0].title || classData.name || "");
    const attendanceRows = await db.select().from(adminItems).where(eq(adminItems.kind, "attendance"));
    for (const row of attendanceRows) {
      let data: Record<string, unknown> = {};
      try { data = JSON.parse(row.data) as Record<string, unknown>; } catch {}
      const savedClassKey = String(data.classKey || data.classId || "");
      const savedClassName = String(data.className || "");
      const belongsToDeletedClass =
        (classKey && savedClassKey === classKey) ||
        savedClassKey === String(existing[0].id) ||
        (className && savedClassName === className);
      if (!belongsToDeletedClass) continue;
      await db.delete(adminItems).where(eq(adminItems.id, row.id));
      attendanceDeleted += 1;
    }
  }
  await db.delete(adminItems).where(eq(adminItems.id, payload.id));
  if (existing[0]?.kind === "calendar") {
    const notificationRows = await db.select().from(adminItems).where(eq(adminItems.kind, "notifications"));
    for (const row of notificationRows) {
      let data: Record<string, unknown> = {};
      try { data = JSON.parse(row.data) as Record<string, unknown>; } catch {}
      if (String(data.category || "") !== "test_calendar") continue;
      if (Number(data.relatedItemId || 0) !== payload.id) continue;
      await db.delete(adminItems).where(eq(adminItems.id, row.id));
    }
  }
  return Response.json({ success: true, attendanceDeleted });
}
