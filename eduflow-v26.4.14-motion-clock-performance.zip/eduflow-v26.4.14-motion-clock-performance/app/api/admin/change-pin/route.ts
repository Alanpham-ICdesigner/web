import { getDb } from "../../../../db";
import { appState } from "../../../../db/schema";
import { requireAdmin, validPin } from "../../../../lib/admin-auth";
import { hashStudentPin } from "../../../../lib/student-auth";

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { currentPin?: string; newPin?: string; confirmPin?: string };
  const currentPin = String(payload.currentPin || "").trim();
  const newPin = String(payload.newPin || "").trim();
  const confirmPin = String(payload.confirmPin || "").trim();
  if (!(await validPin(currentPin))) return Response.json({ error: "PIN Admin hiện tại không đúng." }, { status: 401 });
  if (!/^\d{6}$/.test(newPin)) return Response.json({ error: "PIN Admin mới phải gồm đúng 6 số." }, { status: 400 });
  if (newPin !== confirmPin) return Response.json({ error: "Hai lần nhập PIN mới chưa trùng nhau." }, { status: 400 });
  if (newPin === currentPin) return Response.json({ error: "PIN mới phải khác PIN hiện tại." }, { status: 400 });
  const credential = await hashStudentPin(newPin);
  await (await getDb()).insert(appState).values({ key: "admin_pin_credential", value: JSON.stringify(credential) }).onConflictDoUpdate({ target: appState.key, set: { value: JSON.stringify(credential) } });
  return Response.json({ success: true });
}
