import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { assignmentSubmissions } from "../../../../../db/schema";
import { isAdmin } from "../../../../../lib/admin-auth";
import { getStudentSessionId } from "../../../../../lib/student-auth";
import { secureFileHeaders } from "../../../../../lib/secure-file-response";

type StoredObject = { body: BodyInit; httpMetadata?: { contentType?: string } };
type FileBucket = { get(key: string): Promise<StoredObject | null> };

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const id = Number((await context.params).id);
  if (!id) return new Response("Không tìm thấy bài nộp.", { status: 404 });
  const db = await getDb();
  const rows = await db.select().from(assignmentSubmissions).where(eq(assignmentSubmissions.id, id)).limit(1);
  const submission = rows[0];
  if (!submission?.objectKey) return new Response("Bài nộp không có tệp.", { status: 404 });
  const studentId = await getStudentSessionId(request);
  if (!await isAdmin(request) && studentId !== submission.studentId) return new Response("Bạn không có quyền xem tệp này.", { status: 403 });
  const { env } = await import("cloudflare:workers");
  const bucket = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!bucket) return new Response("Kho tệp chưa được cấu hình.", { status: 503 });
  const object = await bucket.get(submission.objectKey);
  if (!object) return new Response("Tệp đã bị xóa.", { status: 404 });
  return new Response(object.body, { headers: secureFileHeaders(
    request,
    submission.fileName || "bai-nop",
    submission.contentType || object.httpMetadata?.contentType || "application/octet-stream",
  ) });
}
