import { and, desc, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { pointRules, pointTransactions, rewardItems, rewardRedemptions, studentAccounts, students } from "../../../../db/schema";
import { requireAdmin } from "../../../../lib/admin-auth";
import { hashStudentPin } from "../../../../lib/student-auth";
import { createAutomaticNotification, createPointNotification } from "../../../../lib/notifications";
import { sendPushToStudent } from "../../../../lib/web-push";

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const db = await getDb();
  const [studentRows, accountRows, transactionRows, ruleRows, rewardRows, redemptionRows] = await Promise.all([
    db.select().from(students).orderBy(students.name),
    db.select({ studentId: studentAccounts.studentId, updatedAt: studentAccounts.updatedAt }).from(studentAccounts),
    db.select().from(pointTransactions).orderBy(desc(pointTransactions.id)),
    db.select().from(pointRules).orderBy(desc(pointRules.id)),
    db.select().from(rewardItems).orderBy(desc(rewardItems.id)),
    db.select().from(rewardRedemptions).orderBy(desc(rewardRedemptions.id))
  ]);
  const accountSet = new Set(accountRows.map(function(row) { return row.studentId; }));
  const balances = new Map<number, number>();
  transactionRows.forEach(function(row) { balances.set(row.studentId, (balances.get(row.studentId) || 0) + row.delta); });
  const studentMap = new Map(studentRows.map(function(row) { return [row.id, row]; }));
  const rewardMap = new Map(rewardRows.map(function(row) { return [row.id, row]; }));
  return Response.json({
    students: studentRows.map(function(row) { return { id: row.id, code: row.code, name: row.name, className: row.className, points: balances.get(row.id) || 0, hasPin: accountSet.has(row.id) }; }),
    rules: ruleRows,
    rewards: rewardRows,
    redemptions: redemptionRows.map(function(row) { const student = studentMap.get(row.studentId); const reward = rewardMap.get(row.rewardId); return { ...row, studentName: student?.name || "Học sinh đã xóa", studentCode: student?.code || "", rewardTitle: reward?.title || "Quà đã xóa" }; }),
    transactions: transactionRows.slice(0, 80).map(function(row) { const student = studentMap.get(row.studentId); return { ...row, studentName: student?.name || "Học sinh đã xóa", studentCode: student?.code || "" }; })
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as Record<string, unknown>;
  const action = String(payload.action || "");
  const db = await getDb();
  const now = new Date().toISOString();

  if (action === "set_pin") {
    const studentId = Number(payload.studentId);
    const pin = String(payload.pin || "").trim();
    if (!studentId || !/^\d{6}$/.test(pin)) return Response.json({ error: "PIN học sinh phải gồm đúng 6 số." }, { status: 400 });
    const student = await db.select({ id: students.id }).from(students).where(eq(students.id, studentId)).limit(1);
    if (!student.length) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });
    try {
      const credential = await hashStudentPin(pin);
      await db.insert(studentAccounts).values({ studentId, pinHash: credential.hash, pinSalt: credential.salt, updatedAt: now }).onConflictDoUpdate({ target: studentAccounts.studentId, set: { pinHash: credential.hash, pinSalt: credential.salt, updatedAt: now } });
      return Response.json({ success: true });
    } catch {
      return Response.json({ error: "Không thể mã hóa và lưu PIN. Vui lòng thử lại." }, { status: 500 });
    }
  }

  if (action === "apply_rule") {
    const studentId = Number(payload.studentId);
    const ruleId = Number(payload.ruleId);
    const ruleRows = await db.select().from(pointRules).where(and(eq(pointRules.id, ruleId), eq(pointRules.active, true))).limit(1);
    if (!studentId || !ruleRows.length) return Response.json({ error: "Vui lòng chọn một quy tắc đang bật." }, { status: 400 });
    const rule = ruleRows[0];
    const existing = await db.select({ delta: pointTransactions.delta }).from(pointTransactions).where(eq(pointTransactions.studentId, studentId));
    const balance = existing.reduce(function(total, row) { return total + row.delta; }, 0);
    if (balance + rule.points < 0) return Response.json({ error: "Không thể áp dụng vì học sinh không đủ điểm để trừ." }, { status: 400 });
    await db.insert(pointTransactions).values({ studentId, delta: rule.points, reason: rule.title, source: "selected_rule", createdAt: now });
    await createPointNotification(studentId, rule.points, "Quy tắc: " + rule.title);
    await sendPushToStudent(studentId, {
      title: rule.points > 0 ? "Bạn được cộng " + rule.points + " điểm" : "Bạn bị trừ " + Math.abs(rule.points) + " điểm",
      body: "Quy tắc: " + rule.title,
      url: "/student?view=rewards",
      tag: "points-rule-" + rule.id + "-" + studentId,
      category: "points",
      relatedId: rule.id,
    }, "points:" + studentId + ":" + now + ":" + rule.id).catch(function(error) { console.error("[V26 Web Push] points", error); });
    return Response.json({ success: true, balance: balance + rule.points });
  }

  if (action === "apply_rules") {
    const studentId = Number(payload.studentId);
    const rawRuleIds = Array.isArray(payload.ruleIds) ? payload.ruleIds : [];
    const ruleIds = Array.from(new Set(rawRuleIds.map(Number).filter(Boolean))).slice(0, 100);
    if (!studentId || !ruleIds.length) return Response.json({ error: "Vui lòng chọn ít nhất một quy tắc đang bật." }, { status: 400 });
    const allRules = await db.select().from(pointRules).where(eq(pointRules.active, true));
    const selectedRules = ruleIds.map(function(id) { return allRules.find(function(rule) { return rule.id === id; }); }).filter(function(rule): rule is typeof allRules[number] { return Boolean(rule); });
    if (selectedRules.length !== ruleIds.length) return Response.json({ error: "Có quy tắc không tồn tại hoặc đã bị tắt. Vui lòng chọn lại." }, { status: 409 });
    const existing = await db.select({ delta: pointTransactions.delta }).from(pointTransactions).where(eq(pointTransactions.studentId, studentId));
    const balance = existing.reduce(function(total, row) { return total + row.delta; }, 0);
    const totalDelta = selectedRules.reduce(function(total, rule) { return total + rule.points; }, 0);
    if (balance + totalDelta < 0) return Response.json({ error: "Không thể áp dụng vì tổng điểm sau khi trừ sẽ nhỏ hơn 0." }, { status: 400 });
    for (const rule of selectedRules) {
      await db.insert(pointTransactions).values({ studentId, delta: rule.points, reason: rule.title, source: "selected_rule", createdAt: now });
      await createPointNotification(studentId, rule.points, "Quy tắc: " + rule.title);
    }
    const pointSummary = selectedRules.map(function(rule) { return rule.title; }).slice(0, 3).join(", ") + (selectedRules.length > 3 ? "…" : "");
    await sendPushToStudent(studentId, {
      title: totalDelta > 0 ? "Điểm thi đua +" + totalDelta : totalDelta < 0 ? "Điểm thi đua " + totalDelta : "Điểm thi đua đã cập nhật",
      body: pointSummary || "Giáo viên vừa cập nhật điểm thi đua của bạn.",
      url: "/student?view=rewards",
      tag: "points-batch-" + studentId + "-" + now,
      category: "points",
      relatedId: studentId,
    }, "points-batch:" + studentId + ":" + now).catch(function(error) { console.error("[V26 Web Push] points batch", error); });
    return Response.json({ success: true, balance: balance + totalDelta, applied: selectedRules.length });
  }

  if (action === "save_rule") {
    const id = Number(payload.id);
    const title = String(payload.title || "").trim().slice(0, 120);
    const requestedTrigger = String(payload.trigger || "manual");
    const trigger = requestedTrigger === "assignment_streak" ? "assignment_streak" : "manual";
    const points = Math.trunc(Number(payload.points));
    const threshold = Math.max(1, Math.min(100, Math.trunc(Number(payload.threshold) || 1)));
    const active = payload.active !== false;
    if (!title || !points || Math.abs(points) > 100_000) return Response.json({ error: "Vui lòng nhập tên quy tắc và số điểm cộng/trừ hợp lệ." }, { status: 400 });
    if (id) await db.update(pointRules).set({ title, trigger, points, threshold, active, updatedAt: now }).where(eq(pointRules.id, id));
    else await db.insert(pointRules).values({ title, trigger, points, threshold, active, createdAt: now, updatedAt: now });
    return Response.json({ success: true });
  }

  if (action === "toggle_rule") {
    const id = Number(payload.id);
    await db.update(pointRules).set({ active: Boolean(payload.active), updatedAt: now }).where(eq(pointRules.id, id));
    return Response.json({ success: true });
  }

  if (action === "delete_rule") {
    const id = Number(payload.id);
    await db.delete(pointRules).where(eq(pointRules.id, id));
    return Response.json({ success: true });
  }

  if (action === "save_reward") {
    const id = Number(payload.id);
    const title = String(payload.title || "").trim().slice(0, 100);
    const description = String(payload.description || "").trim().slice(0, 500);
    const cost = Math.trunc(Number(payload.cost));
    const stock = Math.max(0, Math.trunc(Number(payload.stock) || 0));
    const active = payload.active !== false;
    if (!title || !cost || cost < 1) return Response.json({ error: "Vui lòng nhập tên quà và số điểm đổi hợp lệ." }, { status: 400 });
    if (id) await db.update(rewardItems).set({ title, description, cost, stock, active, updatedAt: now }).where(eq(rewardItems.id, id));
    else await db.insert(rewardItems).values({ title, description, cost, stock, active, createdAt: now, updatedAt: now });
    return Response.json({ success: true });
  }

  if (action === "toggle_reward") {
    const id = Number(payload.id);
    await db.update(rewardItems).set({ active: Boolean(payload.active), updatedAt: now }).where(eq(rewardItems.id, id));
    return Response.json({ success: true });
  }

  if (action === "delete_reward") {
    const id = Number(payload.id);
    const used = await db.select({ id: rewardRedemptions.id }).from(rewardRedemptions).where(eq(rewardRedemptions.rewardId, id)).limit(1);
    if (used.length) {
      await db.update(rewardItems).set({ active: false, updatedAt: now }).where(eq(rewardItems.id, id));
      return Response.json({ success: true, archived: true });
    }
    await db.delete(rewardItems).where(eq(rewardItems.id, id));
    return Response.json({ success: true });
  }

  if (action === "review_redemption") {
    const id = Number(payload.id);
    const decision = String(payload.decision || "");
    if (decision !== "approved" && decision !== "rejected") return Response.json({ error: "Trạng thái duyệt không hợp lệ." }, { status: 400 });
    const rows = await db.select().from(rewardRedemptions).where(and(eq(rewardRedemptions.id, id), eq(rewardRedemptions.status, "pending"))).limit(1);
    if (!rows.length) return Response.json({ error: "Yêu cầu đã được xử lý hoặc không tồn tại." }, { status: 409 });
    const redemption = rows[0];
    await db.update(rewardRedemptions).set({ status: decision, reviewedAt: now }).where(and(eq(rewardRedemptions.id, id), eq(rewardRedemptions.status, "pending")));
    const rewardRows = await db.select().from(rewardItems).where(eq(rewardItems.id, redemption.rewardId)).limit(1);
    const rewardTitle = rewardRows[0]?.title || "Phần quà";
    if (decision === "rejected") {
      await db.insert(pointTransactions).values({ studentId: redemption.studentId, delta: redemption.cost, reason: "Hoàn điểm do yêu cầu đổi quà bị từ chối", source: "redemption_refund", createdAt: now });
      if (rewardRows.length) await db.update(rewardItems).set({ stock: rewardRows[0].stock + 1, updatedAt: now }).where(eq(rewardItems.id, redemption.rewardId));
    }
    await createAutomaticNotification({ audience: "student", studentId: redemption.studentId, title: decision === "approved" ? "Yêu cầu đổi quà đã được duyệt" : "Yêu cầu đổi quà bị từ chối", body: decision === "approved" ? "Giáo viên đã duyệt phần quà “" + rewardTitle + "”." : "Yêu cầu “" + rewardTitle + "” bị từ chối và " + redemption.cost + " điểm đã được hoàn lại.", actionView: "rewards", category: "redemption" });
    return Response.json({ success: true });
  }

  return Response.json({ error: "Thao tác không được hỗ trợ." }, { status: 400 });
}
