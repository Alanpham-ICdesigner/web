import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems, studentEnrollments, students } from "../../../../db/schema";
import { isAdmin, requireAdmin } from "../../../../lib/admin-auth";
import { getStudentSessionId } from "../../../../lib/student-auth";
import { secureFileHeaders } from "../../../../lib/secure-file-response";

type StoredObject = { body: BodyInit; httpMetadata?: { contentType?: string } };
type FileBucket = { get(key: string): Promise<StoredObject | null> };

async function getBucket(): Promise<FileBucket> {
  const { env } = await import("cloudflare:workers");
  const bucket = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!bucket) throw new Error("Kho tệp chưa được cấu hình.");
  return bucket;
}

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const admin = await isAdmin(request);
  const studentId = admin ? null : await getStudentSessionId(request);
  if (!admin && !studentId) {
    const rejected = await requireAdmin(request);
    if (rejected) return rejected;
  }
  const id = Number((await context.params).id);
  if (!id) return new Response("Không tìm thấy tài liệu.", { status: 404 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.id, id), eq(adminItems.kind, "documents"))).limit(1);
  if (!rows.length) return new Response("Không tìm thấy tài liệu.", { status: 404 });
  const data = JSON.parse(rows[0].data) as { objectKey?: string; contentType?: string; folder?: string };
  if (studentId) {
    const studentRows = await db.select({ className: students.className }).from(students).where(eq(students.id, studentId)).limit(1);
    const enrollmentRows = await db.select({ className: studentEnrollments.className }).from(studentEnrollments).where(and(eq(studentEnrollments.studentId, studentId), eq(studentEnrollments.status, "active")));
    const enrolledClassNames = new Set(enrollmentRows.map(function(item) { return item.className; }));
    const folder = String(data.folder || "Tài liệu chung");
    if (!studentRows.length) return new Response("Bạn không có quyền tải tài liệu này.", { status: 403 });
    const deniedByLegacyRule = folder !== "Tài liệu chung" && folder !== studentRows[0].className;
    if (deniedByLegacyRule && !enrolledClassNames.has(folder)) {
      return new Response("Bạn không có quyền tải tài liệu này.", { status: 403 });
    }
  }
  if (!data.objectKey) return new Response("Tài liệu không hợp lệ.", { status: 404 });
  const object = await (await getBucket()).get(data.objectKey);
  if (!object) return new Response("Tệp đã bị xóa.", { status: 404 });
  return new Response(object.body, { headers: secureFileHeaders(
    request,
    rows[0].title,
    data.contentType || object.httpMetadata?.contentType || "application/octet-stream",
  ) });
}
