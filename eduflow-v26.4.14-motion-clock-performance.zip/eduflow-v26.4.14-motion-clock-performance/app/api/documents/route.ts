import { and, desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { adminItems } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";
import { createAutomaticNotification } from "../../../lib/notifications";

type FileBucket = {
  put(key: string, value: ArrayBuffer, options?: { httpMetadata?: { contentType?: string } }): Promise<unknown>;
  delete(key: string): Promise<void>;
};

async function getBucket(): Promise<FileBucket> {
  const { env } = await import("cloudflare:workers");
  const bucket = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!bucket) throw new Error("Kho tệp chưa được cấu hình.");
  return bucket;
}

function decode(row: typeof adminItems.$inferSelect) {
  let data: Record<string, unknown> = {};
  try { data = JSON.parse(row.data) as Record<string, unknown>; } catch {}
  // The database title is the canonical uploaded filename. Keep it after the
  // legacy metadata so an old `name` field can never replace the real name.
  return { id: row.id, ...data, name: row.title, createdAt: row.createdAt };
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    const db = await getDb();
    const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "documents")).orderBy(desc(adminItems.id));
    return Response.json({ documents: rows.map(decode) }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Không thể tải tài liệu." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    const form = await request.formData();
    const file = form.get("file");
    const folder = String(form.get("folder") || "Tài liệu chung").trim();
    if (!(file instanceof File) || !file.size) return Response.json({ error: "Vui lòng chọn tệp cần tải lên." }, { status: 400 });
    if (file.size > 10 * 1024 * 1024) return Response.json({ error: "Tệp tối đa 10 MB." }, { status: 400 });
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(-100) || "file";
    const objectKey = "documents/" + crypto.randomUUID() + "-" + safeName;
    const bucket = await getBucket();
    await bucket.put(objectKey, await file.arrayBuffer(), { httpMetadata: { contentType: file.type || "application/octet-stream" } });
    const now = new Date().toISOString();
    const db = await getDb();
    const result = await db.insert(adminItems).values({
      kind: "documents", itemKey: crypto.randomUUID(), title: file.name,
      data: JSON.stringify({ objectKey, folder, size: file.size, contentType: file.type || "application/octet-stream" }),
      createdAt: now, updatedAt: now
    }).returning();
    await createAutomaticNotification({ audience: "all_students", className: folder === "Tài liệu chung" ? undefined : folder, title: "Tài liệu mới: " + file.name, body: "Giáo viên vừa đăng tài liệu vào thư mục “" + folder + "”.", actionView: "documents", category: "document" });
    return Response.json({ document: decode(result[0]) }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Không thể tải tài liệu." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { fromFolder?: string; toFolder?: string };
  const fromFolder = String(payload.fromFolder || "").trim();
  const toFolder = String(payload.toFolder || "Tài liệu chung").trim();
  if (!fromFolder || fromFolder === "Tài liệu chung" || !toFolder) {
    return Response.json({ error: "Thư mục cần chuyển không hợp lệ." }, { status: 400 });
  }
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(eq(adminItems.kind, "documents"));
  let moved = 0;
  for (const row of rows) {
    let data: Record<string, unknown> = {};
    try { data = JSON.parse(row.data) as Record<string, unknown>; } catch {}
    if (String(data.folder || "Tài liệu chung") !== fromFolder) continue;
    await db.update(adminItems).set({
      data: JSON.stringify({ ...data, folder: toFolder }),
      updatedAt: new Date().toISOString(),
    }).where(eq(adminItems.id, row.id));
    moved += 1;
  }
  return Response.json({ success: true, moved });
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as { id?: number };
  if (!payload.id) return Response.json({ error: "Thiếu tài liệu cần xóa." }, { status: 400 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.id, payload.id), eq(adminItems.kind, "documents"))).limit(1);
  if (!rows.length) return Response.json({ error: "Không tìm thấy tài liệu." }, { status: 404 });
  try {
    const data = JSON.parse(rows[0].data) as { objectKey?: string };
    if (data.objectKey) await (await getBucket()).delete(data.objectKey);
  } catch {}
  await db.delete(adminItems).where(eq(adminItems.id, payload.id));
  return Response.json({ success: true });
}
