import { AwsClient } from "aws4fetch";
import { requireAdmin } from "../../../../lib/admin-auth";

const MAX_FILE_SIZE = 10 * 1024 * 1024;

type R2SigningEnv = {
  R2_ACCOUNT_ID?: string;
  R2_BUCKET_NAME?: string;
  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;
};

function safeFileName(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(-100) || "file";
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    const payload = (await request.json()) as {
      name?: string;
      size?: number;
      contentType?: string;
    };
    const name = String(payload.name || "").trim();
    const size = Number(payload.size || 0);
    const contentType = String(payload.contentType || "application/octet-stream");
    if (!name || !Number.isFinite(size) || size <= 0)
      return Response.json({ error: "Thông tin tệp không hợp lệ." }, { status: 400 });
    if (size > MAX_FILE_SIZE)
      return Response.json({ error: "Tệp tối đa 10 MB." }, { status: 400 });

    const { env } = await import("cloudflare:workers");
    const signingEnv = env as R2SigningEnv;
    const accountId = signingEnv.R2_ACCOUNT_ID;
    const bucketName = signingEnv.R2_BUCKET_NAME || "eduflow-files";
    const accessKeyId = signingEnv.R2_ACCESS_KEY_ID;
    const secretAccessKey = signingEnv.R2_SECRET_ACCESS_KEY;
    if (!accountId || !accessKeyId || !secretAccessKey)
      return Response.json(
        { error: "Tải trực tiếp R2 chưa được cấu hình." },
        { status: 503 },
      );

    const objectKey = "documents/" + crypto.randomUUID() + "-" + safeFileName(name);
    const endpoint = new URL(
      "https://" + accountId + ".r2.cloudflarestorage.com/" + bucketName + "/" + objectKey,
    );
    endpoint.searchParams.set("X-Amz-Expires", "600");
    const client = new AwsClient({
      accessKeyId,
      secretAccessKey,
      service: "s3",
      region: "auto",
    });
    const signed = await client.sign(
      new Request(endpoint, { method: "PUT", headers: { "Content-Type": contentType } }),
      { aws: { signQuery: true } },
    );
    return Response.json({
      uploadUrl: signed.url,
      objectKey,
      contentType,
      expiresIn: 600,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Không thể chuẩn bị tải lên." },
      { status: 500 },
    );
  }
}
