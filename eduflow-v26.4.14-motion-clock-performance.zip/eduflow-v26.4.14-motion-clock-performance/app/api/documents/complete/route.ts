import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems } from "../../../../db/schema";
import { requireAdmin } from "../../../../lib/admin-auth";
import { createAutomaticNotification } from "../../../../lib/notifications";

const MAX_FILE_SIZE = 10 * 1024 * 1024;
type StoredObject = { size: number; httpMetadata?: { contentType?: string } };
type FileBucket = {
  head(key: string): Promise<StoredObject | null>;
  delete(key: string): Promise<void>;
};

async function getBucket(): Promise<FileBucket> {
  const { env } = await import("cloudflare:workers");
  const bucket = (env as { BUCKET?: FileBucket }).BUCKET;
  if (!bucket) throw new Error("Kho tệp chưa được cấu hình.");
  return bucket;
}

function decode(row: typeof adminItems.$inferSelect) {
  let data: Record<string, unknown> = {};
  try { data = JSON.parse(row.data) as Record<string, unknown>; } catch {}
  // The database title is the canonical uploaded filename. Keep it after the
  // legacy metadata so an old `name` field can never replace the real name.
  return { id: row.id, ...data, name: row.title, createdAt: row.createdAt };
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    const payload = (await request.json()) as {
      objectKey?: string;
      name?: string;
      folder?: string;
      size?: number;
      contentType?: string;
    };
    const objectKey = String(payload.objectKey || "");
    const name = String(payload.name || "").trim();
    const folder = String(payload.folder || "Tài liệu chung").trim();
    const expectedSize = Number(payload.size || 0);
    if (!objectKey.startsWith("documents/") || !name || expectedSize <= 0)
      return Response.json({ error: "Thông tin tệp không hợp lệ." }, { status: 400 });

    const bucket = await getBucket();
    const object = await bucket.head(objectKey);
    if (!object)
      return Response.json({ error: "R2 chưa nhận được tệp. Vui lòng thử lại." }, { status: 409 });
    if (object.size !== expectedSize || object.size > MAX_FILE_SIZE) {
      await bucket.delete(objectKey);
      return Response.json(
        { error: "Dung lượng tệp không hợp lệ hoặc vượt quá 10 MB." },
        { status: 400 },
      );
    }

    const db = await getDb();
    const existing = await db
      .select()
      .from(adminItems)
      .where(and(eq(adminItems.kind, "documents"), eq(adminItems.itemKey, objectKey)))
      .limit(1);
    if (existing.length) return Response.json({ document: decode(existing[0]) });

    const now = new Date().toISOString();
    const contentType = object.httpMetadata?.contentType || String(payload.contentType || "application/octet-stream");
    const result = await db
      .insert(adminItems)
      .values({
        kind: "documents",
        itemKey: objectKey,
        title: name,
        data: JSON.stringify({ objectKey, folder, size: object.size, contentType }),
        createdAt: now,
        updatedAt: now,
      })
      .returning();

    try {
      await createAutomaticNotification({
        audience: "all_students",
        className: folder === "Tài liệu chung" ? undefined : folder,
        title: "Tài liệu mới: " + name,
        body: "Giáo viên vừa đăng tài liệu vào thư mục “" + folder + "”.",
        actionView: "documents",
        category: "document",
      });
    } catch (error) {
      console.error("document_notification_failed", {
        objectKey,
        message: error instanceof Error ? error.message : String(error),
      });
    }
    return Response.json({ document: decode(result[0]) }, { status: 201 });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Không thể hoàn tất tải tài liệu." },
      { status: 500 },
    );
  }
}
