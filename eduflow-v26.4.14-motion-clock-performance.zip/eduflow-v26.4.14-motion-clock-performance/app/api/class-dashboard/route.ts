import { desc, eq, inArray } from "drizzle-orm";
import { getDb } from "../../../db";
import { adminItems, pointTransactions, studentEnrollments, students } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";

function decodeData(value: string): Record<string, unknown> {
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const className = String(new URL(request.url).searchParams.get("className") || "").trim();
  const classKey = String(new URL(request.url).searchParams.get("classKey") || "").trim();
  if (!className) return Response.json({ error: "Thiếu lớp học cần tải." }, { status: 400 });

  try {
    const db = await getDb();
    const members = classKey
      ? await db.select({ id: students.id, code: students.code }).from(studentEnrollments).innerJoin(students, eq(students.id, studentEnrollments.studentId)).where(eq(studentEnrollments.classKey, classKey))
      : await db.select({ id: students.id, code: students.code }).from(students).where(eq(students.className, className));
    const memberIds = members.map(function (student) { return student.id; });
    const memberIdSet = new Set(memberIds);
    const memberCodeSet = new Set(members.map(function (student) { return student.code; }));
    const [transactions, commentRows] = await Promise.all([
      memberIds.length
        ? db.select().from(pointTransactions).where(inArray(pointTransactions.studentId, memberIds))
        : Promise.resolve([]),
      db.select().from(adminItems).where(eq(adminItems.kind, "comments")).orderBy(desc(adminItems.id)),
    ]);
    const points: Record<string, number> = {};
    transactions.forEach(function (item) {
      points[String(item.studentId)] = (points[String(item.studentId)] || 0) + item.delta;
    });
    const latestComments: Record<string, { id: number; content: string; date: string; type: string }> = {};
    commentRows.sort(function(a, b) {
      const aData = decodeData(a.data);
      const bData = decodeData(b.data);
      const aDate = String(aData.commentDate || a.createdAt.slice(0, 10));
      const bDate = String(bData.commentDate || b.createdAt.slice(0, 10));
      return bDate.localeCompare(aDate) || String(b.createdAt).localeCompare(String(a.createdAt));
    }).forEach(function (row) {
      const data = decodeData(row.data);
      const studentId = Number(data.studentId);
      const studentCode = String(data.studentCode || "");
      if ((!memberIdSet.has(studentId) && !memberCodeSet.has(studentCode)) || latestComments[String(studentId)]) return;
      latestComments[String(studentId)] = {
        id: row.id,
        content: String(data.content || ""),
        date: String(data.commentDate || row.createdAt.slice(0, 10)),
        type: String(data.commentType || "Theo ngày"),
      };
    });
    return Response.json({ points, latestComments }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Không thể tải dữ liệu lớp. Vui lòng thử lại." }, { status: 500 });
  }
}
