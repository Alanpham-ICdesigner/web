import { and, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { studentEnrollments, students } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";
import { activeEnrollments, resolveCourse } from "../../../lib/course-access";

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const url = new URL(request.url);
  const classKey = String(url.searchParams.get("classKey") || "");
  const studentId = Number(url.searchParams.get("studentId") || 0);
  const db = await getDb();
  const rows = classKey
    ? await db.select().from(studentEnrollments).where(and(eq(studentEnrollments.classKey, classKey), eq(studentEnrollments.status, "active")))
    : studentId
      ? await activeEnrollments(db, studentId)
      : await db.select().from(studentEnrollments).where(eq(studentEnrollments.status, "active"));
  return Response.json({ enrollments: rows }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { classKey?: string; className?: string; studentIds?: number[]; studentId?: number };
  const db = await getDb();
  const course = await resolveCourse(db, { classKey: String(payload.classKey || ""), className: String(payload.className || "") });
  if (!course) return Response.json({ error: "Không tìm thấy lớp học." }, { status: 404 });
  const studentIds = Array.from(new Set((payload.studentIds || [payload.studentId]).map(Number).filter(Boolean)));
  if (!studentIds.length || studentIds.length > 500) return Response.json({ error: "Vui lòng chọn ít nhất một học sinh." }, { status: 400 });
  const now = new Date().toISOString();
  let added = 0;
  for (const studentId of studentIds) {
    const studentRows = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
    if (!studentRows[0]) continue;
    const existing = await db.select().from(studentEnrollments).where(and(eq(studentEnrollments.studentId, studentId), eq(studentEnrollments.classKey, course.key))).limit(1);
    if (existing[0]?.status === "active") continue;
    await db.insert(studentEnrollments).values({ studentId, classKey: course.key, className: course.name, status: "active", enrolledAt: now, createdAt: now, updatedAt: now }).onConflictDoUpdate({
      target: [studentEnrollments.studentId, studentEnrollments.classKey],
      set: { className: course.name, status: "active", updatedAt: now },
    });
    if (!existing.length || existing[0].status !== "active") added += 1;
    if (!studentRows[0].className || studentRows[0].className === "Chưa xếp lớp") {
      await db.update(students).set({ className: course.name }).where(eq(students.id, studentId));
    }
  }
  return Response.json({ success: true, added, alreadyEnrolled: studentIds.length - added });
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { classKey?: string; studentId?: number };
  const studentId = Number(payload.studentId);
  const classKey = String(payload.classKey || "");
  if (!studentId || !classKey) return Response.json({ error: "Thiếu lớp hoặc học sinh cần xóa." }, { status: 400 });
  const db = await getDb();
  const removed = await db.select().from(studentEnrollments).where(and(eq(studentEnrollments.studentId, studentId), eq(studentEnrollments.classKey, classKey))).limit(1);
  if (!removed[0]) return Response.json({ success: true, removed: false });
  await db.delete(studentEnrollments).where(and(eq(studentEnrollments.studentId, studentId), eq(studentEnrollments.classKey, classKey)));
  const remaining = await activeEnrollments(db, studentId);
  const studentRows = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (studentRows[0] && studentRows[0].className === removed[0].className) {
    await db.update(students).set({ className: remaining[0]?.className || "Chưa xếp lớp" }).where(eq(students.id, studentId));
  }
  return Response.json({ success: true, removed: true, remaining: remaining.length });
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { studentId?: number; fromClassKey?: string; toClassKey?: string };
  const studentId = Number(payload.studentId);
  const fromClassKey = String(payload.fromClassKey || "");
  const toClassKey = String(payload.toClassKey || "");
  if (!studentId || !fromClassKey || !toClassKey || fromClassKey === toClassKey) return Response.json({ error: "Thông tin chuyển lớp không hợp lệ." }, { status: 400 });
  const db = await getDb();
  const target = await resolveCourse(db, { classKey: toClassKey });
  if (!target) return Response.json({ error: "Không tìm thấy lớp chuyển đến." }, { status: 404 });
  const now = new Date().toISOString();
  await db.insert(studentEnrollments).values({ studentId, classKey: target.key, className: target.name, status: "active", enrolledAt: now, createdAt: now, updatedAt: now }).onConflictDoUpdate({ target: [studentEnrollments.studentId, studentEnrollments.classKey], set: { className: target.name, status: "active", updatedAt: now } });
  await db.delete(studentEnrollments).where(and(eq(studentEnrollments.studentId, studentId), eq(studentEnrollments.classKey, fromClassKey)));
  const studentRows = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (studentRows[0]) await db.update(students).set({ className: target.name }).where(eq(students.id, studentId));
  return Response.json({ success: true });
}
