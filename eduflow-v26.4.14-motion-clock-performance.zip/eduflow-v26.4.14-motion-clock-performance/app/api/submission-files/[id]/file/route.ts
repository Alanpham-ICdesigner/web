import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { assignmentSubmissionFiles, assignmentSubmissions } from "../../../../../db/schema";
import { isAdmin } from "../../../../../lib/admin-auth";
import { getStudentSessionId } from "../../../../../lib/student-auth";
import { secureFileHeaders } from "../../../../../lib/secure-file-response";

type StoredObject = { body: BodyInit; httpMetadata?: { contentType?: string } };
type FileBucket = { get(key: string): Promise<StoredObject | null> };

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const id = Number((await context.params).id);
  if (!id) return new Response("Không tìm thấy tệp bài nộp.", { status: 404 });
  const db = await getDb();
  const fileRows = await db.select().from(assignmentSubmissionFiles).where(eq(assignmentSubmissionFiles.id, id)).limit(1);
  const file = fileRows[0];
  if (!file?.objectKey) return new Response("Không tìm thấy tệp bài nộp.", { status: 404 });
  const submissionRows = await db.select({ studentId: assignmentSubmissions.studentId }).from(assignmentSubmissions).where(eq(assignmentSubmissions.id, file.submissionId)).limit(1);
  const submission = submissionRows[0];
  if (!submission) return new Response("Bài nộp không còn tồn tại.", { status: 404 });
  const studentId = await getStudentSessionId(request);
  if (!await isAdmin(request) && studentId !== submission.studentId) return new Response("Bạn không có quyền xem tệp này.", { status: 403 });
  const { env } = await import("cloudflare:workers");
  const bucket = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!bucket) return new Response("Kho tệp chưa được cấu hình.", { status: 503 });
  const object = await bucket.get(file.objectKey);
  if (!object) return new Response("Tệp đã bị xóa.", { status: 404 });
  return new Response(object.body, { headers: secureFileHeaders(
    request,
    file.fileName || "bai-nop",
    file.contentType || object.httpMetadata?.contentType || "application/octet-stream",
  ) });
}
