import { asc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { assignments, courseSchedules, studentEnrollments, students } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";
import { resolveCourse } from "../../../lib/course-access";

type ScheduleInput = { weekday?: number; startTime?: string; endTime?: string; room?: string };

function cleanSchedule(raw: ScheduleInput, index: number) {
  const weekday = Math.trunc(Number(raw.weekday));
  const startTime = String(raw.startTime || "");
  const endTime = String(raw.endTime || "");
  if (weekday < 1 || weekday > 7 || !/^\d{2}:\d{2}$/.test(startTime) || !/^\d{2}:\d{2}$/.test(endTime) || startTime >= endTime) return null;
  return { weekday, startTime, endTime, room: String(raw.room || "").trim().slice(0, 100), sortOrder: index };
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const classKey = String(new URL(request.url).searchParams.get("classKey") || "");
  const db = await getDb();
  const rows = classKey
    ? await db.select().from(courseSchedules).where(eq(courseSchedules.classKey, classKey)).orderBy(asc(courseSchedules.sortOrder))
    : await db.select().from(courseSchedules).orderBy(asc(courseSchedules.classKey), asc(courseSchedules.sortOrder));
  return Response.json({ schedules: rows }, { headers: { "Cache-Control": "no-store" } });
}

export async function PUT(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json().catch(function() { return {}; }) as { classKey?: string; className?: string; schedules?: ScheduleInput[] };
  const db = await getDb();
  const course = await resolveCourse(db, { classKey: String(payload.classKey || ""), className: String(payload.className || "") });
  if (!course) return Response.json({ error: "Không tìm thấy lớp học." }, { status: 404 });
  const schedules = (Array.isArray(payload.schedules) ? payload.schedules : []).map(cleanSchedule).filter(function(item): item is NonNullable<typeof item> { return item !== null; });
  if (!schedules.length) return Response.json({ error: "Mỗi lớp cần ít nhất một buổi học hợp lệ." }, { status: 400 });
  const signatures = new Set<string>();
  for (const item of schedules) {
    const signature = item.weekday + "|" + item.startTime + "|" + item.endTime;
    if (signatures.has(signature)) return Response.json({ error: "Lịch học bị trùng buổi." }, { status: 400 });
    signatures.add(signature);
  }
  await db.delete(courseSchedules).where(eq(courseSchedules.classKey, course.key));
  const now = new Date().toISOString();
  await db.insert(courseSchedules).values(schedules.map(function(item) { return { ...item, classKey: course.key, createdAt: now, updatedAt: now }; }));
  await db.update(studentEnrollments).set({ className: course.name, updatedAt: now }).where(eq(studentEnrollments.classKey, course.key));
  await db.update(assignments).set({ className: course.name, classKey: course.key }).where(eq(assignments.classKey, course.key));
  const members = await db.select({ studentId: studentEnrollments.studentId }).from(studentEnrollments).where(eq(studentEnrollments.classKey, course.key));
  for (const member of members) {
    const rows = await db.select({ className: students.className }).from(students).where(eq(students.id, member.studentId)).limit(1);
    if (rows[0] && (!rows[0].className || rows[0].className === "Chưa xếp lớp")) await db.update(students).set({ className: course.name }).where(eq(students.id, member.studentId));
  }
  return Response.json({ success: true, schedules });
}
