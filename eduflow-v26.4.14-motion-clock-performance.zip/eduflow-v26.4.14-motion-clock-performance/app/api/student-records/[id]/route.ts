import { and, desc, eq, inArray } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems, courseSessions, pointTransactions, studentEnrollments, students } from "../../../../db/schema";
import { requireAdmin } from "../../../../lib/admin-auth";
import { vietnamDateKey } from "../../../../lib/student-companion";

type JsonData = Record<string, unknown>;

function decode(value: string): JsonData {
  try {
    return JSON.parse(value) as JsonData;
  } catch {
    return {};
  }
}

function text(value: unknown, maximum = 2_000): string {
  return String(value || "").replace(/\r\n?/g, "\n").trim().slice(0, maximum);
}

function dateOnly(value: unknown): string {
  const valueText = String(value || "");
  return /^\d{4}-\d{2}-\d{2}$/.test(valueText) ? valueText : vietnamDateKey();
}

async function findStudent(id: number) {
  const db = await getDb();
  const rows = await db.select().from(students).where(eq(students.id, id)).limit(1);
  return rows[0] || null;
}

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const id = Number((await context.params).id);
  if (!id) return Response.json({ error: "Học sinh không hợp lệ." }, { status: 400 });

  try {
    const db = await getDb();
    const student = await findStudent(id);
    if (!student) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });
    const courseId = String(new URL(request.url).searchParams.get("courseId") || "");
    const enrollmentRows = courseId ? await db.select().from(studentEnrollments).where(and(eq(studentEnrollments.studentId, id), eq(studentEnrollments.classKey, courseId), eq(studentEnrollments.status, "active"))).limit(1) : [];
    if (courseId && !enrollmentRows[0]) return Response.json({ error: "Học sinh không thuộc lớp này." }, { status: 403 });
    const selectedClassName = enrollmentRows[0]?.className || student.className;
    const [itemRows, transactionRows, sessionRows] = await Promise.all([
      db.select().from(adminItems)
        .where(inArray(adminItems.kind, ["grades", "attendance", "comments", "settings", "classes"]))
        .orderBy(desc(adminItems.id)),
      db.select().from(pointTransactions)
        .where(eq(pointTransactions.studentId, id))
        .orderBy(desc(pointTransactions.id)),
      courseId ? db.select().from(courseSessions).where(eq(courseSessions.classKey, courseId)).orderBy(desc(courseSessions.sessionDate)) : Promise.resolve([]),
    ]);

    const settings = itemRows.find(function (row) { return row.kind === "settings" && row.itemKey === "profile"; });
    const profile = settings ? decode(settings.data) : {};
    const teacherName = String(profile.teacherName || "Giáo viên");
    const classRow = itemRows.find(function (row) { return row.kind === "classes" && (courseId ? row.itemKey === courseId : row.title === selectedClassName); });
    const classData = classRow ? decode(classRow.data) : {};

    const grades: Array<JsonData> = [];
    itemRows.filter(function (row) { return row.kind === "grades"; }).forEach(function (row) {
      const data = decode(row.data);
      const className = String(data.className || selectedClassName);
      const matchesCourseKey = Boolean(courseId) && String(data.classKey || data.classId || "") === courseId;
      if (!matchesCourseKey && className !== "Tất cả lớp" && className !== selectedClassName) return;
      const rawScores = (data.scores || {}) as Record<string, unknown>;
      const studentScores = rawScores[student.code];
      if (Array.isArray(data.assessments)) {
        const scoreMap = studentScores && typeof studentScores === "object" && !Array.isArray(studentScores)
          ? studentScores as Record<string, unknown>
          : {};
        (data.assessments as JsonData[]).forEach(function (assessment, index) {
          const assessmentId = String(assessment.id || "assessment-" + index);
          const score = Number(scoreMap[assessmentId]);
          if (!Number.isFinite(score)) return;
          grades.push({
            id: row.id + "|" + assessmentId,
            date: String(assessment.date || ""),
            title: String(assessment.title || "Bài kiểm tra " + (index + 1)),
            category: String(assessment.category || "Kiểm tra"),
            maxScore: Math.max(0.1, Number(assessment.maxScore) || 10),
            score,
            term: String(data.term || ""),
          });
        });
        return;
      }
      const legacyScores = Array.isArray(studentScores) ? studentScores : [];
      const labels = ["Bài 1", "Bài 2", "Giữa kỳ", "Cuối kỳ"];
      legacyScores.forEach(function (value, index) {
        const score = Number(value);
        if (!Number.isFinite(score)) return;
        grades.push({
          id: row.id + "|legacy-" + index,
          date: "",
          title: labels[index] || "Bài " + (index + 1),
          category: index < 2 ? "Kiểm tra" : labels[index] || "Kiểm tra",
          maxScore: 10,
          score,
          term: String(data.term || ""),
        });
      });
    });

    const attendance: Array<JsonData> = [];
    itemRows.filter(function (row) { return row.kind === "attendance"; }).forEach(function (row) {
      const data = decode(row.data);
      const className = String(data.className || "");
      const states = (data.states || {}) as Record<string, unknown>;
      const matchesCourseKey = Boolean(courseId) && String(data.classKey || data.classId || "") === courseId;
      if (!matchesCourseKey && className !== "Tất cả lớp" && className !== selectedClassName) return;
      const status = String(states[student.code] || "");
      if (!status) return;
      const arrivalTimes = (data.arrivalTimes || {}) as Record<string, unknown>;
      const notes = (data.notes || {}) as Record<string, unknown>;
      attendance.push({
        id: row.id,
        date: String(data.date || ""),
        startTime: String(data.startTime || classData.startTime || ""),
        endTime: String(data.endTime || classData.endTime || ""),
        status,
        arrivalTime: String(arrivalTimes[student.code] || ""),
        note: String(notes[student.code] || ""),
        sessionType: String(data.sessionType || "regular"),
        sessionId: Number(data.sessionId || 0),
      });
    });

    const comments = itemRows.filter(function (row) {
      if (row.kind !== "comments") return false;
      const data = decode(row.data);
      const ownsStudent = Number(data.studentId) === id || String(data.studentCode || "") === student.code;
      const ownsCourse = Boolean(courseId) && String(data.classKey || "") === courseId || (!data.classKey && String(data.className || selectedClassName) === selectedClassName);
      return ownsStudent && ownsCourse;
    }).map(function (row) {
      const data = decode(row.data);
      return {
        id: row.id,
        content: String(data.content || ""),
        date: String(data.commentDate || row.createdAt.slice(0, 10)),
        type: String(data.commentType || "Theo ngày"),
        creator: String(data.creator || teacherName),
        createdAt: row.createdAt,
      };
    }).sort(function(a, b) {
      const byDate = String(b.date).localeCompare(String(a.date));
      return byDate || String(b.createdAt).localeCompare(String(a.createdAt));
    });

    const points = transactionRows.map(function (row) {
      const automatic = row.source !== "admin" && row.source !== "selected_rule";
      return {
        id: row.id,
        delta: row.delta,
        reason: row.reason,
        source: row.source,
        actor: automatic ? "Hệ thống" : teacherName,
        createdAt: row.createdAt,
        date: row.createdAt.slice(0, 10),
      };
    });
    const pointBalance = points.reduce(function (total, item) { return total + Number(item.delta); }, 0);

    return Response.json({
      student,
      classInfo: {
        key: courseId || String(classRow?.itemKey || ""),
        name: selectedClassName,
        label: String(classData.label || ""),
        teacher: String(classData.teacher || teacherName),
        room: String(classData.room || ""),
        schedule: String(classData.schedule || ""),
        startTime: String(classData.startTime || ""),
        endTime: String(classData.endTime || ""),
      },
      grades: grades.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }),
      attendance: attendance.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }),
      points,
      pointBalance,
      comments,
      sessions: sessionRows,
      teacherName,
    }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Không thể tải dữ liệu. Vui lòng thử lại." }, { status: 500 });
  }
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const id = Number((await context.params).id);
  const student = id ? await findStudent(id) : null;
  if (!student) return Response.json({ error: "Không tìm thấy học sinh." }, { status: 404 });
  const payload = await request.json().catch(function () { return {}; }) as JsonData;
  const content = text(payload.content);
  if (!content) return Response.json({ error: "Vui lòng nhập nội dung nhận xét." }, { status: 400 });
  const now = new Date().toISOString();
  const db = await getDb();
  const courseId = String(new URL(request.url).searchParams.get("courseId") || "");
  const enrollmentRows = courseId ? await db.select().from(studentEnrollments).where(and(eq(studentEnrollments.studentId, id), eq(studentEnrollments.classKey, courseId), eq(studentEnrollments.status, "active"))).limit(1) : [];
  if (courseId && !enrollmentRows[0]) return Response.json({ error: "Học sinh không thuộc lớp này." }, { status: 403 });
  const selectedClassName = enrollmentRows[0]?.className || student.className;
  const settings = await db.select().from(adminItems).where(and(eq(adminItems.kind, "settings"), eq(adminItems.itemKey, "profile"))).limit(1);
  const profile = settings[0] ? decode(settings[0].data) : {};
  const data = {
    studentId: student.id,
    studentCode: student.code,
    classKey: courseId,
    className: selectedClassName,
    content,
    commentDate: dateOnly(payload.date),
    commentType: text(payload.type, 40) || "Theo ngày",
    creator: String(profile.teacherName || "Giáo viên"),
  };
  const rows = await db.insert(adminItems).values({
    kind: "comments",
    itemKey: crypto.randomUUID(),
    title: "Nhận xét " + student.name,
    data: JSON.stringify(data),
    createdAt: now,
    updatedAt: now,
  }).returning();
  return Response.json({ comment: { id: rows[0].id, ...data, createdAt: now } }, { status: 201 });
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const studentId = Number((await context.params).id);
  const payload = await request.json().catch(function () { return {}; }) as JsonData;
  const commentId = Number(payload.commentId);
  const content = text(payload.content);
  if (!studentId || !commentId || !content) return Response.json({ error: "Dữ liệu nhận xét không hợp lệ." }, { status: 400 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.id, commentId), eq(adminItems.kind, "comments"))).limit(1);
  if (!rows.length) return Response.json({ error: "Không tìm thấy nhận xét." }, { status: 404 });
  const data = decode(rows[0].data);
  if (Number(data.studentId) !== studentId) return Response.json({ error: "Nhận xét không thuộc học sinh này." }, { status: 403 });
  const next = { ...data, content, commentDate: dateOnly(payload.date), commentType: text(payload.type, 40) || "Theo ngày" };
  await db.update(adminItems).set({ data: JSON.stringify(next), updatedAt: new Date().toISOString() }).where(eq(adminItems.id, commentId));
  return Response.json({ success: true });
}

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const studentId = Number((await context.params).id);
  const payload = await request.json().catch(function () { return {}; }) as JsonData;
  const commentId = Number(payload.commentId);
  if (!studentId || !commentId) return Response.json({ error: "Dữ liệu nhận xét không hợp lệ." }, { status: 400 });
  const db = await getDb();
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.id, commentId), eq(adminItems.kind, "comments"))).limit(1);
  if (!rows.length) return Response.json({ error: "Không tìm thấy nhận xét." }, { status: 404 });
  const data = decode(rows[0].data);
  if (Number(data.studentId) !== studentId) return Response.json({ error: "Nhận xét không thuộc học sinh này." }, { status: 403 });
  await db.delete(adminItems).where(eq(adminItems.id, commentId));
  return Response.json({ success: true });
}
