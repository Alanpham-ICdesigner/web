import { and, desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { adminItems, appState, assignmentSubmissions, assignmentTeacherCompletions, assignments, studentEnrollments } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";
import { getAssignmentStatus } from "../../../lib/assignment-status";
import { fallbackClassKey, resolveCourse } from "../../../lib/course-access";
import { isAssignmentCompletedStatus, isStudentSubmittedStatus } from "../../../lib/assignment-submission";
import { sendPushToCourse, sendUpcomingAssignmentReminders } from "../../../lib/web-push";

const samples = [
  ["Khảo sát hàm số bậc ba", "Toán 12A1", "2026-08-11T23:59", 10, "Sắp hết hạn", 20, 25],
  ["Dãy số và cấp số cộng", "Toán 11A2", "2026-08-14T20:00", 10, "Đang mở", 17, 22],
  ["Hệ thức lượng trong tam giác", "Toán 10A3", "2026-08-17T22:00", 10, "Đang mở", 9, 18],
  ["Bài kiểm tra Hàm số", "Toán 12A1", "2026-08-08T20:00", 10, "Đã kết thúc", 25, 25]
] as const;

async function seedOnce() {
  const db = await getDb();
  const seeded = await db.select({ key: appState.key }).from(appState).where(eq(appState.key, "initial_assignments_seeded")).limit(1);
  if (seeded.length) return;
  const existing = await db.select({ id: assignments.id }).from(assignments).limit(1);
  if (!existing.length) {
    const now = new Date().toISOString();
    for (const row of samples) {
      const course = await resolveCourse(db, { className: row[1] });
      await db.insert(assignments).values({
        title: row[0], className: row[1], classKey: course?.key || fallbackClassKey(row[1]), dueDate: row[2], maxScore: row[3],
        status: row[4], submittedCount: row[5], totalStudents: row[6], createdAt: now
      }).onConflictDoNothing();
    }
  }
  await db.insert(appState).values({ key: "initial_assignments_seeded", value: new Date().toISOString() }).onConflictDoNothing();
}

export async function GET(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  try {
    await seedOnce();
    const db = await getDb();
    const [rows, submissions, teacherCompletions, studentRows] = await Promise.all([
      db.select().from(assignments).orderBy(desc(assignments.id)),
      db.select({
        assignmentId: assignmentSubmissions.assignmentId,
        studentId: assignmentSubmissions.studentId,
        status: assignmentSubmissions.status,
        score: assignmentSubmissions.score,
        feedback: assignmentSubmissions.feedback,
      }).from(assignmentSubmissions),
      db.select({ assignmentId: assignmentTeacherCompletions.assignmentId, studentId: assignmentTeacherCompletions.studentId }).from(assignmentTeacherCompletions),
      db.select({ studentId: studentEnrollments.studentId, classKey: studentEnrollments.classKey }).from(studentEnrollments).where(eq(studentEnrollments.status, "active"))
    ]);
    const activeStudentsByClass = new Map<string, Set<number>>();
    studentRows.forEach(function(row) {
      const ids = activeStudentsByClass.get(row.classKey) || new Set<number>();
      ids.add(row.studentId);
      activeStudentsByClass.set(row.classKey, ids);
    });
    const submissionsByAssignment = new Map<number, typeof submissions>();
    submissions.forEach(function(row) {
      const list = submissionsByAssignment.get(row.assignmentId) || [];
      list.push(row);
      submissionsByAssignment.set(row.assignmentId, list);
    });
    const completionsByAssignment = new Map<number, typeof teacherCompletions>();
    teacherCompletions.forEach(function(row) {
      const list = completionsByAssignment.get(row.assignmentId) || [];
      list.push(row);
      completionsByAssignment.set(row.assignmentId, list);
    });
    const now = Date.now();
    return Response.json({ assignments: rows.map(function(row) {
      const activeStudentIds = activeStudentsByClass.get(row.classKey) || activeStudentsByClass.get(fallbackClassKey(row.className)) || new Set<number>();
      const submittedStudentIds = new Set<number>();
      let pendingGradingCount = 0;
      (submissionsByAssignment.get(row.id) || []).forEach(function(submission) {
        if (!activeStudentIds.has(submission.studentId)) return;
        if (isAssignmentCompletedStatus(submission.status)) submittedStudentIds.add(submission.studentId);
        if (
          isStudentSubmittedStatus(submission.status) &&
          (submission.status !== "graded" || submission.score === null || submission.score === undefined || !String(submission.feedback || "").trim())
        ) pendingGradingCount += 1;
      });
      (completionsByAssignment.get(row.id) || []).forEach(function(completion) {
        if (!activeStudentIds.has(completion.studentId)) return;
        submittedStudentIds.add(completion.studentId);
      });
      return {
        ...row,
        status: getAssignmentStatus(row.dueDate, now),
        submittedCount: submittedStudentIds.size,
        totalStudents: activeStudentIds.size || row.totalStudents || 0,
        pendingGradingCount,
      };
    }) }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Không thể tải danh sách bài tập." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as Record<string, unknown>;
  const title = String(payload.title || "").trim();
  const className = String(payload.className || "").trim();
  const classKeyInput = String(payload.classKey || "").trim();
  const dueDate = String(payload.dueDate || "").trim();
  if (!title || !className || !dueDate) {
    return Response.json({ error: "Vui lòng nhập tên bài tập, lớp và hạn nộp." }, { status: 400 });
  }
  const db = await getDb();
  const course = await resolveCourse(db, { classKey: classKeyInput, className });
  const classKey = course?.key || fallbackClassKey(className);
  const classStudents = await db.select({ id: studentEnrollments.id }).from(studentEnrollments).where(and(eq(studentEnrollments.classKey, classKey), eq(studentEnrollments.status, "active")));
  const result = await db.insert(assignments).values({
    title, className: course?.name || className, classKey, dueDate,
    description: String(payload.description || ""),
    maxScore: Number(payload.maxScore) || 10,
    status: getAssignmentStatus(dueDate),
    submittedCount: 0,
    totalStudents: classStudents.length,
    createdAt: new Date().toISOString()
  }).returning();
  const assignment = result[0];
  const now = new Date().toISOString();
  await db.insert(adminItems).values({
    kind: "notifications",
    itemKey: "assignment-" + assignment.id,
    title: "Bài tập mới: " + assignment.title,
    data: JSON.stringify({
      body: "Hạn nộp " + new Date(assignment.dueDate).toLocaleString("vi-VN") + ". " + (assignment.description || "Mở mục Bài tập để xem chi tiết."),
      target: assignment.className,
      audience: "all_students",
      className: assignment.className,
      classKey: assignment.classKey,
      actionView: "assignments",
      category: "assignment",
      readByStudentIds: [],
      assignmentId: assignment.id,
      automatic: true
    }),
    createdAt: now,
    updatedAt: now
  }).onConflictDoNothing();
  await sendPushToCourse(assignment.classKey, assignment.className, {
    title: "Bài tập mới: " + assignment.title,
    body: "Hạn nộp " + new Date(assignment.dueDate).toLocaleString("vi-VN") + ". Mở Bài tập để xem chi tiết.",
    url: "/student?courseId=" + encodeURIComponent(assignment.classKey) + "&tab=assignments&assignmentId=" + assignment.id,
    tag: "assignment-" + assignment.id,
    category: "assignment",
    relatedId: assignment.id,
  }, "assignment:" + assignment.id).catch(function(error) { console.error("[V26 Web Push] assignment", error); });
  // If a teacher creates an assignment already inside the exact six-hour
  // "Sắp hết hạn" window, do not wait for the next hourly sweep: create the
  // targeted, idempotent due reminder immediately. The helper's event key
  // prevents this call and the scheduled call from ever duplicating it.
  if (getAssignmentStatus(assignment.dueDate) === "Sắp hết hạn") {
    await sendUpcomingAssignmentReminders(new Date()).catch(function(error) { console.error("[V26.2.2] immediate assignment reminder", error); });
  }
  return Response.json({ assignment }, { status: 201 });
}

export async function PATCH(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as Record<string, unknown>;
  const id = Number(payload.id);
  if (!id) return Response.json({ error: "Thiếu bài tập cần sửa." }, { status: 400 });
  const db = await getDb();
  const className = String(payload.className || "").trim();
  const course = await resolveCourse(db, { classKey: String(payload.classKey || ""), className });
  const classKey = course?.key || fallbackClassKey(className);
  const classStudents = await db.select({ id: studentEnrollments.id }).from(studentEnrollments).where(and(eq(studentEnrollments.classKey, classKey), eq(studentEnrollments.status, "active")));
  const result = await db.update(assignments).set({
    title: String(payload.title || "").trim(),
    className: course?.name || className,
    classKey,
    dueDate: String(payload.dueDate || ""),
    description: String(payload.description || ""),
    maxScore: Number(payload.maxScore) || 10,
    status: getAssignmentStatus(String(payload.dueDate || "")),
    totalStudents: classStudents.length
  }).where(eq(assignments.id, id)).returning();
  const assignment = result[0];
  // A changed deadline is part of the reminder identity. If the edited
  // assignment enters the upcoming window now, send once for the new deadline.
  if (assignment && getAssignmentStatus(assignment.dueDate) === "Sắp hết hạn") {
    await sendUpcomingAssignmentReminders(new Date()).catch(function(error) { console.error("[V26.2.2] edited assignment reminder", error); });
  }
  return Response.json({ assignment });
}

export async function DELETE(request: Request) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const payload = await request.json() as { id?: number; all?: boolean };
  const db = await getDb();
  if (payload.all) {
    await db.delete(assignments);
    return Response.json({ success: true });
  }
  if (!payload.id) return Response.json({ error: "Thiếu bài tập cần xóa." }, { status: 400 });
  await db.delete(assignments).where(eq(assignments.id, payload.id));
  return Response.json({ success: true });
}
