import { and, eq, inArray } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { adminItems, assignmentSubmissionFiles, assignmentSubmissions, assignmentTeacherCompletions, assignments, studentEnrollments, students } from "../../../../../db/schema";
import { requireAdmin } from "../../../../../lib/admin-auth";
import { COMPLETED_SUBMISSION_STATUSES, isAssignmentCompletedStatus, isStudentSubmittedStatus } from "../../../../../lib/assignment-submission";
import { sendPushToStudent } from "../../../../../lib/web-push";

async function refreshAssignmentSubmittedCount(db: Awaited<ReturnType<typeof getDb>>, assignmentId: number): Promise<number> {
  const [submissionRows, completionRows] = await Promise.all([
    db.select({ studentId: assignmentSubmissions.studentId }).from(assignmentSubmissions)
      .where(and(eq(assignmentSubmissions.assignmentId, assignmentId), inArray(assignmentSubmissions.status, [...COMPLETED_SUBMISSION_STATUSES]))),
    db.select({ studentId: assignmentTeacherCompletions.studentId }).from(assignmentTeacherCompletions)
      .where(eq(assignmentTeacherCompletions.assignmentId, assignmentId)),
  ]);
  const submittedCount = new Set(submissionRows.concat(completionRows).map(function(row) { return row.studentId; })).size;
  await db.update(assignments).set({ submittedCount }).where(eq(assignments.id, assignmentId));
  return submittedCount;
}

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const id = Number((await context.params).id);
  if (!id) return Response.json({ error: "Bài tập không hợp lệ." }, { status: 400 });
  const db = await getDb();
  const assignmentRows = await db.select().from(assignments).where(eq(assignments.id, id)).limit(1);
  if (!assignmentRows.length) return Response.json({ error: "Không tìm thấy bài tập." }, { status: 404 });
  const assignment = assignmentRows[0];
  const [studentRows, submissionRows, completionRows] = await Promise.all([
    db.select({ id: students.id, code: students.code, name: students.name, className: studentEnrollments.className })
      .from(studentEnrollments)
      .innerJoin(students, eq(students.id, studentEnrollments.studentId))
      .where(and(eq(studentEnrollments.classKey, assignment.classKey), eq(studentEnrollments.status, "active")))
      .orderBy(students.name),
    db.select().from(assignmentSubmissions).where(eq(assignmentSubmissions.assignmentId, id)),
    db.select().from(assignmentTeacherCompletions).where(eq(assignmentTeacherCompletions.assignmentId, id)),
  ]);
  const uniqueStudentRows = Array.from(new Map(studentRows.map(function(student) { return [student.id, student]; })).values());
  const activeStudentIds = new Set(uniqueStudentRows.map(function(student) { return student.id; }));
  const relevantSubmissionRows = submissionRows.filter(function(row) { return activeStudentIds.has(row.studentId) && row.status !== "teacher_completed"; });
  const completionsByStudent = new Map(completionRows.filter(function(row) { return activeStudentIds.has(row.studentId); }).map(function(row) { return [row.studentId, row]; }));
  const submissionIds = relevantSubmissionRows.map(function(row) { return row.id; });
  const submissionFileRows = submissionIds.length
    ? await db.select().from(assignmentSubmissionFiles).where(inArray(assignmentSubmissionFiles.submissionId, submissionIds))
    : [];
  const filesBySubmission = new Map<number, typeof assignmentSubmissionFiles.$inferSelect[]>();
  submissionFileRows.forEach(function(file) {
    const current = filesBySubmission.get(file.submissionId) || [];
    current.push(file);
    filesBySubmission.set(file.submissionId, current);
  });
  const submissionsByStudent = new Map(relevantSubmissionRows.map(function(row) { return [row.studentId, row]; }));
  const submittedStudentIds = new Set(relevantSubmissionRows.filter(function(row) { return isStudentSubmittedStatus(row.status); }).map(function(row) { return row.studentId; }));
  completionsByStudent.forEach(function(_, studentId) { submittedStudentIds.add(studentId); });
  return Response.json({
    assignment,
    students: uniqueStudentRows.map(function(student) {
      const submission = submissionsByStudent.get(student.id);
      const teacherCompletion = completionsByStudent.get(student.id);
      return {
        ...student,
        submissionId: submission?.id || null,
        submittedAt: submission?.submittedAt || null,
        responseText: submission?.responseText || "",
        fileName: submission?.fileName || "",
        fileSize: submission?.fileSize || 0,
        contentType: submission?.contentType || "",
        files: submission ? (filesBySubmission.get(submission.id) || []).map(function(file) {
          return { id: file.id, fileName: file.fileName, fileSize: file.fileSize, contentType: file.contentType };
        }) : [],
        status: submission?.status || (teacherCompletion ? "teacher_completed" : "not_submitted"),
        score: submission?.score ?? null,
        feedback: submission?.feedback || "",
        gradedAt: submission?.gradedAt || null,
        updatedAt: submission?.updatedAt ?? teacherCompletion?.updatedAt ?? "",
      };
    }),
    submittedCount: submittedStudentIds.size,
    totalStudents: uniqueStudentRows.length
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const assignmentId = Number((await context.params).id);
  if (!assignmentId) return Response.json({ error: "Bài tập không hợp lệ." }, { status: 400 });
  const payload = await request.json().catch(function() { return {}; }) as { studentId?: number; completed?: boolean; score?: number | null; feedback?: string; expectedUpdatedAt?: string };
  const studentId = Number(payload.studentId);
  const grading = Object.prototype.hasOwnProperty.call(payload, "score") || Object.prototype.hasOwnProperty.call(payload, "feedback");
  if (!studentId || (!grading && typeof payload.completed !== "boolean")) {
    return Response.json({ error: "Thiếu học sinh hoặc dữ liệu cần cập nhật." }, { status: 400 });
  }

  const db = await getDb();
  const assignmentRows = await db.select().from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
  const assignment = assignmentRows[0];
  if (!assignment) return Response.json({ error: "Không tìm thấy bài tập." }, { status: 404 });
  const studentRows = await db.select({ id: students.id }).from(studentEnrollments).innerJoin(students, eq(students.id, studentEnrollments.studentId)).where(and(eq(students.id, studentId), eq(studentEnrollments.classKey, assignment.classKey), eq(studentEnrollments.status, "active"))).limit(1);
  if (!studentRows.length) return Response.json({ error: "Học sinh không thuộc lớp được giao bài tập này." }, { status: 400 });

  const existingRows = await db.select().from(assignmentSubmissions).where(and(eq(assignmentSubmissions.assignmentId, assignmentId), eq(assignmentSubmissions.studentId, studentId))).limit(1);
  const existing = existingRows[0];
  const completionRows = await db.select().from(assignmentTeacherCompletions).where(and(eq(assignmentTeacherCompletions.assignmentId, assignmentId), eq(assignmentTeacherCompletions.studentId, studentId))).limit(1);
  const teacherCompletion = completionRows[0];

  if (grading) {
    if (!existing || !isStudentSubmittedStatus(existing.status)) return Response.json({ error: "Học sinh chưa có bài nộp đang chờ chấm." }, { status: 400 });
    if (!Object.prototype.hasOwnProperty.call(payload, "expectedUpdatedAt") || String(payload.expectedUpdatedAt || "") !== existing.updatedAt) {
      return Response.json({ error: "Bài nộp đã thay đổi sau khi bạn mở. Vui lòng tải lại trước khi chấm." }, { status: 409, headers: { "Cache-Control": "no-store" } });
    }
    const score = payload.score === null || payload.score === undefined ? null : Number(payload.score);
    if (score !== null && (!Number.isFinite(score) || score < 0 || score > assignment.maxScore)) return Response.json({ error: "Điểm phải nằm trong khoảng 0 đến " + assignment.maxScore + "." }, { status: 400 });
    const feedback = String(payload.feedback || "").trim().slice(0, 5000);
    const previousScore = existing.score === null || existing.score === undefined ? null : Number(existing.score);
    const gradingChanged = previousScore !== score || String(existing.feedback || "") !== feedback || existing.status !== "graded";
    if (!gradingChanged) return Response.json({ success: true, submission: existing, unchanged: true }, { headers: { "Cache-Control": "no-store" } });
    const now = new Date().toISOString();
    const rows = await db.update(assignmentSubmissions).set({
      score,
      feedback,
      status: "graded",
      gradedAt: now,
      updatedAt: now,
    }).where(and(
      eq(assignmentSubmissions.id, existing.id),
      eq(assignmentSubmissions.status, existing.status),
      eq(assignmentSubmissions.updatedAt, existing.updatedAt),
    )).returning();
    if (!rows.length) return Response.json({ error: "Bài nộp vừa được thu hồi hoặc thay đổi. Vui lòng tải lại trước khi chấm." }, { status: 409 });
    const notificationKey = "assignment-grade-" + assignment.id + "-" + studentId;
    await db.insert(adminItems).values({
      kind: "notifications",
      itemKey: notificationKey,
      title: feedback ? "Có điểm/nhận xét mới" : "Có điểm mới",
      data: JSON.stringify({
        body: score === null ? (feedback || "Bài tập đã được giáo viên chấm.") : "Bài “" + assignment.title + "” được " + score + "/" + assignment.maxScore + " điểm" + (feedback ? ". " + feedback.slice(0, 160) : "."),
        audience: "student", studentId, classKey: assignment.classKey, className: assignment.className,
        actionView: "assignments", category: "grade", assignmentId: assignment.id, studentReadAt: null, automatic: true,
      }),
      createdAt: now, updatedAt: now,
    }).onConflictDoUpdate({
      target: [adminItems.kind, adminItems.itemKey],
      set: {
        title: feedback ? "Có điểm/nhận xét mới" : "Có điểm mới",
        data: JSON.stringify({
          body: score === null ? (feedback || "Bài tập đã được giáo viên chấm.") : "Bài “" + assignment.title + "” được " + score + "/" + assignment.maxScore + " điểm" + (feedback ? ". " + feedback.slice(0, 160) : "."),
          audience: "student", studentId, classKey: assignment.classKey, className: assignment.className,
          actionView: "assignments", category: "grade", assignmentId: assignment.id, studentReadAt: null, automatic: true,
        }),
        updatedAt: now,
      },
    });
    const gradeBody = score === null
      ? (feedback ? "Giáo viên đã gửi nhận xét mới cho bài “" + assignment.title + "”." : "Bài “" + assignment.title + "” đã được giáo viên chấm.")
      : "Bài “" + assignment.title + "” được " + score + "/" + assignment.maxScore + " điểm" + (feedback ? " và có nhận xét mới." : ".");
    await sendPushToStudent(studentId, {
      title: feedback ? "Có điểm/nhận xét mới" : "Có điểm mới",
      body: gradeBody,
      url: "/student?courseId=" + encodeURIComponent(assignment.classKey) + "&tab=assignments&assignmentId=" + assignment.id,
      tag: "assignment-grade-" + assignment.id + "-" + studentId,
      category: "grade",
      relatedId: assignment.id,
    }, "assignment-grade:" + assignment.id + ":" + studentId + ":" + now).catch(function(error) { console.error("[V26 Web Push] assignment grade", error); });
    return Response.json({ success: true, submission: rows[0] }, { headers: { "Cache-Control": "no-store" } });
  }

  const now = new Date().toISOString();
  let currentStatus = existing && existing.status !== "teacher_completed" ? existing.status : teacherCompletion ? "teacher_completed" : "not_submitted";
  let currentSubmissionId = existing && existing.status !== "teacher_completed" ? existing.id : null;
  let currentSubmittedAt = existing && existing.status !== "teacher_completed" ? existing.submittedAt : teacherCompletion?.completedAt || null;

  if (payload.completed) {
    if (existing && isStudentSubmittedStatus(existing.status)) return Response.json({ error: "Học sinh đã có bài nộp thật, không thể thay bằng trạng thái giáo viên đánh dấu." }, { status: 409 });
    if (teacherCompletion) {
      if (!Object.prototype.hasOwnProperty.call(payload, "expectedUpdatedAt") || String(payload.expectedUpdatedAt || "") !== teacherCompletion.updatedAt) {
        return Response.json({ error: "Trạng thái hoàn thành đã thay đổi. Vui lòng tải lại." }, { status: 409, headers: { "Cache-Control": "no-store" } });
      }
      const changed = await db.update(assignmentTeacherCompletions).set({ completedAt: now, updatedAt: now }).where(and(
        eq(assignmentTeacherCompletions.id, teacherCompletion.id),
        eq(assignmentTeacherCompletions.updatedAt, teacherCompletion.updatedAt),
      )).returning({ id: assignmentTeacherCompletions.id });
      if (!changed.length) return Response.json({ error: "Trạng thái hoàn thành vừa thay đổi. Vui lòng tải lại." }, { status: 409 });
    } else {
      const created = await db.insert(assignmentTeacherCompletions).values({ assignmentId, studentId, completedAt: now, updatedAt: now }).onConflictDoNothing().returning({ id: assignmentTeacherCompletions.id });
      if (!created.length) return Response.json({ error: "Trạng thái hoàn thành vừa được cập nhật ở thiết bị khác. Vui lòng tải lại." }, { status: 409 });
    }
    currentSubmissionId = null;
    currentSubmittedAt = now;
    currentStatus = "teacher_completed";
  } else if (teacherCompletion) {
    if (!Object.prototype.hasOwnProperty.call(payload, "expectedUpdatedAt") || String(payload.expectedUpdatedAt || "") !== teacherCompletion.updatedAt) {
      return Response.json({ error: "Trạng thái hoàn thành đã thay đổi. Vui lòng tải lại." }, { status: 409, headers: { "Cache-Control": "no-store" } });
    }
    const removed = await db.delete(assignmentTeacherCompletions).where(and(
      eq(assignmentTeacherCompletions.id, teacherCompletion.id),
      eq(assignmentTeacherCompletions.updatedAt, teacherCompletion.updatedAt),
    )).returning({ id: assignmentTeacherCompletions.id });
    if (!removed.length) return Response.json({ error: "Trạng thái hoàn thành vừa thay đổi. Vui lòng tải lại." }, { status: 409 });
    currentSubmissionId = existing && existing.status !== "teacher_completed" ? existing.id : null;
    currentSubmittedAt = existing && existing.status !== "teacher_completed" ? existing.submittedAt : null;
    currentStatus = existing && existing.status !== "teacher_completed" ? existing.status : "not_submitted";
  }

  const submittedCount = await refreshAssignmentSubmittedCount(db, assignmentId);
  return Response.json({ success: true, completed: isAssignmentCompletedStatus(currentStatus), submittedAt: currentSubmittedAt, submissionId: currentSubmissionId, status: currentStatus, updatedAt: now, submittedCount }, { headers: { "Cache-Control": "no-store" } });
}
