import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { assignments } from "../../../../../db/schema";
import { isAdmin, requireAdmin } from "../../../../../lib/admin-auth";
import { getStudentSessionId } from "../../../../../lib/student-auth";
import { studentCanAccessCourse } from "../../../../../lib/course-access";
import { secureFileHeaders } from "../../../../../lib/secure-file-response";

const MAX_SIZE = 10 * 1024 * 1024;
const ALLOWED_TYPES = new Set(["application/pdf", "image/jpeg", "image/png", "image/webp"]);
type StoredObject = { body: BodyInit; httpMetadata?: { contentType?: string } };
type FileBucket = {
  get(key: string): Promise<StoredObject | null>;
  put(key: string, value: ArrayBuffer, options?: { httpMetadata?: { contentType?: string } }): Promise<unknown>;
  delete(key: string): Promise<void>;
};

async function bucket(): Promise<FileBucket> {
  const { env } = await import("cloudflare:workers");
  const value = (env as unknown as { BUCKET?: FileBucket }).BUCKET;
  if (!value) throw new Error("Kho tệp chưa được cấu hình.");
  return value;
}

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const id = Number((await context.params).id);
  const db = await getDb();
  const rows = id ? await db.select().from(assignments).where(eq(assignments.id, id)).limit(1) : [];
  const assignment = rows[0];
  if (!assignment?.attachmentObjectKey) return new Response("Không tìm thấy tệp đính kèm.", { status: 404 });
  if (!await isAdmin(request)) {
    const studentId = await getStudentSessionId(request);
    if (!studentId || !await studentCanAccessCourse(db, studentId, assignment.classKey)) return new Response("Bạn không có quyền xem tệp này.", { status: 403 });
  }
  const object = await (await bucket()).get(assignment.attachmentObjectKey);
  if (!object) return new Response("Tệp đã bị xóa.", { status: 404 });
  return new Response(object.body, { headers: secureFileHeaders(
    request,
    assignment.attachmentName || "tai-lieu-bai-tap",
    assignment.attachmentType || object.httpMetadata?.contentType || "application/octet-stream",
  ) });
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const id = Number((await context.params).id);
  const db = await getDb();
  const rows = id ? await db.select().from(assignments).where(eq(assignments.id, id)).limit(1) : [];
  const assignment = rows[0];
  if (!assignment) return Response.json({ error: "Không tìm thấy bài tập." }, { status: 404 });
  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File) || !file.size) return Response.json({ error: "Vui lòng chọn tệp." }, { status: 400 });
  if (file.size > MAX_SIZE || !ALLOWED_TYPES.has(file.type)) return Response.json({ error: file.size > MAX_SIZE ? "Tệp tối đa 10 MB." : "Chỉ hỗ trợ ảnh hoặc PDF." }, { status: 400 });
  const storage = await bucket();
  const objectKey = "assignment-attachments/" + id + "/" + crypto.randomUUID();
  await storage.put(objectKey, await file.arrayBuffer(), { httpMetadata: { contentType: file.type } });
  try {
    await db.update(assignments).set({ attachmentObjectKey: objectKey, attachmentName: file.name, attachmentType: file.type, attachmentSize: file.size }).where(eq(assignments.id, id));
  } catch (reason) {
    try { await storage.delete(objectKey); } catch {}
    throw reason;
  }
  if (assignment.attachmentObjectKey && assignment.attachmentObjectKey !== objectKey) {
    try { await storage.delete(assignment.attachmentObjectKey); } catch {}
  }
  return Response.json({ success: true, name: file.name, size: file.size });
}

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  const rejected = await requireAdmin(request);
  if (rejected) return rejected;
  const id = Number((await context.params).id);
  const db = await getDb();
  const rows = id ? await db.select().from(assignments).where(eq(assignments.id, id)).limit(1) : [];
  if (!rows[0]) return Response.json({ error: "Không tìm thấy bài tập." }, { status: 404 });
  await db.update(assignments).set({ attachmentObjectKey: "", attachmentName: "", attachmentType: "", attachmentSize: 0 }).where(eq(assignments.id, id));
  if (rows[0].attachmentObjectKey) {
    try { await (await bucket()).delete(rows[0].attachmentObjectKey); } catch {}
  }
  return Response.json({ success: true });
}
