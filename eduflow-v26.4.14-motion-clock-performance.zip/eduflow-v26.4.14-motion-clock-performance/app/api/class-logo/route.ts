import { getDb } from "../../../db";
import { adminItems } from "../../../db/schema";
import { requireAdmin } from "../../../lib/admin-auth";

type FileBucket = { put(key:string,value:ArrayBuffer,options?:{httpMetadata?:{contentType?:string}}):Promise<unknown> };

async function getBucket():Promise<FileBucket>{const {env}=await import("cloudflare:workers");const bucket=(env as unknown as {BUCKET?:FileBucket}).BUCKET;if(!bucket)throw new Error("Kho ảnh chưa được cấu hình.");return bucket;}

export async function POST(request:Request){
  const rejected=await requireAdmin(request);if(rejected)return rejected;
  try{
    const form=await request.formData();const file=form.get("file");
    if(!(file instanceof File)||!file.size)return Response.json({error:"Vui lòng chọn ảnh logo."},{status:400});
    if(!["image/png","image/jpeg","image/webp","image/gif"].includes(file.type))return Response.json({error:"Logo phải là ảnh PNG, JPG, WEBP hoặc GIF."},{status:400});
    if(file.size>3*1024*1024)return Response.json({error:"Ảnh logo tối đa 3 MB."},{status:400});
    const objectKey="class-logos/"+crypto.randomUUID();await (await getBucket()).put(objectKey,await file.arrayBuffer(),{httpMetadata:{contentType:file.type}});
    const now=new Date().toISOString();const rows=await (await getDb()).insert(adminItems).values({kind:"class_logos",itemKey:crypto.randomUUID(),title:file.name,data:JSON.stringify({objectKey,contentType:file.type}),createdAt:now,updatedAt:now}).returning({id:adminItems.id});
    return Response.json({url:"/api/class-logo/"+rows[0].id},{status:201});
  }catch(error){return Response.json({error:error instanceof Error?error.message:"Không thể tải logo."},{status:500});}
}
