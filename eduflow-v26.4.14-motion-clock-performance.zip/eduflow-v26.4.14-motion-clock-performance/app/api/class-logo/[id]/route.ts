import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { adminItems } from "../../../../db/schema";

type StoredObject={body:BodyInit;httpMetadata?:{contentType?:string}};type FileBucket={get(key:string):Promise<StoredObject|null>};
async function getBucket():Promise<FileBucket>{const {env}=await import("cloudflare:workers");const bucket=(env as unknown as {BUCKET?:FileBucket}).BUCKET;if(!bucket)throw new Error("Kho ảnh chưa được cấu hình.");return bucket;}

export async function GET(_request:Request,context:{params:Promise<{id:string}>}){const id=Number((await context.params).id);if(!id)return new Response("Không tìm thấy ảnh.",{status:404});const rows=await (await getDb()).select().from(adminItems).where(and(eq(adminItems.id,id),eq(adminItems.kind,"class_logos"))).limit(1);if(!rows.length)return new Response("Không tìm thấy ảnh.",{status:404});const data=JSON.parse(rows[0].data) as {objectKey?:string;contentType?:string};if(!data.objectKey)return new Response("Ảnh không hợp lệ.",{status:404});const object=await (await getBucket()).get(data.objectKey);if(!object)return new Response("Ảnh đã bị xóa.",{status:404});return new Response(object.body,{headers:{"Content-Type":data.contentType||object.httpMetadata?.contentType||"image/png","Cache-Control":"public, max-age=31536000, immutable"}});}
