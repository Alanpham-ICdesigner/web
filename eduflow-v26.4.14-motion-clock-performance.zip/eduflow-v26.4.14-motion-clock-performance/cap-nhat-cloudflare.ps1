$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host ""
Write-Host "=== EDUFLOW V26.4.5 - NOTIFICATION + PROGRESS + CLASS CLEANUP ===" -ForegroundColor Cyan
Write-Host "Ban sach deploy: khong kem node_modules, tu cai dependency dung Windows." -ForegroundColor Yellow
Write-Host "Thu muc: $PSScriptRoot" -ForegroundColor DarkGray
Write-Host ""

function Assert-LastCommand {
  param([string]$Message)
  if ($LASTEXITCODE -ne 0) { throw $Message }
}

function Ensure-D1Column {
  param(
    [Parameter(Mandatory=$true)][string]$Table,
    [Parameter(Mandatory=$true)][string]$Column,
    [Parameter(Mandatory=$true)][string]$Definition
  )

  $checkSql = "SELECT CASE WHEN EXISTS(SELECT 1 FROM pragma_table_info('$Table') WHERE name='$Column') THEN 'COLUMN_PRESENT' ELSE 'COLUMN_MISSING' END AS migration_check;"
  $checkOutput = (& ".\node_modules\.bin\wrangler.cmd" d1 execute eduflow-db --remote --config wrangler.jsonc --command $checkSql 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0) { throw "Khong the kiem tra cot $Table.$Column tren D1." }

  if ($checkOutput -match "COLUMN_PRESENT") {
    Write-Host "Da co cot $Table.$Column - bo qua." -ForegroundColor DarkGray
    return
  }

  Write-Host "Dang them cot con thieu $Table.$Column..." -ForegroundColor DarkGray
  $alterSql = "ALTER TABLE ``$Table`` ADD COLUMN ``$Column`` $Definition;"
  & ".\node_modules\.bin\wrangler.cmd" d1 execute eduflow-db --remote --config wrangler.jsonc --command $alterSql
  Assert-LastCommand "Khong the them cot $Table.$Column. D1 cu van duoc giu nguyen."
}



function Test-D1Table {
  param([Parameter(Mandatory=$true)][string]$Table)
  $sql = "SELECT CASE WHEN EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name='$Table') THEN 'TABLE_PRESENT' ELSE 'TABLE_MISSING' END AS migration_check;"
  $output = (& ".\node_modules\.bin\wrangler.cmd" d1 execute eduflow-db --remote --config wrangler.jsonc --command $sql 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0) { throw "Khong the kiem tra bang $Table tren D1." }
  return ($output -match "TABLE_PRESENT")
}

function Test-D1Column {
  param(
    [Parameter(Mandatory=$true)][string]$Table,
    [Parameter(Mandatory=$true)][string]$Column
  )
  $sql = "SELECT CASE WHEN EXISTS(SELECT 1 FROM pragma_table_info('$Table') WHERE name='$Column') THEN 'COLUMN_PRESENT' ELSE 'COLUMN_MISSING' END AS migration_check;"
  $output = (& ".\node_modules\.bin\wrangler.cmd" d1 execute eduflow-db --remote --config wrangler.jsonc --command $sql 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0) { throw "Khong the kiem tra cot $Table.$Column tren D1." }
  return ($output -match "COLUMN_PRESENT")
}

function Test-D1Index {
  param([Parameter(Mandatory=$true)][string]$Index)
  $sql = "SELECT CASE WHEN EXISTS(SELECT 1 FROM sqlite_master WHERE type='index' AND name='$Index') THEN 'INDEX_PRESENT' ELSE 'INDEX_MISSING' END AS migration_check;"
  $output = (& ".\node_modules\.bin\wrangler.cmd" d1 execute eduflow-db --remote --config wrangler.jsonc --command $sql 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0) { throw "Khong the kiem tra index $Index tren D1." }
  return ($output -match "INDEX_PRESENT")
}

function Ensure-WebPushSecrets {
  Write-Host "Dang kiem tra VAPID secret cho Web Push..." -ForegroundColor Yellow
  $secretOutput = (& ".\node_modules\.bin\wrangler.cmd" secret list --config wrangler.jsonc 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0) {
    Write-Host $secretOutput -ForegroundColor Red
    throw "Khong the kiem tra Cloudflare secrets cho Web Push. Website hien tai chua bi thay doi."
  }
  $hasPublic = $secretOutput -match "VAPID_PUBLIC_KEY"
  $hasPrivate = $secretOutput -match "VAPID_PRIVATE_JWK"
  if ($hasPublic -and $hasPrivate) {
    Write-Host "VAPID da co san - giu nguyen key hien tai de subscription cu tiep tuc hoat dong." -ForegroundColor DarkGray
    return
  }
  if ($hasPublic -xor $hasPrivate) {
    throw "VAPID dang thieu mot nua key pair. Khong tu ghi de de tranh lam mat hieu luc subscription cu. Hay xoa/cap nhat cap VAPID thu cong roi chay lai."
  }
  Write-Host "Lan dau V26: dang tao VAPID P-256 va luu vao Cloudflare Worker secrets..." -ForegroundColor Cyan
  $vapidText = (& node ".\scripts\generate-vapid.mjs" 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0) { throw "Khong the tao VAPID key pair." }
  $vapid = $vapidText | ConvertFrom-Json
  if (-not $vapid.publicKey -or -not $vapid.privateJwk) { throw "VAPID generator tra ve du lieu khong hop le." }
  $vapid.publicKey | & ".\node_modules\.bin\wrangler.cmd" secret put VAPID_PUBLIC_KEY --config wrangler.jsonc
  Assert-LastCommand "Khong the luu VAPID_PUBLIC_KEY."
  $vapid.privateJwk | & ".\node_modules\.bin\wrangler.cmd" secret put VAPID_PRIVATE_JWK --config wrangler.jsonc
  Assert-LastCommand "Khong the luu VAPID_PRIVATE_JWK."
  Write-Host "Da cau hinh VAPID. Private key chi nam trong Cloudflare secret, khong ghi vao source ZIP." -ForegroundColor Green
}

function Repair-LegacyStudentEnrollments {
  if (-not (Test-D1Table -Table "student_enrollments")) {
    Write-Host "Chua co bang student_enrollments - migration 0005 se tao moi." -ForegroundColor DarkGray
    return
  }

  # Compatibility with the first duplicate hotfix. That version created:
  # id, student_id, class_name, created_at. Keep created_at instead of dropping
  # the table so no existing enrollment row needs to be destroyed or recreated.
  Ensure-D1Column -Table "student_enrollments" -Column "class_key" -Definition "text DEFAULT '' NOT NULL"
  Ensure-D1Column -Table "student_enrollments" -Column "status" -Definition "text DEFAULT 'active' NOT NULL"
  Ensure-D1Column -Table "student_enrollments" -Column "enrolled_at" -Definition "text DEFAULT '' NOT NULL"
  Ensure-D1Column -Table "student_enrollments" -Column "created_at" -Definition "text DEFAULT '' NOT NULL"
  Ensure-D1Column -Table "student_enrollments" -Column "updated_at" -Definition "text DEFAULT '' NOT NULL"

  Write-Host "Dang chuan hoa student_enrollments cu sang schema LMS V20..." -ForegroundColor Yellow
  $normalizeSql = @"
UPDATE student_enrollments
SET class_key = COALESCE(
  (SELECT ai.item_key FROM admin_items ai WHERE ai.kind = 'classes' AND ai.title = student_enrollments.class_name ORDER BY ai.id LIMIT 1),
  'legacy:' || lower(replace(trim(student_enrollments.class_name), ' ', '-'))
)
WHERE trim(COALESCE(class_key, '')) = '';
UPDATE student_enrollments SET status = 'active' WHERE trim(COALESCE(status, '')) = '';
UPDATE student_enrollments SET enrolled_at = COALESCE(NULLIF(created_at, ''), CURRENT_TIMESTAMP) WHERE trim(COALESCE(enrolled_at, '')) = '';
UPDATE student_enrollments SET created_at = enrolled_at WHERE trim(COALESCE(created_at, '')) = '';
UPDATE student_enrollments SET updated_at = enrolled_at WHERE trim(COALESCE(updated_at, '')) = '';
DELETE FROM student_enrollments
WHERE id NOT IN (SELECT MIN(id) FROM student_enrollments GROUP BY student_id, class_key);
DROP INDEX IF EXISTS student_enrollments_student_class_unique;
DROP INDEX IF EXISTS student_enrollments_student_idx;
DROP INDEX IF EXISTS student_enrollments_class_idx;
CREATE UNIQUE INDEX IF NOT EXISTS student_enrollments_student_class_unique ON student_enrollments(student_id, class_key);
CREATE INDEX IF NOT EXISTS student_enrollments_student_idx ON student_enrollments(student_id);
CREATE INDEX IF NOT EXISTS student_enrollments_class_idx ON student_enrollments(class_key);
"@
  # IMPORTANT: do not pass a multi-statement SQL batch via --command on Windows.
  # cmd.exe/PowerShell argument forwarding can truncate the batch and Cloudflare D1 then
  # returns `incomplete input`. Write the batch to a UTF-8 SQL file and execute --file.
  $repairDir = Join-Path $PSScriptRoot ".wrangler"
  New-Item -ItemType Directory -Force -Path $repairDir | Out-Null
  $normalizeSqlFile = Join-Path $repairDir "repair-student-enrollments-v4.sql"
  [System.IO.File]::WriteAllText($normalizeSqlFile, $normalizeSql, [System.Text.UTF8Encoding]::new($false))

  Write-Host "V4: Dang chay SQL chuan hoa bang --file (khong dung --command nhieu dong)..." -ForegroundColor Cyan
  try {
    & ".\node_modules\.bin\wrangler.cmd" d1 execute eduflow-db --remote --config wrangler.jsonc --file $normalizeSqlFile
    Assert-LastCommand "Khong the chuan hoa student_enrollments. Du lieu hoc sinh van duoc giu nguyen."
  }
  finally {
    Remove-Item $normalizeSqlFile -Force -ErrorAction SilentlyContinue
  }
  Write-Host "student_enrollments da san sang cho LMS V20." -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "=== CAP NHAT EDUFLOW V26 ===" -ForegroundColor Cyan
Write-Host "Website : https://edumath.phmt.workers.dev/"
Write-Host "D1      : eduflow-db (giu nguyen du lieu)"
Write-Host "R2      : eduflow-files (giu nguyen tai lieu)"
Write-Host ""

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw "Chua cai Node.js. Hay cai Node.js LTS roi chay lai tep nay."
}
if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) {
  throw "Khong tim thay npm.cmd. Hay cai lai Node.js LTS."
}
$nodeVersion = [version]((node --version).TrimStart("v"))
if ($nodeVersion -lt [version]"22.13.0") {
  throw "Can Node.js 22.13.0 tro len. Phien ban hien tai: $nodeVersion"
}

$wranglerLogDirectory = Join-Path $PSScriptRoot ".wrangler"
New-Item -ItemType Directory -Force -Path $wranglerLogDirectory | Out-Null
$env:WRANGLER_LOG_PATH = Join-Path $wranglerLogDirectory "wrangler.log"
$env:WRANGLER_WRITE_LOGS = "false"

# V7.8.1: always let npm create node_modules on THIS machine. Never trust a
# node_modules folder copied from another OS / another generated ZIP.
$ExpectedWindowsWorkerdVersion = "1.20260515.1"
$env:npm_config_include = "optional"
Remove-Item Env:npm_config_omit -ErrorAction SilentlyContinue
Remove-Item Env:npm_config_optional -ErrorAction SilentlyContinue

function Test-WindowsWorkerd {
  if ($env:OS -ne "Windows_NT") { return $true }
  return (Test-Path ".\node_modules\@cloudflare\workerd-windows-64\bin\workerd.exe")
}

function Install-ProjectDependencies {
  Write-Host "Dang dong bo thu vien dung cho may nay..." -ForegroundColor Yellow
  $installOk = $false
  for ($attempt = 1; $attempt -le 3; $attempt++) {
    if ($attempt -gt 1) {
      Write-Host "Thu lai npm lan $attempt/3..." -ForegroundColor Yellow
      Start-Sleep -Seconds 4
    }

    & npm.cmd ci --include=optional --no-audit --no-fund
    if ($LASTEXITCODE -eq 0) {
      $installOk = $true
      break
    }
  }

  if (-not $installOk) {
    throw "Khong the cai dependency tu package-lock sau 3 lan. Website hien tai chua bi thay doi."
  }

  # workerd is a platform binary distributed through optionalDependencies.
  # If npm on Windows omits it for any reason, install the exact locked version
  # explicitly before Vite/Miniflare is allowed to start.
  if (-not (Test-WindowsWorkerd)) {
    Write-Host "Dang bo sung Cloudflare workerd cho Windows..." -ForegroundColor Yellow
    & npm.cmd install --no-save --package-lock=false --include=optional --no-audit --no-fund "@cloudflare/workerd-windows-64@$ExpectedWindowsWorkerdVersion"
    Assert-LastCommand "Khong the cai @cloudflare/workerd-windows-64. Website hien tai chua bi thay doi."
  }

  if (-not (Test-Path ".\node_modules\.bin\vinext.cmd")) {
    throw "Thieu vinext sau khi cai dependency. Website hien tai chua bi thay doi."
  }
  if (-not (Test-Path ".\node_modules\.bin\wrangler.cmd")) {
    throw "Thieu wrangler sau khi cai dependency. Website hien tai chua bi thay doi."
  }
  if (-not (Test-WindowsWorkerd)) {
    throw "Thieu @cloudflare/workerd-windows-64 sau khi tu sua. Website hien tai chua bi thay doi."
  }

  Write-Host "Dependency OK cho $($env:OS) / Node $nodeVersion." -ForegroundColor Green
}

Install-ProjectDependencies

Write-Host "Dang build website..." -ForegroundColor Yellow
& ".\node_modules\.bin\vinext.cmd" build
Assert-LastCommand "Build that bai. Website hien tai chua bi thay doi."

if (-not (Test-Path ".\dist\server\index.js")) {
  throw "Build chua tao dist\server\index.js. Website hien tai chua bi thay doi."
}
if (-not (Test-Path ".\dist\client")) {
  throw "Build chua tao dist\client. Website hien tai chua bi thay doi."
}

Write-Host "Dang chay kiem thu tu dong..." -ForegroundColor Yellow
$testFiles = @(Get-ChildItem ".\tests" -Filter "*.test.mjs" -File | Sort-Object Name)
if (-not $testFiles.Count) { throw "Khong tim thay tep kiem thu." }
node --test $testFiles.FullName
Assert-LastCommand "Kiem thu that bai. Website hien tai chua bi thay doi."

Write-Host "Dang kiem tra dang nhap Cloudflare..." -ForegroundColor Yellow
$whoamiOutput = (& ".\node_modules\.bin\wrangler.cmd" whoami 2>&1 | Out-String)
if ($LASTEXITCODE -ne 0) {
  Write-Host $whoamiOutput -ForegroundColor Red
  throw "Chua dang nhap Cloudflare. Chay: npx.cmd wrangler login"
}
Write-Host $whoamiOutput.Trim() -ForegroundColor DarkGray
$TargetAccountId = "d32e8b29f70220457507587201acc3a1"
Write-Host "Tai khoan dich cua EDUFLOW: $TargetAccountId" -ForegroundColor DarkGray
if ($whoamiOutput -notmatch [regex]::Escape($TargetAccountId)) {
  throw "Dang nhap nham Cloudflare account. Hay wrangler logout/login dung tai khoan EDUFLOW. Chua deploy gi ca."
}

Ensure-WebPushSecrets

# R2 secrets va CORS la cau hinh persistent tren Cloudflare, khong can doc/ghi lai moi lan deploy.
# Cac ban cu dung `wrangler secret list` va `r2 bucket cors set` o moi lan cap nhat,
# nen chi mot loi API/quyen tam thoi cung lam dung ca website. V7.7.1 bo hai precheck nay.
# Deploy Worker khong xoa secrets R2 da co; bucket/CORS cu cung duoc giu nguyen.
Write-Host "Bo qua kiem tra lai R2 secret/CORS (giu nguyen cau hinh Cloudflare hien co)." -ForegroundColor DarkGray

Write-Host "Dang kiem tra goi deploy (khong thay doi website)..." -ForegroundColor Yellow
& ".\node_modules\.bin\wrangler.cmd" deploy --config wrangler.jsonc --dry-run
Assert-LastCommand "Kiem tra deploy that bai. Website hien tai chua bi thay doi."

Write-Host "Dry-run OK. Tiep tuc deploy tu dong theo workflow mot lenh." -ForegroundColor Green

Write-Host "Dang kiem tra schema D1 de tranh loi duplicate column..." -ForegroundColor Yellow
Repair-LegacyStudentEnrollments

if (Test-D1Table -Table "student_enrollments") {
  if (-not (Test-D1Column -Table "student_enrollments" -Column "class_key")) {
    throw "V4 PRECHECK FAILED: student_enrollments van chua co class_key. DUNG TRUOC MIGRATION; chua thay doi website."
  }
  Write-Host "V4 PRECHECK OK: student_enrollments.class_key da ton tai." -ForegroundColor Green
}

Ensure-D1Column -Table "assignments" -Column "class_key" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignments" -Column "attachment_object_key" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignments" -Column "attachment_name" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignments" -Column "attachment_type" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignments" -Column "attachment_size" -Definition "integer DEFAULT 0 NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "response_text" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "object_key" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "file_name" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "file_size" -Definition "integer DEFAULT 0 NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "content_type" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "status" -Definition "text DEFAULT 'submitted' NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "score" -Definition "real"
Ensure-D1Column -Table "assignment_submissions" -Column "feedback" -Definition "text DEFAULT '' NOT NULL"
Ensure-D1Column -Table "assignment_submissions" -Column "graded_at" -Definition "text"
Ensure-D1Column -Table "assignment_submissions" -Column "updated_at" -Definition "text DEFAULT '' NOT NULL"

Write-Host "Dang cap nhat D1 (khong xoa du lieu cu)..." -ForegroundColor Yellow
& ".\node_modules\.bin\wrangler.cmd" d1 migrations apply eduflow-db --remote --config wrangler.jsonc
Assert-LastCommand "Khong the cap nhat D1. Website hien tai va du lieu cu van duoc giu nguyen."

Write-Host "Dang xac minh bang Pet/Streak/Focus moi..." -ForegroundColor Yellow
foreach ($companionTable in @("student_pet_profiles", "student_daily_checkins", "student_focus_sessions", "student_focus_timer_state")) {
  if (-not (Test-D1Table -Table $companionTable)) {
    throw "Migration V8.2 chua tao du bang $companionTable. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
if (-not (Test-D1Column -Table "student_pet_profiles" -Column "freeze_last_used_date")) {
  throw "Migration V8.2.3 chua tao cot student_pet_profiles.freeze_last_used_date. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
}
foreach ($engagementIndex in @("student_daily_checkins_date_student_idx", "student_focus_sessions_date_student_idx")) {
  if (-not (Test-D1Index -Index $engagementIndex)) {
    throw "Migration V8.2.4 chua tao index $engagementIndex. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
if (-not (Test-D1Index -Index "student_focus_timer_running_end_idx")) {
  throw "Migration V23 chua tao index student_focus_timer_running_end_idx. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
}
if (-not (Test-D1Table -Table "assignment_submission_files")) {
  throw "Migration V23.1 chua tao bang assignment_submission_files. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
}
if (-not (Test-D1Index -Index "assignment_submission_files_submission_idx")) {
  throw "Migration V23.1 chua tao index assignment_submission_files_submission_idx. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
}
if (-not (Test-D1Table -Table "assignment_teacher_completions")) {
  throw "Migration V25.1 chua tao bang assignment_teacher_completions. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
}
foreach ($completionIndex in @("assignment_teacher_completions_unique", "assignment_teacher_completions_assignment_idx", "assignment_teacher_completions_student_idx")) {
  if (-not (Test-D1Index -Index $completionIndex)) {
    throw "Migration V25.1 chua tao index $completionIndex. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($timerColumn in @("mode", "status", "focus_minutes", "break_minutes", "remaining_ms", "ends_at", "session_key", "started_at", "revision")) {
  if (-not (Test-D1Column -Table "student_focus_timer_state" -Column $timerColumn)) {
    throw "Migration V23 chua tao cot student_focus_timer_state.$timerColumn. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($pushTable in @("push_subscriptions", "push_deliveries")) {
  if (-not (Test-D1Table -Table $pushTable)) {
    throw "Migration V26 chua tao bang $pushTable. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($pushIndex in @("push_subscriptions_endpoint_unique", "push_subscriptions_student_enabled_idx", "push_deliveries_subscription_event_unique", "push_deliveries_student_idx")) {
  if (-not (Test-D1Index -Index $pushIndex)) {
    throw "Migration V26 chua tao index $pushIndex. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($timerColumn in @("duration_ms", "session_id")) {
  if (-not (Test-D1Column -Table "student_focus_timer_state" -Column $timerColumn)) {
    throw "Migration V26 chua tao cot student_focus_timer_state.$timerColumn. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($adjustmentTable in @("student_focus_adjustments")) {
  if (-not (Test-D1Table -Table $adjustmentTable)) {
    throw "Migration V26.2.2 chua tao bang $adjustmentTable. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($adjustmentIndex in @("student_focus_adjustments_student_date_unique", "student_focus_adjustments_date_student_idx")) {
  if (-not (Test-D1Index -Index $adjustmentIndex)) {
    throw "Migration V26.2.2 chua tao index $adjustmentIndex. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
if (-not (Test-D1Table -Table "student_focus_adjustment_history")) {
  throw "Migration V26.2.5 chua tao bang student_focus_adjustment_history. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
}
foreach ($historyIndex in @("student_focus_adjustment_history_created_idx", "student_focus_adjustment_history_student_date_idx")) {
  if (-not (Test-D1Index -Index $historyIndex)) {
    throw "Migration V26.2.5 chua tao index $historyIndex. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($focusWorkspaceTable in @("student_focus_tasks", "student_focus_task_sessions")) {
  if (-not (Test-D1Table -Table $focusWorkspaceTable)) {
    throw "Migration V26.4.6 chua tao bang $focusWorkspaceTable. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
foreach ($focusWorkspaceIndex in @("student_focus_tasks_student_done_sort_idx", "student_focus_task_sessions_student_session_unique", "student_focus_task_sessions_task_idx")) {
  if (-not (Test-D1Index -Index $focusWorkspaceIndex)) {
    throw "Migration V26.4.6 chua tao index $focusWorkspaceIndex. DUNG TRUOC DEPLOY; website hien tai van duoc giu nguyen."
  }
}
Write-Host "V26.4.6 D1 OK: LMS, Push, Pomodoro server-authoritative, Focus Workspace task va lich su audit da san sang." -ForegroundColor Green
Write-Host "Giu nguyen toan bo du lieu cu va trang thai bao mat dang nhap." -ForegroundColor DarkGray

Write-Host "Dang cap nhat website..." -ForegroundColor Yellow
& ".\node_modules\.bin\wrangler.cmd" deploy --config wrangler.jsonc --keep-vars
Assert-LastCommand "Cap nhat that bai. D1 va R2 khong bi xoa."

Write-Host ""
Write-Host "CAP NHAT THANH CONG" -ForegroundColor Green
Write-Host "Mo: https://edumath.phmt.workers.dev/"
Write-Host "Nhan Ctrl + F5 de tai giao dien moi."
Read-Host "Nhan Enter de dong"
