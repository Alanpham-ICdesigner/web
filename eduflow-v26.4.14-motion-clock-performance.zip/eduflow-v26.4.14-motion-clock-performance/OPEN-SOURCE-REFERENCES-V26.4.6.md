# Open-source references used for EDUFLOW V26.4.6

EDUFLOW keeps its existing Next/Vinext/D1 architecture. These projects were reviewed for interaction patterns instead of cloning a separate focus application into EDUFLOW.

- **Morphicons** — vendored from the user-provided `morphicons-main.zip`; MIT license is kept at `lib/vendor/morphicons/LICENSE`. Used directly for animated state icons.
- **Focus Flow** — https://github.com/dat-lequoc/focus-flow — MIT. Referenced for the task ↔ Pomodoro workflow, completed-task separation and lightweight focus planning.
- **SortableJS** — https://github.com/SortableJS/Sortable — MIT. Referenced for touch-friendly handle/reorder behavior. EDUFLOW keeps a small app-native reorder implementation rather than adding a new runtime package.
- **FlipClock.js** — https://github.com/objectivehtml/flipclock — MIT. Referenced for flip-clock hierarchy and motion behavior. EDUFLOW renders from its existing server-authoritative timer instead of introducing a second timer engine.
- **React Spotify Embed** — https://github.com/ctjlewis/react-spotify-embed — MIT. Referenced for safe Spotify URL-to-embed behavior. EDUFLOW uses the official Spotify iframe endpoint directly and stores no Spotify OAuth token.

This avoids importing another app shell, auth system, database or timer state machine. Astryx + TasteSkill remain the visual/UI foundation of EDUFLOW.
