# EDUFLOW V25.1 — Assignment LMS + PDF Viewer

## Kết quả

Bản nâng cấp hoàn thiện luồng bài tập từ giao bài đến nộp, nộp lại, xem tệp, chấm điểm và trả kết quả. Các route, module D1/R2, thương hiệu EDUFLOW, Be Vietnam Pro, light/dark mode và chức năng ngoài phạm vi bài tập được giữ nguyên.

Giao diện tiếp tục dùng nền Astryx/TasteSkill theo chế độ preserve: token màu hiện có, hierarchy rõ, bảng gọn, label nằm trên input, bo góc 12/18/22 px, chuyển động có ý nghĩa và có `prefers-reduced-motion`.

## Học sinh

- Chọn nhiều tệp PDF/JPG/PNG/WEBP; tổng bài nộp sau cập nhật không vượt 10 MB.
- Trước hạn có thể nộp lại trực tiếp, giữ tệp cũ, xóa từng tệp, thêm tệp mới và sửa câu trả lời.
- Không còn yêu cầu thu hồi bài nộp trước khi chỉnh sửa.
- Sau hạn, bài nộp chuyển sang chỉ đọc nhưng vẫn xem tệp và kết quả chấm.
- Hiển thị trạng thái, thời gian nộp gần nhất, điểm, nhận xét, giáo viên chấm và thời gian chấm.
- Tệp PDF và ảnh mở trong viewer nội bộ; tải xuống là hành động riêng.

## Giáo viên

- Modal chi tiết bài tập dùng bảng học sinh gọn, có tìm kiếm, lọc trạng thái và sắp xếp.
- Mỗi học sinh mở một modal chấm bài riêng với tệp, câu trả lời, điểm và nhận xét.
- Sau khi lưu, kết quả ở chế độ chỉ đọc; nút `Chỉnh sửa` mới mở lại form. `Hủy chỉnh sửa` chỉ hoàn nguyên UI về dữ liệu server gần nhất.
- Không có thao tác hủy bài nộp của học sinh.
- `GV đánh dấu hoàn thành` được lưu trong bảng riêng, không tạo hoặc ghi đè bài nộp giả.
- Danh sách được canonical hóa bằng `studentId`; draft điểm/nhận xét cũng được khóa theo `studentId`, tránh trùng dòng và rò state giữa học sinh.

## Viewer và bảo mật tệp

- Viewer PDF hỗ trợ trang trước/sau, trang hiện tại/tổng trang, zoom, vừa chiều rộng, vừa trang, fullscreen và download.
- Ảnh JPG/PNG/WEBP được preview nội bộ với trạng thái loading/error.
- Mọi URL tệp tiếp tục đi qua API có session; R2 không public.
- Admin được xem tất cả; học sinh chỉ xem tệp của mình hoặc tài liệu thuộc lớp đang học.
- Response mặc định `Content-Disposition: inline`; chỉ `?download=1` trả `attachment`.
- Header `private, no-store` và `X-Content-Type-Options: nosniff` được áp dụng thống nhất.
- Sửa lỗi cookie học sinh cũ làm chặn nhầm quyền Admin khi mở tài liệu.

## Dữ liệu, transaction và concurrency

- Migration mới: `drizzle/0012_assignment_lms_viewer_integrity.sql`.
- Tạo bảng `assignment_teacher_completions` cùng unique/index theo assignment và student.
- Migration chỉ `CREATE ... IF NOT EXISTS` và `INSERT OR IGNORE`; không drop, truncate hoặc delete dữ liệu cũ.
- Upload R2 chạy song song bằng `Promise.allSettled`.
- Metadata bài nộp và danh sách tệp được ghi bằng một D1 batch có guard `updated_at`.
- Revision cũ nhận HTTP 409 và yêu cầu tải lại; không ghi đè thay đổi từ thiết bị khác.
- Khi upload hoặc transaction lỗi, object mới được dọn an toàn. Object cũ chỉ bị xóa sau khi D1 thành công và không còn tham chiếu.
- Unique/index hiện hữu được giữ nguyên; script deploy kiểm tra bảng/index mới trước khi thay Worker.

## Responsive và accessibility

- Desktop dùng bảng roster gọn và modal chấm hai vùng.
- Tablet/mobile đổi roster thành card theo hàng, modal một cột và viewer gần toàn màn hình.
- Guardrail riêng cho 760 px và 430 px; nút quan trọng đạt tối thiểu 44 px trên mobile.
- Có focus-visible, aria-label cho icon button, text truncation an toàn, scroll nội bộ và reduced-motion.

## Xác minh

| Kiểm tra | Kết quả |
|---|---:|
| `npm run build` | PASS |
| `npm test` | PASS — 150/150 |
| `npx tsc --noEmit` | PASS |
| `npm run lint` | PASS |
| Test mới V25.1 | PASS — 21/21 |
| Validate Worker artifact | PASS |

Bộ V25.1 bao phủ các tình huống bắt buộc: một tệp, nhiều tệp, vượt 10 MB, loại tệp sai, nộp lại trực tiếp, giữ/xóa/thêm tệp, viewer PDF/ảnh, download riêng, chấm/sửa/hủy chỉnh sửa UI, completion riêng, duplicate/state isolation, permission 401/403, revision conflict, cleanup R2, mobile, dark-mode token và migration additive.

## Deploy Cloudflare

1. Giải nén ZIP vào đường dẫn ngắn.
2. Trên Windows chạy `DEPLOY-EDUFLOW.bat` hoặc `cap-nhat-cloudflare.ps1`.
3. Script tự cài dependency đúng nền tảng, build, chạy test, kiểm tra đăng nhập/account Cloudflare và dry-run.
4. Script sửa schema legacy theo guard hiện có, apply toàn bộ D1 migration và xác minh bảng/index V25.1.
5. Chỉ khi migration và verify thành công, script mới deploy Worker với `--keep-vars`.

Không cần tạo D1/R2 mới. Script tiếp tục dùng `eduflow-db`, `eduflow-files` và Worker hiện hữu; không xóa `login_attempts` hay dữ liệu học sinh cũ.
