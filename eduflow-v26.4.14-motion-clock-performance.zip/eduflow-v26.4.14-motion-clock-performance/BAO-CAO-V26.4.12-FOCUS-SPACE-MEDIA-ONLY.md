# EDUFLOW V26.4.12 — Focus Space Media Only

## Thay đổi

Theo yêu cầu mới, phần **Âm thanh** trong cửa sổ **Music** đã được gỡ hoàn toàn.

Music hiện chỉ còn:

- Spotify Embed.
- YouTube Embed.
- Ô dán link Spotify/YouTube.
- Preset Peaceful Piano hiện có.

Đã gỡ khỏi runtime:

- Tab `Âm thanh`.
- Mưa / Brown noise / Sóng biển / Café / Lò sưởi / Rừng.
- Các soundscape preset.
- Master volume và volume từng sound.
- `FocusAmbientAudioEngine`.
- Local state và logic khởi tạo Web Audio cho soundscape.
- CSS của ambient mixer.
- LocalStorage `eduflow-focus-ambient` và `eduflow-focus-music-tab` không còn được đọc/ghi.

Các dữ liệu localStorage cũ nếu còn trên máy học sinh sẽ chỉ bị bỏ qua, không ảnh hưởng Focus Space.

## Không thay đổi

- Pomodoro / Break.
- Digital / Flip Clock.
- Task, Music, Notes có thể mở đồng thời.
- Kéo thả popup.
- Dark mode.
- Fullscreen/mobile landscape.
- Spotify/YouTube media.
- Motion Astryx + TasteSkill + Morphicons.
