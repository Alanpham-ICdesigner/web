# V25.1 — ASSIGNMENT LMS + PDF VIEWER

- Học sinh nộp/nộp lại nhiều tệp trước hạn và xem PDF/ảnh ngay trong app.
- Giáo viên dùng roster gọn, modal chấm riêng từng học sinh và kết quả chỉ đọc sau lưu.
- Trạng thái giáo viên đánh dấu hoàn thành được tách khỏi bài nộp thật.
- Session authorization, revision guard, D1 batch và R2 cleanup theo tham chiếu bảo vệ dữ liệu.
- Migration additive-only và script chỉ deploy Worker sau khi verify bảng/index thành công.

Chi tiết: `BAO-CAO-V25.1-ASSIGNMENT-LMS-PDF-VIEWER.md`.

---

# V23 — POMODORO ĐỒNG BỘ LAPTOP + ĐIỆN THOẠI

- Active Pomodoro được lưu theo **tài khoản học sinh trong D1**, không còn phụ thuộc localStorage của từng thiết bị.
- Bắt đầu trên laptop → mở điện thoại cùng tài khoản thấy đúng Focus/Break và thời gian còn lại.
- Một tài khoản chỉ có **1 timer authoritative**; revision compare-and-swap ngăn thao tác laptop/điện thoại tạo state song song.
- Đóng tab/chuyển app: phase hiện tại vẫn chạy theo server timestamp. Nếu phase hết khi không còn dashboard hoạt động, hệ thống dừng đúng boundary và không tự tiêu thụ phase tiếp theo.
- Focus hoàn tất được ghi idempotent một lần; Thống kê GV reconcile expired Focus trước khi tổng hợp.
- Poll timer-only mỗi 10 giây + resync khi visible/focus/online để cân bằng độ trễ và D1 Rows Read.
- Migration V23 additive-only: thêm `student_focus_timer_state` + index expiry; không sửa dữ liệu LMS/Punch/Streak/điểm/chuyên cần/R2.
- UI/motion giữ nguyên Astryx × TasteSkill, không thêm dependency và không đổi layout.

Chi tiết: `BAO-CAO-V23-CROSS-DEVICE-POMODORO.md`.

---

# V8.2.5 — POMODORO CHẠY NỀN, DỪNG Ở CUỐI PHASE

- Đóng tab, reload, chuyển app trên điện thoại hoặc rời Trang chủ khi Pomodoro đang chạy: timer vẫn tính theo `endAt` thực tế.
- Quay lại trước khi hết phase: tiếp tục đúng thời gian còn lại.
- Nếu Focus hết khi đang rời trang: ghi nhận phiên Focus và dừng ở đầu Break; Break chưa tự chạy ngầm.
- Nếu Break hết khi đang rời trang: dừng và trở về Focus sẵn sàng; không tự chạy phiên mới.
- Khi vẫn đang xem trang và Focus kết thúc bình thường, flow Focus → Break hiện tại vẫn giữ nguyên.
- Không đổi layout/motion/CSS; Astryx + TasteSkill của V8.2.4.2 được giữ nguyên. Không migration D1 mới.

Chi tiết: `BAO-CAO-V8.2.5-BACKGROUND-POMODORO-BOUNDARY.md`.

---

# V8.2.4.2 — THÁNG + XẾP HẠNG + FIX TOOLBAR/MOTION

- Sửa triệt để toolbar thống kê: các control có lane riêng, không còn `Hôm nay` đè lên search/filter.
- Bỏ icon lịch custom cạnh date picker; giữ native date/month picker để không còn 2 icon trùng nhau.
- Bỏ ngày in đậm lặp lại dưới toolbar; chỉ còn ngày/tháng trong picker.
- Thêm tab **Tháng** cạnh Ngày/Tuần.
- Theo **Ngày**: summary dùng **Check-in sớm nhất** (tên + giờ) thay cho streak cao nhất.
- Theo **Tuần/Tháng**: summary **Streak cao nhất** hiển thị tên học sinh + số ngày.
- **Pomodoro nhiều nhất** hiển thị tên học sinh + tổng phút của kỳ.
- Recheck motion theo TasteSkill/Astryx: tactile hover/active, focus-visible, transition token hiện có, transform-only cho chuyển động, reduced-motion đầy đủ.
- Không có migration mới; query tháng tiếp tục dùng index date-first V8.2.4.

Chi tiết: `BAO-CAO-V8.2.4.2-STATS-MONTH-RANKING-LAYOUT-FIX.md`.

---

# V8.2.4.1 — FIX BỐ CỤC TOOLBAR THỐNG KÊ

- Sửa nút `Hôm nay` bị kéo full-width do kế thừa CSS global `.button.soft`.
- Khôi phục date picker đủ rộng ở desktop; mobile vẫn co giãn an toàn.
- Chỉ sửa CSS scoped của bảng **Điểm danh streak & Pomodoro**, không đổi logic/API/D1.
- Recheck theo source Astryx + TasteSkill: giữ stable input footprint, bounded control lanes, explicit mobile collapse, semantic tokens và interaction states hiện hữu.

Chi tiết: `BAO-CAO-V8.2.4.1-STATS-TOOLBAR-LAYOUT-FIX.md`.

---

# V8.2.4 — THỐNG KÊ CHECK-IN STREAK & POMODORO CHO GIÁO VIÊN

- Thêm bảng **Điểm danh streak & Pomodoro** trong tab **Thống kê & Phân tích** của web GV.
- Chọn **Ngày / Tuần**, chọn mốc ngày, tìm học sinh và lọc theo lớp.
- Sort hai chiều theo: tên, lớp, check-in, streak hiện tại, kỷ lục, tổng check-in và tổng phút Pomodoro.
- Tuần hiện tại chỉ tính đến hôm nay; tuần lịch sử đủ 7 ngày.
- Search/filter/sort chạy local sau khi tải kỳ, không query D1 lại theo từng thao tác.
- Thêm 2 date-first D1 indexes để giảm Rows Read; migration additive-only và deploy script kiểm tra index trước khi deploy.
- UI đã recheck trực tiếp với `astryx-main` + `taste-skill-main`: sticky header/first column, local scroll, responsive, loading/empty/error, `aria-sort`, reduced-motion.
- Không thay đổi điểm học tập, chuyên cần buổi học, điểm thi đua, lớp, bài tập, pet/streak student logic hay R2.

Chi tiết: `BAO-CAO-V8.2.4-TEACHER-ENGAGEMENT-STATS.md`.

# V8.2.3 — PUNCH + FREEZE 30 NGÀY + FAILED REACTION

- Pet mới: Punch (asset local từ `monkeypet.zip`).
- Streak Freeze hồi lại sau đúng 30 ngày kể từ ngày được dùng, không còn reset đầu tháng.
- UI hiển thị `Còn N ngày` ngay cạnh Freeze.
- Punch `failed` khoảng 10 giây khi phát hiện miss daily check-in hoặc khi học sinh bấm Kết thúc Pomodoro.
- Giữ nguyên Pause Timer V8.2.2, Daily Streak, milestone, đổi tên pet, LMS, D1/R2 cũ và Astryx + TasteSkill.

Chi tiết: `BAO-CAO-V8.2.3-PUNCH-FREEZE30-FAILED.md`.

# V8 — ASTRYX × TASTESKILL DEEP REDESIGN · DEPLOY READY

Redesign sâu toàn bộ giao diện giáo viên và học sinh, giữ nguyên chức năng, route, API, dữ liệu D1/R2, migration và quy trình deploy. Chi tiết tại `BAO-CAO-V8-ASTRYX-TASTE-DEEP-REDESIGN.md`.

> Trên Windows chỉ cần chạy `powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"` hoặc double-click `DEPLOY-EDUFLOW.bat`. Không copy `node_modules` từ bản cũ vào thư mục này.

# EDUFLOW V20 - V7.7.2

Bản vá Điểm danh: Tất cả lớp + lịch sử mới nhất trước.


## V7.6 — Dashboard date + gender greeting
- Tổng quan điểm danh dùng đúng ngày hiện tại theo `Asia/Ho_Chi_Minh`; không lấy ngày điểm danh mới nhất trong DB.
- Chưa điểm danh hôm nay: donut hiển thị `— / Chưa điểm danh`, không hiển thị 0% gây hiểu nhầm.
- Cài đặt thêm Giới tính: Nam → Thầy, Nữ → Cô; lời chào tự đổi sáng/chiều/tối.
- Lịch dạy hôm nay dùng ngày thật và lọc đúng các lớp có lịch trong ngày.
- Không có migration D1 mới.

# EDUFLOW V20 — V7.5

Nền V7.4. Bản này bổ sung kéo-thả sidebar, lịch cuộn dọc + luân phiên lịch trùng, scroll cho lịch sử dài, chat Messenger trực tiếp GV–HS và recheck UI theo TasteSkill. Xem `BAO-CAO-V7.5-DRAG-NAV-SCROLL-MESSENGER.md`.

# vinext-starter

A clean full-stack starter running on
[vinext](https://github.com/cloudflare/vinext), with optional Cloudflare D1 and
Drizzle support.

## Prerequisites

- Node.js `>=22.13.0`
- Linux with `flock`, `curl`, and GNU `timeout`

## Sites Lifecycle

The Sites lifecycle CLI runs the locked dependency install before returning this checkout. Edit the source under `app/`, then checkpoint when a coherent milestone is ready to inspect or share. The remote Sites builder runs `npm run build` against the pushed commit. Do not repeat install or build as a normal pre-checkpoint step.

This starter does not use `wrangler.jsonc`.

`install:ci` is intentionally a single, non-retrying `npm ci`. It refuses a concurrent install for the same project, consumes a matching image-seeded npm cache with `--prefer-offline` while retaining registry fallback for a missing cache object, otherwise downloads and verifies the complete vinext tarball recorded in `package-lock.json`, limits npm to one socket, and terminates a stalled install. `build` applies a short timeout and then validates the Sites artifact. These helpers target Linux and use GNU `timeout`; they are not native macOS scripts.

Scripts that need writable project-scoped home, npm, XDG, and temporary paths use `scripts/sites-env.sh`. The `dev` and `start` scripts honor the caller's runtime environment and keep Wrangler logs inside the checkout. The generated `.sites-runtime/` directory is disposable and ignored by Git.

## Included Shape

- edit site code under `app/`
- `app/chatgpt-auth.ts` provides optional dispatch-owned ChatGPT sign-in helpers
- `.openai/hosting.json` declares optional Sites D1 and R2 bindings
- `vite.config.ts` simulates declared bindings for local development
- `db/index.ts` reads the D1 binding from the Cloudflare Worker environment
- `db/schema.ts` starts intentionally empty
- `examples/d1/` contains an optional D1 example surface
- `drizzle.config.ts` supports local migration generation when needed

## Workspace Auth Headers

OpenAI workspace sites can read the current user's email from
`oai-authenticated-user-email`.

SIWC-authenticated workspace sites may also receive
`oai-authenticated-user-full-name` when the user's SIWC profile has a non-empty
`name` claim. The full-name value is percent-encoded UTF-8 and is accompanied by
`oai-authenticated-user-full-name-encoding: percent-encoded-utf-8`.

Treat the full name as optional and fall back to email when it is absent:

```tsx
import { headers } from "next/headers";

export default async function Home() {
  const requestHeaders = await headers();
  const email = requestHeaders.get("oai-authenticated-user-email");
  const encodedFullName = requestHeaders.get("oai-authenticated-user-full-name");
  const fullName =
    encodedFullName &&
    requestHeaders.get("oai-authenticated-user-full-name-encoding") ===
      "percent-encoded-utf-8"
      ? decodeURIComponent(encodedFullName)
      : null;

  const displayName = fullName ?? email;
  // ...
}
```

## Optional Dispatch-Owned ChatGPT Sign-In

Import the ready-to-use helpers from `app/chatgpt-auth.ts` when the site needs
optional or required ChatGPT sign-in:

- Use `getChatGPTUser()` for optional signed-in UI.
- Use `requireChatGPTUser(returnTo)` for server-rendered pages that should send
  anonymous visitors through Sign in with ChatGPT.
- Use `chatGPTSignInPath(returnTo)` and `chatGPTSignOutPath(returnTo)` for
  browser links or actions.
- Pass a same-origin relative `returnTo` path for the destination after sign-in
  or sign-out. The helper validates and safely encodes it.
- Mark protected pages with `export const dynamic = "force-dynamic"` because
  they depend on per-request identity headers.

Dispatch owns `/signin-with-chatgpt`, `/signout-with-chatgpt`, `/callback`, the
OAuth cookies, and identity header injection. Do not implement app routes for
those reserved paths. Routes that do not import and call the helper remain
anonymous-compatible.

SIWC establishes identity only; it does not prove workspace membership. Use the
Sites hosting platform's access policy controls for workspace-wide restrictions,
or enforce explicit server-side membership or allowlist checks.

Use SIWC for account pages, user-specific dashboards, saved records, and write
actions tied to the current ChatGPT user. Leave public content anonymous.

## Diagnostic Commands

- `npm run install:ci`: perform the one bounded lockfile install
- `npm run dev`: start the Vite/Vinext development server
- `npm run build`: build and validate the deployable Sites artifact
- `npm run start`: start the built Vinext application
- `npm test`: build, validate, and verify the rendered development-preview metadata
- `npm run validate:artifact`: recheck an existing artifact's manifest and ESM `default.fetch` export
- `npm run db:generate`: generate Drizzle migrations after schema changes

Use build and validation commands for targeted diagnosis after a remote failure, not as part of the normal checkpoint path.

The timeout defaults can be overridden for a controlled canary with `SITES_INSTALL_TIMEOUT`, `SITES_INSTALL_KILL_AFTER`, `SITES_BUILD_TIMEOUT`, and `SITES_BUILD_KILL_AFTER`. A timeout fails the command; the helpers never retry an unchanged install or build.

## Learn More

- [vinext Documentation](https://github.com/cloudflare/vinext)
- [Drizzle D1 Guide](https://orm.drizzle.team/docs/get-started/d1-new)

## V7.6.3 — Dashboard Class Scroll
- Kết quả theo lớp có vùng cuộn dọc riêng khi số lớp nhiều.
- Card Điểm danh hôm nay không bị kéo cao theo danh sách lớp.
- Không thay đổi D1/API/R2.

## V7.6.4 — Test Calendar Notification

- Tạo lịch kiểm tra theo lớp sẽ tự tạo thông báo cho học sinh thuộc đúng lớp đó.
- Thông báo hiển thị trong chuông thông báo chung của web học sinh.
- Bấm thông báo sẽ mở đúng môn và tab Lịch kiểm tra.
- Xóa lịch kiểm tra sẽ xóa thông báo tự động liên quan.
- Không thêm migration D1.


## V7.7
Xóa hội thoại, xếp lớp đúng classKey không tạo môn Chưa xếp lớp, lịch kiểm tra tất cả lớp + overlap cycling, nhận xét mới nhất → cũ nhất.

## V8.2.3 — Punch + Freeze 30 ngày + Failed reaction

- Thay Shinchan bằng pet khỉ Punch từ `monkeypet.zip`, bundle local trong `public/pets/punch/`.
- Streak Freeze chuyển sang cooldown lăn 30 ngày kể từ ngày Freeze thực sự được dùng; UI hiển thị thời gian còn lại ngay cạnh chip Freeze.
- Punch chạy animation `failed` khoảng 10 giây khi học sinh quay lại sau khi đã bỏ lỡ check-in hoặc khi bấm Kết thúc Pomodoro trước khi hoàn tất.
- Trong Focus, pet giữ hành vi `review` như V8.2.2; yêu cầu thử nghiệm đổi sang `idle` đã được bỏ.
- Pomodoro vẫn tự tạm dừng khi rời Trang chủ, reload hoặc đóng tab.
- Giữ nguyên Astryx + TasteSkill và không thay đổi logic điểm, điểm danh buổi học, lớp học, bài tập, tài liệu hay R2.

## V23.2 — LMS Submission Integrity & Performance

V23.2 chuẩn hóa bài nộp theo flow LMS: nộp → thu hồi → chỉnh sửa file/text → nộp lại; tách `teacher_completed` khỏi bài nộp thật, cô lập state chấm bài theo từng học sinh, tối ưu upload nhiều file và thêm guard chống ghi đè khi có nhiều thiết bị/request đồng thời. Giao diện Astryx/TasteSkill được giữ nguyên; migration 0011 chỉ normalize placeholder legacy an toàn.


## V26.2.4 — Student Manual Pomodoro Sync
- Thời gian Pomodoro ngoài web do GV xác nhận được cộng vào Hôm nay/Tuần này trên trang HS.
- Số phiên hoàn thành vẫn chỉ tính timer EDUFLOW, không tạo phiên giả.
- Ô Pomodoro trong bảng thống kê GV dùng meta compact `0 phiên` + chip `+45p` để tránh tràn chiều ngang.
- Không có migration D1 mới.


## V26.2.5 — Focus Adjustment History + Smart Alert Order
- Thêm audit log cho mọi lần GV thay đổi Pomodoro ngoài web: ngày học, học sinh, +/- thời gian, tổng ngoài web sau lưu, tổng ngày, ghi chú và thời điểm cập nhật.
- Migration `0015_focus_adjustment_history.sql` backfill các manual adjustment đã có trước đó để lịch sử không bị trống sau khi nâng cấp.
- Lịch sử chỉ dùng truy vết; tổng Ngày/Tuần/Tháng vẫn lấy từ `student_focus_adjustments`, không tạo phiên Pomodoro giả.
- Ghi chú được đính kèm vào thông báo/Web Push khi số phút thay đổi.
- Đưa “Cảnh báo thông minh” lên trên “Điểm danh streak & Pomodoro”.
- UI giữ nền Astryx + TasteSkill và có layout riêng cho mobile.
