# EDUFLOW V20 - Schedule UI Fix V5

## Da sua

1. Form Tao/Sua lop:
   - Khoi "Lich hoc" bat buoc span toan bo 2 cot cua form.
   - "Mau the" khong con chen vao cung hang voi cac o Thu/Bat dau/Ket thuc.
   - O time/select co `min-width: 0` va `width: 100%` de khong overflow.
   - Mobile van chuyen ve layout 2 cot nho theo breakpoint hien co.

2. Card lop hoc:
   - Khong con hien `schedule + startTime-endTime` tu buoi dau tien.
   - Neu co `schedules[]`, moi buoi hien dung cap Thu + gio cua chinh buoi do.
   - Vi du: `Thu 3 18:00–20:00 · Thu 5 19:00–21:00 · Chu nhat 08:00–10:00`.
   - Header chi tiet lop dung cung formatter de tranh sai lech.

## Pham vi thay doi
- app/class-hub.tsx
- app/redesign.css

Khong thay doi database schema, migration V4, enrollment, R2 hay logic diem danh.
