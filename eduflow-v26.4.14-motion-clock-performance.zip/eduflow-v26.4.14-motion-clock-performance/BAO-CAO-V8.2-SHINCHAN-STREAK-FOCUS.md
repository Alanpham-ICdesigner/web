# EDUFLOW V8.2 — Shinchan Daily Streak + Focus Companion

## 1. Phạm vi thay đổi

V8.2 được phát triển trực tiếp từ **V8.1 Compact Cards + Adaptive Text** theo nguyên tắc thay đổi có mục tiêu: giữ nguyên cấu trúc LMS, luồng giáo viên/học sinh, dữ liệu học tập, D1/R2 và workflow Cloudflare hiện có. Astryx + TasteSkill tiếp tục là nền UI; không thay theme hoặc redesign lại toàn bộ website.

## 2. Daily Check-in & Streak

- Mỗi tài khoản học sinh chỉ được ghi nhận **1 check-in/ngày**.
- Ngày được tính theo **Asia/Ho_Chi_Minh** ở backend.
- Check-in liên tiếp tăng streak; bỏ nhiều hơn một ngày thì lần check-in tiếp theo bắt đầu chuỗi mới từ 1.
- Nếu quên **đúng 1 ngày**, hệ thống tự dùng **1 Streak Freeze/tháng** nếu tháng đó chưa dùng Freeze.
- Luôn giữ **kỷ lục streak** và **tổng số ngày check-in** dù chuỗi hiện tại bị reset.
- Mốc thành tích là mọi **bội số của 10**; bội số của 100 là mốc lớn.
- API dùng ràng buộc unique `(student_id, checkin_date)` và D1 batch để chống bấm nhiều lần cộng streak.

Daily streak là gamification riêng, **không cộng/trừ điểm thi đua và không sửa điểm danh buổi học do giáo viên quản lý**.

## 3. Shinchan / Petdex

Shinchan dùng format spritesheet Petdex với các state:

- Idle
- Run Right
- Run Left
- Waving
- Jumping
- Failed
- Waiting
- Running
- Review

Desktop và mobile đều đặt pet trong một **playground an toàn bên trong companion card**. Pet có thể đi qua lại nhưng không phủ lên nút, bảng, card môn học hay popup của LMS. Khi Focus chạy, Shinchan chuyển sang `Review`; trong Break chuyển sang trạng thái vận động; check-in/milestone dùng animation ăn mừng.

Asset Shinchan được lấy từ **manifest chính thức của Petdex**. Backend streak không phụ thuộc Petdex: request check-in không chờ mạng Petdex; nếu Petdex tạm lỗi, streak/Pomodoro vẫn hoạt động và UI dùng fallback. Petdex Shinchan là fan art cộng đồng, vì vậy khi EDUFLOW được thương mại hóa/public rộng nên xem lại quyền sử dụng IP hoặc thay bằng mascot riêng.

## 4. Pomodoro / Focus

Preset:

- 25 / 5
- 45 / 10
- 50 / 10
- 90 / 15

Tùy chỉnh:

- Focus: 5–180 phút
- Break: 1–60 phút

Có Bắt đầu, Tạm dừng, Tiếp tục, Kết thúc và Bỏ qua nghỉ. Timer dùng **deadline timestamp**, không dùng counter cục bộ làm nguồn sự thật nên refresh/chuyển tab vẫn khôi phục đúng trạng thái. Local timer được namespace theo `studentId` để máy dùng chung không mang timer của học sinh này sang học sinh khác.

Chỉ phiên Focus hoàn tất mới được lưu thống kê. Backend có kiểm tra thời gian tối thiểu trước khi ghi nhận và `session_key` unique để tránh ghi trùng. Focus stats hoàn toàn độc lập với Daily Streak và điểm học tập.

## 5. D1 migration

Migration mới: `drizzle/0006_student_companion_focus.sql`.

Chỉ thêm 3 bảng:

- `student_pet_profiles`
- `student_daily_checkins`
- `student_focus_sessions`

Migration chỉ có `CREATE TABLE IF NOT EXISTS` và `CREATE INDEX IF NOT EXISTS`; **không DROP, TRUNCATE, DELETE hoặc ALTER dữ liệu cũ**.

`cap-nhat-cloudflare.ps1` sau khi apply migration sẽ kiểm tra cả 3 bảng mới. Nếu migration chưa thành công, script dừng trước bước deploy website.

## 6. Astryx + TasteSkill / responsive

- Dùng semantic token có sẵn (`--surface`, `--surface-2`, `--text`, `--muted`, `--line`, `--primary`, ...).
- Không tạo theme màu riêng cho pet.
- Motion chủ yếu bằng `transform`, progress và opacity; có `prefers-reduced-motion`.
- Desktop: companion dùng bố cục nhiều cột có kiểm soát.
- Tablet: pet thành một hàng rộng, streak/focus nằm dưới.
- Mobile: một cột; phần Pomodoro có disclosure để không đẩy danh sách môn học xuống quá xa khi timer chưa chạy.
- Nút chính trên mobile có touch target 42–44 px.

## 7. Kiểm tra

- Syntax/transpile check: các file TS/TSX thay đổi đều PASS.
- Regression/source tests không phụ thuộc build: **88/88 PASS**.
- Test riêng V8.2: **5/5 PASS**.
- SQLite simulation: migration + first check-in + duplicate check-in + consecutive streak + monthly Freeze + reset + focus unique session đều PASS.
- Diff audit so với V8.1 chỉ có các file V8.2 chủ đích.

Môi trường đóng gói hiện tại không thể chạy full production build vì dependency cache/npm network không khả dụng. Không có dependency mới được thêm và `package-lock.json` giữ nguyên V8.1. Script deploy vẫn thực hiện cài dependency, test/build/verify trước khi deploy và sẽ dừng nếu bước kiểm tra thất bại.

## 8. Deploy

Giải nén và chạy:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Không cần tự tạo bảng D1 bằng tay; migration 0006 nằm trong source và updater xử lý theo workflow hiện tại.
