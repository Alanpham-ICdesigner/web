# EDUFLOW V8.2.5 — BACKGROUND POMODORO + PHASE BOUNDARY STOP

## Yêu cầu

Đổi hành vi Pomodoro trên web học sinh:

- Đang chạy Focus/Break thì đóng tab, reload, chuyển app trên điện thoại hoặc rời Trang chủ: **thời gian vẫn tiếp tục tính theo thời gian thực**.
- Nếu quay lại trước khi phase hiện tại hết: timer tiếp tục đúng số thời gian còn lại, không reset và không cộng thời gian bị ẩn.
- Nếu phase hết khi học sinh đang rời trang: **dừng đúng ở ranh giới phase đó**, không tự tiêu thụ phase tiếp theo trong lúc website không hiện.
  - Focus hết khi đang rời trang → ghi nhận phiên Focus hoàn tất, chuyển sang Break ở trạng thái chờ với đủ thời lượng Break.
  - Break hết khi đang rời trang → dừng và trở về Focus sẵn sàng với đủ thời lượng Focus.
- Khi tab vẫn đang mở/hiện và phase kết thúc bình thường, flow Focus → Break hiện hữu vẫn được giữ.
- Nút `Tạm dừng` vẫn là thao tác tạm dừng thủ công; nút `Kết thúc` vẫn reset và giữ phản ứng `failed` của Punch khoảng 10 giây.

## Kỹ thuật

- Timer vẫn là client-side và được scope theo `studentId`, không thêm bảng D1 và không thay đổi schema/API học tập.
- `endAt` là nguồn thời gian chuẩn. Timer không phụ thuộc số lần `setInterval` chạy, nên browser throttle ở background không làm sai số đếm ngược.
- Thêm `backgroundedAt` vào state local của timer để phân biệt phase kết thúc khi đang rời trang với phase kết thúc khi đang xem trực tiếp.
- `visibilitychange` được dùng cho mobile app switch/tab background; `pagehide` + `beforeunload` giữ snapshot khi đóng/reload; `pageshow` hỗ trợ back-forward cache.
- Phiên Focus hoàn tất khi đang rời trang vẫn POST bằng `sessionKey` idempotent khi completion được xử lý, với `completedAt` là `endAt` gốc nên thống kê ngày/tuần/tháng không bị dồn sai sang thời điểm mở lại.

## Astryx + TasteSkill

- Không thay đổi JSX bố cục, CSS, breakpoint, spacing, motion hay semantic token.
- Vì đây là thay đổi timer lifecycle thuần logic, toàn bộ UI tiếp tục dùng nguyên component/CSS Astryx × TasteSkill của V8.2.4.2.
- Không thêm animation mới, không thay đổi chuyển động Punch, không thêm dependency UI.

## An toàn dữ liệu

- Không migration D1 mới.
- Không thay đổi bảng streak, check-in, focus history, điểm, chuyên cần, bài tập, lớp học hoặc R2.
- API Focus vẫn idempotent bằng `(student_id, session_key)`.
