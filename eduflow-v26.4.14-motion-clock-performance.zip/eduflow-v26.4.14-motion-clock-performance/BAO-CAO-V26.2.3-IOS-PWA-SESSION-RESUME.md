# EDUFLOW V26.2.3 – iOS PWA Session Resume

## Vấn đề
Một Home Screen web app đã cài từ phiên bản cũ có thể vẫn mở tại `/` thay vì `start_url` mới. Trang `/` trước đây luôn render form đăng nhập và không kiểm tra student session, nên người dùng có cảm giác bị đăng xuất dù cookie còn hợp lệ. Ngoài ra cookie đã có `Max-Age=30 ngày` nhưng chưa có `Expires`, làm giảm khả năng tương thích với một số hành vi WebKit/PWA.

## Thay đổi
- Khi chạy ở standalone/Home Screen mode, trang `/` tự kiểm tra `/api/student/session` trước khi hiện form đăng nhập. Nếu session còn hợp lệ, chuyển thẳng sang `/student?source=pwa`.
- Không auto-redirect trên browser tab bình thường để không cản luồng đăng nhập Admin.
- Student cookie tiếp tục 30 ngày, thêm `Expires`, đổi `SameSite=Lax`, giữ `HttpOnly`, `Secure`, `Path=/`, và thêm `Priority=High`.
- Login/session bootstrap/logout dùng `credentials: include` tường minh.
- Không lưu PIN/password/local auth token vào localStorage/sessionStorage.
- Không migration D1.

## Kỳ vọng
Đăng nhập trong icon Home Screen -> vuốt đóng app -> mở lại icon -> nếu session 30 ngày còn hợp lệ, vào thẳng trang học sinh. Không cần gỡ/cài lại icon cũ.
