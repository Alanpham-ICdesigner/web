# EDUFLOW V26.1.0 — Push / Chat / Assignment / PDF polish

Base: EDUFLOW V26.0.0, originally upgraded from V25.3.3.

## Changes

- Web Push remains event-driven: assignment creation, test calendar, grade/comment updates, teacher messages, manual announcements and completed Pomodoro sessions.
- Teacher point-rule changes now automatically Push only the affected student. Applying multiple rules in one action emits one aggregated Push instead of one Push per rule.
- Point Push deep-links to the student reward/points area.
- Existing manual teacher notification creation remains unchanged.
- Student direct-message UI is bounded to the dynamic viewport on phones, including iOS safe-area handling, so the composer remains inside the screen.
- Push settings popover is viewport-anchored on desktop and no longer clips its action button.
- Removed the explanatory Apple Developer / Live Activity / Dynamic Island footnote.
- Teacher assignment detail now shows the assignment description above submission statistics.
- PDF viewer opens at exactly 100% (`zoom = 1`, custom scale), removes “Vừa chiều rộng” and “Vừa trang”, and keeps +/- manual zoom, page navigation, thumbnails, fullscreen and download.

## Data / infrastructure

- No destructive D1 change.
- No new migration in V26.1.
- Existing V26 push subscription and Pomodoro migrations are preserved.
- R2, Worker routes and the Cloudflare deployment workflow are preserved.

## Verification in this environment

- 183/183 source regression tests pass when excluding `rendered-html.test.mjs`, which requires built `dist` output.
- V26 + V26.1 targeted tests pass.
- `public/sw.js` and `scripts/generate-vapid.mjs` pass `node --check`.
- Final `npm ci`/Vinext build could not be completed in this execution environment because dependency installation timed out while accessing the npm registry. The Cloudflare update script still performs install → build → test before migration/deploy and stops if those checks fail.
