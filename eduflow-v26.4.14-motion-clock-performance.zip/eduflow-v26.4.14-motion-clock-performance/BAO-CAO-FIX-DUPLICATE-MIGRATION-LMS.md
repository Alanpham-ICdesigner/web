# EDUFLOW V20 - Fix duplicate migration trên đúng bản LMS multi-course

- Nền source: `edumath-cloudflare-v20-lms-multicourse-ready(2)`
- Giữ nguyên toàn bộ UI/API LMS multi-course.
- Sửa lỗi production D1: `duplicate column name: score: SQLITE_ERROR`.
- Không reset D1, không DROP bảng, không xóa dữ liệu.
- `cap-nhat-cloudflare.ps1` kiểm tra từng cột bằng `pragma_table_info` và chỉ `ALTER TABLE` khi cột còn thiếu.
- Migration `0005_many_courses_lms.sql` vẫn tạo enrollment, course schedules, make-up sessions và backfill dữ liệu; các CREATE/INDEX được chuyển sang `IF NOT EXISTS` để an toàn khi retry.
- Giữ nguyên Worker `edumath`, D1 `eduflow-db`, R2 `eduflow-files`.
