# EDUFLOW V26.2.1 — Sleep-safe Pomodoro

Bản này tiếp tục trực tiếp từ V26.2.0 và giữ nguyên toàn bộ thay đổi multi-class, grading queue, mobile teacher logout và student persistent session.

## Feedback được xử lý

Khi học sinh bắt đầu Pomodoro rồi thu nhỏ tab, để trình duyệt chạy nền hoặc gập laptop đi ngủ, phiên Focus không được phụ thuộc vào JavaScript timer của tab. Timer dùng mốc `ends_at` do server lưu trong D1. Cloudflare scheduled reconciliation có thể kết thúc và ghi nhận phiên khi browser của học sinh không còn hoạt động.

### Quy tắc mới được khóa rõ

- **Không thao tác gì + thu nhỏ/gập laptop:** Focus vẫn chạy theo wall clock của server. Khi đủ thời lượng, phiên được ghi nhận.
- **Tạm dừng:** còn bao nhiêu thời gian thì giữ nguyên bấy nhiêu, kể cả qua ngày hoặc đổi thiết bị; chỉ chạy tiếp khi học sinh bấm Tiếp tục.
- **Kết thúc:** hủy phiên chưa hoàn thành và reset về preset; không coi là Tạm dừng.
- **Qua 0h:** phiên được tính vào ngày học sinh **bắt đầu** Focus theo `Asia/Ho_Chi_Minh`, tránh trường hợp mở lại hôm sau rồi phiên bị chuyển sang ngày hôm sau.

## Kỹ thuật

- Không thêm migration D1.
- `student_focus_timer_state.ends_at` vẫn là nguồn thời gian authoritative.
- `student_focus_sessions.completed_at` vẫn lưu thời điểm hoàn tất thực tế/scheduled boundary.
- `student_focus_sessions.date_key` dùng ngày bắt đầu Focus theo giờ Việt Nam.
- Cron reconciliation hiện là `* * * * *` để xử lý boundary/push khi không có client đang mở.

## Kiểm thử

- 200/200 static regression tests PASS (đã loại `rendered-html.test.mjs` vì test đó yêu cầu `dist/server/index.js` sau full build).
- Test mới kiểm tra server wall clock, scheduled reconciliation, date attribution và phân biệt Pause với browser background.

## Deploy

Không cần migration mới. Chạy workflow deploy hiện có:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\cap-nhat-cloudflare.ps1
```
