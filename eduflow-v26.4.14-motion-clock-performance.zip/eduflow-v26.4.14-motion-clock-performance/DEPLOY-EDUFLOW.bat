@echo off
cd /d "%~dp0"
title EDUFLOW V26.2.5 Deploy
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0cap-nhat-cloudflare.ps1"
if errorlevel 1 (
  echo.
  echo DEPLOY KHONG HOAN TAT. Website tren Cloudflare khong bi thay doi neu script dung truoc buoc deploy.
  pause
)
