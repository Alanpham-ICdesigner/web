# EDUFLOW V20 — V7.1 Reward UI Fix

- Giữ nguyên toàn bộ V7.
- Quà trên trang học sinh đổi sang cơ chế chọn trước: card được viền primary + glow và có nhãn `Đang chọn`.
- Sau khi chọn, hiển thị khu xác nhận và nút `Đổi quà đã chọn`.
- Sau khi đổi thành công, trạng thái chọn được xóa.
- Sửa xung đột CSS cũ ép nội dung lịch sử đổi quà về 42px.
- Lịch sử đổi quà dùng grid 3 cột: icon / nội dung / trạng thái; tên quà, thời gian, điểm không còn vỡ dọc.
- Trạng thái approved/rejected có màu tương ứng; mobile chuyển trạng thái xuống hàng để tránh chèn nội dung.
- Không thay đổi database schema, API hoặc migration.
