# EDUFLOW V20 — V7 Weekly Timetable

## Thay đổi

- Giữ nguyên toàn bộ V6.1: thông báo chung, nhắn tin hai chiều, giáo viên chủ động nhắn học sinh, LMS nhiều môn và các bản vá D1.
- Đổi **Lịch học học sinh** sang thời khóa biểu tuần dạng lưới: Thứ 2 → Chủ nhật, trục giờ, điều hướng tuần, nút Hôm nay.
- Đổi **Lịch dạy giáo viên** sang cùng kiểu thời khóa biểu tuần và tổng hợp tất cả lớp.
- Mỗi block nằm đúng vị trí theo giờ bắt đầu/kết thúc.
- Học bù/buổi bổ sung được phân biệt trực quan.
- Giáo viên vẫn có thể điểm danh từ block lịch; buổi học bù vẫn sửa/xóa được.
- Mobile/tablet dùng vùng cuộn ngang riêng, không kéo vỡ toàn trang.
- Không thêm bảng/cột/migration D1 mới.

## Kiểm tra

- Source regression tests (không cần `dist`): **49/49 PASS** bằng `node --test`.
- Kiểm tra cú pháp TSX bằng TypeScript `--noResolve`: **0 syntax error**.
- Full build trong môi trường đóng gói không chạy được vì cài dependency npm bị timeout; script deploy trên máy người dùng vẫn tự `npm ci → build → test → deploy` như trước.
