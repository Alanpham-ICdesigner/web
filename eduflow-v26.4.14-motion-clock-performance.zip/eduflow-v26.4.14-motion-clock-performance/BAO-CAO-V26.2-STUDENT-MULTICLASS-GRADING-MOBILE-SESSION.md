# EDUFLOW V26.2.0 — Multi-class, grading queue, mobile logout & persistent student session

## Mục tiêu
Bản V26.2.0 tiếp tục trực tiếp từ V26.1.4 và giữ nguyên kiến trúc Cloudflare Worker + D1 + R2. UI dùng lớp thiết kế Astryx + TasteSkill hiện có; không thay đổi route chính, font, màu thương hiệu hoặc dữ liệu học tập cũ.

## Thay đổi chính

### 1. Học sinh thuộc nhiều lớp trong màn hình chỉnh sửa
- Modal **Sửa thông tin học sinh** đổi từ chọn một lớp sang multi-select.
- Tự nạp toàn bộ enrollment đang active của học sinh.
- Có thể thêm/bỏ nhiều lớp trong một lần lưu; `Chưa xếp lớp` là trạng thái rỗng, không phải một lớp thật.
- API `/api/students` nhận `classKeys` / `classEnrollments` nhưng vẫn tương thích payload `classKey` cũ.
- PATCH thực hiện diff enrollment, tránh xóa/tạo lại toàn bộ và tránh duplicate.
- Export Excel/PDF dùng toàn bộ tên lớp thay vì chỉ lớp legacy chính.

### 2. Đổi PIN học sinh bằng modal an toàn
- Bỏ `window.prompt()` cho thao tác đặt PIN.
- Modal mới có validation đúng 6 chữ số, show/hide và tạo PIN ngẫu nhiên.
- PIN cũ **không thể hiển thị** vì source đang lưu PBKDF2 hash + salt; không hạ cấp bảo mật sang plaintext.

### 3. Bài tập
- Card bài tập desktop dùng grid 2 cột đều nhau; bài lẻ không kéo full width. Mobile về 1 cột.
- Thêm bộ lọc `Tất cả lớp` kết hợp cùng các tab trạng thái.
- Badge sidebar `Bài tập` chỉ đếm assignment chưa `Đã kết thúc`; khi bằng 0 badge được ẩn theo logic badge hiện tại.
- `Tất cả` đếm assignment theo lớp đang lọc.
- `Chờ chấm` đếm **submission** thực sự còn thiếu điểm hoặc nhận xét, không đếm assignment.
- Assignment hết deadline vẫn xuất hiện trong `Chờ chấm` nếu còn submission chưa hoàn tất chấm.
- Card hiển thị số bài nộp đang chờ chấm.
- Chi tiết bài nộp hiển thị `Chờ hoàn tất` nếu record đã mang status `graded` nhưng còn thiếu score hoặc feedback; mở thẳng chế độ chỉnh sửa cho trường hợp này.
- GET `/api/assignments` gom dữ liệu theo batch, không tạo N+1 request theo từng assignment.

### 4. Đăng xuất giáo viên trên điện thoại
- Thêm action `Đăng xuất` rõ ràng ở cuối sidebar mobile của GV/Admin.
- Dùng API logout Admin hiện có; không tạo session API mới.
- Desktop giữ luồng hiện có.

### 5. Giữ đăng nhập học sinh 30 ngày
- Student session đổi từ 12 giờ sang 30 ngày.
- Cookie vẫn `HttpOnly; Secure; SameSite=Strict; Path=/` và thêm `Max-Age=2592000`.
- Token ký HMAC bên trong cũng hết hạn 30 ngày, đồng bộ với cookie.
- `GET /api/student/session` đã là request bootstrap hiện có; khi authenticated nó cấp lại cookie 30 ngày để tạo rolling session.
- Không có request refresh riêng, không polling session và không phát sinh request chỉ vì học sinh không đăng xuất khi web đang đóng.
- Logout vẫn xóa cookie bằng `Max-Age=0`.

## Database / migration
**Không có migration mới cho V26.2.0.** Multi-class dùng bảng `student_enrollments` hiện có và PIN dùng bảng account hiện có.

Script deploy cũ vẫn chạy các migration/precheck lịch sử theo cách idempotent nhằm tương thích database đang dùng.

## File chính được thay đổi
- `app/page.tsx`
- `app/astryx-taste-deep.css`
- `app/api/students/route.ts`
- `app/api/assignments/route.ts`
- `app/api/student/session/route.ts`
- `lib/student-auth.ts`
- `package.json`
- `package-lock.json`
- `cap-nhat-cloudflare.ps1`
- `DEPLOY-EDUFLOW.bat`
- test regression liên quan V20/V25/V26 + test mới V26.2

## Kiểm thử trong môi trường tạo source
- Static Node tests không phụ thuộc build: **197/197 pass**.
- TypeScript transpile/syntax check cho các file logic chính: **pass**.
- Full `vinext build` chưa thể chạy trong sandbox này vì môi trường không truy cập được `registry.npmjs.org` để cài dependency. Script deploy trên Windows vẫn giữ thứ tự an toàn: install dependency → build → test → Cloudflare dry-run → D1 precheck/migrations → deploy.

## Deploy Windows
1. Giải nén source.
2. Đảm bảo máy có Node.js >= 22.13 và đã đăng nhập đúng Cloudflare account của EDUFLOW.
3. Chạy `DEPLOY-EDUFLOW.bat`.

Hoặc PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\cap-nhat-cloudflare.ps1
```

Script chỉ đi đến bước deploy sau khi build, test, Cloudflare dry-run và D1 precheck thành công.
