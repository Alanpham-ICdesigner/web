# BÁO CÁO CẬP NHẬT V19.8.9

## Bộ chọn quy tắc

- Popup áp dụng quy tắc lấy toàn bộ quy tắc đang bật từ cùng nguồn dữ liệu với bảng quản lý quy tắc.
- Không còn loại quy tắc `assignment_streak`; quy tắc thủ công và quy tắc chuỗi hoàn thành bài đều xuất hiện.
- Giữ nguyên thứ tự cộng lớn đến nhỏ, sau đó trừ theo thứ tự đã thiết lập.
- Popup hiển thị tổng số quy tắc đang bật và loại của từng quy tắc.
- Backend vẫn xác minh lại từng ID và trạng thái đang bật trước khi ghi điểm.
- Form tạo/sửa quy tắc không còn trường “Cách áp dụng”; quy tắc mới mặc định là thủ công, còn loại của quy tắc tự động có sẵn được giữ nguyên khi chỉnh sửa.

## Popup toàn website

- Popup của các trang giáo viên và học sinh được neo theo toàn bộ viewport.
- Lớp phủ che cả sidebar, topbar và vùng nội dung thay vì bị thu trong trang con.
- Khóa cuộn trang nền khi popup mở.
- Giữ giới hạn chiều cao theo màn hình và cuộn nội dung trên laptop/điện thoại.
- Không thay đổi màu thương hiệu, font Be Vietnam Pro, route hoặc cấu trúc form.

## Deploy Windows bằng một lệnh

Chỉ cần chạy:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Script tự động:

1. Kiểm tra Node.js.
2. Cài dependency nếu thư mục mới chưa có `node_modules`.
3. Build và xác nhận `dist/server/index.js`, `dist/client`.
4. Chạy toàn bộ test.
5. Kiểm tra đăng nhập Cloudflare và chạy dry-run.
6. Chỉ deploy sau khi người dùng nhập `Y`.

Script dùng Wrangler cục bộ đã khóa phiên bản, giữ nguyên Worker `edumath`, D1 `eduflow-db` và R2 `eduflow-files`.

## Xác minh

- Build thành công và có đủ `dist/server/index.js`, `dist/client`.
- 27/27 kiểm thử tự động đạt.
- ESLint: 0 lỗi.
