# EDUFLOW V25.3.3 — PDF / Submission / Pomodoro UI Fix

## Base
Bản này được sửa trực tiếp từ **V25.3.2 PDF Viewport Fix**, giữ toàn bộ continuous PDF viewer, portal viewport, toolbar thống kê V25.3.1 và UI Astryx/TasteSkill.

## Các lỗi đã sửa

### 1. Nút PDF bị mất khi chọn “Vừa chiều rộng”
Nguyên nhân UI là nhóm `fit controls` có các button không co trong lane `max-content`, nên ở viewport trung gian (đặc biệt Windows display scaling) có thể bị ép khỏi mép phải. V25.3.3 cho button co theo lane và thêm breakpoint `1440px`: nhóm **Vừa chiều rộng / Vừa trang** chuyển sang hàng thứ hai của toolbar trước khi có nguy cơ clipping.

### 2. Học sinh chọn PDF nhưng “Không thể nộp bài”
Luồng mới tách upload tệp và commit bài nộp:
1. Browser PUT raw file tới `/api/student/submissions/upload`.
2. Worker stream request body thẳng vào R2, xác minh lại bằng `head()`.
3. Browser POST JSON metadata tới `/api/student/submissions` để commit D1.
4. Nếu commit lỗi, cleanup chỉ xóa các object chưa được tham chiếu.

Luồng multipart cũ vẫn được giữ để tương thích. `next.config.ts` đặt transport ceiling 12 MB, còn validation nghiệp vụ vẫn giữ đúng **10 MB tổng bài nộp**.

### 3. Header “Pomodoro hiện tại” quá to/đậm
Cột thứ 8 ở bảng ngày dùng cùng typography với các `engagement-sort`: `10px`, `font-weight: 800`, màu `var(--muted)` và cùng vị trí inset text. Không đổi logic hoặc trạng thái Pomodoro.

## Kiểm tra
- Source regression suite không cần build: **163/163 pass**.
- Có thêm 4 regression checks riêng cho V25.3.3: typography Pomodoro, PDF fit toolbar, raw R2 submission upload, cleanup an toàn.
- `rendered-html.test.mjs` cần `dist/server/index.js` sau build nên không nằm trong source-only suite.
- Không thay schema/migration D1.
