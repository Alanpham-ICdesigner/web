# EDUFLOW V8.2.2 — Local Shinchan + Pause Timer on Exit

## Mục tiêu lần sửa
Hoàn thiện hệ Focus Pet theo phản hồi thực tế mà không làm thay đổi logic học tập hiện có và vẫn giữ guardrail Astryx + TasteSkill.

## Thay đổi chính
- Dùng trực tiếp `SHINCHANPET.zip` do người dùng cung cấp: `pet.json` + `spritesheet.webp` được bundle tại `public/pets/shinchan/`.
- Bỏ phụ thuộc Petdex manifest/proxy khi website đang chạy. Link Petdex chỉ còn vai trò ghi nguồn.
- Pet chỉ được mount tại Trang chủ HS > **Các môn học của tôi**. Sang **Lịch học** hoặc vào môn học thì component pet/timer unmount.
- Khi component unmount, reload, `pagehide` hoặc đóng trang: thời gian Focus/Break còn lại được ghi localStorage ở trạng thái `running=false`, `endAt=0`.
- Khi quay lại: đồng hồ khôi phục đúng số thời gian đã lưu nhưng ở trạng thái **Tạm dừng**; HS phải bấm **Tiếp tục**.
- Hỗ trợ back-forward cache bằng `pageshow` để không vô tình tiếp tục timer sau khi quay lại trang.
- Bỏ vòng progress ring quanh Shinchan; thời gian chỉ hiển thị trong panel Pomodoro.
- Thêm đổi tên pet 1–24 ký tự qua API `PATCH /api/student/pet`; dùng cột `pet_name` đã có, không thêm migration.
- Xóa hai đoạn giải thích dài dưới Streak/Pomodoro; logic Freeze, milestone, thống kê Focus vẫn giữ nguyên.

## An toàn dữ liệu / logic
- Không DROP/ALTER bảng học thuật.
- Không thay đổi quy tắc Daily Streak, Freeze, milestone bội 10/100.
- Không cộng Pomodoro vào điểm thi đua hoặc điểm danh buổi học.
- Không đổi API lớp học, bài tập, điểm, tài liệu, thông báo, D1/R2 hiện có.

## Kiểm tra
- 9/9 test riêng cho Student Companion PASS.
- 92/92 test source/regression không phụ thuộc build PASS.
- TypeScript syntax/transpile của các file TS/TSX thay đổi PASS.
- Full production build không chạy được trong môi trường đóng gói vì môi trường không resolve được `registry.npmjs.org`; workflow deploy của source vẫn giữ nguyên và sẽ tự install/build/verify trước khi deploy trên máy người dùng.
