# EDUFLOW V26.4.6 — Focus Workspace

## Mục tiêu

Nâng Pomodoro của học sinh thành một không gian tập trung hoàn chỉnh nhưng không thay đổi logic LMS hiện có. UI tiếp tục dùng Astryx + TasteSkill làm nền, Morphicons cho các icon có chuyển trạng thái và motion chỉ dùng transform/opacity để giữ PWA nhẹ.

## Thay đổi chính

### 1. Sửa lỗi không nhập được thời gian Pomodoro

Nguyên nhân cũ: input là controlled value từ timer server và `onChange` gửi `configure` ngay sau từng ký tự. Khi người dùng xóa số cũ để nhập số mới, server clamp/đồng bộ lại nên input bị giật về giá trị trước.

V26.4.6 dùng `focusMinutesDraft` / `breakMinutesDraft` cục bộ. Chỉ ghi cấu hình server khi bấm **Áp dụng**, Enter hoặc rời toàn bộ vùng chỉnh thời gian. Giới hạn vẫn giữ Focus 5–180 phút, Break 1–60 phút.

### 2. Focus Workspace toàn màn hình

- Overlay 100dvh, không làm thay đổi route hay dữ liệu timer.
- Digital clock hoặc Flip clock; lựa chọn được nhớ theo học sinh trên thiết bị.
- Nút Fullscreen API thật trên browser hỗ trợ; nếu không hỗ trợ, overlay vẫn phủ toàn bộ app.
- Screen Wake Lock khi timer đang chạy nếu browser hỗ trợ.
- Escape/Thoát khôi phục scroll, orientation và fullscreen sạch sẽ.
- Tôn trọng `prefers-reduced-motion`.

### 3. Mobile landscape + iOS/PWA fallback

- Layout ngang: Task | Timer | Spotify.
- Thử `screen.orientation.lock("landscape")` sau khi vào fullscreen (các browser yêu cầu gesture/fullscreen).
- Nếu iOS/PWA không cho khóa orientation, dùng visual landscape fallback riêng; người dùng có thể trả lại layout bình thường.
- Safe-area cho notch/home indicator và breakpoint riêng cho màn hình hẹp.

### 4. Personal Focus Tasks giống workflow LifeAt

Đây là task cá nhân của học sinh, **không phải bài tập giáo viên giao**.

Có:
- thêm nhanh task;
- chọn task đang tập trung;
- sửa tên;
- hoàn thành / mở lại;
- xóa;
- kéo thả sắp xếp trên chuột và touch;
- đồng bộ D1 giữa laptop và điện thoại;
- nhớ task được chọn;
- liên kết task với phiên Focus đang chạy.

Migration mới:
- `student_focus_tasks`
- `student_focus_task_sessions`

Khi một Pomodoro hoàn tất theo timer server-authoritative, mapping session được claim idempotent rồi mới tăng `completed_pomodoros`, tránh cộng trùng nếu nhiều thiết bị cùng sync.

### 5. Spotify

- Spotify Embed; không lưu access token/OAuth secret.
- Học sinh có thể dán playlist/album/track Spotify.
- Link gần nhất được nhớ cục bộ trên thiết bị.
- Có quick pick **Peaceful Piano** (playlist công khai của Spotify) cho nhạc piano không lời.
- Browser vẫn yêu cầu người dùng tự bấm Play do chính sách autoplay.

### 6. Morphicons + motion

Morphicons được vendored tại `lib/vendor/morphicons/` cùng MIT license. Các trạng thái Play/Pause, Digital/Flip, checkbox và fullscreen dùng MorphIcon; button có hover/pressed/focus rõ ràng, touch target được tối ưu và reduced-motion được tôn trọng.

## File chính

- `app/student/pet-focus-companion.tsx`
- `app/student/focus-studio.tsx`
- `app/api/student/focus/tasks/route.ts`
- `lib/focus-timer.ts`
- `db/schema.ts`
- `drizzle/0017_focus_workspace_tasks.sql`
- `app/astryx-taste-deep.css`
- `lib/vendor/morphicons/*`
- `cap-nhat-cloudflare.ps1`
- `tests/v26.4.6-focus-workspace.test.mjs`

## Kiểm thử trong môi trường hiện tại

- Test riêng V26.4.6: PASS 6/6.
- Toàn bộ test nguồn không phụ thuộc build artifact: PASS 231/231.
- TypeScript syntax transpile cho các file đã sửa: PASS.
- Test `rendered-html` / `validate:artifact` cần `dist/server/index.js` nên chưa chạy được khi chưa build.
- `npm run install:ci` không chạy được vì môi trường sandbox không resolve `registry.npmjs.org`; vì vậy chưa thể chạy full `npm run build` tại đây. Không có deploy Cloudflare nào được thực hiện.

## Triển khai

Script `cap-nhat-cloudflare.ps1` vẫn chạy migration trước deploy và V26.4.6 bổ sung precheck cho 2 bảng + 3 index Focus Workspace. Nếu migration chưa đủ, script dừng trước bước deploy Worker.
