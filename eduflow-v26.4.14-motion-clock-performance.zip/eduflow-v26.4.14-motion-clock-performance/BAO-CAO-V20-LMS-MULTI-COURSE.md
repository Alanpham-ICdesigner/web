# Báo cáo nâng cấp EDUFLOW / PHMT MATH V20 — LMS Multi-course

## 1. Audit source thực tế

- Framework: Next.js 16 + React 19, build/deploy bằng Vinext/Vite lên Cloudflare Worker.
- Database: Cloudflare D1 qua Drizzle ORM; migration nằm trong `drizzle/`.
- File storage: Cloudflare R2 binding `BUCKET` (`eduflow-files`).
- Authentication: cookie ký riêng cho Admin và Student; PIN học sinh được PBKDF2.
- Mô hình cũ: `students.class_name` gắn trực tiếp học sinh với một lớp; lớp lưu trong `admin_items` (`kind=classes`).
- Bài tập cũ: `assignments` và `assignment_submissions` chỉ ghi nhận thời điểm hoàn thành.
- Teacher UI: `app/page.tsx` và `app/class-hub.tsx`.
- Student UI cũ: `app/student/page.tsx`.
- Worker/D1/R2 đang deploy được giữ nguyên: `edumath`, `eduflow-db`, `eduflow-files`.

## 2. Kiến trúc mới

```text
Student account (students + student_accounts)
        |
        | 1:N
        v
Enrollment (student_enrollments)
        |
        | N:1
        v
Course/Class (admin_items kind=classes)
        |
        +-- Course schedules (course_schedules)
        +-- Actual/make-up sessions (course_sessions)
        +-- Assignments -> submissions -> score/feedback
        +-- Course-filtered grades, attendance, notices and documents
```

`students.class_name` vẫn được giữ làm snapshot lớp chính để tương thích code và dữ liệu cũ. Quan hệ tham gia lớp chính thức nằm ở `student_enrollments`, có unique index `(student_id, class_key)` để không thể ghi danh trùng.

## 3. Migration và bảo toàn dữ liệu

Migration `0005_many_courses_lms.sql`:

- tạo `student_enrollments`, `course_schedules`, `course_sessions`;
- tự động tạo một enrollment từ `students.class_name` cho toàn bộ học sinh cũ;
- thêm `class_key` và metadata tệp cho bài tập;
- backfill `assignments.class_key` từ lớp cũ;
- mở rộng submission bằng text, R2 object key, tên/kích thước/loại tệp, trạng thái, điểm, feedback và thời điểm chấm;
- không `DROP`, không reset, không xóa học sinh hoặc lịch sử cũ.

Migration đã được chạy thử tuần tự từ `0000` đến `0005` trên SQLite in-memory với dữ liệu học sinh, bài tập và bài nộp cũ; dữ liệu và quan hệ sau migration được giữ đúng.

## 4. Chức năng hoàn thành

- Một tài khoản học sinh tham gia nhiều course; thêm nhiều học sinh có sẵn trong modal của lớp; chặn enrollment trùng.
- Xóa học sinh khỏi lớp chỉ xóa enrollment; account và các course còn lại vẫn hoạt động.
- Student LMS mới: “Các môn học của tôi”, course card, course detail và sáu tab Tổng quan/Lịch/Thông báo/Tài liệu/Bài tập/Điểm-quá trình.
- Backend xác minh enrollment khi truy cập `courseId`, tải đề bài, nộp bài và tải submission; sửa URL sang course chưa tham gia trả 403.
- Course có nhiều lịch học có cấu trúc; form thêm/sửa/xóa nhiều buổi.
- Teacher có “Lịch dạy” theo tuần, chuyển tuần/hôm nay, tổng hợp mọi course và đánh dấu học bù.
- Buổi học bù lưu riêng, không sửa lịch định kỳ; xuất hiện trong Teacher schedule, Student course, điểm danh và báo cáo.
- Workflow bài tập: giao bài + tệp đề, Student nộp ảnh/PDF hoặc text, Teacher tải bài/nhập điểm/feedback, Student xem kết quả.
- Teacher Settings có upload/preview/xóa/thay QR R2; báo cáo chỉ chèn QR khi đã cấu hình.
- Không có bảng, API hoặc UI quản lý học phí/giao dịch thanh toán.
- UI mới dùng token hiện có, Be Vietnam Pro, light/dark mode, card/modal/tab/empty-state nhất quán và breakpoint mobile/tablet/desktop.
- API dữ liệu Teacher được bảo vệ bằng Admin session; endpoint settings công khai chỉ trả hồ sơ branding cần cho trang login.

## 5. File thêm/sửa

### Database và hạ tầng kiểu dữ liệu

- `db/schema.ts`
- `drizzle/0005_many_courses_lms.sql`
- `drizzle/meta/_journal.json`
- `cloudflare-env.d.ts`
- `tsconfig.json`

### Helper

- `lib/course-access.ts`
- `lib/admin-ui-utils.mjs`
- `lib/admin-ui-utils.d.mts`
- `lib/student-auth.ts`

### API

- `app/api/admin/items/route.ts`
- `app/api/students/route.ts`
- `app/api/enrollments/route.ts`
- `app/api/course-schedules/route.ts`
- `app/api/course-sessions/route.ts`
- `app/api/assignments/route.ts`
- `app/api/assignments/[id]/attachment/route.ts`
- `app/api/assignments/[id]/submissions/route.ts`
- `app/api/student/submissions/route.ts`
- `app/api/submissions/[id]/file/route.ts`
- `app/api/student/portal/route.ts`
- `app/api/student/notifications/route.ts`
- `app/api/student-records/[id]/route.ts`
- `app/api/class-dashboard/route.ts`
- `app/api/documents/[id]/route.ts`
- `app/api/settings/payment-qr/route.ts`

### Giao diện và báo cáo

- `app/page.tsx`
- `app/class-hub.tsx`
- `app/student/page.tsx`
- `app/redesign.css`

### Test và tài liệu

- `tests/multi-course-lms.test.mjs`
- `BAO-CAO-V20-LMS-MULTI-COURSE.md`

## 6. Kiểm thử và build

- `npm run lint`: pass, 0 lỗi và 0 cảnh báo.
- `npx tsc --noEmit`: pass.
- `node --test tests/*.test.mjs`: 43/43 test pass.
- Migration chain `0000 -> 0005` với dữ liệu legacy: pass.
- `npm run build`: pass; Vinext tạo Worker ESM và client assets.
- `npm run validate:artifact`: pass; `dist/server/index.js` có `default.fetch`, hosting manifest hợp lệ.
- Responsive được kiểm tra bằng các guardrail CSS/test cho nhóm 375, 390, 430, 700/768, 1366 và 1440 px; Teacher schedule chuyển từ lưới sang danh sách một cột trên mobile.

## 7. Deploy

Giữ nguyên workflow hiện tại:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Script sẽ cài dependency nếu cần, build, chạy test, dry-run, hỏi xác nhận, apply D1 migration theo kiểu không xóa dữ liệu, rồi deploy Worker. Nên sao lưu D1 theo quy trình vận hành hiện có trước một migration production lớn, dù migration này không có lệnh phá hủy dữ liệu.
