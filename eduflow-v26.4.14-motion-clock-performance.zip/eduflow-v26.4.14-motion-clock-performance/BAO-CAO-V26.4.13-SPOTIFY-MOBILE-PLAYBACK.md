# EDUFLOW V26.4.13 — Spotify Mobile/PWA Playback

## Mục tiêu
Khắc phục trải nghiệm Spotify Embed trên mobile/PWA khi Spotify chỉ cho preview dù desktop phát đầy đủ.

## Thay đổi
- Giữ nguyên iframe Spotify theo mẫu chính thức với `allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"`.
- Iframe Spotify dùng `frameBorder="0"`, `width="100%"`, `height="152"` và tải eager khi panel Music đã mở.
- Thêm `Mở Spotify` để hand-off link gốc sang Spotify app/web player; phù hợp nhất khi iOS/PWA không cấp full encrypted playback cho iframe.
- Thêm `Tải lại player` để remount iframe sau khi người dùng đăng nhập Spotify bên ngoài.
- Không thêm OAuth, không lưu token Spotify và không chia sẻ tài khoản Premium của giáo viên.
- Không thay đổi D1/R2/schema.

## Giới hạn nền tảng
Spotify có thể chỉ phát preview trong một số browser/PWA context. EDUFLOW không bypass giới hạn playback của Spotify; nút hand-off dùng luồng chính thức của Spotify.
