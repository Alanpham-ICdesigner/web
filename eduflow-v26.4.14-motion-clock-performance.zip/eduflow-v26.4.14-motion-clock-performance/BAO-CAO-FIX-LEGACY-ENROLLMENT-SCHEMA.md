# EDUFLOW V20 – Fix legacy student_enrollments schema

## Lỗi production đã ghi nhận

`table student_enrollments has no column named class_key`

Nguyên nhân: hotfix duplicate trước đó đã tạo bảng `student_enrollments` dạng cũ với `id, student_id, class_name, created_at`. LMS V20 cần thêm `class_key, status, enrolled_at, updated_at`.

## Cách sửa an toàn

Bản này **không drop/rebuild bảng enrollment**. Script deploy tự phát hiện bảng cũ, bổ sung các cột còn thiếu, backfill `class_key`, chuẩn hóa index unique `(student_id, class_key)`, đồng thời giữ `created_at` để tương thích dữ liệu cũ. Migration 0005 và API LMS cũng dùng `created_at`, vì vậy cả database cũ lẫn database mới đều chạy được.

Không reset D1, không xóa học sinh, không xóa R2.
