# EDUFLOW V8.2.4.1 — Stats toolbar layout fix

## Lỗi đã sửa
- Nút `Hôm nay` trong bảng **Điểm danh streak & Pomodoro** bị kế thừa rule global `.button.soft { width: 100%; margin-top: 14px; }`, làm nút chiếm phần lớn hàng toolbar và ép bộ chọn ngày co gần như về 0.
- Bộ chọn ngày vì vậy chỉ còn một pill rỗng/tiny ở desktop.

## Cách sửa
- Scope lại `.engagement-today` với `width: auto` và `margin-top: 0`.
- Giữ date picker ở desktop với footprint ổn định 156px và input tối thiểu 112px.
- Ở mobile, trả date picker về flex co giãn (`flex: 1 1 auto`, `min-width: 0`) để không gây tràn ngang.
- Không thay API, D1, migration, dữ liệu, sort/filter hay logic thống kê.

## UI guardrail
- Chỉ sửa CSS scoped cho module V8.2.4.
- Tiếp tục dùng token `--line`, `--surface`, `--muted`, `--primary` và control primitives hiện có theo Astryx/TasteSkill.
