# EDUFLOW V26.4.8 · Focus Space controls

- Bỏ badge `FOCUS` ở card Pomodoro ngoài dashboard, chỉ giữ nút `Focus Space`.
- Focus Space có dark mode độc lập, ghi nhớ theo học sinh trên thiết bị.
- Clock có selector `Focus / Break`; Break có thể bắt đầu trực tiếp từ Focus Space.
- Thêm nút Settings trong Focus Space để chỉnh Focus 5–180 phút và Break 1–60 phút, có preset 25/5, 45/10, 50/10, 90/15.
- Draft thời gian vẫn là controlled-local draft; chỉ gửi server khi Apply, tránh lỗi không thể nhập trên desktop/PWA.
- Giảm kích thước Digital/Flip clock để cân đối trên desktop, mobile dọc và landscape.
- Giữ Task / Music / Notes floating windows, Spotify embed, fullscreen portal, wake lock và landscape behavior từ V26.4.7.

## Test
- V26.4.6 + V26.4.7 + V26.4.8 regression: 16/16 PASS.
- Toàn bộ source tests: 241 PASS; 1 test `rendered-html` không chạy vì package sandbox không có `dist/server/index.js` (cần build trước), không phải regression source.
