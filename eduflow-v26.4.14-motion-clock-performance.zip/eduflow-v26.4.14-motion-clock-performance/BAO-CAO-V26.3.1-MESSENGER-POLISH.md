# EDUFLOW V26.3.1 — Messenger polish

- Bỏ subtitle “Nhắn trực tiếp · không chia theo môn học” ở popover tin nhắn giáo viên.
- Bỏ subtitle “Trao đổi trực tiếp · không chia theo môn học” ở popover tin nhắn học sinh.
- Nới khoảng cách giữa tên học sinh và mã HS để không còn cảm giác dính chữ.
- Đồng bộ line-height ở header và danh sách hội thoại.
- Không thay đổi API, dữ liệu D1, logic chat, streak, Pomodoro hay Web Push.
