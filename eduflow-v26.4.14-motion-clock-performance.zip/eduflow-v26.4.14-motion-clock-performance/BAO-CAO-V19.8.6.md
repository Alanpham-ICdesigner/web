# PHMT MATH v19.8.6 — Báo cáo nâng cấp

Base: `edumath-cloudflare-v19.8.5`

## A. Audit summary

### Website giáo viên

- Tổng quan: danh sách lớp, học sinh cần chú ý và hoạt động gần đây.
- Học sinh: bảng học sinh, bộ lọc và thao tác Admin.
- Lớp học: lưới lớp, bảng học sinh trong lớp, bảng điểm, lịch sử cộng/trừ điểm, nhận xét và timeline hoạt động.
- Điểm danh: danh sách học sinh, bốn trạng thái, lịch sử buổi, modal chi tiết và chế độ sửa buổi cũ.
- Bài tập: danh sách bài tập và modal danh sách bài nộp.
- Điểm số: bảng điểm có cuộn dọc/ngang và header cố định.
- Thi đua & Tích điểm: quy tắc, kho quà, điểm học sinh, yêu cầu đổi quà và modal chọn quy tắc.
- Thống kê: cảnh báo theo dữ liệu học sinh.
- Lịch học: lịch tháng và danh sách sự kiện đã tạo.
- Tài liệu: thư mục, tệp đã tải lên và trạng thái tải nhiều tệp.
- Thông báo/ghi chú/cài đặt: popover và các danh sách có khả năng tăng theo thời gian.

### Website học sinh

- Tổng quan: bài tập và thông báo dạng preview.
- Lịch & Bài tập: lịch tháng và chi tiết sự kiện/bài tập.
- Tài liệu học tập: filter thư mục, danh sách file và tải xuống.
- Điểm & chuyên cần: điểm kiểm tra và toàn bộ lịch sử điểm danh.
- Đổi quà: kho quà và toàn bộ lịch sử điểm/giao dịch.
- Thông báo: popover có cuộn, không cắt còn 8 thông báo.

## B. Component có nguy cơ overflow đã xử lý

1. Teacher student table.
2. Attendance roster.
3. Teacher attendance history.
4. Assignment grid.
5. Grade table.
6. Class grid và class roster.
7. Student grade/point tables trong hồ sơ lớp.
8. Student activity timeline.
9. Teacher comments history.
10. Point rules, reward inventory, student-points table và redemption table.
11. Analytics alerts.
12. Calendar event list.
13. Teacher uploaded files.
14. Student materials.
15. Student grade history.
16. Student attendance history.
17. Student rewards và point/redemption history.
18. Teacher/student notification popovers.

## C. File đã sửa/thêm

- `app/page.tsx`
- `app/student/page.tsx`
- `app/globals.css`
- `app/api/student/portal/route.ts`
- `app/api/notifications/route.ts`
- `app/api/rewards/admin/route.ts`
- `app/api/rewards/events/route.ts`
- `lib/attendance-rewards.mjs`
- `lib/attendance-rewards.d.mts`
- `tests/attendance-rewards-overflow.test.mjs`
- `package.json`
- `package-lock.json`

Không thay đổi database schema, migration, D1 binding, R2 architecture, route, font, logo, tên PHMT MATH hoặc permission tài liệu.

## D. Behavior danh sách dài

- Dữ liệu ít: container co theo nội dung, không tạo vùng trắng cố định.
- Laptop: mục dạng row hiển thị khoảng 6 dòng trước khi cuộn.
- Tablet: khoảng 5 dòng.
- Mobile: khoảng 4 dòng; các grid/card đặc thù dùng viewport phù hợp để tránh scroll trap.
- Không dùng `slice()` để giấu lịch sử điểm danh, giao dịch điểm, tài liệu hoặc thông báo trong popover.
- Table dài có vùng cuộn riêng; header quan trọng được giữ sticky.
- Scrollbar mảnh, dùng màu từ theme và hỗ trợ light/dark.
- Các vùng chính có thể focus bằng bàn phím, đồng thời hỗ trợ mouse wheel, trackpad và touch.

## E. Tài liệu

### Giáo viên

- Giữ layout list ngang hiện tại.
- Sort `createdAt DESC` (mới nhất trước).
- Khoảng 6 file trên laptop, 5 trên tablet, 4 trên mobile rồi cuộn dọc.
- Giữ icon, tên file, thư mục/lớp, dung lượng, ngày upload, download và delete.

### Học sinh

- Đổi từ card lớn 2 cột sang compact horizontal list.
- Hiển thị ngày upload thật từ `admin_items.created_at`.
- Sort timestamp mới nhất → cũ nhất, kể cả sau khi filter thư mục.
- Giữ quyền: chỉ tài liệu chung và tài liệu đúng lớp của học sinh.
- Tên file dài được ellipsis và có `title` để xem tên đầy đủ.
- Mobile tự xếp lại metadata, ngày và nút tải; không phát sinh scroll ngang.

## F. Tự động cộng/trừ điểm theo điểm danh

Các trạng thái được liên kết như sau:

| Điểm danh | Quy tắc tự động |
| --- | --- |
| Có mặt | Có mặt đúng giờ / Đi đúng giờ |
| Đi trễ | Đi trễ |
| Có phép | Vắng có phép |
| Không phép | Vắng không phép |

- Có thể chọn trigger rõ ràng khi tạo/sửa quy tắc.
- Quy tắc cũ đang để `manual` nhưng có tên tương ứng vẫn được nhận diện để không phải tạo lại.
- `Sau mỗi N lần` được tính theo số lần thực tế và chỉ áp dụng ở mốc N, 2N, 3N...
- Lưu cùng một buổi nhiều lần không cộng/trừ trùng.
- Sửa trạng thái sẽ gỡ giao dịch tự động không còn hợp lệ và thêm giao dịch đúng trạng thái mới.
- Sửa một buổi cũ sẽ đối soát lại các mốc phía sau, tránh điểm tích lũy sai.
- Xóa buổi điểm danh sẽ tự hoàn tác giao dịch điểm liên quan.
- Quy tắc điểm danh/bài tập không còn xuất hiện trong modal áp dụng thủ công, tránh giáo viên cộng/trừ lần hai.
- Không thêm migration hoặc bảng D1 mới; dùng `point_transactions.event_key` hiện có để bảo đảm idempotent.

## G. Regression và kiểm thử

- `npm run lint`: đạt, không có error; còn 4 warning cũ của project.
- `npm run build`: đạt; artifact Worker/hosting hợp lệ.
- `node --test tests/*.test.mjs`: 22/22 test đạt.
- Đã kiểm tra bằng test: đủ bốn trạng thái điểm danh, threshold, rebuild idempotent, sửa trạng thái cũ, quyền tài liệu, ngày upload, sort mới nhất trước và presence của các vùng cuộn.
- CSS responsive có breakpoint laptop/tablet/mobile, dùng biến theme hiện tại cho light/dark và giữ Be Vietnam Pro.
