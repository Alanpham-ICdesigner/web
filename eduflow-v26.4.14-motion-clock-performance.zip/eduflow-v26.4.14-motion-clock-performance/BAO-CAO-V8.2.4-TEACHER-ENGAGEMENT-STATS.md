# EDUFLOW V8.2.4 — Thống kê check-in streak & Pomodoro cho giáo viên

## Mục tiêu

Bổ sung một bảng thống kê hoạt động học sinh ngay trong tab **Thống kê & Phân tích** của web giáo viên. Phần này chỉ đọc dữ liệu gamification đã có từ V8.2.x; không thay đổi điểm học tập, điểm thi đua, chuyên cần buổi học, bài tập, lớp học hay dữ liệu R2.

## Recheck Astryx + TasteSkill

Trước khi chốt UI, phần mới được đối chiếu lại trực tiếp với source `astryx-main` và `taste-skill-main`:

- TasteSkill Redesign: sửa có mục tiêu trên stack hiện tại, không viết lại toàn trang; giữ chức năng cũ; có loading/empty/error/focus states; giữ light/dark token và responsive.
- Astryx table/filter: toolbar lọc nằm cùng vùng dữ liệu; header có sort state; sorting/filtering chạy local sau lần tải dữ liệu; bảng có vùng scroll riêng; giữ cột học sinh và header sticky; có `aria-sort` và nhãn điều khiển.
- Không thêm framework UI/dependency mới. Dùng React + Lucide + semantic token hiện có của `astryx-taste-deep.css`.
- Typography được cân lại theo chính hierarchy V8 đang dùng: header bảng khoảng 10px, row chính 11–12px, mô tả 10–11px; tránh chữ 7–8px ở các vùng cần đọc.

## Chức năng bảng mới

### Chu kỳ

- **Ngày**: xem check-in và tổng phút Pomodoro của ngày được chọn.
- **Tuần**: xem từ thứ Hai đến Chủ nhật của tuần được chọn.
- Với tuần hiện tại, khoảng thống kê chỉ tính **đến ngày hôm nay**, không xem các ngày tương lai là ngày bỏ lỡ.
- Có nút ngày/tuần trước, ngày/tuần sau, chọn ngày trực tiếp và **Hôm nay**.

### Lọc

- Tìm theo tên học sinh, mã học sinh hoặc tên lớp; tìm kiếm bỏ qua dấu tiếng Việt và chữ hoa/thường.
- Lọc theo lớp.
- Tất cả thao tác tìm kiếm/lọc/sắp xếp chạy phía client sau một lần tải dữ liệu của kỳ, không gọi D1 lại liên tục.

### Các cột có thể sắp xếp hai chiều

1. **Học sinh** — A→Z / Z→A.
2. **Lớp** — A→Z / Z→A.
3. **Điểm danh / Check-in tuần** — thấp→cao / cao→thấp.
4. **Streak hiện tại** — thấp→cao / cao→thấp; mặc định cao→thấp.
5. **Kỷ lục** — thấp→cao / cao→thấp.
6. **Tổng check-in** — thấp→cao / cao→thấp.
7. **Pomodoro ngày / Pomodoro tuần** — tổng phút thấp→cao / cao→thấp; hiển thị thêm số phiên hoàn tất.

### Tóm tắt nhanh

Bảng có một strip tóm tắt compact:

- số học sinh đã check-in trong kỳ;
- tổng lượt check-in;
- streak hiện tại cao nhất trong nhóm đang lọc;
- tổng phút Pomodoro trong kỳ.

## D1 / hiệu năng

API mới: `GET /api/admin/student-engagement?period=day|week&date=YYYY-MM-DD`.

- Chỉ Admin đã đăng nhập mới gọi được.
- Chỉ chạy khi giáo viên mở tab Thống kê có component này.
- Thay đổi search, class filter và sort không gọi lại API.
- Thêm 2 index date-first để giảm Rows Read cho truy vấn ngày/tuần:
  - `student_daily_checkins_date_student_idx (checkin_date, student_id)`
  - `student_focus_sessions_date_student_idx (date_key, student_id)`
- Migration `0008_teacher_engagement_stats_indexes.sql` là additive-only: không `DROP`, `DELETE`, `TRUNCATE`.
- `cap-nhat-cloudflare.ps1` kiểm tra hai index trên D1 trước khi deploy website mới; thiếu index thì dừng trước deploy.

## Responsive / accessibility

- Desktop: toolbar một hàng khi đủ chỗ; bảng compact, header/cột học sinh sticky.
- Tablet: toolbar tự reflow; summary chuyển 2×2.
- Mobile: filter xếp lại, vùng bảng cuộn ngang/dọc riêng, không kéo rộng toàn trang; touch target chính tăng kích thước.
- Có loading skeleton, empty state, error state + retry.
- `prefers-reduced-motion` tắt skeleton animation/chuyển động không cần thiết.
- Header sort dùng `aria-sort`; vùng bảng có nhãn và có thể focus bằng bàn phím.

## Kiểm tra

- **100/100 source/regression tests không cần build: PASS**.
- Bộ test riêng V8.2.4: **5/5 PASS**.
- SQL aggregation đã chạy trên SQLite mẫu: PASS; query plan xác nhận hai truy vấn ngày dùng đúng date-first indexes.
- TypeScript syntax audit: không có diagnostic TS1xxx; các lỗi còn lại trong lệnh `--noResolve` chỉ do checkout deploy-ready không kèm `node_modules`/types.
- `rendered-html.test.mjs` chưa thể chạy vì checkout hiện không có `dist/server/index.js`; file này cần production build trước.

## File thay đổi chức năng

- `app/admin/student-engagement-stats.tsx` — bảng/thanh lọc/sort.
- `app/api/admin/student-engagement/route.ts` — API thống kê Admin.
- `app/page.tsx` — mount bảng trong Analytics.
- `app/astryx-taste-deep.css` — presentation layer responsive theo Astryx × TasteSkill.
- `db/schema.ts` — khai báo 2 index mới.
- `drizzle/0008_teacher_engagement_stats_indexes.sql` — migration additive.
- `cap-nhat-cloudflare.ps1` — guard xác minh index trước deploy.
- `tests/v8.2.4-teacher-engagement-stats.test.mjs` — regression guard.
