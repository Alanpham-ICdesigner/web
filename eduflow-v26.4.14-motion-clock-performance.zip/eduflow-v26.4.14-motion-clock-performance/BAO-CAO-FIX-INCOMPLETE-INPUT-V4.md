# EDUFLOW V20 – V4 SQLFILE MIGRATION FIX

## Lỗi đã sửa

Cloudflare D1 báo `incomplete input: SQLITE_ERROR` trong bước chuẩn hóa `student_enrollments`.

Nguyên nhân là một batch SQL nhiều statement được truyền qua `wrangler d1 execute --command` trên Windows. Batch có thể bị cắt khi đi qua PowerShell/cmd shim của `wrangler.cmd`.

## Cách sửa

- Giữ nguyên dữ liệu D1/R2.
- Vẫn kiểm tra và bổ sung các cột LMS còn thiếu.
- Batch chuẩn hóa enrollment được ghi thành file UTF-8 tạm `.wrangler/repair-student-enrollments-v4.sql`.
- Chạy bằng `wrangler d1 execute ... --file <file>` thay vì `--command` nhiều dòng.
- Xóa file tạm sau khi chạy.
- Có marker `=== EDUFLOW V20 - V4 SQLFILE MIGRATION FIX ===` để tránh chạy nhầm bản cũ.

Không reset database và không xóa R2.
