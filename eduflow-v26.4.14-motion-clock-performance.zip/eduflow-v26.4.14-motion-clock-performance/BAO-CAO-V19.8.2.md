# EDUMATH CLOUDFLARE V19.8.2

## Chức năng mới

- Thêm trường **Câu giới thiệu trang đăng nhập** trong tab **Cài đặt** của giáo viên.
- Chỉ tài khoản Admin mới có thể sửa và lưu nội dung.
- Nội dung được lưu trong mục `settings/profile` hiện có và tự động hiển thị ở trang đăng nhập.
- Giới hạn 180 ký tự; nếu để trống, hệ thống dùng lại câu mặc định.
- Dấu ngoặc kép trang trí được giao diện thêm tự động.

## An toàn dữ liệu

- Không tạo migration D1 mới.
- Không thay đổi cấu trúc database, D1, R2 hoặc dữ liệu học sinh.
- Hồ sơ cũ chưa có trường mới vẫn hoạt động nhờ giá trị mặc định.

## Cách sử dụng

1. Đăng nhập bằng tài khoản Admin.
2. Mở **Cài đặt**.
3. Nhập nội dung tại **Câu giới thiệu trang đăng nhập**.
4. Bấm **Lưu cài đặt**, sau đó đăng xuất để xem câu mới.
