# EDUFLOW V20 V6 — Global Notification & Messaging

## Thay đổi

1. Nút **Thông báo** của học sinh luôn hiển thị trên header và đặt cạnh Dark Mode. Danh sách gom thông báo từ tất cả môn học mà tài khoản đang tham gia.
2. Loại bỏ tab **Thông báo** và khối “Thông báo gần nhất” bên trong từng môn học.
3. Thêm **Nhắn tin với giáo viên** trên header học sinh. Học sinh chọn môn học, xem đúng giáo viên phụ trách và gửi/nhận tin theo môn.
4. Thêm **Tin nhắn học sinh** trên header Admin. Giáo viên xem badge tin chưa đọc, chọn cuộc trò chuyện theo học sinh + môn và trả lời trực tiếp.
5. Tin nhắn được lưu trong `admin_items` với `kind = messages`; không tạo bảng mới, không thêm migration D1.
6. Giữ nguyên V4 repair migration và V5 schedule UI. Card môn học được bảo đảm hiển thị toàn bộ các slot lịch với giờ riêng.

## Kiểm thử

- TypeScript/TSX syntax transpile: PASS cho các file thay đổi.
- 46/46 test không phụ thuộc build artifact: PASS.
- Full build không chạy được trong môi trường đóng gói do registry npm không có DNS; script deploy trên máy người dùng vẫn thực hiện `npm ci`, build, test rồi deploy như trước.
