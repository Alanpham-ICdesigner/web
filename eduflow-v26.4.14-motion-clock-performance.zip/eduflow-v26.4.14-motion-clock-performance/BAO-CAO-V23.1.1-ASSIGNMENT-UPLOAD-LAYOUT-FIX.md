# EDUFLOW V23.1.1 — Assignment upload layout fix

## Root cause
V23.1 introduced a richer multi-file picker inside `.lms-file-field`, but an older rule in `redesign.css` still defines that container as a two-column grid (`38px + 1fr`). The new nested header became the first grid item, so the browser placed it inside the legacy 38px column while the empty-state/summary auto-flowed into adjacent cells. This produced one-word-per-line text and overlapping controls.

## Fix
- Add a modal-scoped final override in `astryx-taste-deep.css`.
- Force `.lms-file-field` to a single full-width content lane.
- Force every direct child to span the full grid width.
- Keep the inner header as icon + flexible copy + compact action on desktop.
- Explicitly collapse to icon + copy and a full-width action on <=640px.
- Preserve semantic color/motion tokens; no new dependency.

## Safety
No data schema, migration, API, R2, submission validation, scoring, student progress, streak, pet or Pomodoro logic is changed.
