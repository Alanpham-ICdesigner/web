# EDUFLOW V26.4.11 — Focus Space LifeAt Audio + Motion

## Mục tiêu
Nâng Focus Space theo hướng workspace tập trung kiểu LifeAt nhưng vẫn giữ giao diện EDUFLOW, Astryx + TasteSkill + Morphicons và không thay đổi logic LMS/Pomodoro/D1 hiện có.

## 1. Music mới: Âm thanh + Media

### Âm thanh tích hợp sẵn
Focus Space có mixer âm thanh chạy trực tiếp bằng Web Audio API trong trình duyệt, không gọi dịch vụ stream bên ngoài và không cần OAuth/API key.

Âm thanh có thể bật đồng thời và chỉnh âm lượng riêng:
- Mưa
- Brown noise
- Sóng biển
- Quán cà phê
- Lò sưởi
- Rừng

Preset:
- Deep Focus
- Rainy Café
- Ocean Calm
- Cozy Study

Có master volume và lưu cấu hình theo học sinh trên thiết bị.

### Media
Tab Media nhận link:
- Spotify track / album / playlist
- YouTube video / playlist hỗ trợ bởi embed

Spotify/YouTube vẫn phụ thuộc chính sách playback, đăng nhập và quảng cáo của dịch vụ tương ứng. Với nhu cầu học tập không quảng cáo, nên dùng tab Âm thanh tích hợp sẵn.

Khi đóng cửa sổ Music, panel biến mất ngay. Iframe media được giữ mounted để việc đóng cửa sổ không đồng nghĩa với dừng media đang phát.

## 2. Motion / kéo thả popup

Task, Music và Notes vẫn có thể mở cùng lúc và kéo độc lập.

Tối ưu theo nguyên tắc TasteSkill:
- Trong lúc pointer move, vị trí panel được cập nhật trực tiếp bằng `transform: translate3d(...)`.
- Không gọi React `setState` liên tục theo từng pixel kéo.
- Chỉ commit vị trí vào state/localStorage ở `pointerup`.
- Motion dùng transform/opacity và easing dạng spring-like.
- Có `prefers-reduced-motion` fallback.
- Title bar dùng `touch-action: none` để drag ổn định hơn trên PWA/mobile.

Điều này giảm re-render và giảm cảm giác giật khi kéo popup trên điện thoại.

## 3. Lưu trạng thái

Không có migration D1 mới.

Các preference mới dùng localStorage theo học sinh:
- `eduflow-focus-ambient` — mức âm lượng từng soundscape + master volume.
- `eduflow-focus-music-tab` — tab Âm thanh/Media gần nhất.
- `eduflow-focus-media` — provider và link media gần nhất.

Có đọc key Spotify cũ để giữ tương thích với bản trước.

## 4. Audio engine

File mới: `lib/focus-ambient-audio.ts`

Engine tự tổng hợp texture âm thanh bằng Web Audio API:
- white / pink / brown noise
- filter low-pass, high-pass, band-pass
- oscillator modulation cho sóng biển
- gain smoothing bằng `setTargetAtTime`

Không chứa URL audio và không fetch file âm thanh bên ngoài.

## 5. Kiểm thử

Focus Space regression suite:
- 23/23 PASS

Toàn bộ source tests:
- 255 tests được phát hiện
- 254 PASS
- 1 test build-dependent không chạy vì package sandbox không có `dist/server/index.js`: `tests/rendered-html.test.mjs`

Đây không phải lỗi regression của source V26.4.11.

Kiểm tra syntax riêng cho các file TypeScript/TSX thay đổi: PASS bằng TypeScript `transpileModule`.

Không xác nhận full `tsc --noEmit` hoặc production build vì bản sandbox hiện không có `node_modules`/build output đầy đủ.

## 6. Tham khảo thiết kế/kỹ thuật

- LifeAt: mô hình Focus Space có soundscape, media, task và notes.
- TasteSkill: motion có mục đích, ưu tiên transform/opacity, tránh state update liên tục cho pointer physics, hỗ trợ reduced motion.
- Astryx: floating/popover surface, viewport fitting và safe-area behavior.
- Morphicons: icon system cho controls.
- Noisekun / Noisebox: tham khảo mô hình mixer ambient và procedural Web Audio; không clone UI.

## Trạng thái phát hành

- Source đã đóng gói sẵn sàng để người dùng kiểm tra/deploy theo workflow Cloudflare hiện có.
- CHƯA deploy Cloudflare.
