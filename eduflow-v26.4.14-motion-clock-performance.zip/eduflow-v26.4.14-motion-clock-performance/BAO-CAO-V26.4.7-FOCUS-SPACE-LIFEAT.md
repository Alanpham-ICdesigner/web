# EDUFLOW V26.4.7 — Focus Space LifeAt-style workspace

## UI
Focus Space is now timer-first. The timer remains the central surface while personal utilities live in a compact bottom dock: Task, Music, Notes. Each utility opens as an independent floating panel that can be dragged and snapped between the left and right sides. The header keeps only the `FOCUS SPACE` brand and icon-only utility controls for Digital, Flip, Fullscreen, mobile landscape and Close.

## Fullscreen / PWA fix
`FocusStudio` is mounted through `createPortal(..., document.body)`, preventing the parent Pomodoro card and responsive dashboard containers from becoming the visual containing block. Native fullscreen targets the Focus Space element itself. iOS/PWA contexts without the standard Fullscreen API retain a true viewport-sized portal overlay. Desktop landscape no longer automatically sets the manual mobile fallback.

## Flip clock
The split-flap transition has been increased to approximately 820 ms and uses a stronger perspective motion so second changes remain visible without delaying the timer state.

## Music
There is no separate “Tắt nhạc” action. Closing the Music popup only hides the window; its Spotify iframe stays mounted so the popup lifecycle is not treated as a stop control.

## Notes
A minimal Notes popup was added to the same movable-window system. Notes are stored under a per-student local-storage key. This version does not add a new D1 table for notes.

## Regression checks
- Existing D1-backed personal tasks remain unchanged.
- Pomodoro server-authoritative timer and statistics are unchanged.
- Morphicons remain the main icon/motion layer for Focus Space controls.
- Source tests for V26.4.6 and V26.4.7: 11/11 passed.
- Full source-only suite: 236 tests passed; the single `rendered-html` test requires the generated `dist/server/index.js` and therefore cannot run before a local build.
