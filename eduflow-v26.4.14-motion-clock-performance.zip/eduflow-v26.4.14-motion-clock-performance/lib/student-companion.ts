export const PETDEX_PUNCH_SLUG = "punch";
export const VIETNAM_TIME_ZONE = "Asia/Ho_Chi_Minh";
export const FREEZE_COOLDOWN_DAYS = 30;

export function vietnamDateKey(date = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: VIETNAM_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const values: Record<string, string> = {};
  parts.forEach(function(part) { values[part.type] = part.value; });
  return values.year + "-" + values.month + "-" + values.day;
}

export function shiftDateKey(dateKey: string, days: number): string {
  const parts = dateKey.split("-").map(Number);
  if (parts.length !== 3 || parts.some(function(value) { return !Number.isFinite(value); })) return dateKey;
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + days));
  return date.toISOString().slice(0, 10);
}

export function dateKeyDiffDays(fromDateKey: string, toDateKey: string): number {
  const from = fromDateKey.split("-").map(Number);
  const to = toDateKey.split("-").map(Number);
  if (from.length !== 3 || to.length !== 3 || from.some(function(value) { return !Number.isFinite(value); }) || to.some(function(value) { return !Number.isFinite(value); })) return 0;
  const fromMs = Date.UTC(from[0], from[1] - 1, from[2]);
  const toMs = Date.UTC(to[0], to[1] - 1, to[2]);
  return Math.round((toMs - fromMs) / 86_400_000);
}

export function freezeCooldownState(lastUsedDate: string, today: string) {
  const normalized = /^\d{4}-\d{2}-\d{2}$/.test(lastUsedDate) ? lastUsedDate : "";
  if (!normalized) {
    return { available: true, daysRemaining: 0, nextAvailableDate: "" };
  }
  const nextAvailableDate = shiftDateKey(normalized, FREEZE_COOLDOWN_DAYS);
  const daysRemaining = Math.max(0, dateKeyDiffDays(today, nextAvailableDate));
  return {
    available: daysRemaining === 0,
    daysRemaining,
    nextAvailableDate,
  };
}

export function missedCheckinDays(lastCheckinDate: string, today: string): number {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(lastCheckinDate)) return 0;
  return Math.max(0, dateKeyDiffDays(lastCheckinDate, today) - 1);
}

export function mondayDateKey(dateKey: string): string {
  const parts = dateKey.split("-").map(Number);
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
  const day = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() - day + 1);
  return date.toISOString().slice(0, 10);
}

export function nextTenDayMilestone(streak: number): number {
  const safe = Math.max(0, Math.floor(Number(streak) || 0));
  return (Math.floor(safe / 10) + 1) * 10;
}

export function clampFocusMinutes(value: unknown): number {
  const parsed = Math.round(Number(value));
  if (!Number.isFinite(parsed)) return 25;
  return Math.min(180, Math.max(5, parsed));
}
