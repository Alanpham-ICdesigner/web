import { eq } from "drizzle-orm";
import { getDb } from "../db";
import { appState } from "../db/schema";
import { verifyStudentPin } from "./student-auth";

const COOKIE_NAME = "eduflow_admin";
const TOKEN_PAYLOAD = "eduflow-admin-session-v1";
const ADMIN_PIN_KEY = "admin_pin_credential";

async function runtimeValue(key: string): Promise<string> {
  const { env } = await import("cloudflare:workers");
  const values = env as unknown as Record<string, string | undefined>;
  return values[key] || "";
}

async function sign(value: string): Promise<string> {
  const secret = await runtimeValue("ADMIN_SESSION_SECRET");
  if (!secret) return "";
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  return Array.from(new Uint8Array(signature)).map(function(byte) {
    return byte.toString(16).padStart(2, "0");
  }).join("");
}

function cookieValue(request: Request): string {
  const cookie = request.headers.get("cookie") || "";
  const found = cookie.split(";").map(function(part) { return part.trim(); }).find(function(part) {
    return part.startsWith(COOKIE_NAME + "=");
  });
  return found ? found.slice(COOKIE_NAME.length + 1) : "";
}

export async function isAdmin(request: Request): Promise<boolean> {
  const actual = cookieValue(request);
  const expected = await sign(TOKEN_PAYLOAD);
  return Boolean(actual && expected && actual === expected);
}

export async function validPin(pin: string): Promise<boolean> {
  if (!pin) return false;
  try {
    const rows = await (await getDb()).select({ value: appState.value }).from(appState).where(eq(appState.key, ADMIN_PIN_KEY)).limit(1);
    if (rows.length) {
      const credential = JSON.parse(rows[0].value) as { hash?: string; salt?: string };
      if (credential.hash && credential.salt) return verifyStudentPin(pin, credential.hash, credential.salt);
    }
  } catch {}
  const expected = await runtimeValue("ADMIN_PIN");
  return Boolean(expected && pin && expected === pin);
}

export async function sessionCookie(): Promise<string> {
  const token = await sign(TOKEN_PAYLOAD);
  return COOKIE_NAME + "=" + token + "; Path=/; HttpOnly; Secure; SameSite=Strict";
}

export function clearSessionCookie(): string {
  return COOKIE_NAME + "=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0";
}

export async function requireAdmin(request: Request): Promise<Response | null> {
  if (await isAdmin(request)) return null;
  return Response.json({ error: "Bạn cần đăng nhập Admin để thực hiện thao tác này." }, { status: 401 });
}
