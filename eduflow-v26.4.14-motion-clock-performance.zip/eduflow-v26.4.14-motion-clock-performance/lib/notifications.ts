import { getDb } from "../db";
import { adminItems } from "../db/schema";

export type AutomaticNotification = {
  audience: "admin" | "all_students" | "student";
  title: string;
  body: string;
  studentId?: number;
  className?: string;
  actionView?: string;
  category?: string;
};

export function decodeNotification(value: string): Record<string, unknown> {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

export async function createAutomaticNotification(input: AutomaticNotification) {
  const now = new Date().toISOString();
  const key = "auto-" + now.replace(/[^0-9]/g, "") + "-" + crypto.randomUUID();
  const db = await getDb();
  await db.insert(adminItems).values({
    kind: "notifications",
    itemKey: key,
    title: input.title,
    data: JSON.stringify({
      body: input.body,
      audience: input.audience,
      studentId: input.studentId,
      className: input.className,
      actionView: input.actionView || "dashboard",
      category: input.category || "system",
      automatic: true,
      adminReadAt: null,
      studentReadAt: null,
      readByStudentIds: []
    }),
    createdAt: now,
    updatedAt: now
  });
}

export async function createPointNotification(studentId: number, delta: number, reason: string) {
  await createAutomaticNotification({
    audience: "student",
    studentId,
    title: delta > 0 ? "Bạn được cộng " + delta + " điểm" : "Bạn bị trừ " + Math.abs(delta) + " điểm",
    body: reason,
    actionView: "rewards",
    category: "points"
  });
}
