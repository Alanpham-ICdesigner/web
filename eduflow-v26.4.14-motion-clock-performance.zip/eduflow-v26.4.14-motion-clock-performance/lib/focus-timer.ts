import { clampFocusMinutes, vietnamDateKey } from "./student-companion";

export type FocusTimerMode = "focus" | "break";
export type FocusTimerStatus = "idle" | "running" | "paused";

export type FocusTimerRow = {
  student_id: number;
  mode: FocusTimerMode;
  status: FocusTimerStatus;
  focus_minutes: number;
  break_minutes: number;
  remaining_ms: number;
  duration_ms: number;
  ends_at: string;
  session_key: string;
  session_id: string;
  started_at: string;
  revision: number;
  created_at: string;
  updated_at: string;
};

export type FocusTimerView = {
  mode: FocusTimerMode;
  status: FocusTimerStatus;
  running: boolean;
  focusMinutes: number;
  breakMinutes: number;
  remainingMs: number;
  duration: number;
  endsAt: string;
  sessionKey: string;
  sessionId: string;
  userId: number;
  startedAt: string;
  revision: number;
  updatedAt: string;
};

export type FocusTimerMutation = {
  action: "configure" | "start" | "start-break" | "pause" | "resume-break" | "stop" | "skip-break";
  revision: number;
  focusMinutes?: unknown;
  breakMinutes?: unknown;
};

export class FocusTimerConflictError extends Error {
  timer: FocusTimerView;
  constructor(message: string, timer: FocusTimerView) {
    super(message);
    this.name = "FocusTimerConflictError";
    this.timer = timer;
  }
}

const DEFAULT_FOCUS_MINUTES = 25;
const DEFAULT_BREAK_MINUTES = 5;
const MAX_BREAK_MINUTES = 60;
const MIN_BREAK_MINUTES = 1;

function clampBreakMinutes(value: unknown): number {
  const parsed = Math.round(Number(value));
  if (!Number.isFinite(parsed)) return DEFAULT_BREAK_MINUTES;
  return Math.min(MAX_BREAK_MINUTES, Math.max(MIN_BREAK_MINUTES, parsed));
}

function timerDurationMs(row: FocusTimerRow): number {
  return (row.mode === "focus" ? row.focus_minutes : row.break_minutes) * 60_000;
}

function safeRemainingMs(row: FocusTimerRow, now: Date): number {
  const maximum = timerDurationMs(row);
  if (row.status === "running" && row.ends_at) {
    const endMs = Date.parse(row.ends_at);
    if (Number.isFinite(endMs)) return Math.min(maximum, Math.max(0, endMs - now.getTime()));
  }
  const stored = Number(row.remaining_ms);
  return Math.min(maximum, Math.max(0, Number.isFinite(stored) ? stored : maximum));
}

function rowToView(row: FocusTimerRow, now: Date): FocusTimerView {
  return {
    mode: row.mode === "break" ? "break" : "focus",
    status: row.status === "running" || row.status === "paused" ? row.status : "idle",
    running: row.status === "running",
    focusMinutes: clampFocusMinutes(row.focus_minutes),
    breakMinutes: clampBreakMinutes(row.break_minutes),
    remainingMs: safeRemainingMs(row, now),
    duration: Math.max(1000, Number(row.duration_ms) || timerDurationMs(row)),
    endsAt: row.status === "running" ? String(row.ends_at || "") : "",
    sessionKey: String(row.session_key || ""),
    sessionId: String(row.session_id || row.session_key || ""),
    userId: Number(row.student_id),
    startedAt: String(row.started_at || ""),
    revision: Math.max(0, Number(row.revision) || 0),
    updatedAt: String(row.updated_at || ""),
  };
}

function newSessionKey(): string {
  return "focus_" + crypto.randomUUID().replace(/-/g, "");
}

function focusSessionDateKey(startedAt: string, completedAt: Date): string {
  // Attribute a completed Focus session to the day on which the student started it.
  // This keeps an overnight/laptop-sleep reconciliation from moving the session into
  // the next day's statistics merely because no browser was awake at the boundary.
  const started = new Date(String(startedAt || ""));
  return vietnamDateKey(Number.isNaN(started.getTime()) ? completedAt : started);
}

async function readTimerRow(db: D1Database, studentId: number): Promise<FocusTimerRow> {
  const row = await db.prepare(`
    SELECT student_id, mode, status, focus_minutes, break_minutes, remaining_ms, duration_ms,
           ends_at, session_key, session_id, started_at, revision, created_at, updated_at
    FROM student_focus_timer_state
    WHERE student_id = ?
    LIMIT 1
  `).bind(studentId).first() as FocusTimerRow | null;
  if (!row) throw new Error("Không thể khởi tạo trạng thái Pomodoro.");
  return row;
}

async function ensureTimerRow(db: D1Database, studentId: number, now: Date): Promise<FocusTimerRow> {
  const existing = await db.prepare(`
    SELECT student_id, mode, status, focus_minutes, break_minutes, remaining_ms, duration_ms,
           ends_at, session_key, session_id, started_at, revision, created_at, updated_at
    FROM student_focus_timer_state
    WHERE student_id = ?
    LIMIT 1
  `).bind(studentId).first() as FocusTimerRow | null;
  if (existing) return existing;

  const nowIso = now.toISOString();
  await db.prepare(`
    INSERT OR IGNORE INTO student_focus_timer_state
      (student_id, mode, status, focus_minutes, break_minutes, remaining_ms, duration_ms,
       ends_at, session_key, session_id, started_at, revision, created_at, updated_at)
    VALUES (?, 'focus', 'idle', ?, ?, ?, ?, '', '', '', '', 0, ?, ?)
  `).bind(studentId, DEFAULT_FOCUS_MINUTES, DEFAULT_BREAK_MINUTES, DEFAULT_FOCUS_MINUTES * 60_000, DEFAULT_FOCUS_MINUTES * 60_000, nowIso, nowIso).run();
  return readTimerRow(db, studentId);
}

async function completeLinkedFocusTask(db: D1Database, studentId: number, sessionKey: string, completedAt: string): Promise<void> {
  if (!sessionKey) return;
  const claim = await db.prepare(`
    UPDATE student_focus_task_sessions
    SET completed_at = ?, updated_at = ?
    WHERE student_id = ? AND session_key = ? AND completed_at = ''
  `).bind(completedAt, completedAt, studentId, sessionKey).run();
  if (!claim.meta?.changes) return;
  await db.prepare(`
    UPDATE student_focus_tasks
    SET completed_pomodoros = completed_pomodoros + 1, updated_at = ?
    WHERE student_id = ? AND id = (
      SELECT task_id
      FROM student_focus_task_sessions
      WHERE student_id = ? AND session_key = ?
      LIMIT 1
    )
  `).bind(completedAt, studentId, studentId, sessionKey).run();
}

async function advanceExpiredTimer(db: D1Database, row: FocusTimerRow, now: Date): Promise<void> {
  if (row.status !== "running" || !row.ends_at) return;
  const endMs = Date.parse(row.ends_at);
  if (!Number.isFinite(endMs) || endMs > now.getTime()) return;

  const nowIso = now.toISOString();
  if (row.mode === "focus") {
    const advance = db.prepare(`
      UPDATE student_focus_timer_state
      SET mode = 'break', status = 'paused', remaining_ms = break_minutes * 60000, duration_ms = break_minutes * 60000,
          ends_at = '', session_key = '', started_at = '', session_id = '', revision = revision + 1, updated_at = ?
      WHERE student_id = ? AND revision = ? AND mode = 'focus' AND status = 'running' AND ends_at = ?
    `).bind(nowIso, row.student_id, row.revision, row.ends_at);
    if (row.session_key && row.started_at) {
      const completedAt = new Date(endMs);
      const record = db.prepare(`
        INSERT OR IGNORE INTO student_focus_sessions
          (student_id, session_key, focus_minutes, started_at, completed_at, date_key)
        VALUES (?, ?, ?, ?, ?, ?)
      `).bind(row.student_id, row.session_key, clampFocusMinutes(row.focus_minutes), row.started_at, completedAt.toISOString(), focusSessionDateKey(row.started_at, completedAt));
      await db.batch([record, advance]);
      await completeLinkedFocusTask(db, row.student_id, row.session_key, completedAt.toISOString());
    } else {
      await advance.run();
    }
    return;
  }

  await db.prepare(`
    UPDATE student_focus_timer_state
    SET mode = 'focus', status = 'idle', remaining_ms = focus_minutes * 60000, duration_ms = focus_minutes * 60000,
        ends_at = '', session_key = '', started_at = '', session_id = '', revision = revision + 1, updated_at = ?
    WHERE student_id = ? AND revision = ? AND mode = 'break' AND status = 'running' AND ends_at = ?
  `).bind(nowIso, row.student_id, row.revision, row.ends_at).run();
}

export async function getFocusTimer(db: D1Database, studentId: number, now = new Date()): Promise<FocusTimerView> {
  let row = await ensureTimerRow(db, studentId, now);
  if (row.status === "running" && row.ends_at && Date.parse(row.ends_at) <= now.getTime()) {
    await advanceExpiredTimer(db, row, now);
    row = await readTimerRow(db, studentId);
  }
  return rowToView(row, now);
}

async function updateWithRevision(
  db: D1Database,
  studentId: number,
  expectedRevision: number,
  sql: string,
  bindings: Array<string | number>,
  now: Date,
): Promise<FocusTimerView> {
  const result = await db.prepare(sql).bind(...bindings, studentId, expectedRevision).run();
  if (!result.meta?.changes) {
    const timer = await getFocusTimer(db, studentId, now);
    throw new FocusTimerConflictError("Pomodoro đã thay đổi trên thiết bị khác. Dữ liệu mới nhất đã được đồng bộ.", timer);
  }
  return getFocusTimer(db, studentId, now);
}

export async function mutateFocusTimer(
  db: D1Database,
  studentId: number,
  mutation: FocusTimerMutation,
  now = new Date(),
): Promise<FocusTimerView> {
  const current = await getFocusTimer(db, studentId, now);
  const expectedRevision = Math.max(0, Math.floor(Number(mutation.revision) || 0));
  if (expectedRevision !== current.revision) {
    throw new FocusTimerConflictError("Pomodoro đã thay đổi trên thiết bị khác. Dữ liệu mới nhất đã được đồng bộ.", current);
  }

  const nowIso = now.toISOString();
  if (mutation.action === "configure") {
    if (current.status !== "idle" || current.mode !== "focus") {
      throw new FocusTimerConflictError("Không thể đổi thời lượng khi đang có phiên Pomodoro.", current);
    }
    const focusMinutes = clampFocusMinutes(mutation.focusMinutes);
    const breakMinutes = clampBreakMinutes(mutation.breakMinutes);
    return updateWithRevision(db, studentId, expectedRevision, `
      UPDATE student_focus_timer_state
      SET focus_minutes = ?, break_minutes = ?, remaining_ms = ?, duration_ms = ?,
          ends_at = '', session_key = '', started_at = '', session_id = '', revision = revision + 1, updated_at = ?
      WHERE student_id = ? AND revision = ?
    `, [focusMinutes, breakMinutes, focusMinutes * 60_000, focusMinutes * 60_000, nowIso], now);
  }

  if (mutation.action === "start-break") {
    if (current.mode !== "focus" || current.status !== "idle") {
      throw new FocusTimerConflictError("Chỉ có thể chuyển sang giờ nghỉ khi Pomodoro đang ở trạng thái sẵn sàng.", current);
    }
    const remainingMs = current.breakMinutes * 60_000;
    return updateWithRevision(db, studentId, expectedRevision, `
      UPDATE student_focus_timer_state
      SET mode = 'break', status = 'paused', remaining_ms = ?, duration_ms = ?, ends_at = '',
          session_key = '', started_at = '', session_id = '', revision = revision + 1, updated_at = ?
      WHERE student_id = ? AND revision = ?
    `, [remainingMs, remainingMs, nowIso], now);
  }

  if (mutation.action === "start") {
    if (current.mode !== "focus") throw new FocusTimerConflictError("Hãy kết thúc hoặc bỏ qua giờ nghỉ trước khi bắt đầu Focus.", current);
    if (current.status === "running") return current;
    const continuing = current.status === "paused" && Boolean(current.sessionKey && current.startedAt);
    const remainingMs = continuing ? Math.max(1000, current.remainingMs) : current.focusMinutes * 60_000;
    const plannedDurationMs = continuing ? Math.max(1000, current.duration) : current.focusMinutes * 60_000;
    const endAt = new Date(now.getTime() + remainingMs).toISOString();
    const sessionKey = continuing ? current.sessionKey : newSessionKey();
    const startedAt = continuing ? current.startedAt : nowIso;
    return updateWithRevision(db, studentId, expectedRevision, `
      UPDATE student_focus_timer_state
      SET mode = 'focus', status = 'running', remaining_ms = ?, duration_ms = ?, ends_at = ?,
          session_key = ?, session_id = ?, started_at = ?, revision = revision + 1, updated_at = ?
      WHERE student_id = ? AND revision = ?
    `, [remainingMs, plannedDurationMs, endAt, sessionKey, sessionKey, startedAt, nowIso], now);
  }

  if (mutation.action === "pause") {
    if (current.status !== "running") return current;
    const remainingMs = Math.max(0, current.remainingMs);
    if (remainingMs <= 0) return getFocusTimer(db, studentId, now);
    return updateWithRevision(db, studentId, expectedRevision, `
      UPDATE student_focus_timer_state
      SET status = 'paused', remaining_ms = ?, ends_at = '', revision = revision + 1, updated_at = ?
      WHERE student_id = ? AND revision = ?
    `, [remainingMs, nowIso], now);
  }

  if (mutation.action === "resume-break") {
    if (current.mode !== "break" || current.status !== "paused") {
      throw new FocusTimerConflictError("Giờ nghỉ hiện không ở trạng thái chờ tiếp tục.", current);
    }
    const remainingMs = Math.max(1000, current.remainingMs || current.breakMinutes * 60_000);
    const plannedDurationMs = Math.max(1000, current.duration || current.breakMinutes * 60_000);
    const endAt = new Date(now.getTime() + remainingMs).toISOString();
    return updateWithRevision(db, studentId, expectedRevision, `
      UPDATE student_focus_timer_state
      SET status = 'running', remaining_ms = ?, duration_ms = ?, ends_at = ?, revision = revision + 1, updated_at = ?
      WHERE student_id = ? AND revision = ?
    `, [remainingMs, plannedDurationMs, endAt, nowIso], now);
  }

  if (mutation.action === "skip-break") {
    if (current.mode !== "break") throw new FocusTimerConflictError("Hiện không có giờ nghỉ để bỏ qua.", current);
    return updateWithRevision(db, studentId, expectedRevision, `
      UPDATE student_focus_timer_state
      SET mode = 'focus', status = 'idle', remaining_ms = focus_minutes * 60000, duration_ms = focus_minutes * 60000,
          ends_at = '', session_key = '', started_at = '', session_id = '', revision = revision + 1, updated_at = ?
      WHERE student_id = ? AND revision = ?
    `, [nowIso], now);
  }

  return updateWithRevision(db, studentId, expectedRevision, `
    UPDATE student_focus_timer_state
    SET mode = 'focus', status = 'idle', remaining_ms = focus_minutes * 60000, duration_ms = focus_minutes * 60000,
        ends_at = '', session_key = '', started_at = '', session_id = '', revision = revision + 1, updated_at = ?
    WHERE student_id = ? AND revision = ?
  `, [nowIso], now);
}

export async function reconcileAllExpiredFocusTimers(db: D1Database, now = new Date()): Promise<number> {
  const result = await db.prepare(`
    SELECT student_id, mode, status, focus_minutes, break_minutes, remaining_ms, duration_ms,
           ends_at, session_key, session_id, started_at, revision, created_at, updated_at
    FROM student_focus_timer_state
    WHERE status = 'running' AND ends_at <> '' AND ends_at <= ?
    ORDER BY ends_at, student_id
  `).bind(now.toISOString()).all() as { results?: FocusTimerRow[] };

  let reconciled = 0;
  for (const row of result.results || []) {
    await advanceExpiredTimer(db, row, now);
    reconciled += 1;
  }
  return reconciled;
}
