import { freezeCooldownState, shiftDateKey, vietnamDateKey } from "./student-companion";

type ProfileRow = {
  student_id: number;
  current_streak: number;
  last_checkin_date: string;
  freeze_last_used_date: string;
};

export type FreezeReconcileResult = {
  usedFreeze: boolean;
  protectedDate: string;
  streakReset: boolean;
};

export async function hasFreezeProtection(db: D1Database, studentId: number, dateKey: string): Promise<boolean> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return false;
  const row = await db.prepare(`
    SELECT 1 AS ok
    FROM student_daily_checkins
    WHERE student_id = ? AND checkin_date = ? AND used_freeze = 1
    LIMIT 1
  `).bind(studentId, dateKey).first() as { ok?: number } | null;
  return Boolean(row?.ok);
}

/**
 * Reconcile yesterday before today's UI/reminders run.
 * A Freeze protects exactly one missed day and starts its 30-day cooldown from
 * the date it protected. It never increments total check-ins or the streak; it
 * only keeps the existing streak alive so today's real check-in can continue it.
 */
export async function reconcileAutomaticStreakFreeze(
  db: D1Database,
  studentId: number,
  now = new Date(),
): Promise<FreezeReconcileResult> {
  const today = vietnamDateKey(now);
  const yesterday = shiftDateKey(today, -1);
  const twoDaysAgo = shiftDateKey(today, -2);
  const profile = await db.prepare(`
    SELECT student_id, current_streak, last_checkin_date, freeze_last_used_date
    FROM student_pet_profiles
    WHERE student_id = ?
    LIMIT 1
  `).bind(studentId).first() as ProfileRow | null;

  if (!profile) return { usedFreeze: false, protectedDate: "", streakReset: false };
  const lastCheckin = String(profile.last_checkin_date || "");

  if (!lastCheckin || lastCheckin === today || lastCheckin === yesterday) {
    return { usedFreeze: false, protectedDate: "", streakReset: false };
  }

  if (await hasFreezeProtection(db, studentId, yesterday)) {
    return { usedFreeze: false, protectedDate: yesterday, streakReset: false };
  }

  // Exactly one missed calendar day: automatically consume Freeze if ready.
  if (lastCheckin === twoDaysAgo) {
    const freeze = freezeCooldownState(String(profile.freeze_last_used_date || ""), yesterday);
    if (freeze.available) {
      const nowIso = now.toISOString();
      const inserted = await db.prepare(`
        INSERT OR IGNORE INTO student_daily_checkins
          (student_id, checkin_date, checked_at, used_freeze)
        VALUES (?, ?, ?, 1)
      `).bind(studentId, yesterday, nowIso).run();
      if (inserted.meta?.changes) {
        await db.prepare(`
          UPDATE student_pet_profiles
          SET freeze_last_used_date = ?, freeze_used_month = ?, updated_at = ?
          WHERE student_id = ?
        `).bind(yesterday, yesterday.slice(0, 7), nowIso, studentId).run();
        return { usedFreeze: true, protectedDate: yesterday, streakReset: false };
      }
      return { usedFreeze: false, protectedDate: yesterday, streakReset: false };
    }
  }

  // More than one missed day, or Freeze unavailable: the old streak is no longer live.
  if (Number(profile.current_streak || 0) > 0) {
    await db.prepare(`
      UPDATE student_pet_profiles
      SET current_streak = 0, updated_at = ?
      WHERE student_id = ?
    `).bind(now.toISOString(), studentId).run();
    return { usedFreeze: false, protectedDate: "", streakReset: true };
  }
  return { usedFreeze: false, protectedDate: "", streakReset: false };
}

export async function reconcileAllAutomaticStreakFreezes(
  db: D1Database,
  now = new Date(),
): Promise<{ checked: number; used: number; reset: number }> {
  const rows = await db.prepare(`SELECT student_id FROM student_pet_profiles ORDER BY student_id`).all() as { results?: Array<{ student_id: number }> };
  let used = 0;
  let reset = 0;
  for (const row of rows.results || []) {
    const studentId = Number(row.student_id);
    if (!studentId) continue;
    const result = await reconcileAutomaticStreakFreeze(db, studentId, now);
    if (result.usedFreeze) used += 1;
    if (result.streakReset) reset += 1;
  }
  return { checked: (rows.results || []).length, used, reset };
}
