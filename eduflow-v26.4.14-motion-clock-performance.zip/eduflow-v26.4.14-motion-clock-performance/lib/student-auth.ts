const COOKIE_NAME = "eduflow_student";
const PIN_ITERATIONS = 100_000;
export const STUDENT_SESSION_MAX_AGE_SECONDS = 30 * 24 * 60 * 60;

async function runtimeSecret(): Promise<string> {
  const { env } = await import("cloudflare:workers");
  return String((env as unknown as Record<string, unknown>).ADMIN_SESSION_SECRET || "");
}

function toHex(bytes: ArrayBuffer | Uint8Array): string {
  const values = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  return Array.from(values).map(function(byte) { return byte.toString(16).padStart(2, "0"); }).join("");
}

function fromHex(value: string): Uint8Array {
  const pairs = value.match(/.{1,2}/g) || [];
  return new Uint8Array(pairs.map(function(pair) { return Number.parseInt(pair, 16); }));
}

async function hmac(value: string): Promise<string> {
  const secret = await runtimeSecret();
  if (!secret) return "";
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return toHex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}

function cookieValue(request: Request): string {
  const cookie = request.headers.get("cookie") || "";
  const found = cookie.split(";").map(function(part) { return part.trim(); }).find(function(part) { return part.startsWith(COOKIE_NAME + "="); });
  return found ? decodeURIComponent(found.slice(COOKIE_NAME.length + 1)) : "";
}

export async function hashStudentPin(pin: string, saltHex?: string): Promise<{ hash: string; salt: string }> {
  const salt = saltHex ? fromHex(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt as BufferSource, iterations: PIN_ITERATIONS }, material, 256);
  return { hash: toHex(bits), salt: toHex(salt) };
}

export async function verifyStudentPin(pin: string, expectedHash: string, salt: string): Promise<boolean> {
  const actual = (await hashStudentPin(pin, salt)).hash;
  if (actual.length !== expectedHash.length) return false;
  let difference = 0;
  for (let index = 0; index < actual.length; index += 1) difference |= actual.charCodeAt(index) ^ expectedHash.charCodeAt(index);
  return difference === 0;
}

export async function studentSessionCookie(studentId: number): Promise<string> {
  const expires = Date.now() + STUDENT_SESSION_MAX_AGE_SECONDS * 1000;
  const payload = studentId + "." + expires;
  const token = payload + "." + await hmac(payload);
  const cookieExpires = new Date(expires).toUTCString();
  return COOKIE_NAME + "=" + encodeURIComponent(token) + "; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=" + STUDENT_SESSION_MAX_AGE_SECONDS + "; Expires=" + cookieExpires + "; Priority=High";
}

export function clearStudentSessionCookie(): string {
  return COOKIE_NAME + "=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Priority=High";
}

export async function getStudentSessionId(request: Request): Promise<number | null> {
  const parts = cookieValue(request).split(".");
  if (parts.length !== 3) return null;
  const studentId = Number(parts[0]);
  const expires = Number(parts[1]);
  if (!studentId || !expires || expires < Date.now()) return null;
  const payload = parts[0] + "." + parts[1];
  const expected = await hmac(payload);
  if (!expected || expected.length !== parts[2].length) return null;
  let difference = 0;
  for (let index = 0; index < expected.length; index += 1) difference |= expected.charCodeAt(index) ^ parts[2].charCodeAt(index);
  return difference === 0 ? studentId : null;
}
