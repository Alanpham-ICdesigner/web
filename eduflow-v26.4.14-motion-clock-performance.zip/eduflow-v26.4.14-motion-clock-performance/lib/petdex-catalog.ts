import { PETDEX_PUNCH_SLUG } from "./student-companion";

export type PetdexCatalogPet = {
  slug: string;
  displayName: string;
  spritesheetUrl: string;
  thumbnailUrl: string;
  previewUrl: string;
  petJsonUrl: string;
  sourceUrl: string;
  tags: string[];
  kind: string;
  version: string;
  gridRows: number;
  available: boolean;
};

export type PetdexCatalogSnapshot = {
  pets: PetdexCatalogPet[];
  warning: string;
};

// Petdex upstream source (petdex-main/src/app/api/manifest/v2/route.ts)
// exposes the compact v2 manifest. The entries are arrays and asset paths are
// relative to `assetBase`, so they must be resolved against that base exactly
// like packages/petdex-cli/src/manifest.ts does.
const MANIFEST_V2_URL = "https://petdex.dev/api/manifest/v2";
const MANIFEST_LEGACY_URL = "https://petdex.dev/api/manifest";
const CANONICAL_ASSET_HOST = "assets.petdex.dev";
const LEGACY_ASSET_HOSTS = new Set([
  "petdex-assets.raillyhugo.workers.dev",
  "pub-94495283df974cfea5e98d6a9e3fa462.r2.dev",
]);
const COMPACT_FIELDS = [
  "slug",
  "displayName",
  "kind",
  "submittedBy",
  "spritesheet",
  "petJson",
  "zip",
  "spriteVersionNumber",
] as const;

const LOCAL_PUNCH: PetdexCatalogPet = {
  slug: PETDEX_PUNCH_SLUG,
  displayName: "Punch",
  spritesheetUrl: "/pets/punch/spritesheet.webp",
  thumbnailUrl: "/pets/punch/spritesheet.webp",
  previewUrl: "/pets/punch/spritesheet.webp",
  petJsonUrl: "/pets/punch/pet.json",
  sourceUrl: "https://petdex.dev/pets/punch",
  tags: ["default", "monkey"],
  kind: "creature",
  version: "v1",
  gridRows: 9,
  available: true,
};

let cache: { expiresAt: number; snapshot: PetdexCatalogSnapshot } | null = null;
let inflight: Promise<PetdexCatalogSnapshot> | null = null;

function asObject(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? value as Record<string, unknown> : {};
}
function asString(value: unknown): string { return typeof value === "string" ? value.trim() : ""; }
function trustedAssetUrl(raw: unknown, assetBase?: string): string {
  const text = asString(raw);
  if (!text) return "";
  try {
    const base = assetBase ? assetBase.replace(/\/+$/, "") + "/" : undefined;
    const url = base ? new URL(text, base) : new URL(text);
    if (url.protocol !== "https:") return "";
    if (LEGACY_ASSET_HOSTS.has(url.hostname)) url.hostname = CANONICAL_ASSET_HOST;
    if (url.hostname !== CANONICAL_ASSET_HOST) return "";
    return url.toString();
  } catch { return ""; }
}
function publicPetPage(slug: string): string {
  return "https://petdex.dev/pets/" + encodeURIComponent(slug);
}
function thumbnailUrl(slug: string): string {
  // This is the exact upstream convention in src/lib/pet-thumbnail.ts.
  return "https://assets.petdex.dev/pets/" + encodeURIComponent(slug) + "/thumb.webp";
}
function previewUrl(slug: string): string {
  return "https://assets.petdex.dev/pets/" + encodeURIComponent(slug) + "/preview.webp";
}
function fromCompact(payload: unknown): PetdexCatalogPet[] {
  const root = asObject(payload);
  if (root.v !== 2 || !Array.isArray(root.pets) || !Array.isArray(root.fields)) return [];
  if (root.fields.length !== COMPACT_FIELDS.length || root.fields.some((field, index) => field !== COMPACT_FIELDS[index])) return [];
  const assetBase = trustedAssetUrl(root.assetBase);
  if (!assetBase) return [];
  const pets: PetdexCatalogPet[] = [];
  for (const item of root.pets) {
    if (!Array.isArray(item) || item.length !== COMPACT_FIELDS.length) continue;
    const slug = asString(item[0]).toLowerCase();
    const displayName = asString(item[1]) || slug;
    const kind = asString(item[2]).toLowerCase();
    const spritesheetUrl = trustedAssetUrl(item[4], assetBase);
    const petJsonUrl = trustedAssetUrl(item[5], assetBase);
    const spriteVersionNumber = item[7] === 2 ? 2 : 1;
    if (!slug || !/^[a-z0-9][a-z0-9_-]{0,79}$/.test(slug) || !spritesheetUrl || !petJsonUrl) continue;
    pets.push({
      slug,
      displayName,
      spritesheetUrl,
      thumbnailUrl: thumbnailUrl(slug),
      previewUrl: previewUrl(slug),
      petJsonUrl,
      sourceUrl: publicPetPage(slug),
      tags: [],
      kind,
      version: spriteVersionNumber === 2 ? "v2" : "v1",
      gridRows: spriteVersionNumber === 2 ? 11 : 9,
      available: true,
    });
  }
  return pets;
}
function fromLegacy(payload: unknown): PetdexCatalogPet[] {
  const root = asObject(payload);
  if (!Array.isArray(root.pets)) return [];
  const pets: PetdexCatalogPet[] = [];
  for (const raw of root.pets) {
    const item = asObject(raw);
    const slug = asString(item.slug).toLowerCase();
    const spritesheetUrl = trustedAssetUrl(item.spritesheetUrl);
    const petJsonUrl = trustedAssetUrl(item.petJsonUrl);
    const spriteVersionNumber = Number(item.spriteVersionNumber) === 2 ? 2 : 1;
    if (!slug || !spritesheetUrl || !petJsonUrl) continue;
    pets.push({
      slug,
      displayName: asString(item.displayName) || slug,
      spritesheetUrl,
      thumbnailUrl: thumbnailUrl(slug),
      previewUrl: previewUrl(slug),
      petJsonUrl,
      sourceUrl: publicPetPage(slug),
      tags: [],
      kind: asString(item.kind).toLowerCase(),
      version: spriteVersionNumber === 2 ? "v2" : "v1",
      gridRows: spriteVersionNumber === 2 ? 11 : 9,
      available: true,
    });
  }
  return pets;
}
async function fetchManifest(url: string): Promise<unknown> {
  const response = await fetch(url, {
    headers: { Accept: "application/json", "User-Agent": "EDUFLOW-Petdex/26.4.3" },
    redirect: "follow",
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) throw new Error("Petdex manifest HTTP " + response.status);
  return await response.json() as unknown;
}

export async function petdexCatalogSnapshot(force = false): Promise<PetdexCatalogSnapshot> {
  const now = Date.now();
  if (!force && cache && cache.expiresAt > now) return cache.snapshot;
  if (!force && inflight) return inflight;

  inflight = (async function() {
    try {
      let remote: PetdexCatalogPet[] = [];
      try { remote = fromCompact(await fetchManifest(MANIFEST_V2_URL)); } catch { /* legacy fallback below */ }
      if (!remote.length) remote = fromLegacy(await fetchManifest(MANIFEST_LEGACY_URL));
      if (!remote.length) throw new Error("Petdex manifest did not contain usable remote pets");
      const unique = new Map<string, PetdexCatalogPet>();
      unique.set(LOCAL_PUNCH.slug, LOCAL_PUNCH);
      for (const pet of remote) if (!unique.has(pet.slug)) unique.set(pet.slug, pet);
      const snapshot = { pets: Array.from(unique.values()), warning: "" };
      cache = { expiresAt: Date.now() + 10 * 60_000, snapshot };
      return snapshot;
    } catch (error) {
      console.warn("[EDUFLOW Petdex] Manifest unavailable", error);
      const previous = cache?.snapshot?.pets?.length && cache.snapshot.pets.length > 1 ? cache.snapshot.pets : [LOCAL_PUNCH];
      const snapshot = { pets: previous, warning: "Petdex đang tạm thời gián đoạn. Bạn có thể tiếp tục dùng Punch và thử lại sau." };
      cache = { expiresAt: Date.now() + 60_000, snapshot };
      return snapshot;
    } finally { inflight = null; }
  })();
  return inflight;
}

export async function petdexCatalog(force = false): Promise<PetdexCatalogPet[]> {
  return (await petdexCatalogSnapshot(force)).pets;
}
export async function findPetdexPet(slug: string): Promise<PetdexCatalogPet | null> {
  const normalized = String(slug || "").trim().toLowerCase();
  if (!normalized || normalized === PETDEX_PUNCH_SLUG) return LOCAL_PUNCH;
  return (await petdexCatalog()).find((pet) => pet.slug === normalized) || null;
}
export function localPunchPet(): PetdexCatalogPet { return LOCAL_PUNCH; }
function proxiedPetdexAsset(slug: string, value: string): string {
  if (!value) return "";
  if (value.startsWith("/")) return value;
  if (!isAllowedPetdexAsset(value)) return "";
  const params = new URLSearchParams({ pet: slug, src: value });
  return "/api/student/pets/asset?" + params.toString();
}
export function clientPetdexPet(pet: PetdexCatalogPet): PetdexCatalogPet {
  if (pet.slug === PETDEX_PUNCH_SLUG) return pet;
  return {
    ...pet,
    // Browsers on EDUFLOW no longer fetch Petdex R2 directly. Keeping the
    // bytes same-origin avoids CDN hot-link/CORP/browser-policy failures while
    // still loading only the pets that are actually visible/selected.
    spritesheetUrl: proxiedPetdexAsset(pet.slug, pet.spritesheetUrl),
    thumbnailUrl: proxiedPetdexAsset(pet.slug, pet.thumbnailUrl),
    previewUrl: proxiedPetdexAsset(pet.slug, pet.previewUrl),
  };
}
export function isAllowedPetdexAsset(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.hostname === CANONICAL_ASSET_HOST && /\.(?:webp|png)$/i.test(url.pathname);
  } catch { return false; }
}
