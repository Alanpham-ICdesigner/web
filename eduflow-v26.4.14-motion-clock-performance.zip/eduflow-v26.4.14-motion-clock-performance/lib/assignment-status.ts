export type AssignmentStatus = "Đang mở" | "Sắp hết hạn" | "Đã kết thúc";

export function assignmentDeadlineMs(value: string): number {
  const localVietnam = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(value.trim());
  if (localVietnam) {
    return Date.UTC(
      Number(localVietnam[1]), Number(localVietnam[2]) - 1, Number(localVietnam[3]),
      Number(localVietnam[4]) - 7, Number(localVietnam[5]), Number(localVietnam[6] || 0)
    );
  }
  return Date.parse(value);
}

export function getAssignmentStatus(dueDate: string, now = Date.now()): AssignmentStatus {
  const deadline = assignmentDeadlineMs(dueDate);
  if (!Number.isFinite(deadline) || deadline <= now) return "Đã kết thúc";
  if (deadline - now <= 6 * 60 * 60 * 1000) return "Sắp hết hạn";
  return "Đang mở";
}
