export const ALL_CLASSES_ID: "all";
export const APP_TIME_ZONE: "Asia/Ho_Chi_Minh";

export type ClassLike = {
  id?: number;
  key?: string;
  name: string;
};

export type AttendanceItemLike = {
  id?: number;
  data?: Record<string, unknown>;
  createdAt?: string;
};

export type PointRuleLike = {
  id?: number;
  points: number;
  createdAt?: string;
};

export type SearchStudentLike = {
  id?: number;
  name: string;
  code: string;
  className: string;
  classKeys?: string[];
  classNames?: string[];
};

export function localDateInTimeZone(value?: Date, timeZone?: string): string;
export function shiftDateKey(dateKey: string, days: number): string;
export function mondayDateKey(dateKey: string): string;
export function formatDateKey(
  dateKey: string,
  locale?: string,
  options?: Intl.DateTimeFormatOptions,
): string;
export function classIdentifier(classRecord?: ClassLike): string;
export function compareAttendanceItems(
  a: AttendanceItemLike,
  b: AttendanceItemLike,
): number;
export function attendanceBelongsToClass(
  item: AttendanceItemLike,
  selectedClassId: string,
  className: string,
): boolean;
export function filterAndSortAttendance<T extends AttendanceItemLike>(
  items: readonly T[],
  selectedClassId: string,
  className: string,
): T[];
export function comparePointRules(a: PointRuleLike, b: PointRuleLike): number;
export function sortPointRules<T extends PointRuleLike>(rules: readonly T[]): T[];
export function normalizeSearchText(value: unknown): string;
export function searchStudents<T extends SearchStudentLike>(
  students: readonly T[],
  query: unknown,
): T[];
export function resolveStudentNavigationTarget(
  student: SearchStudentLike,
  classes: readonly ClassLike[],
): { studentId: number; classId: string } | null;
