export function secureFileHeaders(request: Request, fileName: string, contentType: string): Headers {
  const download = new URL(request.url).searchParams.get("download") === "1";
  const disposition = download ? "attachment" : "inline";
  const headers = new Headers();
  headers.set("Content-Type", contentType || "application/octet-stream");
  headers.set("Content-Disposition", disposition + "; filename*=UTF-8''" + encodeURIComponent(fileName || "tep"));
  headers.set("Cache-Control", "private, no-store");
  headers.set("X-Content-Type-Options", "nosniff");
  return headers;
}
