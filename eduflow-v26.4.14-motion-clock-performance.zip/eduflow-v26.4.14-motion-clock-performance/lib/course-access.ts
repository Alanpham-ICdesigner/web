import { and, eq } from "drizzle-orm";
import { getDb } from "../db";
import { adminItems, studentEnrollments } from "../db/schema";

type Database = Awaited<ReturnType<typeof getDb>>;

export type CourseRecord = {
  id: number;
  key: string;
  name: string;
  data: Record<string, unknown>;
};

export function decodeCourseData(value: string): Record<string, unknown> {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

export function fallbackClassKey(className: string): string {
  // Keep Vietnamese characters so this matches the deterministic SQLite
  // fallback used by the one-time migration on existing Cloudflare D1 data.
  const slug = className.trim().toLocaleLowerCase("vi").replace(/\s+/g, "-").slice(0, 80);
  return "legacy:" + (slug || "class");
}

export async function findCourseByKey(db: Database, classKey: string): Promise<CourseRecord | null> {
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.kind, "classes"), eq(adminItems.itemKey, classKey))).limit(1);
  const row = rows[0];
  return row ? { id: row.id, key: row.itemKey, name: row.title, data: decodeCourseData(row.data) } : null;
}

export async function findCourseByName(db: Database, className: string): Promise<CourseRecord | null> {
  const rows = await db.select().from(adminItems).where(and(eq(adminItems.kind, "classes"), eq(adminItems.title, className))).limit(1);
  const row = rows[0];
  return row ? { id: row.id, key: row.itemKey, name: row.title, data: decodeCourseData(row.data) } : null;
}

export async function resolveCourse(db: Database, input: { classKey?: string; className?: string }): Promise<CourseRecord | null> {
  if (input.classKey) {
    const course = await findCourseByKey(db, input.classKey);
    if (course) return course;
  }
  if (input.className) return findCourseByName(db, input.className);
  return null;
}

export async function activeEnrollments(db: Database, studentId: number) {
  return db.select().from(studentEnrollments).where(and(eq(studentEnrollments.studentId, studentId), eq(studentEnrollments.status, "active")));
}

export async function studentCanAccessCourse(db: Database, studentId: number, classKey: string): Promise<boolean> {
  const rows = await db.select({ id: studentEnrollments.id }).from(studentEnrollments).where(and(
    eq(studentEnrollments.studentId, studentId),
    eq(studentEnrollments.classKey, classKey),
    eq(studentEnrollments.status, "active"),
  )).limit(1);
  return rows.length > 0;
}
