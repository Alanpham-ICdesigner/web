import { eq, sql } from "drizzle-orm";
import { getDb } from "../db";
import { loginAttempts } from "../db/schema";

export const MAX_FAILED_ATTEMPTS = 5;
export const LOGIN_LOCK_MINUTES = 15;
const LOGIN_LOCK_MS = LOGIN_LOCK_MINUTES * 60 * 1000;

type LoginAttemptResult = {
  locked: boolean;
  remainingAttempts: number;
  retryAfter: number;
};

async function digest(value: string): Promise<string> {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(bytes)).map(function (byte) { return byte.toString(16).padStart(2, "0"); }).join("");
}

async function accountKey(scope: "admin" | "student", identifier: string): Promise<string> {
  return "login:" + scope + ":" + await digest(identifier.trim().toUpperCase());
}

function result(failedAttempts: number, lockedUntil: number, now: number): LoginAttemptResult {
  const locked = lockedUntil > now;
  return {
    locked,
    remainingAttempts: locked ? 0 : Math.max(0, MAX_FAILED_ATTEMPTS - failedAttempts),
    retryAfter: locked ? Math.max(1, Math.ceil((lockedUntil - now) / 1000)) : 0,
  };
}

export async function checkLoginAllowed(scope: "admin" | "student", identifier: string): Promise<LoginAttemptResult> {
  const now = Date.now();
  try {
    const key = await accountKey(scope, identifier);
    const rows = await (await getDb()).select().from(loginAttempts).where(eq(loginAttempts.accountKey, key)).limit(1);
    if (!rows.length) return result(0, 0, now);
    if (rows[0].lockedUntil > 0 && rows[0].lockedUntil <= now) {
      await (await getDb()).delete(loginAttempts).where(eq(loginAttempts.accountKey, key));
      return result(0, 0, now);
    }
    return result(rows[0].failedAttempts, rows[0].lockedUntil, now);
  } catch {
    return result(0, 0, now);
  }
}

export async function recordFailedLogin(scope: "admin" | "student", identifier: string): Promise<LoginAttemptResult> {
  const now = Date.now();
  try {
    const lockUntil = now + LOGIN_LOCK_MS;
    const key = await accountKey(scope, identifier);
    const rows = await (await getDb()).insert(loginAttempts).values({
      accountKey: key,
      failedAttempts: 1,
      lockedUntil: 0,
      updatedAt: new Date(now).toISOString(),
    }).onConflictDoUpdate({
      target: loginAttempts.accountKey,
      set: {
        failedAttempts: sql<number>`CASE WHEN ${loginAttempts.lockedUntil} > 0 AND ${loginAttempts.lockedUntil} <= ${now} THEN 1 ELSE MIN(${loginAttempts.failedAttempts} + 1, ${MAX_FAILED_ATTEMPTS}) END`,
        lockedUntil: sql<number>`CASE WHEN ${loginAttempts.lockedUntil} > ${now} THEN ${loginAttempts.lockedUntil} WHEN ${loginAttempts.lockedUntil} > 0 AND ${loginAttempts.lockedUntil} <= ${now} THEN 0 WHEN ${loginAttempts.failedAttempts} + 1 >= ${MAX_FAILED_ATTEMPTS} THEN ${lockUntil} ELSE 0 END`,
        updatedAt: new Date(now).toISOString(),
      },
    }).returning();
    return result(rows[0].failedAttempts, rows[0].lockedUntil, now);
  } catch {
    return result(1, 0, now);
  }
}

export async function resetFailedLogins(scope: "admin" | "student", identifier: string): Promise<void> {
  try {
    const key = await accountKey(scope, identifier);
    await (await getDb()).delete(loginAttempts).where(eq(loginAttempts.accountKey, key));
  } catch {
    // A rate-limit storage failure must never block a valid login.
  }
}
