import { assignmentDeadlineMs, getAssignmentStatus } from "./assignment-status";

export type PushSubscriptionRecord = {
  id: number;
  student_id: number;
  endpoint: string;
  p256dh: string;
  auth: string;
  enabled: number;
  created_at: string;
  updated_at: string;
};

export type PushNotificationPayload = {
  title: string;
  body: string;
  url: string;
  tag: string;
  badgeCount?: number;
  icon?: string;
  category?: string;
  relatedId?: string | number;
};

type PushEnv = {
  VAPID_PUBLIC_KEY?: string;
  VAPID_PRIVATE_JWK?: string;
  VAPID_SUBJECT?: string;
};

function base64UrlToBytes(value: string): Uint8Array {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
  const binary = atob(padded);
  const output = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) output[index] = binary.charCodeAt(index);
  return output;
}

function bytesToBase64Url(value: Uint8Array): string {
  let binary = "";
  for (let index = 0; index < value.length; index += 1) binary += String.fromCharCode(value[index]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function concatBytes(...parts: Uint8Array[]): Uint8Array {
  const length = parts.reduce(function(sum, part) { return sum + part.length; }, 0);
  const output = new Uint8Array(length);
  let offset = 0;
  parts.forEach(function(part) { output.set(part, offset); offset += part.length; });
  return output;
}

async function hmacSha256(keyBytes: Uint8Array, data: Uint8Array): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey("raw", keyBytes as BufferSource, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, data as BufferSource));
}

async function hkdfExpand(prk: Uint8Array, info: Uint8Array, length: number): Promise<Uint8Array> {
  const output = new Uint8Array(length);
  let previous = new Uint8Array(0);
  let offset = 0;
  let counter = 1;
  while (offset < length) {
    const block = await hmacSha256(prk, concatBytes(previous, info, new Uint8Array([counter])));
    const take = Math.min(block.length, length - offset);
    output.set(block.slice(0, take), offset);
    previous = new Uint8Array(block);
    offset += take;
    counter += 1;
  }
  return output;
}

function text(value: string): Uint8Array { return new TextEncoder().encode(value); }

async function encryptPayload(payload: string, p256dh: string, auth: string): Promise<Uint8Array> {
  const receiverPublic = base64UrlToBytes(p256dh);
  const authSecret = base64UrlToBytes(auth);
  if (receiverPublic.length !== 65 || receiverPublic[0] !== 4) throw new Error("Push subscription p256dh không hợp lệ.");
  if (authSecret.length < 16) throw new Error("Push subscription auth không hợp lệ.");

  const receiverKey = await crypto.subtle.importKey("raw", receiverPublic as BufferSource, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const senderKeys = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const senderPublic = new Uint8Array(await crypto.subtle.exportKey("raw", senderKeys.publicKey));
  const sharedSecret = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: receiverKey }, senderKeys.privateKey, 256));

  const prkKey = await hmacSha256(authSecret, sharedSecret);
  const keyInfo = concatBytes(text("WebPush: info\u0000"), receiverPublic, senderPublic);
  const ikm = await hkdfExpand(prkKey, keyInfo, 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const prk = await hmacSha256(salt, ikm);
  const cek = await hkdfExpand(prk, text("Content-Encoding: aes128gcm\u0000"), 16);
  const nonce = await hkdfExpand(prk, text("Content-Encoding: nonce\u0000"), 12);

  const clear = concatBytes(text(payload), new Uint8Array([2]));
  if (clear.length + 16 > 4096) throw new Error("Nội dung Web Push quá dài.");
  const aesKey = await crypto.subtle.importKey("raw", cek as BufferSource, "AES-GCM", false, ["encrypt"]);
  const encrypted = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce as BufferSource, tagLength: 128 }, aesKey, clear as BufferSource));

  const recordSize = 4096;
  const header = new Uint8Array(16 + 4 + 1 + senderPublic.length);
  header.set(salt, 0);
  new DataView(header.buffer).setUint32(16, recordSize, false);
  header[20] = senderPublic.length;
  header.set(senderPublic, 21);
  return concatBytes(header, encrypted);
}

async function vapidAuthorization(endpoint: string, env: PushEnv): Promise<string> {
  const publicKey = String(env.VAPID_PUBLIC_KEY || "").trim();
  const privateJwkText = String(env.VAPID_PRIVATE_JWK || "").trim();
  if (!publicKey || !privateJwkText) throw new Error("Web Push chưa có VAPID key trên Cloudflare.");
  const privateJwk = JSON.parse(privateJwkText) as JsonWebKey;
  const privateKey = await crypto.subtle.importKey("jwk", privateJwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  const now = Math.floor(Date.now() / 1000);
  const header = bytesToBase64Url(text(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const claims = bytesToBase64Url(text(JSON.stringify({
    aud: new URL(endpoint).origin,
    exp: now + 12 * 60 * 60,
    sub: String(env.VAPID_SUBJECT || "https://edumath.phmt.workers.dev/"),
  })));
  const signingInput = header + "." + claims;
  const signature = new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, privateKey, text(signingInput) as BufferSource));
  return "vapid t=" + signingInput + "." + bytesToBase64Url(signature) + ", k=" + publicKey;
}

async function rawDatabase(): Promise<D1Database> {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("D1 binding DB is unavailable");
  return env.DB as D1Database;
}

async function pushEnv(): Promise<PushEnv> {
  const { env } = await import("cloudflare:workers");
  return env as unknown as PushEnv;
}

export async function getVapidPublicKey(): Promise<string> {
  const env = await pushEnv();
  return String(env.VAPID_PUBLIC_KEY || "").trim();
}

export async function sendPushRequest(subscription: Pick<PushSubscriptionRecord, "endpoint" | "p256dh" | "auth">, payload: PushNotificationPayload): Promise<Response> {
  const env = await pushEnv();
  const body = await encryptPayload(JSON.stringify(payload), subscription.p256dh, subscription.auth);
  const requestBody = new Uint8Array(body);
  const authorization = await vapidAuthorization(subscription.endpoint, env);
  return fetch(subscription.endpoint, {
    method: "POST",
    headers: {
      Authorization: authorization,
      "Content-Encoding": "aes128gcm",
      "Content-Type": "application/octet-stream",
      TTL: "86400",
      Urgency: payload.category === "pomodoro" || payload.category === "message" ? "high" : "normal",
    },
    body: requestBody.buffer,
  });
}

function decodeJson(value: string): Record<string, unknown> {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

async function enrollmentMaps(db: D1Database, studentIds: Set<number>) {
  const rows = await db.prepare("SELECT student_id, class_key, class_name FROM student_enrollments WHERE status = 'active'").all() as { results?: Array<{ student_id: number; class_key: string; class_name: string }> };
  const keys = new Map<number, Set<string>>();
  const names = new Map<number, Set<string>>();
  for (const row of rows.results || []) {
    const studentId = Number(row.student_id);
    if (!studentIds.has(studentId)) continue;
    if (!keys.has(studentId)) keys.set(studentId, new Set());
    if (!names.has(studentId)) names.set(studentId, new Set());
    keys.get(studentId)!.add(String(row.class_key || ""));
    names.get(studentId)!.add(String(row.class_name || ""));
  }
  return { keys, names };
}

async function unreadCounts(db: D1Database, studentIds: number[]): Promise<Map<number, number>> {
  const unique = new Set(studentIds.filter(function(id) { return Number.isInteger(id) && id > 0; }));
  const counts = new Map<number, number>();
  unique.forEach(function(id) { counts.set(id, 0); });
  if (!unique.size) return counts;
  const maps = await enrollmentMaps(db, unique);
  const rows = await db.prepare("SELECT kind, data FROM admin_items WHERE kind IN ('notifications','messages') ORDER BY id DESC").all() as { results?: Array<{ kind: string; data: string }> };
  for (const row of rows.results || []) {
    const data = decodeJson(row.data);
    if (row.kind === "messages") {
      if (String(data.direction || "") !== "teacher" || data.studentReadAt) continue;
      const studentId = Number(data.studentId || 0);
      if (unique.has(studentId)) counts.set(studentId, Math.min(99, (counts.get(studentId) || 0) + 1));
      continue;
    }
    const audience = String(data.audience || "all_students");
    for (const studentId of unique) {
      const classKey = String(data.classKey || "");
      const className = String(data.className || "");
      const courseAllowed = (!classKey && !className) || maps.keys.get(studentId)?.has(classKey) || maps.names.get(studentId)?.has(className);
      if (!courseAllowed) continue;
      if (audience === "student") {
        if (Number(data.studentId || 0) !== studentId || data.studentReadAt) continue;
      } else {
        if (audience !== "all_students" && audience !== "") continue;
        const readIds = Array.isArray(data.readByStudentIds) ? data.readByStudentIds.map(Number) : [];
        if (readIds.includes(studentId)) continue;
      }
      counts.set(studentId, Math.min(99, (counts.get(studentId) || 0) + 1));
    }
  }
  return counts;
}

async function subscriptionsForStudents(db: D1Database, studentIds: number[]): Promise<PushSubscriptionRecord[]> {
  const unique = Array.from(new Set(studentIds.filter(function(id) { return Number.isInteger(id) && id > 0; })));
  if (!unique.length) return [];
  const placeholders = unique.map(function() { return "?"; }).join(",");
  const result = await db.prepare(`SELECT id, student_id, endpoint, p256dh, auth, enabled, created_at, updated_at FROM push_subscriptions WHERE enabled = 1 AND student_id IN (${placeholders})`).bind(...unique).all() as { results?: PushSubscriptionRecord[] };
  return result.results || [];
}

async function reserveDelivery(db: D1Database, subscriptionId: number, studentId: number, eventKey: string, now: string): Promise<boolean> {
  const result = await db.prepare(`
    INSERT OR IGNORE INTO push_deliveries (subscription_id, student_id, event_key, status, created_at, updated_at)
    VALUES (?, ?, ?, 'pending', ?, ?)
  `).bind(subscriptionId, studentId, eventKey, now, now).run();
  return Boolean(result.meta?.changes);
}

async function updateDelivery(db: D1Database, subscriptionId: number, eventKey: string, status: string, now: string) {
  await db.prepare(`
    UPDATE push_deliveries
    SET status = ?, updated_at = ?
    WHERE subscription_id = ? AND event_key = ?
  `).bind(status, now, subscriptionId, eventKey).run();
}


async function studentsInActiveFocus(db: D1Database, studentIds: number[], now = new Date()): Promise<Set<number>> {
  const unique = Array.from(new Set(studentIds.filter(function(id) { return Number.isInteger(id) && id > 0; })));
  if (!unique.length) return new Set();
  const placeholders = unique.map(function() { return "?"; }).join(",");
  const rows = await db.prepare(`
    SELECT student_id
    FROM student_focus_timer_state
    WHERE student_id IN (${placeholders})
      AND status = 'running'
      AND ends_at <> ''
      AND ends_at > ?
  `).bind(...unique, now.toISOString()).all() as { results?: Array<{ student_id: number }> };
  return new Set((rows.results || []).map(function(row) { return Number(row.student_id); }).filter(Boolean));
}

async function deferPush(db: D1Database, studentId: number, payload: Omit<PushNotificationPayload, "badgeCount">, eventKey: string, now: string) {
  await db.prepare(`
    INSERT INTO deferred_push_notifications (student_id, event_key, payload, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(student_id, event_key) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at
  `).bind(studentId, eventKey, JSON.stringify(payload), now, now).run();
}

export async function sendPushToStudents(
  studentIds: number[],
  payload: Omit<PushNotificationPayload, "badgeCount">,
  eventKey: string,
  options: { bypassFocusQuietMode?: boolean } = {},
): Promise<{ sent: number; failed: number }> {
  const db = await rawDatabase();
  const uniqueStudentIds = Array.from(new Set(studentIds.filter(function(id) { return Number.isInteger(id) && id > 0; })));
  const bypassFocusQuietMode = Boolean(options.bypassFocusQuietMode);
  let deliverStudentIds = uniqueStudentIds;
  if (!bypassFocusQuietMode && uniqueStudentIds.length) {
    const activeFocus = await studentsInActiveFocus(db, uniqueStudentIds);
    if (activeFocus.size) {
      const now = new Date().toISOString();
      for (const studentId of activeFocus) await deferPush(db, studentId, payload, eventKey, now);
      deliverStudentIds = uniqueStudentIds.filter(function(studentId) { return !activeFocus.has(studentId); });
    }
  }
  const subscriptions = await subscriptionsForStudents(db, deliverStudentIds);
  if (!subscriptions.length) return { sent: 0, failed: 0 };
  const badgeCounts = await unreadCounts(db, subscriptions.map(function(item) { return item.student_id; }));
  let sent = 0;
  let failed = 0;
  for (const subscription of subscriptions) {
    const now = new Date().toISOString();
    // Claim the event before the outbound request. The UNIQUE index makes the
    // claim atomic, so two overlapping Worker requests cannot double-send the
    // same notification to the same browser endpoint.
    if (!await reserveDelivery(db, subscription.id, subscription.student_id, eventKey, now)) continue;
    try {
      const response = await sendPushRequest(subscription, { ...payload, badgeCount: badgeCounts.get(subscription.student_id) || 0, icon: payload.icon || "/icons/pwa-192.png" });
      if (response.ok) {
        sent += 1;
        await db.prepare("UPDATE push_subscriptions SET last_success_at = ?, failure_count = 0, updated_at = ? WHERE id = ?").bind(now, now, subscription.id).run();
        await updateDelivery(db, subscription.id, eventKey, "sent", now);
      } else {
        failed += 1;
        const expired = response.status === 404 || response.status === 410;
        await db.prepare("UPDATE push_subscriptions SET enabled = ?, failure_count = failure_count + 1, updated_at = ? WHERE id = ?").bind(expired ? 0 : 1, now, subscription.id).run();
        await updateDelivery(db, subscription.id, eventKey, "http_" + response.status, now);
      }
    } catch {
      failed += 1;
      await db.prepare("UPDATE push_subscriptions SET failure_count = failure_count + 1, updated_at = ? WHERE id = ?").bind(now, subscription.id).run();
      await updateDelivery(db, subscription.id, eventKey, "error", now);
    }
  }
  return { sent, failed };
}

export async function sendPushToStudent(
  studentId: number,
  payload: Omit<PushNotificationPayload, "badgeCount">,
  eventKey: string,
  options: { bypassFocusQuietMode?: boolean } = {},
) {
  return sendPushToStudents([studentId], payload, eventKey, options);
}

export async function activeStudentIdsForCourse(classKey?: string, className?: string): Promise<number[]> {
  const db = await rawDatabase();
  const key = String(classKey || "").trim();
  const name = String(className || "").trim();
  if (!key && !name) {
    const rows = await db.prepare("SELECT id AS student_id FROM students ORDER BY id").all() as { results?: Array<{ student_id: number }> };
    return (rows.results || []).map(function(row) { return Number(row.student_id); }).filter(Boolean);
  }
  const rows = key
    ? await db.prepare("SELECT DISTINCT student_id FROM student_enrollments WHERE status = 'active' AND class_key = ?").bind(key).all() as { results?: Array<{ student_id: number }> }
    : await db.prepare("SELECT DISTINCT student_id FROM student_enrollments WHERE status = 'active' AND class_name = ?").bind(name).all() as { results?: Array<{ student_id: number }> };
  return (rows.results || []).map(function(row) { return Number(row.student_id); }).filter(Boolean);
}

export async function sendPushToCourse(classKey: string, className: string, payload: Omit<PushNotificationPayload, "badgeCount">, eventKey: string) {
  const ids = await activeStudentIdsForCourse(classKey, className);
  return sendPushToStudents(ids, payload, eventKey);
}

export async function sendPushToAllStudents(payload: Omit<PushNotificationPayload, "badgeCount">, eventKey: string) {
  const ids = await activeStudentIdsForCourse();
  return sendPushToStudents(ids, payload, eventKey);
}

export async function sendDuePomodoroPushes(now = new Date()): Promise<{ reconciled: number; sent: number }> {
  const db = await rawDatabase();
  const since = new Date(now.getTime() - 15 * 60 * 1000).toISOString();
  const expiredBreaks = await db.prepare(`
    SELECT t.student_id, t.ends_at, COALESCE(NULLIF(TRIM(p.pet_name), ''), 'Punch') AS pet_name
    FROM student_focus_timer_state t
    LEFT JOIN student_pet_profiles p ON p.student_id = t.student_id
    WHERE t.mode = 'break' AND t.status = 'running' AND t.ends_at <> '' AND t.ends_at <= ? AND t.ends_at >= ?
  `).bind(now.toISOString(), since).all() as { results?: Array<{ student_id: number; ends_at: string; pet_name: string }> };
  const { reconcileAllExpiredFocusTimers } = await import("./focus-timer");
  const reconciled = await reconcileAllExpiredFocusTimers(db, now);
  const sessions = await db.prepare(`
    SELECT s.student_id, s.session_key, s.focus_minutes, s.completed_at, COALESCE(NULLIF(TRIM(p.pet_name), ''), 'Punch') AS pet_name
    FROM student_focus_sessions s
    LEFT JOIN student_pet_profiles p ON p.student_id = s.student_id
    WHERE s.completed_at >= ?
      AND EXISTS (
        SELECT 1 FROM push_subscriptions p
        WHERE p.student_id = s.student_id AND p.enabled = 1 AND p.created_at <= s.completed_at
      )
    ORDER BY s.completed_at
    LIMIT 200
  `).bind(since).all() as { results?: Array<{ student_id: number; session_key: string; focus_minutes: number; completed_at: string; pet_name: string }> };
  let sent = 0;
  for (const session of sessions.results || []) {
    const petName = String(session.pet_name || "Punch").trim() || "Punch";
    const result = await sendPushToStudent(Number(session.student_id), {
      title: "🍅 " + petName + ": Xong rồi đó!",
      body: "Bạn vừa hoàn thành " + Number(session.focus_minutes || 0) + " phút tập trung. Nghỉ một chút nhé.",
      url: "/student?view=pomodoro",
      tag: "pomodoro-" + String(session.session_key),
      category: "pomodoro",
      relatedId: session.session_key,
    }, "pomodoro:" + String(session.session_key), { bypassFocusQuietMode: true });
    sent += result.sent;
  }
  for (const item of expiredBreaks.results || []) {
    const petName = String(item.pet_name || "Punch").trim() || "Punch";
    const result = await sendPushToStudent(Number(item.student_id), {
      title: "🚀 " + petName + " sẵn sàng rồi!",
      body: "Thời gian nghỉ đã kết thúc. Bạn có thể bắt đầu phiên tập trung tiếp theo.",
      url: "/student?view=pomodoro",
      tag: "pomodoro-break-" + Number(item.student_id) + "-" + String(item.ends_at),
      category: "pomodoro",
      relatedId: String(item.ends_at),
    }, "pomodoro-break:" + Number(item.student_id) + ":" + String(item.ends_at), { bypassFocusQuietMode: true });
    sent += result.sent;
  }
  return { reconciled, sent };
}

function vietnamClockParts(now: Date): { dateKey: string; hour: number; minute: number } {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false,
  }).formatToParts(now);
  const get = function(type: string) { return parts.find(function(part) { return part.type === type; })?.value || ""; };
  return { dateKey: get("year") + "-" + get("month") + "-" + get("day"), hour: Number(get("hour")) || 0, minute: Number(get("minute")) || 0 };
}

export async function sendDailyStreakReminders(now = new Date()): Promise<{ checked: number; created: number; sent: number }> {
  const clock = vietnamClockParts(now);
  const minutes = clock.hour * 60 + clock.minute;
  const stage = minutes >= 22 * 60 ? "22" : minutes >= 18 * 60 ? "18" : "";
  if (!stage) return { checked: 0, created: 0, sent: 0 };
  const db = await rawDatabase();
  const rows = await db.prepare(`
    SELECT s.id AS student_id, COALESCE(NULLIF(TRIM(p.pet_name), ''), 'Punch') AS pet_name,
           COALESCE(p.current_streak, 0) AS current_streak, COALESCE(p.last_checkin_date, '') AS last_checkin_date
    FROM students s
    LEFT JOIN student_pet_profiles p ON p.student_id = s.id
    ORDER BY s.id
  `).all() as { results?: Array<{ student_id: number; pet_name: string; current_streak: number; last_checkin_date: string }> };
  let created = 0;
  let sent = 0;
  for (const row of rows.results || []) {
    if (String(row.last_checkin_date || "") === clock.dateKey) continue;
    const studentId = Number(row.student_id);
    if (!studentId) continue;
    const eventKey = "streak-reminder:" + clock.dateKey + ":" + stage + ":" + studentId;
    if (stage === "22") {
      await db.prepare("DELETE FROM deferred_push_notifications WHERE student_id = ? AND event_key = ?")
        .bind(studentId, "streak-reminder:" + clock.dateKey + ":18:" + studentId).run();
    }
    const itemKey = eventKey.replace(/:/g, "-");
    const petName = String(row.pet_name || "Punch").trim() || "Punch";
    const streak = Math.max(0, Number(row.current_streak) || 0);
    const title = stage === "22" ? "😰 " + petName + " đang lo cho chuỗi của bạn!" : "🔥 " + petName + " đang chờ bạn!";
    const body = stage === "22"
      ? streak > 0
        ? "Hôm nay bạn vẫn chưa điểm danh. Chuỗi " + streak + " ngày đang gặp nguy hiểm."
        : "Hôm nay bạn vẫn chưa điểm danh. Điểm danh để bắt đầu một chuỗi mới nhé."
      : streak > 0
        ? "Bạn đang có chuỗi " + streak + " ngày. Đừng quên điểm danh hôm nay để tiếp tục nhé."
        : "Hôm nay bạn chưa điểm danh. " + petName + " đang chờ bạn bắt đầu chuỗi đầu tiên!";
    const data = JSON.stringify({ body, audience: "student", studentId, actionView: "pomodoro", category: "streak_reminder", automatic: true, reminderStage: stage, dateKey: clock.dateKey, adminReadAt: null, studentReadAt: null, readByStudentIds: [] });
    const insert = await db.prepare(`
      INSERT OR IGNORE INTO admin_items (kind, item_key, title, data, created_at, updated_at)
      VALUES ('notifications', ?, ?, ?, ?, ?)
    `).bind(itemKey, title, data, now.toISOString(), now.toISOString()).run();
    if (!insert.meta?.changes) continue;
    created += 1;
    const result = await sendPushToStudent(studentId, { title, body, url: "/student?view=pomodoro", tag: "streak-" + clock.dateKey + "-" + stage, category: "streak", relatedId: clock.dateKey }, eventKey);
    sent += result.sent;
  }
  return { checked: (rows.results || []).length, created, sent };
}

export async function flushDeferredPushes(now = new Date()): Promise<{ checked: number; sent: number; failed: number }> {
  const db = await rawDatabase();
  const rows = await db.prepare(`
    SELECT id, student_id, event_key, payload
    FROM deferred_push_notifications
    ORDER BY id
    LIMIT 200
  `).all() as { results?: Array<{ id: number; student_id: number; event_key: string; payload: string }> };
  if (!(rows.results || []).length) return { checked: 0, sent: 0, failed: 0 };
  const ids = (rows.results || []).map(function(row) { return Number(row.student_id); });
  const active = await studentsInActiveFocus(db, ids, now);
  const clock = vietnamClockParts(now);
  let sent = 0;
  let failed = 0;
  for (const row of rows.results || []) {
    const studentId = Number(row.student_id);
    if (active.has(studentId)) continue;
    let payload: Omit<PushNotificationPayload, "badgeCount">;
    try {
      payload = JSON.parse(String(row.payload || "{}")) as Omit<PushNotificationPayload, "badgeCount">;
    } catch {
      await db.prepare("DELETE FROM deferred_push_notifications WHERE id = ?").bind(row.id).run();
      continue;
    }

    // Streak reminders are state-dependent. A reminder queued during Focus must
    // never arrive after the student has already checked in or after the day
    // has rolled over. Other deferred academic updates can be delivered later.
    if (String(payload.category || "") === "streak") {
      const reminderDate = String(payload.relatedId || "");
      const profile = await db.prepare("SELECT last_checkin_date FROM student_pet_profiles WHERE student_id = ? LIMIT 1").bind(studentId).first() as { last_checkin_date?: string } | null;
      const alreadyCheckedIn = String(profile?.last_checkin_date || "") === reminderDate;
      if (!reminderDate || reminderDate !== clock.dateKey || alreadyCheckedIn) {
        await db.prepare("DELETE FROM deferred_push_notifications WHERE id = ?").bind(row.id).run();
        continue;
      }
    }

    const result = await sendPushToStudent(studentId, payload, String(row.event_key || "deferred:" + row.id));
    sent += result.sent;
    failed += result.failed;
    await db.prepare("DELETE FROM deferred_push_notifications WHERE id = ?").bind(row.id).run();
  }
  return { checked: (rows.results || []).length, sent, failed };
}

type UpcomingAssignmentRow = {
  id: number;
  title: string;
  class_name: string;
  class_key: string;
  due_date: string;
};

function formatAssignmentDeadline(value: string): string {
  const timestamp = assignmentDeadlineMs(value);
  if (!Number.isFinite(timestamp)) return value;
  return new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "Asia/Ho_Chi_Minh",
  }).format(new Date(timestamp));
}

/**
 * V26.2.2: create one upcoming-deadline reminder per assignment + student +
 * concrete deadline. The same six-hour threshold powers the assignment UI, so
 * the notification cannot disagree with the "Sắp hết hạn" tab.
 *
 * `admin_items(kind,item_key)` is the in-app dedupe gate. Including the deadline
 * epoch in item_key intentionally allows one new reminder if a teacher changes
 * the deadline and that new deadline later enters the upcoming window.
 */
export async function sendUpcomingAssignmentReminders(now = new Date()): Promise<{ checked: number; created: number; sent: number }> {
  const db = await rawDatabase();
  const assignmentRows = await db.prepare(`
    SELECT id, title, class_name, class_key, due_date
    FROM assignments
    WHERE COALESCE(due_date, '') <> ''
    ORDER BY id DESC
    LIMIT 500
  `).all() as { results?: UpcomingAssignmentRow[] };

  const upcoming = (assignmentRows.results || []).filter(function(assignment) {
    return getAssignmentStatus(String(assignment.due_date || ""), now.getTime()) === "Sắp hết hạn";
  });
  if (!upcoming.length) return { checked: 0, created: 0, sent: 0 };

  const enrollmentRows = await db.prepare(`
    SELECT student_id, class_key, class_name
    FROM student_enrollments
    WHERE status = 'active'
  `).all() as { results?: Array<{ student_id: number; class_key: string; class_name: string }> };

  const relevantIds = upcoming.map(function(item) { return Number(item.id); }).filter(Boolean);
  const placeholders = relevantIds.map(function() { return "?"; }).join(",");
  const submissionRows = relevantIds.length ? await db.prepare(`
    SELECT assignment_id, student_id, status
    FROM assignment_submissions
    WHERE assignment_id IN (${placeholders})
  `).bind(...relevantIds).all() as { results?: Array<{ assignment_id: number; student_id: number; status: string }> } : { results: [] };
  const completionRows = relevantIds.length ? await db.prepare(`
    SELECT assignment_id, student_id
    FROM assignment_teacher_completions
    WHERE assignment_id IN (${placeholders})
  `).bind(...relevantIds).all() as { results?: Array<{ assignment_id: number; student_id: number }> } : { results: [] };

  const completed = new Set<string>();
  for (const row of submissionRows.results || []) {
    const status = String(row.status || "");
    if (status === "submitted" || status === "graded" || status === "teacher_completed") completed.add(Number(row.assignment_id) + ":" + Number(row.student_id));
  }
  for (const row of completionRows.results || []) completed.add(Number(row.assignment_id) + ":" + Number(row.student_id));

  const studentsByKey = new Map<string, Set<number>>();
  const studentsByName = new Map<string, Set<number>>();
  const classKeyByStudentAndName = new Map<string, string>();
  for (const row of enrollmentRows.results || []) {
    const studentId = Number(row.student_id);
    const classKey = String(row.class_key || "");
    const className = String(row.class_name || "");
    if (classKey) {
      if (!studentsByKey.has(classKey)) studentsByKey.set(classKey, new Set());
      studentsByKey.get(classKey)!.add(studentId);
    }
    if (className) {
      if (!studentsByName.has(className)) studentsByName.set(className, new Set());
      studentsByName.get(className)!.add(studentId);
      if (classKey) classKeyByStudentAndName.set(studentId + "||" + className, classKey);
    }
  }

  let created = 0;
  let sent = 0;
  const createdAt = now.toISOString();
  for (const assignment of upcoming) {
    const deadline = assignmentDeadlineMs(String(assignment.due_date || ""));
    if (!Number.isFinite(deadline) || deadline <= now.getTime()) continue;
    const candidates = studentsByKey.get(String(assignment.class_key || "")) || studentsByName.get(String(assignment.class_name || "")) || new Set<number>();
    for (const studentId of candidates) {
      if (completed.has(Number(assignment.id) + ":" + studentId)) continue;
      const eventKey = "assignment-due:" + Number(assignment.id) + ":" + studentId + ":" + Math.trunc(deadline);
      const itemKey = eventKey.replace(/:/g, "-");
      const resolvedClassKey = String(assignment.class_key || "") || classKeyByStudentAndName.get(studentId + "||" + String(assignment.class_name || "")) || "";
      const body = "Bài tập “" + String(assignment.title || "Bài tập") + "” – " + String(assignment.class_name || "Lớp học") + " sắp tới hạn nộp. Hạn nộp: " + formatAssignmentDeadline(String(assignment.due_date || "")) + ". Hãy hoàn thành bài trước thời hạn.";
      const data = JSON.stringify({
        body,
        audience: "student",
        studentId,
        className: String(assignment.class_name || ""),
        classKey: resolvedClassKey,
        actionView: "assignments",
        category: "assignment_due",
        automatic: true,
        assignmentId: Number(assignment.id),
        dueDate: String(assignment.due_date || ""),
        adminReadAt: null,
        studentReadAt: null,
        readByStudentIds: [],
      });
      const insert = await db.prepare(`
        INSERT OR IGNORE INTO admin_items (kind, item_key, title, data, created_at, updated_at)
        VALUES ('notifications', ?, ?, ?, ?, ?)
      `).bind(itemKey, "Bài tập sắp tới hạn", data, createdAt, createdAt).run();
      if (!insert.meta?.changes) continue;
      created += 1;
      const result = await sendPushToStudent(studentId, {
        title: "Bài tập sắp tới hạn",
        body,
        url: resolvedClassKey ? "/student?courseId=" + encodeURIComponent(resolvedClassKey) + "&tab=assignments&assignmentId=" + Number(assignment.id) : "/student",
        tag: "assignment-due-" + Number(assignment.id) + "-" + studentId,
        category: "assignment",
        relatedId: Number(assignment.id),
      }, eventKey);
      sent += result.sent;
    }
  }
  return { checked: upcoming.length, created, sent };
}
