// Only statuses backed by real student work belong in submission queries.
// `teacher_completed` remains a UI compatibility status and is persisted in
// assignment_teacher_completions from V25.1 onward.
export const COMPLETED_SUBMISSION_STATUSES = ["submitted", "graded"] as const;
export const STUDENT_SUBMITTED_STATUSES = ["submitted", "graded"] as const;

export function isAssignmentCompletedStatus(status: string | null | undefined): boolean {
  return status === "submitted" || status === "graded" || status === "teacher_completed";
}

export function isStudentSubmittedStatus(status: string | null | undefined): boolean {
  return status === "submitted" || status === "graded";
}

export function isDraftSubmissionStatus(status: string | null | undefined): boolean {
  return status === "draft";
}

export function isTeacherCompletedStatus(status: string | null | undefined): boolean {
  return status === "teacher_completed";
}

export function isLegacyCompletionPlaceholder(value: string | null | undefined): boolean {
  return String(value || "").trim() === "Đã hoàn thành theo dữ liệu cũ";
}
