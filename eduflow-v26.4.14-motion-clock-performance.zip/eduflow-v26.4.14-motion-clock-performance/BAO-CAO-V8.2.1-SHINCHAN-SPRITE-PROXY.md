# EDUFLOW V8.2.1 — Shinchan sprite proxy fix

## Hiện tượng
Card Focus Pet tải được metadata Petdex nhưng vùng pet trắng.

## Nguyên nhân
Frontend V8.2 dùng trực tiếp `spritesheetUrl` từ asset host của Petdex. Metadata có thể tải thành công từ Worker nhưng trình duyệt vẫn có thể bị chặn khi nhúng asset cross-site, tạo trạng thái “Petdex · Shinchan” nhưng sprite không render.

## Sửa lỗi
- Chuyển spritesheet qua route same-origin `/api/student/pet/sprite`.
- Route yêu cầu student session, allowlist host Petdex, kiểm tra redirect, MIME và kích thước.
- Renderer preload ảnh; loading/error đều có fallback hiển thị, không còn vùng trắng im lặng.

## Phạm vi
Không đổi migration, D1 schema, streak, Freeze, Pomodoro, điểm số, điểm danh buổi học, API học thuật hoặc bố cục Astryx/TasteSkill ngoài trạng thái hiển thị pet.
