# EDUMATH CLOUDFLARE V19.8.3

## Root cause

- Popup báo cáo được render bên trong `.view-transition`. Animation của vùng này tạo `transform`, khiến phần tử `position: fixed` bên dưới bị ràng buộc vào containing block của tab và bị clip khi tab Tổng quan ngắn.
- `statusForDate` chỉ trả về `unmarked` khi ngày thuộc lịch lặp và `date <= today`, nên các buổi học tương lai bị đổi thành `none`.
- API đăng nhập Admin và học sinh chỉ xác minh PIN, chưa có trạng thái số lần sai hoặc thời điểm khóa ở backend.

## Files changed

- `app/class-hub.tsx`
- `app/globals.css`
- `app/api/admin/session/route.ts`
- `app/api/student/session/route.ts`
- `db/schema.ts`
- `lib/login-security.ts`
- `drizzle/0004_last_sugar_man.sql`
- `drizzle/meta/0004_snapshot.json`
- `drizzle/meta/_journal.json`
- `tests/report-calendar-security.test.mjs`
- `cap-nhat-cloudflare.ps1`
- `HUONG-DAN-CAP-NHAT.txt`
- `package.json`
- `package-lock.json`

## Nội dung đã sửa

### A. Report Modal

- Render modal qua React portal trực tiếp vào `document.body`.
- Overlay bám viewport, modal giới hạn bằng `100dvh`, content cuộn độc lập và footer luôn nằm trong vùng thao tác.
- Khóa scroll nền khi mở; khôi phục khi đóng; hỗ trợ phím Escape và thuộc tính dialog accessibility.

### B. Attendance Calendar

- Ưu tiên attendance record; nếu chưa có record nhưng ngày thuộc lịch lớp thì hiển thị `Chưa điểm danh`, kể cả tương lai.
- Dùng mốc ngày hiện tại theo `Asia/Ho_Chi_Minh`.
- Chỉ tô vòng tròn quanh số ngày hôm nay; giữ nguyên màu và layout calendar.

### C. Login Security

- Tối đa 5 lần nhập sai liên tiếp; khóa 15 phút sau lần thứ 5.
- Kiểm tra trạng thái khóa trước khi xác minh PIN.
- Cảnh báo số lần còn lại từ lần sai thứ 3; trả `retryAfter` khi bị khóa.
- Đăng nhập đúng sẽ xóa bộ đếm; khóa hết hạn sẽ tự reset.
- Khóa theo từng tài khoản, không khóa toàn bộ học sinh chỉ vì dùng chung mạng trường.

## Database changes

- Migration `0004_last_sugar_man.sql` tạo bảng `login_attempts` gồm khóa tài khoản dạng băm, số lần sai, thời điểm khóa và thời điểm cập nhật.
- Migration dùng `CREATE TABLE IF NOT EXISTS` để lần chạy lại không lỗi nếu bảng đã được tạo nhưng Wrangler chưa ghi nhận migration hoàn tất.
- Không DROP/ALTER bảng cũ; không xóa hoặc reset dữ liệu D1/R2.

## Test result

- Build: PASS.
- Tests: PASS, 9/9.
- Lint: PASS với 0 lỗi; còn 4 warning có sẵn trong `app/page.tsx` từ bản trước.
- Typecheck riêng: FAIL do các lỗi type Cloudflare/Worker và file example có sẵn từ bản trước; build production vẫn PASS và thay đổi mới không phát sinh lỗi type trong log.
- Responsive: kiểm tra tĩnh PASS cho `100dvh`, content scroll, footer cố định trong modal và breakpoint mobile. Không thể hoàn tất kiểm tra trình duyệt vì môi trường preview chỉ hỗ trợ compatibility date đến `2026-05-22`, trong khi project đang dùng `2026-08-13`.
