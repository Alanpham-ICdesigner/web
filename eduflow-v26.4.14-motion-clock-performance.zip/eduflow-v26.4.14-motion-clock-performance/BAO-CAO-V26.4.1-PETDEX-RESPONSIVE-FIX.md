# EDUFLOW V26.4.1

## Root cause

1. The Petdex picker lived below `.lms-home`. That ancestor keeps a CSS transform after its entry animation, so the picker's `position: fixed` was resolved against the long LMS surface instead of the visual viewport.
2. Every mounted pet card called `new Image()` immediately with a third-party R2 URL. There was no viewport gate, same-origin asset path, timeout or per-pet retry.
3. Manifest failures were swallowed and silently reduced the catalog to Punch, which made a remote outage indistinguishable from an empty catalog.
4. A card click wrote D1 immediately and closed the modal, so there was no real preview-confirm flow.

## Changes

- The picker is rendered into `document.body` with a portal.
- Body scroll lock preserves and restores the exact scroll position on iOS.
- Escape, Tab focus containment and focus return are implemented.
- Desktop uses a centered bounded dialog. Touch/mobile uses a bottom sheet bounded by `100dvh` and iOS safe-area insets.
- Header, tools and footer remain available while only the pet list scrolls.
- Catalog search is debounced and requests are cancelled when superseded.
- Catalog results use 24-item offset pages and dynamic facets from real `kind`, `tags` and `version` fields.
- Sprites begin loading only within 240px of the list viewport.
- Remote sprites are streamed through `/api/student/pets/asset`, restricted to the canonical Petdex asset host and cached by the browser.
- Failed images show a fallback and retry control without breaking other cards.
- Selecting a card updates preview only. The existing D1 `pet_slug` is changed only by the footer confirmation button.

## Data and PWA

- No new D1 migration is required. `student_pet_profiles.pet_slug` already stores the selection per account and therefore remains cross-device.
- `public/sw.js` is unchanged because it has no fetch handler and does not cache Petdex assets.
- Punch remains the local fallback and all visual skins continue using the existing Punch action state machine.

## Validation

- `npx tsc --noEmit`: passed with no TypeScript errors.
- `npm test`: production build passed; 222/222 regression tests passed.
- ESLint on every changed source and test file: passed with no errors or warnings.
- The production artifact exposes an ESM Worker `default.fetch` entry and retains the existing D1/R2 hosting manifest.
- The managed visual-preview runtime could not boot because its Cloudflare worker binary supports compatibility dates only through 2026-05-22 while EDUFLOW targets 2026-08-13. The production date was intentionally preserved; responsive behavior is covered by the new source-level viewport regression tests.
