# EDUFLOW V26.4.14 — Motion / Clock Performance

Base trực tiếp: **V26.4.13 Spotify Mobile Playback**.

## Mục tiêu

- Không rollback bất kỳ tính năng V26.4.13 nào.
- Đồng hồ điện tử không dịch trái/phải khi chữ số thay đổi.
- Flip clock dùng split-flap thật, chỉ animate digit thay đổi.
- Giảm jank của Focus Space và motion toàn app, đặc biệt iOS/Android PWA.

## Thay đổi chính

1. **Digital clock fixed glyph slots**
   - 4 digit slot có chiều rộng cố định và 1 separator slot cố định.
   - `tabular-nums` vẫn được bật nhưng layout không còn phụ thuộc font có hỗ trợ hoàn hảo hay không.

2. **Flip clock mới**
   - Không animate cả card bằng `filter + perspective + scale` 720–820ms nữa.
   - Mỗi digit có static top/bottom và 2 half-leaf chỉ xuất hiện khi digit đổi.
   - Top leaf 165ms + bottom leaf 165ms; chỉ `transform: rotateX()`.
   - Không remount digit container theo giá trị, nên geometry ổn định.

3. **Pomodoro render cadence**
   - Bỏ tick 500ms (`2 Hz`) ở parent.
   - Countdown cập nhật đúng theo ranh giới giây hiển thị, xấp xỉ `1 Hz`.
   - Visibility resume vẫn đồng bộ ngay khi quay lại tab/app.

4. **Pet sprite**
   - Bỏ `setInterval + setFrame()` 125ms trong React.
   - Sprite sheet chạy bằng một image track với CSS `translate3d + steps()`.
   - Giảm React render liên tục và tránh background-position repaint mỗi frame.

5. **Motion / blur pass**
   - Loại entrance animation chồng lớp ở dashboard/LMS.
   - Card hover không translate + repaint shadow lớn.
   - Focus aura trở thành radial tĩnh; bỏ animation trên vùng lớn.
   - Focus Space bỏ backdrop-filter trên topbar/dock/floating panels/mode/settings.
   - Mobile/touch tắt backdrop-filter ở các glass surface toàn app.
   - Floating window enter còn 150ms opacity + translate, không scale overshoot.

## File chính

- `app/student/focus-studio.tsx`
- `app/student/pet-focus-companion.tsx`
- `app/motion-performance.css`
- `app/layout.tsx`

