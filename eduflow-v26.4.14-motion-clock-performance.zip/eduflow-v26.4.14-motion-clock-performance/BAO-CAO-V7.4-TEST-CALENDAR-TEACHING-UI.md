# EDUFLOW V20 — V7.4

Nền: V7.3.

## Thay đổi

- Giữ tab Lịch học tổng hợp ở trang chủ học sinh.
- Trong từng môn, tab **Lịch học** được đổi thành **Lịch kiểm tra** và chỉ hiển thị lịch kiểm tra của môn/lớp đang mở.
- Trang Admin **Lịch học** được đổi thành **Lịch kiểm tra**, có bộ lọc lớp và khi tạo lịch bắt buộc chọn lớp. Dữ liệu lưu `classKey`, `className`, `type=Kiểm tra` để portal học sinh lọc đúng enrollment.
- Tab **Thi đua & Tích điểm**: bảng **Điểm học sinh** được đưa lên trước **Quy tắc cộng / trừ điểm** và **Kho quà**.
- **Lịch dạy**: card luôn hiện tên lớp, giờ bắt đầu–kết thúc và phòng. Lịch trùng giờ xếp chồng có chỉ báo; click/tap card nào thì card đó nổi lên trên và mở rộng để hiện ghi chú, sửa/xóa và Điểm danh.
- Audit tương tác theo TasteSkill: button, link, select, role=button, checkbox/radio có cursor pointer; disabled giữ not-allowed; bổ sung hover/focus/active states.
- Sửa nút “Xem lịch” ở dashboard để đi đúng trang **Lịch dạy** thay vì lịch kiểm tra.

## An toàn dữ liệu

- Không thêm migration D1.
- Không đổi D1/R2/Worker binding.
- Giữ toàn bộ V7.3: report QR góc phải, buổi học bù dưới lịch điểm danh, Số buổi học A/B, thông báo, nhắn tin, multi-course, reward UI.

## Kiểm tra

- 62/62 source regression tests pass khi loại test rendered-html cần `dist/server/index.js` đã build.
- 4/4 test riêng V7.4 pass.
- TypeScript transpile syntax: `app/page.tsx`, `app/student/page.tsx`, `app/api/student/portal/route.ts` đều OK.
