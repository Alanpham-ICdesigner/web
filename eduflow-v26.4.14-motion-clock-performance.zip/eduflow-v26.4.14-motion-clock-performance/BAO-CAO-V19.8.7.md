# PHMT MATH v19.8.7 — Báo cáo sửa lỗi

## Tài liệu trên web giáo viên

- Hoàn nguyên danh sách tài liệu về đúng cấu trúc và giao diện của v19.8.5.
- Tên tệp luôn lấy từ tên gốc đã lưu trong cơ sở dữ liệu, không còn bị metadata cũ hoặc tên thư mục ghi đè.
- Giữ nguyên giao diện tài liệu mới trên web học sinh.

## Cửa sổ chi tiết bài tập

- Khóa cuộn trang nền khi cửa sổ chi tiết đang mở.
- Chỉ cuộn danh sách học sinh khi danh sách dài.
- Giữ phần tiêu đề, thống kê và nút Đóng ổn định trong khung nhìn.
- Cố định hàng tiêu đề của bảng học sinh trong lúc cuộn.

## Căn chỉnh giao diện

- Sửa danh sách lịch sử khi chọn “Tất cả lớp”: mỗi buổi chỉ còn một biểu tượng và một nút xóa, các buổi xếp theo từng dòng.
- Nút xóa thư mục được thu gọn và nằm hoàn toàn bên trong thẻ thư mục.
- Các trạng thái chưa có dữ liệu hiển thị thành một hàng, căn giữa toàn bộ thẻ.
- Nút “Đánh dấu tất cả đã đọc” trên web học sinh hiển thị chữ ngang và căn giữa.

## Xác minh

- Build production thành công.
- 24/24 kiểm thử tự động đạt.
- ESLint không có lỗi; còn 4 cảnh báo có sẵn từ trước.
