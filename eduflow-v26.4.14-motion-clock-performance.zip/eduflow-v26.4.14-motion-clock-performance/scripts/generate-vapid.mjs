import { webcrypto } from "node:crypto";

function base64Url(bytes) {
  return Buffer.from(bytes).toString("base64url");
}

const pair = await webcrypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
const publicRaw = await webcrypto.subtle.exportKey("raw", pair.publicKey);
const privateJwk = await webcrypto.subtle.exportKey("jwk", pair.privateKey);
process.stdout.write(JSON.stringify({
  publicKey: base64Url(new Uint8Array(publicRaw)),
  privateJwk: JSON.stringify(privateJwk),
}));
