# EDUFLOW V20 — V7.5

Nền: V7.4. Không thay đổi database schema, D1/R2 bindings, routes cũ hoặc nhận diện PHMT MATH.

## Thay đổi

1. Sidebar giáo viên kéo-thả trực tiếp để đổi thứ tự; thứ tự lưu ở localStorage của trình duyệt.
2. Lịch dạy GV và lịch học tổng hợp HS có vùng cuộn dọc/ngang riêng. Khung thời gian luôn bao phủ từ trước 07:00 và tự cuộn tới khoảng 07:00 khi mở/đổi tuần, nên có thể kéo lên xem sớm hơn hoặc kéo xuống xem tối muộn.
3. Lịch trùng giờ: click/tap card đang nổi trên cùng sẽ luân phiên đưa card phía sau lên trên. Keyboard Enter/Space dùng cùng hành vi.
4. Các vùng lịch sử dài (điểm danh, đổi quà, cộng/trừ điểm, nhận xét, hoạt động, điểm học tập, thông báo, danh sách lịch kiểm tra và các bảng lịch sử liên quan) được giới hạn chiều cao và tự có scrollbar.
5. Chat đổi sang dạng Messenger trực tiếp, không chia theo môn: GV có ô tìm học sinh trên cùng, danh sách hội thoại ở dưới và khung chat; HS có một cuộc trò chuyện trực tiếp với GV. Badge chưa đọc vẫn giữ.
6. Recheck TasteSkill toàn giao diện HS/GV: điều chỉnh nhịp spacing, typography, control height, hover/focus/cursor, scrollbar và responsive mà không redesign thương hiệu.
7. Script deploy tự retry `npm ci` tối đa 3 lần khi kết nối npm bị reset; website chưa bị thay đổi nếu cài thư viện vẫn thất bại.

## Kiểm tra

- Node regression tests không phụ thuộc build: pass.
- Test riêng V7.5: sidebar drag, timetable scroll/cycle, history overflow, messenger direct.
- TypeScript syntax check cho các file TS/TSX sửa: pass.
- `rendered-html.test.mjs` cần `dist/` sau `vinext build`, nên không chạy được trong artifact chưa cài dependencies.
