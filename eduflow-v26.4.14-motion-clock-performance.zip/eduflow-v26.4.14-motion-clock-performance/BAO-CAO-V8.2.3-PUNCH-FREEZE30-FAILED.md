# EDUFLOW V8.2.3 — Punch + Freeze 30 ngày + Failed reaction

## Thay đổi chính

- Thay Shinchan bằng pet khỉ **Punch** từ `monkeypet.zip` do người dùng cung cấp.
- Asset được bundle local tại `public/pets/punch/`; website không cần tải spritesheet từ Petdex lúc runtime.
- Giữ nguyên hệ 9 state trên spritesheet 8×9: idle, run right, run left, waving, jumping, failed, waiting, running, review.
- Giữ chức năng đổi tên pet theo từng học sinh. Các tên tùy chỉnh cũ được giữ nguyên; chỉ tên mặc định `Shinchan` được đổi thành `Punch`.

## Streak Freeze mới

- Bỏ cơ chế hồi Freeze theo đầu tháng.
- Freeze chỉ tự dùng khi học sinh **quên đúng 1 ngày** và Freeze đang sẵn sàng.
- Sau khi Freeze được dùng, bắt đầu cooldown **30 ngày kể từ chính ngày dùng**.
- Ví dụ dùng ngày 03/09/2026 → có lại vào 03/10/2026 theo `Asia/Ho_Chi_Minh`.
- UI hiển thị nhỏ ngay cạnh chip Freeze: `Có lại sau N ngày`; khi sẵn sàng hiển thị `Sẵn sàng`.
- Migration V8.2.3 thêm `freeze_last_used_date` và backfill từ lịch sử `student_daily_checkins.used_freeze=1`, nên lần dùng Freeze cũ gần nhất không bị quên.

## Phản ứng Failed

- Nếu vào Trang chủ HS và hệ thống phát hiện đã bỏ lỡ ít nhất một ngày check-in, Punch chạy state `failed` khoảng **10 giây**.
- Nếu bấm **Kết thúc** Pomodoro trước khi phiên tự hoàn tất, Punch chạy `failed` khoảng **10 giây**.
- Check-in thành công/milestone có thể ghi đè ngay animation failed bằng animation thành công; không khóa thao tác của học sinh.

## An toàn dữ liệu / logic

- Không thay đổi điểm thi đua, điểm danh buổi học, bài tập, tài liệu, R2 hoặc các bảng học tập.
- Migration mới là additive: thêm một cột và cập nhật metadata pet/freeze hiện có, không DROP/TRUNCATE/DELETE dữ liệu.
- Pomodoro vẫn tạm dừng khi rời Trang chủ, reload hoặc đóng tab như V8.2.2.
- Pet vẫn chỉ mount tại Trang chủ HS / Các môn học của tôi.
- Astryx + TasteSkill tiếp tục là guardrail UI; chip cooldown được giữ compact và responsive.
