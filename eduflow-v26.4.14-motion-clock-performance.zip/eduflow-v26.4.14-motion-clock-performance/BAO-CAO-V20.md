# BÁO CÁO NÂNG CẤP EDUFLOW / PHMT MATH V20

## Phạm vi

V20 được nâng cấp trực tiếp từ source V19.8.9 theo nguyên tắc minimal change. Không đổi schema D1, API contract, R2, route, phân quyền, font, logo, màu chủ đạo hoặc cấu trúc điều hướng.

## Root cause và cách sửa

1. Nội dung dài: một số grid dùng cột `1fr` và các flex child/card chưa có `min-width: 0`; title/body/URL chưa có clamp nên chuỗi dài có thể mở rộng container. V20 dùng `minmax(0, 1fr)`, `min-width: 0`, line-clamp 2 dòng và `overflow-wrap: anywhere` tại đúng component.
2. Bảng mobile: `.scroll-region` khai báo sau đã ghi đè `overflow-x` thành `hidden`, vì vậy bảng học sinh rộng 900px không vuốt ngang được. V20 khôi phục `overflow-x: auto` riêng cho wrapper bảng và giữ pagination bên ngoài.
3. Thống kê bài tập: một số nơi dùng số row submission hoặc độ dài mảng trực tiếp. V20 gom theo `Set` để đếm distinct `(assignmentId, studentId)`, distinct học sinh trên từng bài và distinct assignment trên từng học sinh.
4. Popup thông báo: action mark-all nằm sau vòng lặp render danh sách, trong cùng vùng scroll. V20 tách thành header, action cố định và `notification-list` cuộn riêng.

## Logic bài tập

- Total: số assignment của lớp học sinh.
- Open / Ending soon / Ended: tính từ deadline bằng `getAssignmentStatus`; deadline không đồng nghĩa hoàn thành.
- Pending grading: giữ logic hiện tại của giao diện giáo viên, dựa trên tiến độ nộp của bài.
- Completed: số `assignmentId` distinct có submission của đúng học sinh.
- Submitted X/Y: X là số `studentId` distinct đã nộp bài; Y là số học sinh hiện thuộc lớp được giao bài.

Do đó, giáo viên tạo 10 bài nhưng học sinh chỉ hoàn thành 1 bài thì `Completed = 1`. Nhiều row submission trùng học sinh/bài (nếu dữ liệu cũ bất thường) vẫn chỉ tính một lần.

## Cấu trúc popup mới

```text
Notification popup
├── Header
├── Mark all read
└── Scrollable notification list
```

Với 25 thông báo chưa đọc, nút “Đánh dấu tất cả đã đọc” xuất hiện ngay dưới header khi mở popup; người dùng không phải kéo xuống cuối. Nút có trạng thái đang xử lý để chặn gửi request trùng và badge chỉ cập nhật sau response thành công.

## Files changed

- `app/api/assignments/route.ts`
- `app/api/assignments/[id]/submissions/route.ts`
- `app/api/student/portal/route.ts`
- `app/api/student/submissions/route.ts`
- `app/page.tsx`
- `app/student/page.tsx`
- `app/globals.css`
- `tests/v20-responsive-assignment-notification.test.mjs`
- `package.json`
- `package-lock.json`
- `cap-nhat-cloudflare.ps1`
- `HUONG-DAN-CAP-NHAT.txt`

## Triển khai

Giải nén ZIP, mở PowerShell đúng thư mục có `package.json`, rồi chạy duy nhất:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Script vẫn build, chạy test và dry-run trước khi hỏi xác nhận deploy; D1 và R2 hiện tại được giữ nguyên.

## Verification

- Build: PASS; đã tạo Worker ESM và hosting manifest hợp lệ.
- Tests: PASS 31/31, không có test fail/skip.
- API assignment/submission: PASS qua kiểm tra distinct assignment và distinct student.
- Completed count: PASS case 10 assignment / 1 assignment hoàn thành → 1.
- Submission count: PASS dữ liệu trùng cùng học sinh/bài vẫn tính 1.
- Text overflow: PASS kiểm tra selector clamp 2 dòng, `min-width: 0`, `overflow-wrap: anywhere`.
- Table scroll: PASS kiểm tra wrapper có `overflow-x: auto` và touch scrolling; pagination vẫn nằm ngoài wrapper.
- Notification structure: PASS; action đứng trước `notification-list`, list cuộn riêng.
- Mark all read / unread badge: PASS kiểm tra state chỉ cập nhật sau response thành công và có khóa chống request trùng.
- Light/dark mode: PASS kiểm tra dùng theme token hiện tại, không hard-code nền trắng cho action mới.
- Lint: 0 error; còn 4 warning có sẵn trong `app/page.tsx`, không thuộc phạm vi V20.
- Desktop/mobile browser preview: môi trường preview không khởi động được do runtime kiểm thử chỉ hỗ trợ compatibility date cũ hơn project. Build production và toàn bộ kiểm tra cấu trúc responsive vẫn PASS; không ghi nhận browser PASS khi chưa chạy được.
- Deploy: chưa thực hiện.
