# V23.1 — Assignment link & multi-file submission

- URL trong mô tả bài tập được hiển thị thành nút **Mở liên kết**, mở tab mới an toàn.
- Nhãn **Yêu cầu** tăng hierarchy bằng font-weight theo hệ typography hiện tại, không tạo style hệ riêng.
- File picker được thay native chrome bằng control TasteSkill: nút chọn tệp rõ ràng, danh sách file, dung lượng từng file, xóa từng file và tổng dung lượng.
- Học sinh chọn nhiều JPG/PNG/WEBP/PDF; **tổng tất cả file tối đa 10 MB** (kiểm tra cả client và server).
- D1 thêm bảng `assignment_submission_files` theo migration additive; dữ liệu file nộp cũ được backfill.
- GV xem/chấm bài có thể mở từng file trong bài nộp nhiều tệp.
- Không thay đổi logic điểm, chuyên cần, streak, Pomodoro, lớp học, R2 bucket hay các route LMS khác.
- Motion chỉ dùng transform/background nhẹ, có `prefers-reduced-motion`.
