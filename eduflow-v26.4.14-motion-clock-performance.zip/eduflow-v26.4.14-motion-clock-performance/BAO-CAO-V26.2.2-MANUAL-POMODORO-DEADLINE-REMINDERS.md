# EDUFLOW V26.2.2 — Manual Pomodoro + Assignment Deadline Reminders

Base: **EDUFLOW V26.2.1 sleep-safe Pomodoro**. Bản này giữ nguyên các thay đổi trước đó (multi-class student edit, grading queue, mobile teacher logout, student session 30 ngày, sleep-safe/cross-device Pomodoro) và bổ sung hai nhóm chức năng mới.

## 1. Bổ sung Pomodoro ngoài EDUFLOW theo từng ngày

### Giao diện giáo viên
- Chỉ hiện ở **Thống kê → Ngày**, ngay dưới bảng thống kê hiện tại.
- Chọn học sinh của ngày đang xem.
- Hiển thị riêng:
  - thời gian Pomodoro hệ thống ghi nhận từ web;
  - thời gian giáo viên bổ sung ngoài web (giờ + phút);
  - tổng sau điều chỉnh;
  - ghi chú tùy chọn.
- Sau khi lưu thành công, số Pomodoro trên bảng **cập nhật ngay, không cần F5**.
- Khi chuyển sang Tuần/Tháng, API thống kê cộng luôn phần bổ sung của các ngày trong khoảng đó.

### Nguyên tắc dữ liệu
- Không sửa hoặc tạo giả `student_focus_sessions`.
- Không cộng số phiên Pomodoro hoàn tất.
- Không kích hoạt Break/Pet/session-complete notification.
- Công thức thống kê:
  - `Pomodoro hiển thị = trackedFocusMinutes + manualFocusMinutes`.
- Giới hạn tổng tối đa 24 giờ/ngày.
- Một học sinh + một ngày chỉ có một bản điều chỉnh, lưu bằng upsert nên sửa lại không bị cộng dồn sai.

### D1 mới
Migration: `drizzle/0014_manual_focus_adjustments.sql`

Bảng mới: `student_focus_adjustments`
- `student_id`
- `date_key`
- `manual_minutes`
- `note`
- `created_at`
- `updated_at`

Unique: `(student_id, date_key)`.

## 2. Tự động thông báo cho học sinh khi GV điều chỉnh Pomodoro

Khi **số phút thực sự thay đổi**:
1. D1 lưu adjustment.
2. D1 tạo targeted in-app notification cho đúng học sinh trong cùng atomic batch.
3. Sau khi D1 thành công, hệ thống gửi Web Push nếu học sinh đã bật Push.

Các trường hợp:
- `0 → >0`: **Bổ sung thời gian Pomodoro**.
- `>0 → số khác`: **Điều chỉnh thời gian Pomodoro**.
- `>0 → 0`: thông báo phần thời gian ngoài EDUFLOW đã được gỡ.
- Chỉ sửa ghi chú, số phút không đổi: lưu ghi chú nhưng **không spam thông báo mới**.

Push failure không rollback dữ liệu D1; in-app notification vẫn tồn tại.

## 3. Nhắc bài tập “Sắp hết hạn”

- Dùng đúng helper `getAssignmentStatus()` hiện tại của UI.
- Ngưỡng hiện tại: **còn tối đa 6 giờ** trước deadline.
- Chỉ gửi cho học sinh đang active trong lớp của assignment và **chưa hoàn thành/nộp**.
- Bỏ qua các trạng thái `submitted`, `graded`, `teacher_completed` và bản ghi trong `assignment_teacher_completions`.
- Tạo cả:
  - thông báo trong EDUFLOW;
  - Web Push nếu đã đăng ký.
- Push mở đúng môn/bài tập khi có `classKey`.

### Chống gửi lặp
Reminder identity:
`assignment + student + deadline cụ thể`.

`admin_items(kind,item_key)` dùng `INSERT OR IGNORE`, đồng thời `push_deliveries` tiếp tục chống duplicate ở tầng Push. Vì deadline nằm trong identity, nếu GV đổi deadline thì deadline mới có thể nhận một reminder mới khi đi vào vùng “Sắp hết hạn”.

### Tần suất nền
- Giữ cron hiện tại `* * * * *` để sleep-safe Pomodoro vẫn reconcile mỗi phút.
- Phần quét assignment chỉ chạy **một lần mỗi giờ** bên trong cron hiện tại; không thêm cron/request riêng mỗi phút cho assignment.
- Nếu GV **tạo hoặc sửa** một assignment và deadline đã nằm ngay trong vùng “Sắp hết hạn”, route assignment gọi reminder ngay, không chờ tới đầu giờ tiếp theo. Cơ chế idempotent ngăn cron gửi trùng.

## 4. UI foundation

Phần mới giữ nguyên visual language hiện có và dùng Astryx + TasteSkill làm nền:
- semantic tokens hiện tại;
- responsive desktop/tablet/mobile;
- touch target mobile >= 44px;
- input mobile >= 16px để tránh Safari iOS zoom;
- không tạo dashboard style tách rời khỏi EDUFLOW.

## 5. Files chính đã thay đổi

- `drizzle/0014_manual_focus_adjustments.sql`
- `db/schema.ts`
- `app/api/admin/student-engagement/route.ts`
- `app/admin/student-engagement-stats.tsx`
- `app/astryx-taste-deep.css`
- `lib/web-push.ts`
- `worker/index.ts`
- `app/api/assignments/route.ts`
- `tests/v26.2.2-manual-pomodoro-deadline-reminders.test.mjs`
- `package.json`
- `package-lock.json`
- `cap-nhat-cloudflare.ps1`
- `DEPLOY-EDUFLOW.bat`

## 6. Kiểm thử đã chạy trong môi trường tạo source

- Static regression tests (không gồm `rendered-html.test.mjs` vì cần output build): **205/205 PASS**.
- TypeScript/TSX syntax transpile cho 6 file logic thay đổi chính: **6/6 PASS**.

Full `vinext build` không chạy được trong môi trường đóng gói do không có dependency cache/network ổn định để `npm ci`. Vì vậy không ghi nhận build giả. Script deploy trên máy Windows của bạn vẫn giữ guardrail:

`npm ci → vinext build → toàn bộ tests (bao gồm rendered-html) → Cloudflare dry-run → D1 migration → xác minh schema → deploy`.

Nếu build/test/dry-run/migration verify lỗi, script dừng trước khi cập nhật Worker production.

## 7. Migration / Deploy

**Migration required: YES** — `0014_manual_focus_adjustments.sql`.

Không có thay đổi R2.

Deploy:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\cap-nhat-cloudflare.ps1
```

Hoặc chạy `DEPLOY-EDUFLOW.bat`.
