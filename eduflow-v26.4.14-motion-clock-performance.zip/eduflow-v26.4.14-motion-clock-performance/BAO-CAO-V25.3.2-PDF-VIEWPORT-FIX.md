# EDUFLOW V25.3.2 — PDF viewport fix

## Lỗi
Viewer PDF của tab **Tài liệu** được render bên trong `.lms-course-page`. Entrance animation của Taste/Astryx dùng `transform`, và `animation-fill-mode: both` giữ một containing block sau khi animation kết thúc. Vì vậy `position: fixed` của overlay có thể bị ràng buộc theo vùng nội dung thay vì viewport trình duyệt, làm modal tràn ra ngoài vùng đó và bị cắt ở mép phải/đáy.

## Sửa
- `FileViewerModal` dùng `createPortal(..., document.body)` để thoát khỏi mọi stacking/containing context của LMS.
- Geometry modal dùng `100dvw/100dvh`, có `max-width/max-height` và `scrollbar-gutter` để ổn định khi scrollbar xuất hiện.
- Khóa scroll của trang phía sau trong lúc viewer mở.
- Motion mở viewer ngắn, chỉ opacity/transform và tôn trọng `prefers-reduced-motion`.

## Không thay đổi
- Continuous vertical PDF từ V25.3.
- Toolbar stats/refresh từ V25.3.1.
- API, D1, R2, schema, quyền tải/xem, Assignment/Pomodoro.
