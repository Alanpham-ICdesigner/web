-- EDUFLOW V26 - additive Web Push / PWA storage. No academic rows are deleted or rewritten.
CREATE TABLE IF NOT EXISTS `push_subscriptions` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `student_id` integer NOT NULL,
  `endpoint` text NOT NULL,
  `p256dh` text NOT NULL,
  `auth` text NOT NULL,
  `user_agent` text DEFAULT '' NOT NULL,
  `platform` text DEFAULT '' NOT NULL,
  `enabled` integer DEFAULT 1 NOT NULL,
  `last_success_at` text DEFAULT '' NOT NULL,
  `failure_count` integer DEFAULT 0 NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `push_subscriptions_endpoint_unique` ON `push_subscriptions` (`endpoint`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `push_subscriptions_student_enabled_idx` ON `push_subscriptions` (`student_id`, `enabled`);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `push_deliveries` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `subscription_id` integer NOT NULL,
  `student_id` integer NOT NULL,
  `event_key` text NOT NULL,
  `status` text DEFAULT 'pending' NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`subscription_id`) REFERENCES `push_subscriptions`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `push_deliveries_subscription_event_unique` ON `push_deliveries` (`subscription_id`, `event_key`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `push_deliveries_student_idx` ON `push_deliveries` (`student_id`, `created_at`);
--> statement-breakpoint
ALTER TABLE `student_focus_timer_state` ADD COLUMN `duration_ms` integer DEFAULT 1500000 NOT NULL;
--> statement-breakpoint
ALTER TABLE `student_focus_timer_state` ADD COLUMN `session_id` text DEFAULT '' NOT NULL;
--> statement-breakpoint
UPDATE `student_focus_timer_state`
SET `duration_ms` = CASE WHEN `mode` = 'break' THEN `break_minutes` * 60000 ELSE `focus_minutes` * 60000 END,
    `session_id` = COALESCE(NULLIF(`session_key`, ''), `session_id`)
WHERE `duration_ms` <= 0 OR (`session_id` = '' AND `session_key` <> '');
