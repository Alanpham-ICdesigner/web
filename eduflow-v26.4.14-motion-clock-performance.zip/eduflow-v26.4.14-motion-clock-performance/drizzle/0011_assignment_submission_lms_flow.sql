-- V23.2: normalize only synthetic legacy completion rows created by the old
-- "mark as done" flow. Real student submissions (file/text) are untouched.
UPDATE assignment_submissions
SET
  status = 'teacher_completed',
  response_text = '',
  updated_at = CASE WHEN updated_at = '' THEN submitted_at ELSE updated_at END
WHERE assignment_submissions.status = 'submitted'
  AND COALESCE(assignment_submissions.object_key, '') = ''
  AND COALESCE(assignment_submissions.file_name, '') = ''
  AND (TRIM(COALESCE(assignment_submissions.response_text, '')) = '' OR TRIM(assignment_submissions.response_text) = 'Đã hoàn thành theo dữ liệu cũ')
  AND NOT EXISTS (
    SELECT 1
    FROM assignment_submission_files AS f
    WHERE f.submission_id = assignment_submissions.id
  );
