CREATE TABLE `assignments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`class_name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`due_date` text NOT NULL,
	`max_score` real DEFAULT 10 NOT NULL,
	`status` text DEFAULT 'Đang mở' NOT NULL,
	`submitted_count` integer DEFAULT 0 NOT NULL,
	`total_students` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`class_name` text NOT NULL,
	`average_score` real DEFAULT 0 NOT NULL,
	`attendance_rate` integer DEFAULT 100 NOT NULL,
	`status` text DEFAULT 'Đang học' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `students_code_unique` ON `students` (`code`);