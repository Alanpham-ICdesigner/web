-- EDUFLOW Focus Workspace - personal student tasks linked to completed Pomodoro sessions.
-- Additive only. Academic assignments and existing Pomodoro history are untouched.
CREATE TABLE IF NOT EXISTS `student_focus_tasks` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `student_id` integer NOT NULL,
  `title` text NOT NULL,
  `is_done` integer DEFAULT 0 NOT NULL,
  `sort_order` integer DEFAULT 0 NOT NULL,
  `target_pomodoros` integer DEFAULT 1 NOT NULL,
  `completed_pomodoros` integer DEFAULT 0 NOT NULL,
  `completed_at` text DEFAULT '' NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_focus_tasks_student_done_sort_idx`
ON `student_focus_tasks` (`student_id`, `is_done`, `sort_order`, `id`);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `student_focus_task_sessions` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `student_id` integer NOT NULL,
  `task_id` integer NOT NULL,
  `session_key` text NOT NULL,
  `completed_at` text DEFAULT '' NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`task_id`) REFERENCES `student_focus_tasks`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `student_focus_task_sessions_student_session_unique`
ON `student_focus_task_sessions` (`student_id`, `session_key`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_focus_task_sessions_task_idx`
ON `student_focus_task_sessions` (`task_id`, `completed_at`);
