-- EDUFLOW V26.2.2 - teacher-confirmed Pomodoro time outside EDUFLOW.
-- Additive only: completed timer sessions remain immutable and authoritative.
CREATE TABLE IF NOT EXISTS `student_focus_adjustments` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `student_id` integer NOT NULL,
  `date_key` text NOT NULL,
  `manual_minutes` integer DEFAULT 0 NOT NULL,
  `note` text DEFAULT '' NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `student_focus_adjustments_student_date_unique`
ON `student_focus_adjustments` (`student_id`, `date_key`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_focus_adjustments_date_student_idx`
ON `student_focus_adjustments` (`date_key`, `student_id`);
