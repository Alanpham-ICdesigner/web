-- EDUFLOW V8.2 - student pet, daily streak and focus timer.
-- Additive-only migration: no existing table/column/data is modified or deleted.
CREATE TABLE IF NOT EXISTS `student_pet_profiles` (
  `student_id` integer PRIMARY KEY NOT NULL,
  `pet_slug` text DEFAULT 'shinchan' NOT NULL,
  `pet_name` text DEFAULT 'Shinchan' NOT NULL,
  `current_streak` integer DEFAULT 0 NOT NULL,
  `longest_streak` integer DEFAULT 0 NOT NULL,
  `total_checkins` integer DEFAULT 0 NOT NULL,
  `last_checkin_date` text DEFAULT '' NOT NULL,
  `freeze_used_month` text DEFAULT '' NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `student_daily_checkins` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `student_id` integer NOT NULL,
  `checkin_date` text NOT NULL,
  `checked_at` text NOT NULL,
  `used_freeze` integer DEFAULT 0 NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `student_daily_checkins_student_date_unique` ON `student_daily_checkins` (`student_id`,`checkin_date`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_daily_checkins_student_idx` ON `student_daily_checkins` (`student_id`);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `student_focus_sessions` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `student_id` integer NOT NULL,
  `session_key` text NOT NULL,
  `focus_minutes` integer NOT NULL,
  `started_at` text NOT NULL,
  `completed_at` text NOT NULL,
  `date_key` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `student_focus_sessions_student_key_unique` ON `student_focus_sessions` (`student_id`,`session_key`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_focus_sessions_student_date_idx` ON `student_focus_sessions` (`student_id`,`date_key`);
