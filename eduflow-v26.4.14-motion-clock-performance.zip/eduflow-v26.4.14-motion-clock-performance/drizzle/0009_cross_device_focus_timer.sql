-- EDUFLOW V23 - account-synced Pomodoro state for laptop/mobile handoff.
-- Additive only: academic data, streak history, completed focus sessions and R2 files are untouched.
CREATE TABLE IF NOT EXISTS `student_focus_timer_state` (
  `student_id` integer PRIMARY KEY NOT NULL,
  `mode` text DEFAULT 'focus' NOT NULL,
  `status` text DEFAULT 'idle' NOT NULL,
  `focus_minutes` integer DEFAULT 25 NOT NULL,
  `break_minutes` integer DEFAULT 5 NOT NULL,
  `remaining_ms` integer DEFAULT 1500000 NOT NULL,
  `ends_at` text DEFAULT '' NOT NULL,
  `session_key` text DEFAULT '' NOT NULL,
  `started_at` text DEFAULT '' NOT NULL,
  `revision` integer DEFAULT 0 NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);

CREATE INDEX IF NOT EXISTS `student_focus_timer_running_end_idx`
ON `student_focus_timer_state` (`status`, `ends_at`);
