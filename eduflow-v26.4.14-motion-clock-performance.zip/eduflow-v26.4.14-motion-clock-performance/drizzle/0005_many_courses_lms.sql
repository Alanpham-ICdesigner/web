-- V20 LMS multi-course migration, production-safe variant.
-- Columns on existing tables are ensured by cap-nhat-cloudflare.ps1 before this migration runs.
-- This avoids SQLite `duplicate column name` failures (notably assignment_submissions.score)
-- while preserving all existing D1 rows.
CREATE TABLE IF NOT EXISTS `student_enrollments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`student_id` integer NOT NULL,
	`class_key` text NOT NULL,
	`class_name` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`enrolled_at` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `student_enrollments_student_class_unique` ON `student_enrollments` (`student_id`,`class_key`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_enrollments_student_idx` ON `student_enrollments` (`student_id`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_enrollments_class_idx` ON `student_enrollments` (`class_key`);
--> statement-breakpoint
INSERT OR IGNORE INTO `student_enrollments` (`student_id`,`class_key`,`class_name`,`status`,`enrolled_at`,`created_at`,`updated_at`)
SELECT
	s.`id`,
	COALESCE((SELECT ai.`item_key` FROM `admin_items` ai WHERE ai.`kind` = 'classes' AND ai.`title` = s.`class_name` ORDER BY ai.`id` LIMIT 1), 'legacy:' || lower(replace(s.`class_name`, ' ', '-'))),
	s.`class_name`,
	'active',
	s.`created_at`,
	s.`created_at`,
	CURRENT_TIMESTAMP
FROM `students` s
WHERE trim(s.`class_name`) <> '' AND s.`class_name` <> 'Chưa xếp lớp';
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `course_schedules` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`class_key` text NOT NULL,
	`weekday` integer NOT NULL,
	`start_time` text NOT NULL,
	`end_time` text NOT NULL,
	`room` text DEFAULT '' NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `course_schedules_slot_unique` ON `course_schedules` (`class_key`,`weekday`,`start_time`,`end_time`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `course_schedules_class_idx` ON `course_schedules` (`class_key`);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `course_sessions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`class_key` text NOT NULL,
	`class_name` text NOT NULL,
	`session_type` text DEFAULT 'makeup' NOT NULL,
	`session_date` text NOT NULL,
	`start_time` text NOT NULL,
	`end_time` text NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'scheduled' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `course_sessions_class_idx` ON `course_sessions` (`class_key`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `course_sessions_date_idx` ON `course_sessions` (`session_date`);
--> statement-breakpoint
UPDATE `assignments`
SET `class_key` = COALESCE((SELECT ai.`item_key` FROM `admin_items` ai WHERE ai.`kind` = 'classes' AND ai.`title` = `assignments`.`class_name` ORDER BY ai.`id` LIMIT 1), 'legacy:' || lower(replace(`assignments`.`class_name`, ' ', '-')))
WHERE `class_key` = '';
--> statement-breakpoint
