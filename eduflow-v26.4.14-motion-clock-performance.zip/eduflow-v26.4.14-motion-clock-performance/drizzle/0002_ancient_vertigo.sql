CREATE TABLE `admin_items` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`kind` text NOT NULL,
	`item_key` text NOT NULL,
	`title` text NOT NULL,
	`data` text DEFAULT '{}' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `admin_items_kind_key_unique` ON `admin_items` (`kind`,`item_key`);
--> statement-breakpoint
INSERT INTO `admin_items` (`kind`,`item_key`,`title`,`data`,`created_at`,`updated_at`) VALUES
('classes','class-toan-12a1','Toán 12A1','{"schedule":"Thứ 2 · Thứ 5","studentCount":25,"average":8.2,"attendance":94,"openAssignments":3,"tone":"indigo"}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
('classes','class-toan-11a2','Toán 11A2','{"schedule":"Thứ 3 · Thứ 6","studentCount":22,"average":7.8,"attendance":91,"openAssignments":2,"tone":"green"}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
('classes','class-toan-10a3','Toán 10A3','{"schedule":"Thứ 4 · Thứ 7","studentCount":18,"average":7.5,"attendance":96,"openAssignments":1,"tone":"orange"}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
('folders','folder-common','Tài liệu chung','{}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
('folders','folder-12a1','Toán 12A1','{}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
('calendar','event-12a1','Toán 12A1','{"day":11,"type":"Lịch học","details":"Phòng 302 · 08:00"}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
('notifications','notice-deadline','Nhắc deadline bài tập','{"body":"Hoàn thành bài khảo sát hàm số trước 23:59.","target":"Toàn bộ học sinh"}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
('notes','note-midterm','Nhắc lịch kiểm tra giữa kỳ','{"body":"Chuẩn bị đề và in danh sách phòng thi."}','2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z');
