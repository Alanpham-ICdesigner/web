-- V25.1: teacher completion is intentionally separate from student work.
-- The migration is additive-first. Legacy rows are copied, never deleted.
CREATE TABLE IF NOT EXISTS `assignment_teacher_completions` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `assignment_id` integer NOT NULL,
  `student_id` integer NOT NULL,
  `completed_at` text NOT NULL,
  `updated_at` text NOT NULL,
  FOREIGN KEY (`assignment_id`) REFERENCES `assignments`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `assignment_teacher_completions_unique` ON `assignment_teacher_completions` (`assignment_id`, `student_id`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `assignment_teacher_completions_assignment_idx` ON `assignment_teacher_completions` (`assignment_id`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `assignment_teacher_completions_student_idx` ON `assignment_teacher_completions` (`student_id`);
--> statement-breakpoint
INSERT OR IGNORE INTO `assignment_teacher_completions` (`assignment_id`, `student_id`, `completed_at`, `updated_at`)
SELECT `assignment_id`, `student_id`, COALESCE(NULLIF(`submitted_at`, ''), CURRENT_TIMESTAMP), COALESCE(NULLIF(`updated_at`, ''), NULLIF(`submitted_at`, ''), CURRENT_TIMESTAMP)
FROM `assignment_submissions`
WHERE `status` = 'teacher_completed'
  AND COALESCE(`object_key`, '') = ''
  AND COALESCE(`file_name`, '') = ''
  AND (
    TRIM(COALESCE(`response_text`, '')) = ''
    OR TRIM(`response_text`) = 'Đã hoàn thành theo dữ liệu cũ'
  )
  AND NOT EXISTS (
    SELECT 1 FROM `assignment_submission_files` AS f
    WHERE f.`submission_id` = `assignment_submissions`.`id`
  );
