CREATE TABLE `assignment_submissions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`assignment_id` integer NOT NULL,
	`student_id` integer NOT NULL,
	`submitted_at` text NOT NULL,
	FOREIGN KEY (`assignment_id`) REFERENCES `assignments`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `assignment_submissions_unique` ON `assignment_submissions` (`assignment_id`,`student_id`);--> statement-breakpoint
CREATE INDEX `assignment_submissions_student_idx` ON `assignment_submissions` (`student_id`);--> statement-breakpoint
CREATE TABLE `point_rules` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`trigger` text NOT NULL,
	`points` integer NOT NULL,
	`threshold` integer DEFAULT 1 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
INSERT INTO `point_rules` (`title`,`trigger`,`points`,`threshold`,`active`,`created_at`,`updated_at`) VALUES
	('Đi trễ','attendance_late',-2,1,1,'2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
	('Vắng không phép','attendance_absent',-5,1,1,'2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
	('Có mặt liên tiếp','attendance_present_streak',5,5,1,'2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z'),
	('Hoàn thành bài liên tiếp','assignment_streak',10,3,1,'2026-08-11T00:00:00.000Z','2026-08-11T00:00:00.000Z');
--> statement-breakpoint
CREATE TABLE `point_transactions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`student_id` integer NOT NULL,
	`delta` integer NOT NULL,
	`reason` text NOT NULL,
	`source` text DEFAULT 'admin' NOT NULL,
	`event_key` text,
	`created_at` text NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `point_transactions_student_idx` ON `point_transactions` (`student_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `point_transactions_event_unique` ON `point_transactions` (`student_id`,`event_key`);--> statement-breakpoint
CREATE TABLE `reward_items` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`cost` integer NOT NULL,
	`stock` integer DEFAULT 0 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `reward_redemptions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`student_id` integer NOT NULL,
	`reward_id` integer NOT NULL,
	`cost` integer NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` text NOT NULL,
	`reviewed_at` text,
	FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`reward_id`) REFERENCES `reward_items`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `reward_redemptions_student_idx` ON `reward_redemptions` (`student_id`);--> statement-breakpoint
CREATE INDEX `reward_redemptions_status_idx` ON `reward_redemptions` (`status`);--> statement-breakpoint
CREATE TABLE `student_accounts` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`student_id` integer NOT NULL,
	`pin_hash` text NOT NULL,
	`pin_salt` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `student_accounts_student_unique` ON `student_accounts` (`student_id`);
