CREATE TABLE `deferred_push_notifications` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`student_id` integer NOT NULL,
	`event_key` text NOT NULL,
	`payload` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `deferred_push_notifications_student_event_unique` ON `deferred_push_notifications` (`student_id`,`event_key`);
--> statement-breakpoint
CREATE INDEX `deferred_push_notifications_student_idx` ON `deferred_push_notifications` (`student_id`,`id`);
