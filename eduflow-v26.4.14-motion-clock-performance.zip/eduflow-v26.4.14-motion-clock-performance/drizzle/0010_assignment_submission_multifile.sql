CREATE TABLE IF NOT EXISTS `assignment_submission_files` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `submission_id` integer NOT NULL,
  `object_key` text NOT NULL,
  `file_name` text NOT NULL,
  `file_size` integer DEFAULT 0 NOT NULL,
  `content_type` text DEFAULT '' NOT NULL,
  `created_at` text NOT NULL,
  FOREIGN KEY (`submission_id`) REFERENCES `assignment_submissions`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `assignment_submission_files_submission_idx` ON `assignment_submission_files` (`submission_id`);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `assignment_submission_files_object_unique` ON `assignment_submission_files` (`submission_id`, `object_key`);
--> statement-breakpoint
INSERT OR IGNORE INTO `assignment_submission_files` (`submission_id`, `object_key`, `file_name`, `file_size`, `content_type`, `created_at`)
SELECT `id`, `object_key`, `file_name`, `file_size`, `content_type`, COALESCE(NULLIF(`submitted_at`, ''), datetime('now'))
FROM `assignment_submissions`
WHERE COALESCE(`object_key`, '') <> '';
