CREATE TABLE IF NOT EXISTS `login_attempts` (
	`account_key` text PRIMARY KEY NOT NULL,
	`failed_attempts` integer DEFAULT 0 NOT NULL,
	`locked_until` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL
);
