-- V8.2.4: date-first indexes for the teacher engagement table.
-- Additive only: no rows, columns, or existing indexes are removed.
CREATE INDEX IF NOT EXISTS `student_daily_checkins_date_student_idx`
ON `student_daily_checkins` (`checkin_date`, `student_id`);

CREATE INDEX IF NOT EXISTS `student_focus_sessions_date_student_idx`
ON `student_focus_sessions` (`date_key`, `student_id`);
