-- EDUFLOW V26.2.5 - immutable audit history for teacher Pomodoro adjustments.
-- The daily summary table remains the source for totals; this table records each
-- real change so teachers can trace who was adjusted, for which study date, by
-- how much, and what the resulting daily total became.
CREATE TABLE IF NOT EXISTS `student_focus_adjustment_history` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `student_id` integer NOT NULL,
  `date_key` text NOT NULL,
  `previous_manual_minutes` integer DEFAULT 0 NOT NULL,
  `manual_minutes` integer DEFAULT 0 NOT NULL,
  `delta_minutes` integer DEFAULT 0 NOT NULL,
  `tracked_focus_minutes_snapshot` integer DEFAULT 0 NOT NULL,
  `focus_minutes_after` integer DEFAULT 0 NOT NULL,
  `note` text DEFAULT '' NOT NULL,
  `created_at` text NOT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_focus_adjustment_history_created_idx`
ON `student_focus_adjustment_history` (`created_at`, `id`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `student_focus_adjustment_history_student_date_idx`
ON `student_focus_adjustment_history` (`student_id`, `date_key`, `id`);
--> statement-breakpoint
-- Preserve already-existing V26.2.2/V26.2.4 manual totals as one baseline history row.
INSERT INTO `student_focus_adjustment_history`
  (`student_id`, `date_key`, `previous_manual_minutes`, `manual_minutes`, `delta_minutes`, `tracked_focus_minutes_snapshot`, `focus_minutes_after`, `note`, `created_at`)
SELECT
  a.`student_id`,
  a.`date_key`,
  0,
  a.`manual_minutes`,
  a.`manual_minutes`,
  COALESCE((
    SELECT SUM(f.`focus_minutes`)
    FROM `student_focus_sessions` f
    WHERE f.`student_id` = a.`student_id` AND f.`date_key` = a.`date_key`
  ), 0),
  COALESCE((
    SELECT SUM(f.`focus_minutes`)
    FROM `student_focus_sessions` f
    WHERE f.`student_id` = a.`student_id` AND f.`date_key` = a.`date_key`
  ), 0) + a.`manual_minutes`,
  a.`note`,
  CASE WHEN trim(COALESCE(a.`updated_at`, '')) <> '' THEN a.`updated_at` WHEN trim(COALESCE(a.`created_at`, '')) <> '' THEN a.`created_at` ELSE CURRENT_TIMESTAMP END
FROM `student_focus_adjustments` a
WHERE (a.`manual_minutes` <> 0 OR trim(COALESCE(a.`note`, '')) <> '')
  AND NOT EXISTS (
    SELECT 1
    FROM `student_focus_adjustment_history` h
    WHERE h.`student_id` = a.`student_id` AND h.`date_key` = a.`date_key`
  );
