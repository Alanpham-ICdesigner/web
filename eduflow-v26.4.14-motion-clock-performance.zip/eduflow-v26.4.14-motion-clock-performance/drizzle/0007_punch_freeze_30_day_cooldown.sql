-- EDUFLOW V8.2.3 - Punch pet + rolling 30-day Streak Freeze cooldown.
-- Additive/safe migration: existing streak, check-in, focus and academic data are preserved.
ALTER TABLE `student_pet_profiles` ADD COLUMN `freeze_last_used_date` text DEFAULT '' NOT NULL;
--> statement-breakpoint
UPDATE `student_pet_profiles`
SET `freeze_last_used_date` = COALESCE((
  SELECT MAX(`checkin_date`)
  FROM `student_daily_checkins`
  WHERE `student_daily_checkins`.`student_id` = `student_pet_profiles`.`student_id`
    AND `student_daily_checkins`.`used_freeze` = 1
), '')
WHERE `freeze_last_used_date` = '';
--> statement-breakpoint
UPDATE `student_pet_profiles`
SET `pet_name` = 'Punch'
WHERE `pet_slug` = 'shinchan' AND `pet_name` = 'Shinchan';
--> statement-breakpoint
UPDATE `student_pet_profiles`
SET `pet_slug` = 'punch'
WHERE `pet_slug` = 'shinchan';
