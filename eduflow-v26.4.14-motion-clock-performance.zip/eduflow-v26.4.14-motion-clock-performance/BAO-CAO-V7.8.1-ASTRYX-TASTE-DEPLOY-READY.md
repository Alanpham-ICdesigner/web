# EDUFLOW V20 — V7.8.1 Astryx + Taste Deploy Ready

## Mục tiêu

Bản này xử lý lỗi Windows `@cloudflare/workerd-windows-64 could not be found` và đóng lại source theo workflow deploy sạch. Không đóng gói `node_modules` vào ZIP.

## Deploy một lệnh

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Có thêm `DEPLOY-EDUFLOW.bat` để chạy bằng double-click.

## Dependency / workerd

- `.npmrc` ép `include=optional`.
- `package.json` pin `@cloudflare/workerd-windows-64@1.20260515.1` ở `optionalDependencies`.
- `package-lock.json` giữ đúng platform `win32/x64` cho binary này.
- Mỗi lần deploy chạy `npm ci --include=optional` để `node_modules` được tạo trên chính máy đang deploy.
- Nếu Windows vẫn thiếu `workerd.exe`, PowerShell tự cài lại đúng version trước khi Vite/Miniflare chạy.

## Cloudflare safety

Giữ nguyên:

- Worker: `edumath`.
- D1: `eduflow-db`.
- R2: `eduflow-files`.
- Workflow sửa schema cũ và migration không destructive đã có.
- `--keep-vars` khi deploy.

Script kiểm tra account ID EDUFLOW trước khi dry-run/deploy để tránh deploy nhầm tài khoản Cloudflare.

## Frontend

Giữ lớp TasteSkill hiện tại và bổ sung `app/astryx-taste.css` dựa trên nguyên tắc Astryx:

- motion chỉ dùng để giải thích thay đổi trạng thái;
- không animate các bề mặt dữ liệu ổn định;
- easing giảm tốc tự nhiên, không bounce;
- popup/modal responsive;
- hỗ trợ `prefers-reduced-motion`.

## Kiểm tra

- 80 test source-level đã pass.
- 1 test rendered HTML cần `dist/server/index.js`, chỉ chạy sau production build theo đúng workflow deploy.
- Trong môi trường đóng gói hiện tại, npm registry gặp DNS `EAI_AGAIN`, nên không dùng kết quả mạng đó để thay đổi source/lockfile. Bản nền V7.7.2 đã có build/test report thành công; thay đổi V7.8.1 tập trung vào dependency/deploy và presentation CSS.
