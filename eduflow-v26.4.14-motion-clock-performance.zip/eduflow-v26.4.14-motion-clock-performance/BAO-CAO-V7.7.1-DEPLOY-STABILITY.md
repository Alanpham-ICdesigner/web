# V7.7.1 - Deploy Stability

- Nen: V7.7.
- Khong doi UI/API/database schema.
- Them `account_id` ro rang vao `wrangler.jsonc`.
- Khong con block deploy boi `wrangler secret list` moi lan cap nhat.
- Khong chay lai R2 CORS moi lan cap nhat. Secrets va CORS hien co tren Cloudflare duoc giu nguyen.
- `wrangler whoami` hien output that neu dang nhap loi.
