# EDUFLOW V26.4.5

## Thay đổi

- Notification UX: danh sách vẫn rút gọn 2 dòng; khi học sinh chọn thông báo sẽ mở modal chi tiết với nội dung nguyên văn, xuống dòng và emoji đầy đủ. Thông báo có đích LMS vẫn có nút **Mở mục liên quan**.
- Web Push announcement thêm `notificationId` để khi mở từ push có thể vào đúng nội dung chi tiết.
- Emoji: bổ sung picker nhẹ, không thêm package, dùng chung cho chat giáo viên, chat học sinh và textarea gửi thông báo.
- Progress: ba card **Điểm học tập / Điểm danh / Nhận xét giáo viên** chỉ render 4 mục gần nhất ở mặt card. Nút **Xem chi tiết** mở modal có vùng cuộn riêng, tối ưu desktop và mobile/PWA.
- Xóa lớp: API `/api/admin/items` tự tìm và xóa các record `attendance` theo `classKey`, legacy `classId` hoặc `className` trước khi xóa class. Frontend không archive attendance sang `Chưa xếp lớp`; grade vẫn giữ theo hành vi cũ.

## Giao diện

Các thay đổi dùng token/motion/radius hiện có của Astryx + TasteSkill, không đổi font, logo, route hay mô hình dữ liệu.
