/* eslint-disable @typescript-eslint/no-explicit-any -- Cloudflare injects runtime bindings and Wrangler supplies the concrete production types. */
declare module "cloudflare:workers" {
  export const env: Record<string, any>;
}

type D1Database = any;

interface Fetcher {
  fetch(request: Request): Promise<Response>;
}
