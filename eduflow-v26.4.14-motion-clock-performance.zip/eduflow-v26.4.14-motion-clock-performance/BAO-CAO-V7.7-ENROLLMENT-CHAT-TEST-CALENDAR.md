# EDUFLOW V7.7

Nền: V7.6.4.

## Thay đổi

1. Tin nhắn giáo viên có nút xóa toàn bộ cuộc hội thoại theo học sinh; vẫn xóa được khi tài khoản học sinh đã bị xóa.
2. Form Thêm/Sửa học sinh chọn trực tiếp `classKey` của lớp thật. `Chưa xếp lớp` chỉ là trạng thái hồ sơ, không tạo `student_enrollments`; enrollment giả cũ được bỏ qua ở portal và được dọn khi xếp lớp thật.
3. Lịch kiểm tra có lựa chọn **Tất cả lịch kiểm tra**. Các lịch cùng ngày + cùng giờ được gom thành stack; click card trên cùng để luân phiên lịch phía sau.
4. Lịch sử nhận xét sắp xếp mới nhất → cũ nhất theo ngày nhận xét; cùng ngày dùng thời điểm tạo để phân thứ tự. Áp dụng API chi tiết GV, portal HS và nhận xét mới nhất của lớp.

Không thêm migration D1.
