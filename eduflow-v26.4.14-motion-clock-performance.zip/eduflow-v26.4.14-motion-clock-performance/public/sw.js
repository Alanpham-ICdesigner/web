/* EDUFLOW V26 service worker: Web Push + PWA badge only. No academic data is cached. */
self.addEventListener("install", function() { self.skipWaiting(); });
self.addEventListener("activate", function(event) { event.waitUntil(self.clients.claim()); });

async function updateBadge(count) {
  const value = Math.max(0, Math.min(99, Number(count) || 0));
  try {
    if (self.navigator && typeof self.navigator.setAppBadge === "function") {
      if (value > 0) await self.navigator.setAppBadge(value);
      else if (typeof self.navigator.clearAppBadge === "function") await self.navigator.clearAppBadge();
    }
  } catch {}
}

self.addEventListener("push", function(event) {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch {
    try { payload = { body: event.data ? event.data.text() : "" }; } catch { payload = {}; }
  }
  const title = String(payload.title || "PHMT MATH");
  const options = {
    body: String(payload.body || "Bạn có cập nhật mới."),
    icon: String(payload.icon || "/icons/pwa-192.png"),
    badge: "/icons/pwa-badge-96.png",
    tag: String(payload.tag || "eduflow-update"),
    renotify: false,
    requireInteraction: false,
    data: {
      url: String(payload.url || "/student"),
      category: String(payload.category || ""),
      relatedId: payload.relatedId || ""
    }
  };
  event.waitUntil(Promise.all([
    self.registration.showNotification(title, options),
    updateBadge(payload.badgeCount)
  ]));
});

self.addEventListener("notificationclick", function(event) {
  event.notification.close();
  const requested = String(event.notification.data && event.notification.data.url || "/student");
  const target = new URL(requested, self.location.origin);
  event.waitUntil((async function() {
    const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const client of windows) {
      try {
        if (new URL(client.url).origin !== target.origin) continue;
        if (typeof client.navigate === "function") await client.navigate(target.href);
        await client.focus();
        return;
      } catch {}
    }
    if (self.clients.openWindow) await self.clients.openWindow(target.href);
  })());
});

self.addEventListener("message", function(event) {
  const data = event.data || {};
  if (data.type === "SET_BADGE") event.waitUntil(updateBadge(data.count));
});
