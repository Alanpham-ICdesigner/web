# V7.3 - Báo cáo học tập

## Thay đổi

1. QR thanh toán/chuyển khoản chuyển từ cuối báo cáo lên góc phải trên cùng của phần đầu trang.
2. Mục **Buổi học bù** được đặt ngay sau phần **Điểm danh/Lịch học** và trước lịch sử cộng-trừ điểm, nhận xét giáo viên.
3. Ô **Chuyên cần** trong phần tổng quan báo cáo đổi thành **Số buổi học** và hiển thị `A / B`.
   - A: số lượt điểm danh `present` hoặc `late`; buổi học bù đã điểm danh với hai trạng thái này được tính như buổi học bình thường.
   - B: tổng số lượt điểm danh đã có kết quả (`present`, `late`, `allowed`, `absent`) trong khoảng báo cáo.
   - `allowed` và `absent` là nghỉ nên không tính vào A.
   - Không tính bản ghi chưa điểm danh vào B để đúng nguyên tắc "dựa vào điểm danh".
4. Không thay đổi schema D1/API dữ liệu và không thêm migration.
