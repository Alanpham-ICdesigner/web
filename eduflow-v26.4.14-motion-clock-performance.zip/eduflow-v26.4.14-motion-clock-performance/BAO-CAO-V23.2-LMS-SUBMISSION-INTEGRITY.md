# EDUFLOW V23.2 — LMS Submission Integrity & Performance

## Mục tiêu

Chuẩn hóa cơ chế nộp bài theo mô hình LMS/Google Classroom, sửa các lỗi trạng thái bài nộp cũ và tối ưu luồng upload mà không redesign giao diện, không thay đổi dữ liệu học tập, điểm, điểm danh, pet/streak, Pomodoro hoặc các module LMS khác.

## Thay đổi chính

- Tách rõ 4 trạng thái bài nộp: `draft`, `submitted`, `graded`, `teacher_completed`.
- Học sinh phải **Thu hồi bài nộp** trước khi chỉnh sửa, sau đó có thể thêm/xóa/thay tệp và **Nộp lại**.
- Tệp đã nộp vẫn được giữ khi thu hồi; chỉ xóa/thay khi học sinh chủ động chọn.
- Giáo viên chỉ thấy và chấm bài học sinh khi trạng thái là `submitted`/`graded`.
- `teacher_completed` chỉ là trạng thái GV đánh dấu đã làm, không giả lập một bài nộp của học sinh.
- Migration 0011 chỉ chuẩn hóa các row placeholder cũ `Đã hoàn thành theo dữ liệu cũ`; không đụng bài có file/text thật hoặc bài đã chấm.
- Draft chấm bài phía GV được key riêng theo `studentId`; nhận xét/điểm của học sinh A không thể hiện sang học sinh B.
- Modal chi tiết bài tập reset roster/state khi đổi assignment để tránh dùng roster cũ.
- R2 upload nhiều tệp chạy song song; metadata nhiều tệp ghi D1 theo một insert batch.
- Sau khi R2 + D1 xác nhận lưu thành công, modal HS đóng ngay và refresh course data chạy nền.
- Bỏ một request message bị gọi trùng ở dashboard HS.
- Thêm optimistic-concurrency guard bằng `status + updated_at` cho thao tác thu hồi, nộp lại, chấm bài và thay đổi completion; request cũ nhận 409 thay vì ghi đè dữ liệu mới.
- Rollback upload chỉ xóa object R2 mới khi xác nhận D1 row đã rollback an toàn, tránh làm mất file đang được một request mới hơn tham chiếu.

## UI / Astryx / TasteSkill

Không redesign giao diện. Bốn stylesheet nền sau được giữ byte-for-byte so với V23.1.1:

- `app/astryx-taste-deep.css`
- `app/astryx-taste.css`
- `app/globals.css`
- `app/redesign.css`

## Migration

`drizzle/0011_assignment_submission_lms_flow.sql`

- Chỉ `UPDATE` các placeholder legacy đủ điều kiện.
- Không `DROP TABLE`.
- Không `TRUNCATE`.
- Không `DELETE FROM` dữ liệu bài nộp.
- Bài có multi-file trong `assignment_submission_files` được bảo vệ bằng `NOT EXISTS` guard.

## Kiểm tra cuối

- 131/131 source/regression tests PASS (không tính `rendered-html.test.mjs`, test này cần `dist/server/index.js` sau production build).
- 10/10 test riêng V23.2 PASS.
- TypeScript/TSX syntax transpile PASS cho toàn bộ file V23.2 thay đổi.
- SQLite migration simulation PASS: placeholder cũ được normalize; bài text thật, file thật, multi-file và bài graded giữ nguyên.
- Diff audit xác nhận không thay CSS Astryx/TasteSkill.

## Deploy

Giải nén vào đường dẫn ngắn trên Windows, ví dụ `C:\PHMT\v232`, sau đó chạy:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Script vẫn build/test trước, apply migration D1 và verify các bảng/index cần thiết trước khi deploy Worker mới.
