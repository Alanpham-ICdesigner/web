# EDUFLOW V26.4.9 — Focus Space Mobile Panels

## Thay đổi

- Task, Music và Notes là ba cửa sổ độc lập: có thể mở cùng lúc; cửa sổ được chạm gần nhất nổi lên trên và vẫn kéo thả độc lập.
- Mobile dọc: cửa sổ vừa mở được đặt giữa visual viewport để không nằm ngoài màn hình.
- Mobile ngang: cửa sổ vừa mở mặc định neo bên trái; Task/Music/Notes được lệch nhẹ theo trục dọc để dễ tách ra kéo.
- Nút xoay ngang: ưu tiên Fullscreen + ScreenOrientation.lock(); nếu iOS/PWA từ chối thì bật manual landscape cho riêng Focus Space, có thể bấm lại để trở về dọc.
- Spotify embed giảm chiều cao còn 190px (mobile dọc 184px, landscape 160px) để bỏ phần nền đen dư.
- Khi Focus hết giờ, Break chuyển sang trạng thái chờ và không tự chạy.
- Bấm tab Break chỉ chuyển sang Break ở trạng thái chờ; người học phải bấm `Bắt đầu nghỉ` thủ công.
- Nếu Break đã chạy rồi được tạm dừng, nút đổi thành `Tiếp tục nghỉ`.

## Kiểm thử

- Focus Space regression mới/cũ: 16/16 PASS.
- Toàn bộ source tests không cần build artifact: 246/246 PASS.
- `rendered-html.test.mjs` chưa chạy vì package source không có `dist/server/index.js` (cần build trước).
- Kiểm tra cú pháp TypeScript/TSX cho `focus-studio.tsx`, `pet-focus-companion.tsx`, `focus-timer.ts`: PASS bằng TypeScript transpile parser.

## Deploy

Không deploy Cloudflare trong quá trình cập nhật. Giữ nguyên script `cap-nhat-cloudflare.ps1` của EDUFLOW.
