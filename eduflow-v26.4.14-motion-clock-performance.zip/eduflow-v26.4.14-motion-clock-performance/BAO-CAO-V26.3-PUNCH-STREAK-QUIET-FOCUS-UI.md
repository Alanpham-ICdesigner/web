# EDUFLOW V26.3 — Punch icon, streak reminders, quiet Focus & UI audit

## Thay đổi chính
- Thay icon PWA/iOS bằng icon Punch do người dùng chọn; thêm icon 192/512/maskable và apple-touch-icon 180.
- Streak vẫn là điểm danh hằng ngày theo `Asia/Ho_Chi_Minh`.
- Reminder tự động 18:00 và 22:00 nếu học sinh chưa check-in; nội dung dùng `student_pet_profiles.pet_name`, fallback `Punch`.
- Khi Focus Pomodoro đang chạy, Web Push không-Pomodoro được đưa vào hàng đợi D1 và chỉ gửi sau khi Focus kết thúc.
- Reminder streak bị hoãn sẽ được re-check trước khi gửi; nếu học sinh đã check-in hoặc ngày đã đổi thì tự hủy.
- Nếu Focus kéo dài qua 22:00, reminder 18:00 đang chờ được loại bỏ để tránh dồn hai push cùng lúc.
- Push kết thúc Focus và kết thúc Break được cá nhân hóa theo tên pet.
- Punch đổi trạng thái trong UI theo streak: đã check-in / chờ sau 18:00 / lo lắng sau 22:00; Pomodoro vẫn có ưu tiên animation riêng.
- Audit UI: căn giữa avatar/initials, căn icon + chữ “Gửi thông báo”, đồng bộ spacing/type rhythm, đổi banner analytics xanh đậm sang surface mềm, giới hạn chiều cao và thêm scroll cho lịch sử/cảnh báo dài.

## Database
Migration mới: `drizzle/0016_quiet_focus_streak_push.sql`

Bảng `deferred_push_notifications` chỉ lưu hàng đợi push tạm thời, không thay đổi dữ liệu học tập, điểm danh, streak hoặc lịch sử Pomodoro.
