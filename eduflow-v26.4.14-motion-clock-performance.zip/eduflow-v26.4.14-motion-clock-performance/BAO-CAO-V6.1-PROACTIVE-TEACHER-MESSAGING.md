# EDUFLOW V20 - V6.1 Proactive Teacher Messaging

- Giữ nguyên V6 global notification + messaging.
- Giáo viên không còn phải chờ học sinh nhắn trước.
- Popup Tin nhắn giáo viên có 2 bộ chọn: **Môn học** và **Học sinh**.
- Danh sách học sinh lấy từ enrollment đang active, kể cả chưa có lịch sử chat.
- GV có thể gửi tin đầu tiên; API `/api/admin/messages` đã hỗ trợ POST theo `studentId + classKey` nên không cần bảng/migration D1 mới.
- Badge chưa đọc và lịch sử hội thoại cũ vẫn giữ nguyên.
- Mobile: hai bộ chọn tự xếp dọc.
