# EDUFLOW V20 — V7.6.3 Dashboard Class Scroll

Nền: V7.6.2.

## Thay đổi
- Vùng **Kết quả theo lớp** trên Tổng quan GV có chiều cao danh sách tối đa 270px.
- Khi số lớp vượt quá vùng hiển thị, chỉ danh sách lớp cuộn dọc; tiêu đề và nút **Quản lý lớp** giữ cố định.
- Card **Điểm danh hôm nay** bên phải không còn bị kéo cao theo danh sách lớp.
- Dùng scrollbar mảnh/ổn định theo hệ thống TasteSkill hiện có.
- Không thay đổi D1, API, route hoặc dữ liệu.
