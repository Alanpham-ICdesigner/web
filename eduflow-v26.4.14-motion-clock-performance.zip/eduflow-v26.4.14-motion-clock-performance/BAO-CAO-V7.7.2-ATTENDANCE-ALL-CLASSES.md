# V7.7.2 - Attendance all classes + history sort

- Fix trạng thái dropdown khi bản điểm danh mới nhất thuộc lớp cũ/đã xóa/`Chưa xếp lớp`.
- `Tất cả lớp` hiển thị toàn bộ học sinh đang quản lý và giữ tên lớp cạnh từng học sinh.
- Lịch sử `Tất cả lớp` hiển thị rõ ngày, tên lớp, giờ học.
- Sort lịch sử mới nhất -> cũ nhất; cùng ngày giờ muộn hơn đứng trước.
- Hỗ trợ dữ liệu ngày legacy `dd/mm/yyyy` khi sort.
- Không thay đổi schema D1 / migration.
