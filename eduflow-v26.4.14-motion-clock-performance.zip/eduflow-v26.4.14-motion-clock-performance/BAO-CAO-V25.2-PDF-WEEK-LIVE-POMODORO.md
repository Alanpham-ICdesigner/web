# EDUFLOW V25.2

## Kết quả

- Trình xem PDF dùng chung ở web giáo viên và học sinh đã được nâng cấp theo bố cục Google Drive.
- Thanh công cụ gồm danh sách trang, nhập số trang, chuyển trang, tỷ lệ zoom, vừa chiều rộng, vừa trang, toàn màn hình và tải xuống.
- Cột thumbnail tải lười theo vùng nhìn để tránh dựng toàn bộ PDF dài ngay khi mở.
- Trên điện thoại, thumbnail mặc định đóng và có thể mở bằng nút trên thanh công cụ.
- Chế độ thống kê Tuần hiển thị rõ khoảng `từ ngày ... đến ngày ...` dựa trên đúng dữ liệu API.
- Chế độ Ngày thêm duy nhất cột `Pomodoro hiện tại`; các cột cũ giữ nguyên.
- Bộ đếm của học sinh đang Focus/Break giảm từng giây trên màn hình giáo viên và đồng bộ server mỗi 10 giây.
- Khi học sinh dừng sớm, timer trở về không hoạt động và không tạo lịch sử phiên hoàn tất.
- Không phát sinh migration D1 ở phiên bản này.

## Kiểm tra

- 152/152 kiểm thử mã nguồn chạy độc lập đã đạt.
- Kiểm thử mới bao phủ trình PDF dùng chung, khoảng ngày theo tuần và Pomodoro trực tiếp.
- Kiểm thử render build cần thư mục `dist`; môi trường đóng gói không tải được dependency từ registry, còn script triển khai trên máy người dùng vẫn tự cài, build, kiểm tra artifact rồi mới deploy.
