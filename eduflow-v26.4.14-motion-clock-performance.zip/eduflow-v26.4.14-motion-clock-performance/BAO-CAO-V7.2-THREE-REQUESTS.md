# EDUFLOW V20 — V7.2

Bản này được phát triển trực tiếp trên V7.1 và giữ nguyên toàn bộ chức năng trước đó.

## Thay đổi

1. Trang học sinh có hai tab cấp tài khoản: **Các môn học của tôi** và **Lịch học**. Tab Lịch học tổng hợp lịch định kỳ + học bù của tất cả môn học sinh đang tham gia.
2. Lịch GV và lịch HS được làm gọn theo TasteSkill. Khung giờ tự co theo lịch thực tế. Khi các lớp trùng giờ, card được xếp chồng có mép nhận biết; click/tap card nào thì card đó nổi lên trên.
3. Badge học bù trên card môn chỉ còn khi buổi học bù chưa có dữ liệu điểm danh của học sinh. Sau khi GV đã điểm danh buổi bù, badge tự mất khi dữ liệu refresh.
4. Nộp bài tập không còn kích hoạt quy tắc `assignment_streak`, không tạo `pointTransactions`, không gửi thông báo cộng điểm. Nộp bài chỉ cập nhật submission/progress.

Không thêm migration D1, không reset database, không thay R2.
