# EDUFLOW V26.2.5 — Focus Adjustment History + Smart Alert Order

## 1. Lịch sử bổ sung Pomodoro ngoài web

Mỗi lần giáo viên thay đổi thời gian học ngoài EDUFLOW sẽ tạo một bản ghi audit mới trong `student_focus_adjustment_history`.

Lịch sử hiển thị ngay dưới form “Bổ sung Pomodoro theo ngày” gồm:

- Ngày học được điều chỉnh.
- Học sinh và mã học sinh/lớp.
- Phần thay đổi so với lần lưu trước (`+` hoặc `−`).
- Tổng thời gian ngoài web sau lần lưu.
- Tổng Pomodoro của ngày sau điều chỉnh và phần web ghi nhận.
- Ghi chú.
- Thời điểm cập nhật theo Asia/Ho_Chi_Minh.

Bảng `student_focus_adjustments` vẫn là nguồn tổng theo ngày để tính Ngày/Tuần/Tháng. Bảng history chỉ dùng truy vết, không tạo `student_focus_sessions` và không làm tăng số phiên.

Migration `0015_focus_adjustment_history.sql` cũng backfill các manual adjustment đã tồn tại trước V26.2.5 thành một record nền, tránh trường hợp dữ liệu cũ không xuất hiện trong lịch sử.

## 2. Notification / Web Push

Khi số phút thay đổi, thông báo học sinh giữ nguyên logic cũ và thêm nội dung ghi chú nếu giáo viên có nhập.

## 3. Thứ tự trang Thống kê

Card **Cảnh báo thông minh** được chuyển lên trước card **Điểm danh streak & Pomodoro**, đúng ưu tiên xử lý cảnh báo trước khi xem thống kê chi tiết.

## 4. UI

- Giữ design language hiện tại từ Astryx + TasteSkill.
- Desktop dùng audit table compact.
- Mobile chuyển history thành các card/grid hai cột, không bắt buộc kéo ngang.
- Không thay đổi route, màu chủ đạo, font hoặc logic học tập khác.
