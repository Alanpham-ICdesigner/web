# EDUFLOW V26.0.0 — Web Push + PWA

## Nền tảng

Bản này được phát triển trực tiếp từ `EDUFLOW V25.3.3`, giữ nguyên LMS, PDF viewer, nộp bài, điểm danh, D1, R2 và workflow Cloudflare hiện tại. UI mới chỉ bổ sung phần Web Push/PWA và tiếp tục dùng hệ token/layout/motion Astryx + TasteSkill.

## Web Push/PWA

- `public/manifest.webmanifest`: standalone PWA cho khu vực học sinh.
- `public/sw.js`: nhận Web Push, hiển thị notification, badge và deep-link; không intercept/cache API hay dữ liệu học tập.
- `app/student/push-notification-settings.tsx`: giao diện bật/tắt Web Push với trạng thái `Đã bật`, `Chưa bật`, `Bị trình duyệt chặn` và hướng dẫn Add to Home Screen trên iPhone/iPad.
- `app/api/student/push/route.ts`: đăng ký/tắt Push Subscription của tài khoản học sinh hiện tại.
- `lib/web-push.ts`: VAPID + aes128gcm Web Push, badge unread, dedupe theo event/subscription.

### Sự kiện đã nối Push

1. Giáo viên gửi thông báo.
2. Bài tập mới.
3. Lịch kiểm tra mới.
4. Điểm hoặc nhận xét bài tập mới.
5. Cập nhật sổ điểm có thay đổi điểm thực tế.
6. Tin nhắn mới từ giáo viên.
7. Pomodoro Focus hoàn thành.

Notification mở đúng khu vực bằng deep-link: thông báo, tin nhắn, lịch, bài tập, tiến độ hoặc Pomodoro.

## Pomodoro server-authoritative

`student_focus_timer_state` tiếp tục chỉ có một dòng cho mỗi `student_id`; V26 bổ sung `duration_ms` và `session_id`. API trả `startedAt`, `duration`, `endsAt`, `status`, `sessionId`, `userId`, `revision`. Mutation dùng revision compare-and-swap để thiết bị thứ hai không tạo state độc lập hoặc ghi đè state mới hơn.

Cloudflare Cron chạy mỗi phút chỉ để reconcile timer đã hết hạn. Mỗi completion có `event_key = pomodoro:<session>` và delivery được claim bằng unique index trước khi gửi, vì vậy không thể gửi lại mỗi phút. Chỉ các completion gần thời điểm hiện tại được xét để tránh notification Pomodoro cũ xuất hiện sau khi người dùng vừa bật lại Push.

## D1 migration

`drizzle/0013_web_push_pwa_v26.sql` chỉ bổ sung:

- `push_subscriptions`
- `push_deliveries`
- `student_focus_timer_state.duration_ms`
- `student_focus_timer_state.session_id`

Không có `DROP TABLE` hoặc xóa dữ liệu học tập.

## Shared-device safety

Khi học sinh đăng xuất, endpoint hiện tại được tắt ở server trước khi session bị xóa. Browser subscription không bị xóa, nên nếu đăng nhập lại và quyền Notification vẫn `granted`, EDUFLOW tự bind endpoint đó sang tài khoản đang đăng nhập mà không hiện popup xin quyền tự động. Việc này tránh thiết bị dùng chung tiếp tục nhận push của tài khoản cũ.

## Deploy

Chạy workflow cũ:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```

Ở lần deploy V26 đầu tiên, script kiểm tra Cloudflare Worker secrets. Nếu chưa có VAPID, script tạo P-256 key pair và lưu `VAPID_PUBLIC_KEY` + `VAPID_PRIVATE_JWK` vào Cloudflare secrets. Các lần sau key được giữ nguyên để subscription cũ không mất hiệu lực.

## Kiểm thử trong môi trường tạo source

- 179/179 source regression tests (loại test cần `dist`) pass.
- 16/16 test riêng V26 pass.
- 65 file `.ts/.tsx` được transpile syntax-check: 0 lỗi cú pháp.
- Migration 0013 được chạy mô phỏng trên SQLite với timer V23 hiện hữu: tạo đủ bảng/index, backfill `duration_ms` và `session_id` đúng.
- `public/sw.js` và `scripts/generate-vapid.mjs` qua `node --check`.
- VAPID generator tạo public key P-256 đúng định dạng 65-byte uncompressed/base64url.

Build Vinext cuối cùng chưa thể chạy trong môi trường tạo ZIP vì DNS tại runtime không resolve được `registry.npmjs.org`, nên `npm ci` dừng trước khi cài dependency. Workflow deploy Windows vẫn tự chạy `npm ci -> vinext build -> tests -> D1 migration -> deploy`; nếu build/test fail thì script dừng trước khi thay Worker.

## Giới hạn iOS

Đây là Web Push/PWA, không phải app native. Trên iPhone/iPad, Web Push yêu cầu web app được Add to Home Screen và quyền notification do người dùng cấp từ thao tác trực tiếp. Khả năng hiển thị Lock Screen/Notification Center/badge phụ thuộc phiên bản iOS và cài đặt hệ thống. Không có Live Activity/Dynamic Island trong V26.
