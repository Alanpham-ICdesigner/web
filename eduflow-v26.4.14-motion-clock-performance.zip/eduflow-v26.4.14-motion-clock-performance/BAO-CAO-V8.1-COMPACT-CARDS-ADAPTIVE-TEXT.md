# EDUFLOW V8.1 — Compact cards & adaptive text

## Thay đổi giao diện

1. **Trang học sinh / Các môn học của tôi**
   - Bỏ kiểu `featured` làm môn đầu tiên và trường hợp chỉ có 1 môn chiếm gần toàn bộ chiều ngang.
   - Từ 821px trở lên, các card môn học dùng cùng độ rộng 1/2 grid.
   - Ảnh/cover của môn đầu tiên không còn bị kéo cao theo toàn card.
   - Mobile vẫn tự collapse về 1 cột.

2. **Trang giáo viên / Lớp học**
   - Bỏ nhịp card xen kẽ 7/12, 5/12, 12/12.
   - Tất cả card lớp dùng cùng độ rộng 6/12 trên desktop/tablet, nên card không còn cái dài ngang cái ngắn.
   - Mobile giữ bố cục 1 cột hiện có.

3. **Dòng mô tả ở Quản lý học sinh**
   - Bỏ giới hạn `70ch` gây xuống dòng sớm.
   - Text được phép dùng toàn bộ chiều ngang còn trống của PageTitle.
   - Cơ chế wrap dựa vào kích thước thực tế của container: đủ chỗ thì giữ 1 dòng, thiếu chỗ mới xuống dòng.

4. **Câu nói ở trang đăng nhập**
   - Bỏ giới hạn cứng `620px`.
   - Câu ngắn/vừa sẽ giữ 1 dòng nếu đủ chỗ; câu dài mới tự xuống dòng theo chiều rộng thực tế.

## Phạm vi an toàn

Chỉ thay đổi CSS presentation. Không thay đổi API, dữ liệu, D1, R2, route, login, điểm danh, điểm số, lớp học, học sinh, bài tập hoặc logic nghiệp vụ.
