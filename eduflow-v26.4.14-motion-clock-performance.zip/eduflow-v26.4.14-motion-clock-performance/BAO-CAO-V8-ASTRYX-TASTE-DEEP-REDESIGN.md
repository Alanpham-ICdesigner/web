# EDUFLOW V8 - Astryx x TasteSkill deep redesign

## Phạm vi

Redesign toàn bộ lớp giao diện dùng chung cho web giáo viên và học sinh. Không thay đổi route, API, cấu trúc dữ liệu D1, R2, migration, phân quyền hay logic nghiệp vụ.

## Hướng thiết kế

- Design read: ứng dụng EdTech dùng hằng ngày, ưu tiên tốc độ thao tác và khả năng đọc dữ liệu.
- Dials: variance 6, motion 4, density 6.
- Hệ bo góc: control 12px, card 18px, dialog 22px, pill chỉ dành cho trạng thái.
- Bảng màu: cool-neutral, giữ màu indigo nhận diện của PHMT MATH; màu xanh, vàng, đỏ chỉ dùng cho trạng thái có ý nghĩa.
- Motion chỉ dùng để làm rõ thứ bậc khi mở trang và phản hồi thao tác; có hỗ trợ reduced-motion.

## Thay đổi giao diện chính

- Sidebar giáo viên chuyển thành khối nổi có chiều sâu, trạng thái active rõ, vẫn giữ thu gọn và kéo đổi thứ tự.
- Topbar giáo viên và học sinh chuyển thành thanh nổi, hỗ trợ nền đặc khi người dùng giảm transparency.
- Dashboard dùng scorecard bất đối xứng 6 cột, hai chỉ số chính được nhấn mạnh; các panel phía dưới có nhịp 2-1-1.
- Card lớp và môn học dùng mixed-width grid; card nổi bật có bố cục ngang thay vì lặp lại ba card giống nhau.
- Bảng, sổ điểm, điểm danh, bài tập và popup dùng cùng token, hierarchy và focus state.
- Trang học sinh có hero học tập mới, tab nổi, course card đa nhịp, trang môn học và tiến độ đồng bộ.
- Trang đăng nhập đổi sâu về bố cục, typography và material; bỏ glow trang trí cũ.
- Mobile collapse rõ ràng tại 1260px, 1050px, 820px và 560px; không thay đổi nội dung hay thao tác.

## Nguồn thiết kế tham khảo

- Astryx: AppShell, SideNav, Layout, responsive Grid, semantic tokens, component-family consistency.
- TasteSkill: audit-first, no generic three-card rows, motion có mục đích, reduced-motion, theme và shape consistency.
- Radix Themes và shadcn/ui: token bằng CSS variables, segmented tabs, sidebar inset, focus state và responsive data surface.

## Deploy

Giữ nguyên quy trình:

```powershell
powershell -ExecutionPolicy Bypass -File ".\cap-nhat-cloudflare.ps1"
```
