# EDUFLOW V26.4.10 — Focus Space viewport fix

## Sửa lỗi
- Trạng thái `Focus / Break`: tab đang chọn dùng nền tím rõ, kể cả trên mobile khi control đang disabled bởi trạng thái timer.
- Spotify Embed: giảm iframe compact từ 190px xuống 152px, loại bỏ phần nền đen dư bên dưới player.
- Xoay ngang iOS/PWA: fallback không còn dựa hoàn toàn vào `100dvh/100dvw`; Focus Space đọc kích thước `visualViewport` thật và xoay quanh tâm viewport để phủ kín khung hiển thị.
- Giữ nguyên cơ chế Break thủ công của V26.4.9: chuyển sang Break chỉ chuẩn bị thời gian nghỉ; người dùng phải bấm `Bắt đầu nghỉ`.

## Không thay đổi
- Task / Music / Notes vẫn có thể mở đồng thời và kéo độc lập.
- Desktop Fullscreen API, Dark Mode, Digital/Flip Clock, D1 task sync và timer cross-device giữ nguyên.
