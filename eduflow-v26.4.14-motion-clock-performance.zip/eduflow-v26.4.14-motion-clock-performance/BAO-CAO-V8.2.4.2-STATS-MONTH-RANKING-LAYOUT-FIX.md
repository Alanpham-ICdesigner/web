# EDUFLOW V8.2.4.2

- Sửa toolbar thống kê để không còn đè control: date-nav có lane cố định, `Hôm nay/Tháng này` không dùng `.button.soft` toàn cục.
- Bỏ icon lịch custom cạnh input; giữ native date/month picker của trình duyệt.
- Bỏ ngày in đậm lặp lại bên dưới toolbar; chỉ giữ ngày/tháng trong picker và số học sinh ở dòng meta.
- Thêm chế độ **Tháng** cạnh Ngày/Tuần, dùng tháng dương lịch và chặn ngày tương lai.
- Ngày: summary thứ ba là **Check-in sớm nhất** (tên + giờ Việt Nam).
- Tuần/Tháng: summary thứ ba là **Streak cao nhất** (tên + số ngày).
- Pomodoro: summary hiển thị **học sinh có tổng phút cao nhất** trong kỳ (tên + phút).
- Recheck motion theo TasteSkill: 200–300ms token hiện có, chỉ transform/background/opacity-like properties, active scale .98, focus-visible, reduced-motion.
- Không thêm migration; dùng `checked_at` đã tồn tại và các index date-first V8.2.4.
